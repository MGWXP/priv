#!/bin/bash
# mcp-server-installer.sh - Installs official MCP server packages
# For M3 Max (48GB unified memory) hardware

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

echo -e "${BLUE}=== Installing Official MCP Servers ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e "Hardware Target: M3 Max (48GB unified memory)"

# Install official MCP server packages
echo -e "${BLUE}Installing official MCP server packages...${NC}"

# Install Filesystem MCP Server
echo -e "${YELLOW}Installing @modelcontextprotocol/server-filesystem...${NC}"
npm install -g @modelcontextprotocol/server-filesystem
echo -e "${GREEN}✓ @modelcontextprotocol/server-filesystem installed${NC}"

# Install GitHub MCP Server
echo -e "${YELLOW}Installing github-mcp-server...${NC}"
npm install -g github-mcp-server
echo -e "${GREEN}✓ github-mcp-server installed${NC}"

# Install Notion MCP Server
echo -e "${YELLOW}Installing @notionhq/notion-mcp-server...${NC}"
npm install -g @notionhq/notion-mcp-server
echo -e "${GREEN}✓ @notionhq/notion-mcp-server installed${NC}"

# Install Slack MCP Server
echo -e "${YELLOW}Installing @modelcontextprotocol/server-slack...${NC}"
npm install -g @modelcontextprotocol/server-slack
echo -e "${GREEN}✓ @modelcontextprotocol/server-slack installed${NC}"

echo -e "\n${GREEN}✓ Installation complete!${NC}"
echo -e "${YELLOW}Please restart Claude Desktop to apply the changes.${NC}"
echo -e "${YELLOW}Remember to add your API keys for Notion and Slack in the environment variables.${NC}"
echo -e "Configuration file: ${HOME}/Library/Application Support/Claude/claude_desktop_config.json"
