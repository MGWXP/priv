# MCP Credentials Manager

## Overview

The MCP Credentials Manager is a comprehensive solution for managing your Model Context Protocol (MCP) server credentials. It provides both a graphical user interface and command-line tools to securely store and manage your credentials for GitHub, Notion, Slack, and other MCP servers that integrate with Claude Desktop.

## Features

- **Secure Encryption**: All credentials are encrypted with AES-256 using a master password
- **Graphical User Interface**: Easy-to-use UI for managing all your MCP credentials
- **Command-Line Interface**: Terminal-based tools for automation and scripting
- **Automatic Claude Config Updates**: Seamlessly updates your Claude Desktop configuration
- **Connection Testing**: Tools to verify MCP server connections and troubleshoot issues
- **Quick GitHub Token Updates**: Fast way to update just your GitHub token

## Installation

The MCP Credentials Manager is fully integrated with your CNIF installation. To get started:

1. Run the setup script to make all components executable:
   ```bash
   cd /Users/XPV/Desktop/anchor-core
   chmod +x make-mcp-credential-scripts-executable.sh
   ./make-mcp-credential-scripts-executable.sh
   ```

2. Launch the credential management interface:
   ```bash
   ./mcp-credential-management.sh
   ```

## Usage

### Graphical User Interface

The GUI provides a comprehensive interface for managing all your MCP credentials:

1. Run the UI launcher:
   ```bash
   ./launch-mcp-credentials-ui.sh
   ```

2. Enter your master password to encrypt/decrypt credentials
3. Configure your credentials for each MCP server
4. Save and update your Claude Desktop config
5. Restart Claude Desktop to apply changes

### Command-Line Interface

The CLI provides similar functionality through a terminal interface:

1. Run the CLI:
   ```bash
   ./mcp-credentials-manager.sh
   ```

2. Follow the prompts to enter your master password and credentials
3. The tool will automatically update your Claude Desktop config

### Quick GitHub Token Update

For a fast way to update just your GitHub token:

1. Run the GitHub token updater:
   ```bash
   ./github-token-updater.sh
   ```

2. Enter your GitHub Personal Access Token
3. The tool will update your Claude Desktop config
4. Restart Claude Desktop when prompted

### Testing MCP Connections

To verify that your MCP servers are properly connected:

1. Run the connection test script:
   ```bash
   ./test-mcp-connections.sh
   ```

2. The script will check each configured MCP server
3. It will provide troubleshooting tips for any connection issues

## Directory Structure

- `/Users/XPV/Desktop/anchor-core/utils/` - Core implementation files
- `/Users/XPV/Desktop/anchor-core/data/secure-credentials/` - Encrypted credential storage
- `/Users/XPV/Library/Application Support/Claude/` - Claude Desktop configuration
- `/Users/XPV/Desktop/anchor-core/logs/` - Log files for troubleshooting

## Security

- Credentials are encrypted with AES-256-CBC encryption
- A unique salt is used for key derivation
- The master password never leaves your system
- Encryption/decryption happens locally

## Troubleshooting

If you encounter issues with MCP servers:

1. Run the connection test script to identify problems:
   ```bash
   ./test-mcp-connections.sh
   ```

2. Check the log files for detailed error messages:
   ```bash
   tail -n 50 "/Users/XPV/Desktop/anchor-core/logs/mcp-credentials-manager.log"
   ```

3. Verify that your credentials are correct and have the necessary permissions

4. Try updating your credentials using the MCP Credentials Manager

## Integration with CNIF

The MCP Credentials Manager is fully integrated with the Claude-Notion Integration Framework (CNIF). You can access it through the main CNIF launcher menu or run it directly as described above.
