#!/usr/bin/env node
/**
 * socket-manager.js - Enhanced Unix Socket Manager for Anchor System V6
 * Implements comprehensive lifecycle management for Unix domain sockets
 * © 2025 XPV - MIT
 */

const fs = require('fs').promises;
const fsSync = require('fs');
const net = require('net');
const path = require('path');

/**
 * SocketManager handles all aspects of Unix domain socket lifecycle
 * - Creation with proper directory structure
 * - Permission setting after creation
 * - Connection validation
 * - Cleanup on process termination
 */
class SocketManager {
  /**
   * Create a new SocketManager
   * @param {string} socketPath - Path to the socket file
   * @param {object} options - Options for socket management
   */
  constructor(socketPath, options = {}) {
    this.socketPath = socketPath;
    this.options = {
      mode: 0o666,            // rw-rw-rw- permissions
      dirMode: 0o755,         // rwxr-xr-x for directory
      backlog: 511,           // Connection backlog
      keepAlive: true,        // Enable keepalive
      keepAliveInterval: 1000, // 1 second interval
      retryAttempts: 5,       // Number of retry attempts for recovery
      retryDelay: 500,        // Initial delay between retries (ms)
      ...options
    };
    this.server = null;
    this.isListening = false;
    this.logger = options.logger || console;
    
    // Setup cleanup handlers for proper socket lifecycle
    this._setupCleanup();
  }

  /**
   * Initialize the socket environment
   * - Checks for stale socket files
   * - Ensures directory structure exists
   * - Prepares for socket creation
   */
  async initialize() {
    try {
      // Check if socket directory exists, create if not
      const socketDir = path.dirname(this.socketPath);
      await this._ensureDirectory(socketDir, this.options.dirMode);
      
      // Check if socket file already exists, handle accordingly
      if (await this._exists(this.socketPath)) {
        // Test if socket is actively in use
        const isActive = await this._testSocketConnection();
        if (isActive) {
          this.logger.error(`Socket ${this.socketPath} is already in use`);
          return null;
        } else {
          // Socket is stale, remove it
          await fs.unlink(this.socketPath);
          this.logger.info(`Removed stale socket at ${this.socketPath}`);
        }
      }
      
      return this; // Return self for chaining
    } catch (err) {
      this.logger.error(`Initialization error: ${err.message}`);
      throw err;
    }
  }

  /**
   * Create a server with socket manager integration
   * @param {function} connectionHandler - Handler for new connections
   * @returns {net.Server} - The created server
   */
  createServer(connectionHandler) {
    this.server = net.createServer(connectionHandler);
    
    // Configure server options
    if (this.options.keepAlive) {
      this.server.on('connection', (socket) => {
        socket.setKeepAlive(true, this.options.keepAliveInterval);
      });
    }
    
    return this.server;
  }

  /**
   * Start listening on the socket
   * @returns {Promise<net.Server>} - Server instance
   */
  async listen() {
    if (!this.server) {
      throw new Error('Server not created. Call createServer() first');
    }

    // Set proper umask before creating socket to ensure correct permissions
    const oldUmask = process.umask(0o000);
    
    return new Promise((resolve, reject) => {
      this.server.listen(this.socketPath, this.options.backlog, () => {
        // Reset umask
        process.umask(oldUmask);
        
        // Set explicit permissions on socket file
        try {
          fsSync.chmodSync(this.socketPath, this.options.mode);
          this.isListening = true;
          this.logger.info(`Server listening on socket: ${this.socketPath}`);
          this.logger.info(`Socket permissions set to: 0${this.options.mode.toString(8)}`);
          resolve(this.server);
        } catch (err) {
          this.logger.error(`Failed to set socket permissions: ${err.message}`);
          reject(err);
        }
      });
      
      this.server.on('error', (err) => {
        process.umask(oldUmask); // Reset umask on error
        reject(err);
      });
    });
  }

  /**
   * Close the server and clean up the socket
   * @returns {Promise<void>}
   */
  async close() {
    return new Promise((resolve) => {
      if (this.server && this.isListening) {
        this.server.close(() => {
          this._cleanupSocket()
            .then(() => {
              this.isListening = false;
              this.logger.info(`Socket server closed and cleaned up: ${this.socketPath}`);
              resolve();
            })
            .catch((err) => {
              this.logger.error(`Error during socket cleanup: ${err.message}`);
              resolve(); // Resolve anyway to not block shutdown
            });
        });
      } else {
        this._cleanupSocket()
          .then(() => {
            resolve();
          })
          .catch((err) => {
            this.logger.error(`Error during socket cleanup: ${err.message}`);
            resolve(); // Resolve anyway to not block shutdown
          });
      }
    });
  }

  /**
   * Test if a socket is actively in use
   * @returns {Promise<boolean>} - True if socket is active
   */
  async _testSocketConnection() {
    return new Promise((resolve) => {
      let resolved = false;
      const testSocket = net.connect(this.socketPath);
      
      testSocket.on('error', () => {
        if (!resolved) {
          resolved = true;
          resolve(false); // Socket error = stale or not in use
        }
      });
      
      testSocket.on('connect', () => {
        testSocket.end();
        if (!resolved) {
          resolved = true;
          resolve(true); // Connection successful = socket in use
        }
      });
      
      // Set timeout to avoid hanging
      setTimeout(() => {
        testSocket.destroy();
        if (!resolved) {
          resolved = true;
          resolve(false); // Timeout = assume stale
        }
      }, 1000);
    });
  }

  /**
   * Set up cleanup handlers for proper socket lifecycle
   * @private
   */
  _setupCleanup() {
    // Process termination cleanup
    const cleanup = () => {
      if (this.server) {
        this.server.close();
      }
      
      // Synchronous cleanup for exit handlers
      if (fsSync.existsSync(this.socketPath)) {
        try {
          fsSync.unlinkSync(this.socketPath);
          console.log(`Socket file ${this.socketPath} cleaned up`);
        } catch (err) {
          console.error(`Failed to clean up socket: ${err.message}`);
        }
      }
    };
    
    // Handle various termination signals
    process.on('exit', cleanup);
    process.on('SIGINT', () => {
      cleanup();
      process.exit(0);
    });
    process.on('SIGTERM', () => {
      cleanup();
      process.exit(0);
    });
    
    // Handle uncaught exceptions to ensure socket cleanup
    process.on('uncaughtException', (err) => {
      console.error(`Uncaught exception: ${err.message}`);
      cleanup();
      process.exit(1);
    });
  }

  /**
   * Check if a path exists
   * @param {string} filePath - Path to check
   * @returns {Promise<boolean>} - True if exists
   * @private
   */
  async _exists(filePath) {
    try {
      await fs.access(filePath);
      return true;
    } catch (err) {
      return false;
    }
  }

  /**
   * Ensure a directory exists with proper permissions
   * @param {string} dirPath - Directory path
   * @param {number} mode - Directory permissions
   * @returns {Promise<void>}
   * @private
   */
  async _ensureDirectory(dirPath, mode) {
    try {
      await fs.mkdir(dirPath, { recursive: true, mode });
      this.logger.info(`Created directory: ${dirPath}`);
    } catch (err) {
      // Ignore if directory already exists
      if (err.code !== 'EEXIST') {
        throw err;
      }
    }
  }

  /**
   * Clean up the socket file
   * @returns {Promise<void>}
   * @private
   */
  async _cleanupSocket() {
    if (await this._exists(this.socketPath)) {
      await fs.unlink(this.socketPath);
      this.logger.info(`Socket file removed: ${this.socketPath}`);
    }
  }
}

module.exports = SocketManager;
