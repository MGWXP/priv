#!/bin/bash
# make-new-scripts-executable.sh - Makes all new scripts executable for Anchor system
# For M3 Max (48GB unified memory) hardware

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

echo -e "${BLUE}=== Making New Scripts Executable ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e ""

# Make all the new scripts executable
chmod +x /Users/XPV/Desktop/anchor-core/create-system-metrics-db.sh
chmod +x /Users/XPV/Desktop/anchor-core/create-documentation-db.sh
chmod +x /Users/XPV/Desktop/anchor-core/create-meeting-notes-db.sh
chmod +x /Users/XPV/Desktop/anchor-core/setup-dashboard-views.sh
chmod +x /Users/XPV/Desktop/anchor-core/configure-slack-integration.sh
chmod +x /Users/XPV/Desktop/anchor-core/create-remaining-databases.sh
chmod +x /Users/XPV/Desktop/anchor-core/update-anchor-setup.sh

echo -e "${GREEN}✓ All new scripts are now executable!${NC}"
echo -e "${YELLOW}Run ./update-anchor-setup.sh to update the main setup script with new options.${NC}"
echo -e "${YELLOW}Then run ./complete-anchor-setup.sh to continue setting up your Anchor workspace.${NC}"
