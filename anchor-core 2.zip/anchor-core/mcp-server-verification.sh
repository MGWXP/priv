#!/bin/bash
# mcp-server-verification.sh - Verifies and installs MCP server packages
# Generated for M3 Max (48GB unified memory) optimization

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

echo -e "${BLUE}=== MCP Server Verification and Installation ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e "Hardware Target: M3 Max (48GB unified memory)"

# Check and install required packages
echo -e "${BLUE}Checking MCP server packages...${NC}"

# Check for @modelcontextprotocol/server-filesystem
if npm list -g @modelcontextprotocol/server-filesystem >/dev/null 2>&1; then
    echo -e "${GREEN}✓ @modelcontextprotocol/server-filesystem is installed${NC}"
else
    echo -e "${YELLOW}Installing @modelcontextprotocol/server-filesystem...${NC}"
    npm install -g @modelcontextprotocol/server-filesystem
    echo -e "${GREEN}✓ @modelcontextprotocol/server-filesystem installed${NC}"
fi

# Check for @modelcontextprotocol/server-git
if npm list -g @modelcontextprotocol/server-git >/dev/null 2>&1; then
    echo -e "${GREEN}✓ @modelcontextprotocol/server-git is installed${NC}"
else
    echo -e "${YELLOW}Installing @modelcontextprotocol/server-git...${NC}"
    npm install -g @modelcontextprotocol/server-git
    echo -e "${GREEN}✓ @modelcontextprotocol/server-git installed${NC}"
fi

# Check for notion-mcp-server
if npm list -g notion-mcp-server >/dev/null 2>&1; then
    echo -e "${GREEN}✓ notion-mcp-server is installed${NC}"
else
    echo -e "${YELLOW}Installing notion-mcp-server...${NC}"
    npm install -g notion-mcp-server
    echo -e "${GREEN}✓ notion-mcp-server installed${NC}"
fi

# Check for @slack/mcp-server
if npm list -g @slack/mcp-server >/dev/null 2>&1; then
    echo -e "${GREEN}✓ @slack/mcp-server is installed${NC}"
else
    echo -e "${YELLOW}Installing @slack/mcp-server...${NC}"
    npm install -g @slack/mcp-server
    echo -e "${GREEN}✓ @slack/mcp-server installed${NC}"
fi

echo -e "\n${GREEN}✓ Verification complete!${NC}"
echo -e "${YELLOW}Please restart Claude Desktop to apply the changes.${NC}"
echo -e "Configuration file: ${HOME}/Library/Application Support/Claude/claude_desktop_config.json"
