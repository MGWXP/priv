#!/bin/bash
# cnif-quick-start.sh - Quick start guide for CNIF system
# © 2025 XPV - MIT

cat << EOF
╔════════════════════════════════════════════════════════════════╗
║              CNIF Quick Start Guide                            ║
╚════════════════════════════════════════════════════════════════╝

The Claude-Notion Integration Framework (CNIF) provides bidirectional 
communication between Claude and Notion using Model Context Protocol.

IMPORTANT COMMANDS:

1. START SYSTEM (BASIC):
   /Users/XPV/Desktop/anchor-core/simple-launcher.sh

2. START SYSTEM (ADVANCED):
   /Users/XPV/Desktop/anchor-core/sequenced-launcher.sh

3. START SYSTEM (OPTIMIZED FOR M3 MAX):
   /Users/XPV/Desktop/anchor-core/m3-optimized-launcher.sh

4. STOP SYSTEM:
   /Users/XPV/Desktop/anchor-core/sequenced-launcher.sh stop

5. CHECK SYSTEM STATUS:
   /Users/XPV/Desktop/anchor-core/cnif-system-check.sh

6. RUN INTEGRATION TESTS:
   /Users/XPV/Desktop/anchor-core/cnif-integration-test.sh

7. FIX SOCKET PERMISSIONS:
   /Users/XPV/Desktop/anchor-core/fix-socket-permissions.sh

8. OPTIMIZE FOR M3 MAX:
   /Users/XPV/Desktop/anchor-core/run-cnif-optimizer.sh

LOGS: ~/Library/Logs/Claude/
DOCS: /Users/XPV/Desktop/anchor-core/CNIF_SYSTEM_DOCUMENTATION.md

EOF

# Make all scripts executable
echo "Making all CNIF scripts executable..."
chmod +x /Users/XPV/Desktop/anchor-core/*.sh

echo "✅ CNIF Quick Start Guide complete"
