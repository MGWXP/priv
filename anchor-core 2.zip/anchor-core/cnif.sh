#!/bin/bash
# cnif.sh - CNIF master control script
# © 2025 XPV - MIT
#
# This script provides a single command for managing all CNIF operations.

ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"

# Display help
display_help() {
  cat << EOF
CNIF - Claude-Notion Integration Framework

Usage: ./cnif.sh COMMAND

Commands:
  start       Start CNIF system (recommended)
  stop        Stop all CNIF services
  status      Check system status
  fix         Run complete fix script
  logs        Show system logs
  help        Show this help message

Examples:
  ./cnif.sh start
  ./cnif.sh status
  ./cnif.sh logs
EOF
}

# Check argument
if [ $# -lt 1 ]; then
  display_help
  exit 1
fi

# Process command
case "$1" in
  start)
    echo "Starting CNIF..."
    "${ANCHOR_HOME}/cnif-complete-fix.sh"
    ;;
  stop)
    echo "Stopping CNIF services..."
    pkill -f "node ${ANCHOR_HOME}/mcp-servers" || true
    echo "All services stopped"
    ;;
  status)
    echo "CNIF System Status:"
    echo "===================="
    echo "Running processes:"
    ps aux | grep "node ${ANCHOR_HOME}/mcp-servers" | grep -v grep
    echo
    echo "Socket files:"
    ls -la "${ANCHOR_HOME}/sockets/"
    ;;
  fix)
    echo "Running complete fix script..."
    "${ANCHOR_HOME}/cnif-complete-fix.sh"
    ;;
  logs)
    echo "Showing system logs (press Ctrl+C to exit)..."
    tail -f "${HOME}/Library/Logs/Claude/"*.out
    ;;
  help|*)
    display_help
    ;;
esac
