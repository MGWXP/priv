#!/bin/bash
while true; do
  clear
  echo "=== Git-Local Server Log ==="
  tail -n 20 /Users/XPV/Desktop/anchor-core/git-local.log
  echo ""
  echo "=== Notion Server Log ==="
  tail -n 20 /Users/XPV/Desktop/anchor-core/notion.log
  echo ""
  echo "=== Anchor-Manager Server Log ==="
  tail -n 20 /Users/XPV/Desktop/anchor-core/anchor-manager.log
  echo ""
  echo "Press Ctrl+C to exit"
  sleep 5
done
