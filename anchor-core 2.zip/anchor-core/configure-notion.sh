#!/bin/bash
# CNIF Notion Configuration Script
# Sets up Notion API token and restarts services

echo "======================================================"
echo "  CNIF - Notion API Configuration"
echo "  Setting up Notion integration..."
echo "======================================================"

# Create Notion token directory if it doesn't exist
mkdir -p ~/.notion

# Write Notion API token to file
echo "secret_REPLACE_WITH_ACTUAL_TOKEN" > ~/.notion/token
chmod 600 ~/.notion/token

echo "✅ Notion API token configured successfully"

# Stop current processes
echo "Stopping current processes..."
if [ -f "/Users/XPV/Desktop/anchor-core/webbridge.pid" ]; then
  kill $(cat /Users/XPV/Desktop/anchor-core/webbridge.pid) 2>/dev/null || true
  rm -f /Users/XPV/Desktop/anchor-core/webbridge.pid
fi

if [ -f "/Users/XPV/Desktop/anchor-core/notion-sync.pid" ]; then
  kill $(cat /Users/XPV/Desktop/anchor-core/notion-sync.pid) 2>/dev/null || true
  rm -f /Users/XPV/Desktop/anchor-core/notion-sync.pid
fi

if [ -f "/Users/XPV/Desktop/anchor-core/dashboard.pid" ]; then
  kill $(cat /Users/XPV/Desktop/anchor-core/dashboard.pid) 2>/dev/null || true
  rm -f /Users/XPV/Desktop/anchor-core/dashboard.pid
fi

# Remove any stale socket files
rm -f /Users/XPV/Desktop/anchor-core/sockets/*.sock

# Restart all services
echo "Restarting all services..."
/Users/XPV/Desktop/anchor-core/start-webbridge.sh

echo "======================================================"
echo "✅ Configuration complete"
echo "To verify the status, run:"
echo "  /Users/XPV/Desktop/anchor-core/verify-cnif.sh"
echo "======================================================"
