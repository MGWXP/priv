#!/bin/bash
# NODE_OPTIONS_FIX.md - Documentation on NODE_OPTIONS flag limitations
# © 2025 XPV - MIT

# NODE_OPTIONS and --expose-gc Flag Issue

The `--expose-gc` flag in `NODE_OPTIONS` is not allowed in recent Node.js versions 
due to security considerations. This flag exposes the garbage collector to JavaScript 
code, which could be used for performance attacks.

## Problem

In the original MCP server implementation, all server scripts contained:

```javascript
process.env.NODE_OPTIONS ||= '--max-old-space-size=8192 --expose-gc';
```

This causes the following error when starting the servers:

```
Error: Node option --expose-gc is not allowed in NODE_OPTIONS
```

## Solution

The fix involves two parts:

1. Remove the `--expose-gc` flag from `NODE_OPTIONS` in all server scripts
2. Implement an alternative memory management approach that doesn't rely on `global.gc()`

### Modified Configuration:

```javascript
// Before
process.env.NODE_OPTIONS ||= '--max-old-space-size=8192 --expose-gc';

// After
process.env.NODE_OPTIONS ||= '--max-old-space-size=8192';
```

### Alternative Memory Management:

Instead of directly calling `global.gc()`, we implemented a manual memory pressure 
approach that encourages the V8 engine to run garbage collection naturally:

```javascript
setInterval(() => {
  const memBefore = process.memoryUsage();
  
  // Create and release large temporary objects to encourage GC
  const temp = new Array(10000).fill(0);
  
  // Force a minor GC by creating pressure
  for (let i = 0; i < 10; i++) {
    const arr = new Array(100000).fill(0);
    arr.length = 0;
  }
  
  const memAfter = process.memoryUsage();
  log('DEBUG','Memory management', {
    before: `${(memBefore.heapUsed/1048576).toFixed(1)} MB`,
    after: `${(memAfter.heapUsed/1048576).toFixed(1)} MB`,
    diff: `${((memBefore.heapUsed-memAfter.heapUsed)/1048576).toFixed(1)} MB`
  });
}, 60000);
```

This approach is effective for memory management without requiring the explicit 
`--expose-gc` flag.

## Applied Fixes

The `enhanced-quick-fix.sh` script has applied these changes to all server scripts 
and updated the launch scripts to use the correct configuration.

This approach ensures compatibility with recent Node.js versions while still 
providing effective memory management for M3 Max hardware optimization.
