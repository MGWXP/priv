#!/bin/bash
# mcp-environment-verifier.sh - Verifies and maintains MCP environment
# For M3 Max (48GB unified memory) hardware

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

echo -e "${BLUE}=== MCP Environment Verification ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e "Hardware Target: M3 Max (48GB unified memory)"

# Check MCP server packages and reinstall if needed
echo -e "${BLUE}Verifying MCP server packages...${NC}"

# Check Filesystem MCP Server
if npm list -g @modelcontextprotocol/server-filesystem &>/dev/null; then
    echo -e "${GREEN}✓ @modelcontextprotocol/server-filesystem is installed${NC}"
else
    echo -e "${YELLOW}Installing @modelcontextprotocol/server-filesystem...${NC}"
    npm install -g @modelcontextprotocol/server-filesystem
    echo -e "${GREEN}✓ @modelcontextprotocol/server-filesystem installed${NC}"
fi

# Check Notion MCP Server
if npm list -g @notionhq/notion-mcp-server &>/dev/null; then
    echo -e "${GREEN}✓ @notionhq/notion-mcp-server is installed${NC}"
else
    echo -e "${YELLOW}Installing @notionhq/notion-mcp-server...${NC}"
    npm install -g @notionhq/notion-mcp-server
    echo -e "${GREEN}✓ @notionhq/notion-mcp-server installed${NC}"
fi

# Check Slack MCP Server
if npm list -g @modelcontextprotocol/server-slack &>/dev/null; then
    echo -e "${GREEN}✓ @modelcontextprotocol/server-slack is installed${NC}"
else
    echo -e "${YELLOW}Installing @modelcontextprotocol/server-slack...${NC}"
    npm install -g @modelcontextprotocol/server-slack
    echo -e "${GREEN}✓ @modelcontextprotocol/server-slack installed${NC}"
fi

# Verify environment variables
echo -e "${BLUE}Verifying environment variables...${NC}"

# Check NOTION_API_KEY
if [ -z "${NOTION_API_KEY}" ]; then
    echo -e "${YELLOW}Warning: NOTION_API_KEY environment variable is not set${NC}"
    echo -e "To set it, run: export NOTION_API_KEY=\"your_notion_api_key\""
else
    echo -e "${GREEN}✓ NOTION_API_KEY environment variable is set${NC}"
fi

# Check SLACK_BOT_TOKEN
if [ -z "${SLACK_BOT_TOKEN}" ]; then
    echo -e "${YELLOW}Warning: SLACK_BOT_TOKEN environment variable is not set${NC}"
    echo -e "To set it, run: export SLACK_BOT_TOKEN=\"your_slack_bot_token\""
else
    echo -e "${GREEN}✓ SLACK_BOT_TOKEN environment variable is set${NC}"
fi

# Check SLACK_TEAM_ID
if [ -z "${SLACK_TEAM_ID}" ]; then
    echo -e "${YELLOW}Warning: SLACK_TEAM_ID environment variable is not set${NC}"
    echo -e "To set it, run: export SLACK_TEAM_ID=\"your_slack_team_id\""
else
    echo -e "${GREEN}✓ SLACK_TEAM_ID environment variable is set${NC}"
fi

echo -e "\n${GREEN}✓ Verification complete!${NC}"
echo -e "${YELLOW}If any packages were missing, they have been installed.${NC}"
echo -e "${YELLOW}If any environment variables are missing, please set them and restart Claude Desktop.${NC}"
