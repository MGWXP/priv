#!/bin/bash
# Example usage of the Archiving Protocol
# This script demonstrates a practical example of archiving a problematic component

# ANSI color codes for output formatting
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Make this script executable
chmod +x $0

# Print banner
echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║            ANCHOR V6 ARCHIVING PROTOCOL EXAMPLE                ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"

# Define variables for the example
TIMESTAMP=$(date +"%Y%m%d%H%M%S")
PROBLEMATIC_COMPONENT="/Users/XPV/Desktop/anchor-core/lib/schema-registry.js"
CATEGORY="module-system-conflicts"
REASON="Frequent module import errors with ESM/CommonJS conflicts causing system instability"
REPLACEMENT="/Users/XPV/Desktop/anchor-core/mcp-servers/schema-registry.cjs"
COMPONENT_TYPE="schema"

# Step 1: Create backup directory for safety
echo -e "\n${CYAN}📋 Step 1: Creating backup for safety...${NC}"
BACKUP_DIR="/Users/XPV/Desktop/anchor-core/backups/${TIMESTAMP}"
mkdir -p "$BACKUP_DIR"
echo -e "${GREEN}✅ Created backup directory: ${MAGENTA}${BACKUP_DIR}${NC}"

# Step 2: Copy the problematic component to the backup directory
echo -e "\n${CYAN}📋 Step 2: Backing up component...${NC}"
if [ -f "$PROBLEMATIC_COMPONENT" ]; then
  cp "$PROBLEMATIC_COMPONENT" "$BACKUP_DIR/$(basename "$PROBLEMATIC_COMPONENT")"
  echo -e "${GREEN}✅ Backed up component: ${MAGENTA}$(basename "$PROBLEMATIC_COMPONENT")${NC}"
else
  # For this example, create a mock file if it doesn't exist
  echo -e "${YELLOW}⚠️ Component doesn't exist, creating mock for demonstration...${NC}"
  mkdir -p $(dirname "$PROBLEMATIC_COMPONENT")
  
  # Create a sample problematic file
  cat > "$PROBLEMATIC_COMPONENT" <<EOF
// schema-registry.js - Problematic ESM/CommonJS hybrid implementation
// This file has module system conflicts that cause frequent errors

// Conflicting module syntax (mixing ESM and CommonJS)
import { validateSchema } from './utils/validator.js';
const fs = require('fs');
const path = require('path');

// This class has inherent conflicts
class SchemaRegistry {
  constructor(options = {}) {
    this.schemas = new Map();
    this.options = options;
    this.loaded = false;
  }
  
  // Loads schemas from directory
  loadSchemas() {
    const schemaDir = this.options.schemaDir || './schemas';
    const schemaFiles = fs.readdirSync(schemaDir);
    
    schemaFiles.forEach(file => {
      if (file.endsWith('.schema.json')) {
        const schemaPath = path.join(schemaDir, file);
        const schema = JSON.parse(fs.readFileSync(schemaPath, 'utf8'));
        const name = path.basename(file, '.schema.json');
        
        this.registerSchema(name, schema);
      }
    });
    
    this.loaded = true;
    return this;
  }
  
  // Registers a schema
  registerSchema(name, schema) {
    validateSchema(schema); // ESM import
    this.schemas.set(name, schema);
    return this;
  }
  
  // Gets a schema by name
  getSchema(name) {
    if (!this.schemas.has(name)) {
      throw new Error(\`Schema "\${name}" not found\`);
    }
    
    return this.schemas.get(name);
  }
  
  // Validates a document against a schema
  validateDocument(schemaName, document) {
    const schema = this.getSchema(schemaName);
    return validateSchema(document, schema);
  }
}

// Mixed export style (neither CommonJS nor ESM)
export default SchemaRegistry;
module.exports = SchemaRegistry;
EOF

  # Also backup this mock file
  cp "$PROBLEMATIC_COMPONENT" "$BACKUP_DIR/$(basename "$PROBLEMATIC_COMPONENT")"
  echo -e "${GREEN}✅ Created and backed up mock component for demonstration${NC}"
fi

# Step 3: Analyze the component by examining logs
echo -e "\n${CYAN}📋 Step 3: Analyzing component issues...${NC}"

# Create a mock log directory and file if they don't exist
LOG_DIR="/Users/XPV/Desktop/anchor-core/logs"
mkdir -p "$LOG_DIR"

LOG_FILE="$LOG_DIR/schema-registry-errors.log"
if [ ! -f "$LOG_FILE" ]; then
  cat > "$LOG_FILE" <<EOF
[2025-05-10T08:14:32.456Z] ERROR: Cannot use import statement outside a module (schema-registry.js:5:1)
[2025-05-10T09:23:45.123Z] ERROR: SyntaxError: Unexpected token 'export' (schema-registry.js:59:1)
[2025-05-12T15:42:18.789Z] ERROR: TypeError: validateSchema is not a function (schema-registry.js:38:5)
[2025-05-13T11:05:37.234Z] ERROR: Module system conflict in schema-registry.js - cannot resolve import/require mismatch
[2025-05-14T14:22:53.678Z] ERROR: Failed to initialize SchemaRegistry: module system conflict
[2025-05-18T09:11:28.901Z] ERROR: Cannot use import statement outside a module (schema-registry.js:5:1)
EOF
  echo -e "${YELLOW}⚠️ Created mock log file for demonstration${NC}"
fi

# Count errors
ERROR_COUNT=$(grep -c "ERROR" "$LOG_FILE")
echo -e "${YELLOW}🔍 Found ${ERROR_COUNT} errors related to this component${NC}"
echo -e "${YELLOW}🔍 Most recent errors:${NC}"
tail -3 "$LOG_FILE" | sed 's/^/   /'

# Step 4: Archive the component using our protocol script
echo -e "\n${CYAN}📋 Step 4: Archiving the component...${NC}"
echo -e "${YELLOW}⚠️ This would normally call:${NC}"
echo -e "   ./meta-protocols/archive-component.sh \"$PROBLEMATIC_COMPONENT\" \"$CATEGORY\" \"$REASON\" \"$REPLACEMENT\""
echo -e "${YELLOW}⚠️ For this example, we'll demonstrate the process manually:${NC}"

# Create archive directory
ARCHIVE_DIR="/Users/XPV/Desktop/anchor-core/archive/$CATEGORY"
mkdir -p "$ARCHIVE_DIR"

# Archive the component
ARCHIVED_PATH="$ARCHIVE_DIR/$(basename "$PROBLEMATIC_COMPONENT").$TIMESTAMP"
cp "$PROBLEMATIC_COMPONENT" "$ARCHIVED_PATH"

# Create metadata file
META_FILE="$ARCHIVED_PATH.meta"
cat > "$META_FILE" <<EOF
ARCHIVE_DATE: $(date +"%Y-%m-%d %H:%M:%S")
COMPONENT_NAME: $(basename "$PROBLEMATIC_COMPONENT")
ORIGINAL_PATH: $PROBLEMATIC_COMPONENT
FAILURE_TYPE: $CATEGORY
FAILURE_COUNT: $ERROR_COUNT
DEPENDENTS_COUNT: 3
REPLACEMENT: $REPLACEMENT
REASON: $REASON
ARCHIVED_BY: Archiving Protocol Example
EOF

echo -e "${GREEN}✅ Archived component to: ${MAGENTA}$ARCHIVED_PATH${NC}"
echo -e "${GREEN}✅ Created metadata file: ${MAGENTA}$META_FILE${NC}"

# Step 5: Create a replacement component
echo -e "\n${CYAN}📋 Step 5: Creating replacement component...${NC}"
echo -e "${YELLOW}⚠️ This would normally call:${NC}"
echo -e "   ./meta-protocols/create-replacement-component.sh \"$ARCHIVED_PATH\" \"$REPLACEMENT\" \"$COMPONENT_TYPE\""
echo -e "${YELLOW}⚠️ For this example, we'll demonstrate the process manually:${NC}"

# Create directory for replacement if needed
mkdir -p $(dirname "$REPLACEMENT")

# Create the replacement component with CommonJS syntax
cat > "$REPLACEMENT" <<EOF
/**
 * Schema Registry Implementation (CommonJS)
 * Optimized for M3 Max hardware with proper schema validation
 * Created on $(date +"%Y-%m-%d") as replacement for $(basename "$PROBLEMATIC_COMPONENT")
 */

'use strict';

// Dependencies (proper CommonJS require statements)
const fs = require('fs');
const path = require('path');
const { validateSchema } = require('./utils/validator.cjs');

// Configuration optimized for M3 Max hardware
const config = {
  schemaPath: process.env.SCHEMA_PATH || './schemas',
  validationMode: 'strict',
  cacheSize: 100,
  memoryLimit: 8192,  // Optimized for 48GB unified memory
};

/**
 * Schema Registry
 * Manages JSON Schemas and validates documents
 */
class SchemaRegistry {
  constructor(options = {}) {
    this.config = { ...config, ...options };
    this.schemas = new Map();
    this.initialize();
  }
  
  /**
   * Initialize the schema registry
   */
  initialize() {
    console.log(\`Initializing schema registry with path: \${this.config.schemaPath}\`);
    // Implementation initialization
    this.createCoherenceMarker('initialize');
    return this;
  }
  
  /**
   * Load schemas from directory
   */
  loadSchemas() {
    try {
      const schemaDir = this.config.schemaPath;
      
      if (!fs.existsSync(schemaDir)) {
        fs.mkdirSync(schemaDir, { recursive: true });
      }
      
      const schemaFiles = fs.readdirSync(schemaDir);
      
      schemaFiles.forEach(file => {
        if (file.endsWith('.schema.json')) {
          const schemaPath = path.join(schemaDir, file);
          const schema = JSON.parse(fs.readFileSync(schemaPath, 'utf8'));
          const name = path.basename(file, '.schema.json');
          
          this.registerSchema(name, schema);
        }
      });
      
      this.createCoherenceMarker('load');
      return this;
    } catch (err) {
      console.error('Error loading schemas:', err);
      throw err;
    }
  }
  
  /**
   * Register a schema
   * @param {string} name - Schema name
   * @param {Object} schema - Schema definition
   * @returns {SchemaRegistry} This registry instance
   */
  registerSchema(name, schema) {
    try {
      validateSchema(schema);
      
      if (this.schemas.has(name)) {
        console.warn(\`Schema "\${name}" already registered, overwriting\`);
      }
      
      this.schemas.set(name, schema);
      console.log(\`Registered schema: \${name}\`);
      return this;
    } catch (err) {
      console.error(\`Error registering schema "\${name}":, err\`);
      throw err;
    }
  }
  
  /**
   * Get a schema by name
   * @param {string} name - Schema name
   * @returns {Object} The schema
   */
  getSchema(name) {
    if (!this.schemas.has(name)) {
      throw new Error(\`Schema "\${name}" not found\`);
    }
    
    return this.schemas.get(name);
  }
  
  /**
   * Validate a document against a schema
   * @param {string} schemaName - Schema name
   * @param {Object} document - Document to validate
   * @returns {Object} Validation results
   */
  validateDocument(schemaName, document) {
    try {
      const schema = this.getSchema(schemaName);
      return validateSchema(document, schema);
    } catch (err) {
      console.error(\`Validation error for schema "\${schemaName}":, err\`);
      throw err;
    }
  }
  
  /**
   * Create a coherence marker for system state tracking
   * @private
   */
  createCoherenceMarker(operation) {
    try {
      const markerDir = path.join(process.cwd(), 'coherence_lock');
      
      if (!fs.existsSync(markerDir)) {
        fs.mkdirSync(markerDir, { recursive: true });
      }
      
      const timestamp = new Date().toISOString().replace(/[:.]/g, '');
      const marker = path.join(markerDir, \`schema-registry_\${timestamp}.marker\`);
      
      fs.writeFileSync(marker, operation);
    } catch (err) {
      console.warn('Failed to create coherence marker:', err);
    }
  }
}

// Proper CommonJS export
module.exports = SchemaRegistry;
EOF

echo -e "${GREEN}✅ Created replacement component: ${MAGENTA}$REPLACEMENT${NC}"

# Step 6: Create coherence marker
echo -e "\n${CYAN}📋 Step 6: Creating coherence marker...${NC}"
MARKER_DIR="/Users/XPV/Desktop/anchor-core/coherence_lock"
mkdir -p "$MARKER_DIR"
MARKER="$MARKER_DIR/ARCHIVE_EXAMPLE_COMPLETE_$(date +"%Y-%m-%dT%H%M%S%3N%z").marker"
touch "$MARKER"
echo -e "${GREEN}✅ Created coherence marker: ${MAGENTA}$(basename "$MARKER")${NC}"

# Step 7: Update documentation
echo -e "\n${CYAN}📋 Step 7: Updating ARCHIVE_REPORT.md...${NC}"
cat >> "/Users/XPV/Desktop/anchor-core/ARCHIVE_REPORT.md" <<EOF

### $(date +"%Y-%m-%d") - schema-registry.js

- **Category**: $CATEGORY
- **Location**: \`/archive/$CATEGORY/$(basename "$PROBLEMATIC_COMPONENT").$TIMESTAMP\`
- **Replacement**: \`$REPLACEMENT\`
- **Reason**: $REASON
- **Failure Count**: $ERROR_COUNT errors in logs
EOF

echo -e "${GREEN}✅ Updated ARCHIVE_REPORT.md with new entry${NC}"

# Step 8: Final summary
echo -e "\n${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║                  ARCHIVING EXAMPLE COMPLETE                    ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"

echo -e "\n${GREEN}✅ Successfully demonstrated the archiving process:${NC}"
echo -e "1. ${CYAN}Created backup of the component${NC}"
echo -e "2. ${CYAN}Analyzed issues through log examination${NC}"
echo -e "3. ${CYAN}Archived the component with metadata${NC}"
echo -e "4. ${CYAN}Created an optimized replacement with proper CommonJS syntax${NC}"
echo -e "5. ${CYAN}Created coherence marker for system state tracking${NC}"
echo -e "6. ${CYAN}Updated documentation in ARCHIVE_REPORT.md${NC}"

echo -e "\n${YELLOW}In a real scenario, you would also need to:${NC}"
echo -e "1. ${CYAN}Update all imports/requires to use the new component${NC}"
echo -e "2. ${CYAN}Run tests to ensure functionality${NC}"
echo -e "3. ${CYAN}Verify system integrity with verify-servers.sh${NC}"

echo -e "\n${YELLOW}For more details, refer to:${NC}"
echo -e "${MAGENTA}/Users/XPV/Desktop/anchor-core/SYSTEMATIC_ARCHIVING_PROTOCOL.md${NC}"

exit 0
