#!/bin/bash
# launch-optimized.sh - M3 Max optimized launcher for Claude-Notion Integration Framework
# © 2025 XPV - MIT

set -e

# Define colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color
BLUE='\033[0;34m'

# Base paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
LOG_DIR="$HOME/Library/Logs/Claude"
SOCKET_DIR="$ANCHOR_HOME/sockets"
COHERENCE_LOCK_DIR="$ANCHOR_HOME/coherence_lock"
CONFIG_DIR="$ANCHOR_HOME/data"
MCP_DIR="$ANCHOR_HOME/mcp-servers"
PID_DIR="$MCP_DIR"

# Load optimized environment
if [ -f "$ANCHOR_HOME/.env" ]; then
  echo -e "${BLUE}Loading optimized environment...${NC}"
  source "$ANCHOR_HOME/.env"
else
  # Run optimizer to generate env file
  echo -e "${YELLOW}No .env file found, running optimizer...${NC}"
  node "$ANCHOR_HOME/m3-optimizer/m3-optimizer.js"
  source "$ANCHOR_HOME/.env"
fi

# M3 Max optimized settings
# Only use allowed flags in NODE_OPTIONS
export NODE_OPTIONS="--max-old-space-size=8192"
export UV_THREADPOOL_SIZE=12
export ANCHOR_HOME="$ANCHOR_HOME"
export MCP_DIR="$MCP_DIR"
export SOCKET_DIR="$SOCKET_DIR"
export LOG_DIR="$LOG_DIR"
export CONFIG_DIR="$CONFIG_DIR"
export PATH="$PATH:$ANCHOR_HOME/node_modules/.bin"

# Initialize directories
echo -e "${BLUE}Creating required directories...${NC}"
mkdir -p "$LOG_DIR"
mkdir -p "$SOCKET_DIR"
mkdir -p "$COHERENCE_LOCK_DIR"
mkdir -p "$CONFIG_DIR"

# Check if required files exist
if [ ! -f "$CONFIG_DIR/notion-config.json" ]; then
  echo -e "${YELLOW}Creating default notion config...${NC}"
  echo '{
    "rootPageId": "",
    "enabledDatabases": [],
    "syncInterval": 30000,
    "rateLimitPerSecond": 3
  }' > "$CONFIG_DIR/notion-config.json"
fi

# Define server configurations - using traditional arrays for compatibility
SERVER_NAMES=("socket-server" "notion" "schema-registry" "streaming-transformer" "mcp-orchestrator")
SERVER_SCRIPTS=("$MCP_DIR/socket-server-implementation.cjs" "$MCP_DIR/notion-connection-manager.cjs" "$MCP_DIR/schema-registry.cjs" "$MCP_DIR/streaming-schema-transformer.cjs" "$MCP_DIR/mcp-orchestrator.cjs")

# Function to get script path by server name
get_server_script() {
  local server_name=$1
  local index=0
  for name in "${SERVER_NAMES[@]}"; do
    if [ "$name" = "$server_name" ]; then
      echo "${SERVER_SCRIPTS[$index]}"
      return 0
    fi
    index=$((index + 1))
  done
  echo ""
}

# Clean up function
cleanup() {
  echo -e "${YELLOW}Shutting down all servers...${NC}"
  
  # Kill all running servers
  for server in "${SERVER_NAMES[@]}"; do
    if [ -f "$PID_DIR/$server.pid" ]; then
      pid=$(cat "$PID_DIR/$server.pid")
      if ps -p "$pid" > /dev/null; then
        echo -e "${YELLOW}Stopping $server (PID: $pid)...${NC}"
        kill -15 "$pid" || true
      else
        echo -e "${YELLOW}Process $server (PID: $pid) not running${NC}"
      fi
    fi
  done
  
  # Remove socket files
  echo -e "${YELLOW}Removing socket files...${NC}"
  rm -f "$SOCKET_DIR"/*.sock
  
  # Remove coherence markers
  echo -e "${YELLOW}Removing coherence markers...${NC}"
  rm -f "$COHERENCE_LOCK_DIR"/*.marker
  
  echo -e "${GREEN}Cleanup complete${NC}"
}

# Set trap for clean shutdown
trap cleanup EXIT INT TERM

# Stop any existing servers
echo -e "${BLUE}Stopping any existing servers...${NC}"
cleanup

# Initialize memory pools if enabled
if [ "$M3_MEMORY_POOLING" = "true" ] && [ -f "$ANCHOR_HOME/memory-pool-init.js" ]; then
  echo -e "${BLUE}Initializing memory pools for M3 Max...${NC}"
  node --require "$ANCHOR_HOME/memory-pool-init.js" -e "console.log('✅ Memory pools ready');"
fi

# Initialize Metal accelerator if available
if [ "$M3_METAL_ACCELERATION" = "true" ] && [ -f "$ANCHOR_HOME/metal-accelerator.js" ]; then
  echo -e "${BLUE}Initializing Metal accelerator for M3 Max...${NC}"
  node --require "$ANCHOR_HOME/metal-accelerator.js" -e "console.log('✅ Metal acceleration ready');"
fi

# Check if pm2 is available for process management
if command -v pm2 > /dev/null; then
  # Use PM2 for better process management
  echo -e "${BLUE}Starting services with PM2...${NC}"
  
  # Generate PM2 ecosystem file
  echo '{
    "apps": [' > "$ANCHOR_HOME/ecosystem.config.js"
  
  first=true
  for server in "${SERVER_NAMES[@]}"; do
    if [ "$first" = true ]; then
      first=false
    else
      echo ',' >> "$ANCHOR_HOME/ecosystem.config.js"
    fi
    
    script=$(get_server_script "$server")
    echo "      {
        \"name\": \"$server\",
        \"script\": \"$script\",
        \"env\": {
          \"NODE_OPTIONS\": \"$NODE_OPTIONS\",
          \"UV_THREADPOOL_SIZE\": $UV_THREADPOOL_SIZE,
          \"MCP_SERVER_NAME\": \"$server\",
          \"ANCHOR_HOME\": \"$ANCHOR_HOME\",
          \"LOG_DIR\": \"$LOG_DIR\",
          \"SOCKET_DIR\": \"$SOCKET_DIR\"
        },
        \"log_date_format\": \"YYYY-MM-DD HH:mm:ss Z\",
        \"out_file\": \"$LOG_DIR/$server.log\",
        \"error_file\": \"$LOG_DIR/$server.log\",
        \"merge_logs\": true,
        \"watch\": false,
        \"instances\": 1,
        \"exec_mode\": \"fork\"
      }" >> "$ANCHOR_HOME/ecosystem.config.js"
  done
  
  echo '
    ]
  }' >> "$ANCHOR_HOME/ecosystem.config.js"
  
  # Start all services with PM2
  pm2 start "$ANCHOR_HOME/ecosystem.config.js"
  
  echo -e "${GREEN}All services started with PM2. View logs with:${NC}"
  echo -e "  pm2 logs"
  echo -e "${GREEN}View dashboard with:${NC}"
  echo -e "  pm2 monit"
else
  # Start each server
  echo -e "${BLUE}Starting services...${NC}"
  
  # Start the servers in the correct order
  ordered_servers=("schema-registry" "streaming-transformer" "socket-server" "notion" "mcp-orchestrator")
  
  for server in "${ordered_servers[@]}"; do
    script=$(get_server_script "$server")
    if [ -z "$script" ]; then
      echo -e "${RED}Error: Script not found for $server${NC}"
      continue
    fi
    
    echo -e "${BLUE}Starting $server...${NC}"
    # Set environment variables for this server
    export MCP_SERVER_NAME="$server"
    
    # Start the server
    node --expose-gc "$script" > "$LOG_DIR/$server.log" 2>&1 &
    pid=$!
    
    # Verify process actually started
    if ! ps -p "$pid" > /dev/null; then
      echo -e "${RED}ERROR: Process for $server failed to start!${NC}"
      continue
    fi
    
    # Save PID
    echo "$pid" > "$PID_DIR/$server.pid"
    
    echo -e "${GREEN}Started $server (PID: $pid)${NC}"
    
    # Add a slight delay to ensure logging is initialized before checking
    sleep 0.5
    
    # Check if process is still running and log is created
    if ps -p "$pid" > /dev/null; then
      if [ -f "$LOG_DIR/$server.log" ]; then
        # Check log for immediate errors
        if grep -q "Error" "$LOG_DIR/$server.log" || grep -q "error" "$LOG_DIR/$server.log" || grep -q "not allowed in NODE_OPTIONS" "$LOG_DIR/$server.log"; then
          echo -e "${RED}WARNING: Errors detected in log for $server. See $LOG_DIR/$server.log${NC}"
          cat "$LOG_DIR/$server.log" | head -n 10
        fi
      else
        echo -e "${YELLOW}WARNING: Log file not created for $server${NC}"
      fi
    else
      echo -e "${RED}ERROR: Process for $server died immediately after starting!${NC}"
    fi
    
    # Wait a second to stagger startups
    sleep 1
  done
fi

# Wait for all servers to initialize
echo -e "${BLUE}Waiting for services to initialize...${NC}"
sleep 3

# Check health
echo -e "${BLUE}Checking service health...${NC}"
failed=false

for server in "${SERVER_NAMES[@]}"; do
  if [ -f "$PID_DIR/$server.pid" ]; then
    pid=$(cat "$PID_DIR/$server.pid")
    if ps -p "$pid" > /dev/null; then
      echo -e "${GREEN}✅ $server is running (PID: $pid)${NC}"
    else
      echo -e "${RED}❌ $server failed to start${NC}"
      failed=true
    fi
  else
    echo -e "${RED}❌ No PID file for $server${NC}"
    failed=true
  fi
  
  # Check socket file for socket servers
  if [ "$server" = "socket-server" ]; then
    if [ -e "$SOCKET_DIR/$server.sock" ]; then
      echo -e "${GREEN}✅ Socket file exists for $server${NC}"
    else
      echo -e "${RED}❌ Socket file missing for $server${NC}"
      failed=true
    fi
  fi
done

# Check coherence markers
echo -e "${BLUE}Checking coherence markers...${NC}"
markers=$(ls -1 "$COHERENCE_LOCK_DIR"/*.marker 2>/dev/null | wc -l)
if [ "$markers" -gt 0 ]; then
  echo -e "${GREEN}✅ Found $markers coherence markers${NC}"
else
  echo -e "${RED}❌ No coherence markers found${NC}"
  failed=true
fi

if [ "$failed" = true ]; then
  echo -e "${RED}❌ Some services failed to start properly${NC}"
  echo -e "${YELLOW}Check logs in $LOG_DIR for details${NC}"
  exit 1
else
  echo -e "${GREEN}✅ All services started successfully${NC}"
  echo -e "${BLUE}CNIF is running with M3 Max optimizations${NC}"
  echo -e "${BLUE}Logs available in $LOG_DIR${NC}"
  echo -e "${BLUE}Socket files in $SOCKET_DIR${NC}"
  
  # Launch dashboard if available
  if [ -f "$ANCHOR_HOME/dashboard/server.js" ]; then
    echo -e "${BLUE}Starting dashboard on http://localhost:8765${NC}"
    node "$ANCHOR_HOME/dashboard/server.js" > "$LOG_DIR/dashboard.log" 2>&1 &
    echo "$!" > "$PID_DIR/dashboard.pid"
    echo -e "${GREEN}✅ Dashboard started${NC}"
  fi
fi

# Keep script running to maintain trap handlers
echo -e "${GREEN}Press Ctrl+C to stop all services${NC}"
wait
