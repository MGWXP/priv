# Anchor V6 Archiving Protocol: User Guide

## Overview

The Anchor V6 Archiving Protocol provides a systematic approach for identifying, archiving, and replacing components that have demonstrated instability, inefficiency, or incompatibility with current system requirements. This guide provides detailed instructions for using the protocol tools and understanding the archiving process.

## When to Use the Archiving Protocol

The archiving protocol should be used in the following scenarios:

1. **Module System Conflicts**: When components exhibit issues with mixed ESM/CommonJS syntax
2. **Socket Connectivity Issues**: When components show persistent connection failures
3. **Schema Validation Errors**: When schema validation components produce frequent errors
4. **Process Management Issues**: When components fail to properly manage process lifecycle
5. **Performance Bottlenecks**: When components cause memory leaks or excessive CPU usage
6. **Deprecated Implementations**: When newer, better implementations are available
7. **Obsolete Configurations**: When configuration files are outdated or conflicting

## Protocol Components

The Anchor V6 Archiving Protocol consists of the following components:

### Analysis Tools

- **analyze-archive-candidates.sh**: Identifies components for archiving based on log analysis
- **identify-archive-candidates.sh**: Analyzes source code patterns to find problematic components
- **archive-dashboard.sh**: Generates a dashboard of archiving statistics

### Archiving Tools

- **archive-component.sh**: Archives a single component with metadata
- **bulk-archive-components.sh**: Archives multiple components in batch
- **create-replacement-component.sh**: Creates optimized replacements for archived components
- **component-migration-manager.sh**: Manages coordinated migration of multiple components

### Management Tools

- **archival-protocol-controller.sh**: Unified interface for all archiving operations

## Getting Started

### 1. Initialize the Protocol

Before using the protocol tools, ensure all scripts are executable:

```bash
chmod +x /Users/XPV/Desktop/anchor-core/archival-protocol-controller.sh
```

### 2. Launch the Protocol Controller

The protocol controller provides a unified interface to all archiving operations:

```bash
./archival-protocol-controller.sh
```

This will display the main menu with available operations.

## Workflow Guide

### Step 1: Analyze for Archiving Candidates

There are two main approaches for identifying components that need archiving:

#### Log-Based Analysis

```bash
./meta-protocols/analyze-archive-candidates.sh [days] [threshold]
```

This tool analyzes logs for the specified number of days and identifies components with error counts above the threshold.

Example:
```bash
./meta-protocols/analyze-archive-candidates.sh 30 3
```

This analyzes logs from the past 30 days and identifies components with 3 or more errors.

#### Source Code Analysis

```bash
./meta-protocols/identify-archive-candidates.sh
```

This tool analyzes source code patterns to identify components with potential issues such as module system conflicts, improper error handling, and performance bottlenecks.

### Step 2: Review and Archive Components

After identifying candidates for archiving, you can either archive a single component or perform a bulk archive.

#### Archive a Single Component

```bash
./meta-protocols/archive-component.sh [component_path] [category] [reason] [replacement_path]
```

Example:
```bash
./meta-protocols/archive-component.sh /Users/XPV/Desktop/anchor-core/lib/schema-registry.js module-system-conflicts "Mixed ESM and CommonJS syntax causing import errors" /Users/XPV/Desktop/anchor-core/mcp-servers/schema-registry.cjs
```

#### Bulk Archive Multiple Components

```bash
./meta-protocols/bulk-archive-components.sh [component_list_file]
```

The component list file should be a CSV file with the following format:
```
component_path,category,reason,replacement_path
/path/to/component1.js,module-system-conflicts,Reason for archiving,/path/to/replacement1.cjs
/path/to/component2.js,performance-bottlenecks,Another reason,/path/to/replacement2.cjs
```

Example:
```bash
./meta-protocols/bulk-archive-components.sh /Users/XPV/Desktop/anchor-core/analysis/archive-candidates-20250520123456.csv
```

### Step 3: Create Replacement Components

After archiving components, you can create optimized replacements:

```bash
./meta-protocols/create-replacement-component.sh [archived_path] [replacement_path] [type]
```

Component types:
- server (Socket server implementation)
- schema (Schema registry component)
- transformer (Data transformer component)
- connection (Connection manager component)
- orchestrator (MCP orchestrator component)
- circuit (Circuit breaker component)
- generic (Generic component with basic structure)

Example:
```bash
./meta-protocols/create-replacement-component.sh /Users/XPV/Desktop/anchor-core/archive/module-system-conflicts/schema-registry.js.20250520123456 /Users/XPV/Desktop/anchor-core/mcp-servers/schema-registry.cjs schema
```

### Step 4: Migrate Dependencies

When replacing multiple components, use the migration manager to coordinate the updates:

```bash
./meta-protocols/component-migration-manager.sh -f [migration_file] [options]
```

Options:
- `--dry-run`: Show what would be done without making changes
- `--no-verify`: Skip verification after migration

The migration file should be a CSV file with the following format:
```
original_component,replacement_component,reason
/path/to/old1.js,/path/to/new1.cjs,Reason for migration
/path/to/old2.js,/path/to/new2.cjs,Another reason
```

Example:
```bash
./meta-protocols/component-migration-manager.sh -f /Users/XPV/Desktop/anchor-core/analysis/migration-plan-20250520123456.csv --dry-run
```

### Step 5: Verify System Integrity

After archiving and replacing components, verify system integrity:

```bash
/Users/XPV/Desktop/anchor-core/mcp-servers/verify-servers.sh
```

### Step 6: View Archiving Dashboard

Generate a dashboard to visualize the current archiving status:

```bash
./meta-protocols/archive-dashboard.sh
```

## Archiving Categories

Components are archived into the following categories based on their failure patterns:

1. **module-system-conflicts**: Components with ESM/CommonJS incompatibilities
   - Example: Mixing `require()` and `import` statements
   - Example: Using ES module syntax in CommonJS files

2. **socket-connectivity-issues**: Components with connection handling problems
   - Example: Missing error handling in socket operations
   - Example: Improper socket timeout management

3. **schema-validation-errors**: Components with schema validation issues
   - Example: Missing try/catch around validation
   - Example: Improper error messaging for validation failures

4. **process-management-issues**: Components with process lifecycle problems
   - Example: Missing cleanup of resources
   - Example: Improper handling of process signals

5. **performance-bottlenecks**: Components causing resource constraints
   - Example: Memory leaks from event listeners
   - Example: Inefficient data structures for large datasets

6. **deprecated-implementations**: Components superseded by newer implementations
   - Example: Old API client implementations
   - Example: Legacy utility functions

7. **obsolete-configurations**: Outdated or conflicting configuration files
   - Example: Old configuration formats
   - Example: Duplicate configuration files

## Best Practices

### Archiving Best Practices

1. **Always Create Backups**: The archiving tools automatically create backups, but it's good practice to verify backups before major operations.

2. **Use Dry Run First**: For bulk operations, always use the `--dry-run` option first to see what changes would be made.

3. **Document Thoroughly**: Provide clear reasons when archiving components to maintain a historical record of architectural decisions.

4. **Verify After Archiving**: Always verify system integrity after archiving operations to ensure no critical functionality is broken.

### Replacement Best Practices

1. **Follow Module System Consistency**: Use appropriate file extensions (.cjs, .mjs, .js) and consistent module syntax.

2. **Implement Proper Error Handling**: Ensure all error conditions are properly handled in replacement components.

3. **Optimize for M3 Max Hardware**: Set appropriate thread pool size and memory limits for M3 Max hardware.

4. **Use Circuit Breaker Pattern**: Implement circuit breakers for resilient service communication.

5. **Create Coherence Markers**: Use coherence markers to track system state changes and verify successful operations.

## Troubleshooting

### Common Issues

1. **Missing Executable Permissions**:
   - Error: "Permission denied"
   - Solution: Run `chmod +x script.sh` to make the script executable

2. **Component Not Found**:
   - Error: "Component file does not exist"
   - Solution: Verify the file path is correct and the file exists

3. **Invalid Category**:
   - Error: "Invalid category"
   - Solution: Use one of the predefined categories listed in the documentation

4. **Migration Failures**:
   - Error: "Failed to update reference"
   - Solution: Check the backup directory for the original files and verify the reference update pattern

### Restoring from Backups

If an archiving or migration operation causes issues, you can restore from backups:

1. Locate the backup directory:
   ```
   /Users/XPV/Desktop/anchor-core/backups/[timestamp]/
   ```

2. Copy the original files back to their locations:
   ```bash
   cp /Users/XPV/Desktop/anchor-core/backups/[timestamp]/[file] /original/path/[file]
   ```

## Reference

### Directory Structure

```
/Users/XPV/Desktop/anchor-core/
├── meta-protocols/                # Archiving protocol tools
│   ├── analyze-archive-candidates.sh
│   ├── archive-component.sh
│   ├── bulk-archive-components.sh
│   ├── create-replacement-component.sh
│   ├── archive-dashboard.sh
│   ├── identify-archive-candidates.sh
│   └── component-migration-manager.sh
├── archive/                       # Archived components
│   ├── module-system-conflicts/
│   ├── socket-connectivity-issues/
│   ├── schema-validation-errors/
│   ├── process-management-issues/
│   ├── performance-bottlenecks/
│   ├── deprecated-implementations/
│   └── obsolete-configurations/
├── analysis/                     # Analysis reports and candidates
├── backups/                      # Component backups
├── coherence_lock/               # Coherence markers
└── archival-protocol-controller.sh # Main controller script
```

### Command Reference

#### Analysis Commands

```bash
# Log-based analysis
./meta-protocols/analyze-archive-candidates.sh [days] [threshold]

# Source code analysis
./meta-protocols/identify-archive-candidates.sh

# Archiving dashboard
./meta-protocols/archive-dashboard.sh
```

#### Archiving Commands

```bash
# Archive single component
./meta-protocols/archive-component.sh [component_path] [category] [reason] [replacement_path]

# Bulk archive
./meta-protocols/bulk-archive-components.sh [component_list_file]

# Create replacement
./meta-protocols/create-replacement-component.sh [archived_path] [replacement_path] [type]

# Migration manager
./meta-protocols/component-migration-manager.sh -f [migration_file] [options]
```

#### Controller Command

```bash
# Launch the archiving protocol controller
./archival-protocol-controller.sh
```

## Conclusion

The Anchor V6 Archiving Protocol provides a systematic approach to managing component lifecycle and maintaining system coherence. By following the workflows and best practices outlined in this guide, you can effectively identify, archive, and replace components to improve system stability, performance, and maintainability.

For more detailed information, refer to the comprehensive protocol documentation in `SYSTEMATIC_ARCHIVING_PROTOCOL.md`.
