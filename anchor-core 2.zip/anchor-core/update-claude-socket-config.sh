#!/bin/bash
# update-claude-socket-config.sh - Update Claude configuration
# © 2025 XPV - MIT

set -e  # Exit on error

# Define paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
SOCKET_DIR="${ANCHOR_HOME}/sockets"
CONFIG_DIR="${HOME}/Library/Application Support/Claude"
CONFIG_FILE="${CONFIG_DIR}/claude_desktop_config.json"

echo "🔧 Updating Claude socket configuration..."

# Create config directory if it doesn't exist
mkdir -p "${CONFIG_DIR}"

# Create a backup of existing config
if [ -f "${CONFIG_FILE}" ]; then
  cp "${CONFIG_FILE}" "${CONFIG_FILE}.bak.$(date +%Y%m%d%H%M%S)"
  echo "📦 Backed up existing configuration"
fi

# Define the absolute socket paths
GIT_LOCAL_SOCKET="${SOCKET_DIR}/git-local.sock"
NOTION_SOCKET="${SOCKET_DIR}/notion.sock"
ANCHOR_MANAGER_SOCKET="${SOCKET_DIR}/anchor-manager.sock"

# Create a new configuration with the correct socket paths
cat > "${CONFIG_FILE}" << EOL
{
  "mcpServers": {
    "git-local": {
      "socketPath": "${GIT_LOCAL_SOCKET}"
    },
    "notion": {
      "socketPath": "${NOTION_SOCKET}"
    },
    "anchor-manager": {
      "socketPath": "${ANCHOR_MANAGER_SOCKET}"
    }
  }
}
EOL

echo "✅ Updated Claude configuration with correct socket paths:"
echo "  - git-local: ${GIT_LOCAL_SOCKET}"
echo "  - notion: ${NOTION_SOCKET}"
echo "  - anchor-manager: ${ANCHOR_MANAGER_SOCKET}"
echo
echo "Now you should:"
echo "1. Run: ./socket-server-launcher.sh"
echo "2. Restart Claude if it's already running"
echo "3. Check Developer settings in Claude"
