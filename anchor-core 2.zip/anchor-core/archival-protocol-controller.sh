#!/bin/bash
# archival-protocol-controller.sh - Master control script for all archiving operations
# This script provides a unified interface to all archiving protocol operations

# Set strict error handling
set -e

# ANSI color codes for output formatting
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Make this script executable
chmod +x $0

# Print banner
echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║               ANCHOR V6 ARCHIVAL PROTOCOL CONTROLLER           ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"

# Define paths
META_PROTOCOLS_DIR="/Users/XPV/Desktop/anchor-core/meta-protocols"
ARCHIVE_DIR="/Users/XPV/Desktop/anchor-core/archive"
COHERENCE_DIR="/Users/XPV/Desktop/anchor-core/coherence_lock"
ANALYSIS_DIR="/Users/XPV/Desktop/anchor-core/analysis"

# Verify required directories exist
mkdir -p "$ARCHIVE_DIR"
mkdir -p "$COHERENCE_DIR"
mkdir -p "$ANALYSIS_DIR"

# Make all protocol scripts executable
chmod +x "$META_PROTOCOLS_DIR/analyze-archive-candidates.sh" 2>/dev/null || true
chmod +x "$META_PROTOCOLS_DIR/archive-component.sh" 2>/dev/null || true
chmod +x "$META_PROTOCOLS_DIR/bulk-archive-components.sh" 2>/dev/null || true
chmod +x "$META_PROTOCOLS_DIR/create-replacement-component.sh" 2>/dev/null || true
chmod +x "$META_PROTOCOLS_DIR/archive-dashboard.sh" 2>/dev/null || true
chmod +x "$META_PROTOCOLS_DIR/identify-archive-candidates.sh" 2>/dev/null || true
chmod +x "$META_PROTOCOLS_DIR/component-migration-manager.sh" 2>/dev/null || true

# Function to show menu
show_menu() {
    clear
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║               ANCHOR V6 ARCHIVAL PROTOCOL CONTROLLER           ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${CYAN}Available Operations:${NC}"
    echo ""
    echo -e "${YELLOW}Analysis:${NC}"
    echo "  1) Run log-based analysis for archive candidates"
    echo "  2) Run source code analysis for archive candidates"
    echo "  3) View archiving dashboard"
    echo ""
    echo -e "${YELLOW}Archiving:${NC}"
    echo "  4) Archive a single component"
    echo "  5) Bulk archive multiple components"
    echo ""
    echo -e "${YELLOW}Replacement:${NC}"
    echo "  6) Create a replacement component"
    echo "  7) Run migration manager"
    echo ""
    echo -e "${YELLOW}System:${NC}"
    echo "  8) Verify system integrity"
    echo "  9) View coherence markers"
    echo " 10) View archived components"
    echo ""
    echo "  0) Exit"
    echo ""
    echo -e "${CYAN}Enter your choice [0-10]:${NC} "
}

# Function to analyze for archive candidates
run_analysis() {
    clear
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                 LOG-BASED ARCHIVE CANDIDATE ANALYSIS           ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${CYAN}This operation analyzes logs to identify components with frequent errors.${NC}"
    echo ""
    
    read -p "Enter days to analyze [default: 30]: " days
    days=${days:-30}
    
    read -p "Enter minimum error threshold [default: 3]: " threshold
    threshold=${threshold:-3}
    
    echo ""
    echo -e "${CYAN}Running analysis with parameters:${NC}"
    echo -e "  Days: $days"
    echo -e "  Threshold: $threshold"
    echo ""
    
    "$META_PROTOCOLS_DIR/analyze-archive-candidates.sh" "$days" "$threshold"
    
    echo ""
    read -p "Press Enter to continue..."
    show_menu
}

# Function to run source code analysis
run_source_analysis() {
    clear
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                 SOURCE CODE ARCHIVE CANDIDATE ANALYSIS         ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${CYAN}This operation analyzes source code to identify problematic components.${NC}"
    echo ""
    
    "$META_PROTOCOLS_DIR/identify-archive-candidates.sh"
    
    echo ""
    read -p "Press Enter to continue..."
    show_menu
}

# Function to view archiving dashboard
view_dashboard() {
    clear
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                    ARCHIVING DASHBOARD                         ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${CYAN}This operation generates and displays the archiving dashboard.${NC}"
    echo ""
    
    "$META_PROTOCOLS_DIR/archive-dashboard.sh"
    
    echo ""
    read -p "Press Enter to continue..."
    show_menu
}

# Function to archive a single component
archive_component() {
    clear
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                   ARCHIVE SINGLE COMPONENT                     ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${CYAN}This operation archives a single component.${NC}"
    echo ""
    
    read -p "Enter component path: " component_path
    
    if [ -z "$component_path" ]; then
        echo -e "${RED}Component path is required${NC}"
        echo ""
        read -p "Press Enter to continue..."
        archive_component
        return
    fi
    
    if [ ! -f "$component_path" ]; then
        echo -e "${RED}Component file does not exist: $component_path${NC}"
        echo ""
        read -p "Press Enter to continue..."
        archive_component
        return
    fi
    
    echo ""
    echo -e "${YELLOW}Available categories:${NC}"
    echo "  1) module-system-conflicts"
    echo "  2) socket-connectivity-issues"
    echo "  3) schema-validation-errors"
    echo "  4) process-management-issues"
    echo "  5) performance-bottlenecks"
    echo "  6) deprecated-implementations"
    echo "  7) obsolete-configurations"
    echo ""
    read -p "Enter category number [1-7]: " category_num
    
    case $category_num in
        1) category="module-system-conflicts" ;;
        2) category="socket-connectivity-issues" ;;
        3) category="schema-validation-errors" ;;
        4) category="process-management-issues" ;;
        5) category="performance-bottlenecks" ;;
        6) category="deprecated-implementations" ;;
        7) category="obsolete-configurations" ;;
        *) 
            echo -e "${RED}Invalid category number${NC}"
            echo ""
            read -p "Press Enter to continue..."
            archive_component
            return
            ;;
    esac
    
    read -p "Enter reason for archiving: " reason
    
    if [ -z "$reason" ]; then
        echo -e "${RED}Reason is required${NC}"
        echo ""
        read -p "Press Enter to continue..."
        archive_component
        return
    fi
    
    read -p "Enter replacement path (optional): " replacement_path
    
    echo ""
    echo -e "${CYAN}Archiving component with parameters:${NC}"
    echo -e "  Component: $component_path"
    echo -e "  Category: $category"
    echo -e "  Reason: $reason"
    echo -e "  Replacement: ${replacement_path:-None}"
    echo ""
    
    "$META_PROTOCOLS_DIR/archive-component.sh" "$component_path" "$category" "$reason" "${replacement_path:-None}"
    
    echo ""
    read -p "Press Enter to continue..."
    show_menu
}

# Function to bulk archive components
bulk_archive() {
    clear
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                   BULK ARCHIVE COMPONENTS                      ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${CYAN}This operation archives multiple components listed in a CSV file.${NC}"
    echo ""
    
    # List available CSV files in analysis directory
    echo -e "${YELLOW}Available CSV files in analysis directory:${NC}"
    csv_files=$(find "$ANALYSIS_DIR" -name "*.csv" | sort -r)
    
    if [ -z "$csv_files" ]; then
        echo -e "${RED}No CSV files found in analysis directory${NC}"
        echo ""
        read -p "Press Enter to continue..."
        show_menu
        return
    fi
    
    # Display CSV files with numbers
    count=1
    declare -a csv_array
    while read -r file; do
        echo "  $count) $(basename "$file") ($(date -r "$file" "+%Y-%m-%d %H:%M"))"
        csv_array[$count]="$file"
        count=$((count + 1))
    done <<< "$csv_files"
    
    echo ""
    read -p "Enter file number or full path to CSV file: " file_input
    
    # Determine file path
    if [[ "$file_input" =~ ^[0-9]+$ ]] && [ "$file_input" -gt 0 ] && [ "$file_input" -lt "$count" ]; then
        file_path="${csv_array[$file_input]}"
    else
        file_path="$file_input"
    fi
    
    if [ ! -f "$file_path" ]; then
        echo -e "${RED}File does not exist: $file_path${NC}"
        echo ""
        read -p "Press Enter to continue..."
        bulk_archive
        return
    fi
    
    echo ""
    echo -e "${CYAN}Bulk archiving components from:${NC} $file_path"
    echo ""
    
    "$META_PROTOCOLS_DIR/bulk-archive-components.sh" "$file_path"
    
    echo ""
    read -p "Press Enter to continue..."
    show_menu
}

# Function to create a replacement component
create_replacement() {
    clear
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                 CREATE REPLACEMENT COMPONENT                   ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${CYAN}This operation creates a replacement for an archived component.${NC}"
    echo ""
    
    # Show recently archived components
    echo -e "${YELLOW}Recently archived components:${NC}"
    recently_archived=$(find "$COHERENCE_DIR" -name "ARCHIVED_*" -type f -printf "%T@ %p\n" | sort -nr | head -5)
    
    if [ -n "$recently_archived" ]; then
        count=1
        declare -a archived_array
        while read -r line; do
            marker_file=$(echo "$line" | cut -d' ' -f2-)
            component=$(basename "$marker_file" | sed 's/ARCHIVED_//' | sed 's/_.*.marker//')
            archived_date=$(date -r "$marker_file" "+%Y-%m-%d %H:%M")
            
            # Try to find the archived component
            archived_path=""
            for cat_dir in "$ARCHIVE_DIR"/*; do
                if [ -d "$cat_dir" ]; then
                    for archived_file in $(find "$cat_dir" -name "${component}*" -not -name "*.meta"); do
                        if [ -f "$archived_file" ]; then
                            archived_path="$archived_file"
                            break
                        fi
                    done
                    if [ -n "$archived_path" ]; then
                        break
                    fi
                fi
            done
            
            if [ -n "$archived_path" ]; then
                echo "  $count) $component ($archived_date)"
                archived_array[$count]="$archived_path"
                count=$((count + 1))
            fi
        done <<< "$recently_archived"
        
        if [ $count -eq 1 ]; then
            echo "  None found"
        fi
    else
        echo "  None found"
    fi
    
    echo ""
    read -p "Enter archived component path or number: " archived_input
    
    # Determine archived path
    if [[ "$archived_input" =~ ^[0-9]+$ ]] && [ "$archived_input" -gt 0 ] && [ "$archived_input" -lt "$count" ]; then
        archived_path="${archived_array[$archived_input]}"
    else
        archived_path="$archived_input"
    fi
    
    if [ ! -f "$archived_path" ]; then
        echo -e "${RED}Archived component does not exist: $archived_path${NC}"
        echo ""
        read -p "Press Enter to continue..."
        create_replacement
        return
    fi
    
    read -p "Enter replacement component path: " replacement_path
    
    if [ -z "$replacement_path" ]; then
        echo -e "${RED}Replacement path is required${NC}"
        echo ""
        read -p "Press Enter to continue..."
        create_replacement
        return
    fi
    
    echo ""
    echo -e "${YELLOW}Available component types:${NC}"
    echo "  1) server        (Socket server implementation)"
    echo "  2) schema        (Schema registry component)"
    echo "  3) transformer   (Data transformer component)"
    echo "  4) connection    (Connection manager component)"
    echo "  5) orchestrator  (MCP orchestrator component)"
    echo "  6) circuit       (Circuit breaker component)"
    echo "  7) generic       (Generic component with basic structure)"
    echo ""
    read -p "Enter component type number [1-7]: " type_num
    
    case $type_num in
        1) component_type="server" ;;
        2) component_type="schema" ;;
        3) component_type="transformer" ;;
        4) component_type="connection" ;;
        5) component_type="orchestrator" ;;
        6) component_type="circuit" ;;
        7) component_type="generic" ;;
        *) 
            echo -e "${RED}Invalid component type number${NC}"
            echo ""
            read -p "Press Enter to continue..."
            create_replacement
            return
            ;;
    esac
    
    echo ""
    echo -e "${CYAN}Creating replacement component with parameters:${NC}"
    echo -e "  Archived Component: $archived_path"
    echo -e "  Replacement Path: $replacement_path"
    echo -e "  Component Type: $component_type"
    echo ""
    
    "$META_PROTOCOLS_DIR/create-replacement-component.sh" "$archived_path" "$replacement_path" "$component_type"
    
    echo ""
    read -p "Press Enter to continue..."
    show_menu
}

# Function to run migration manager
run_migration() {
    clear
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                    COMPONENT MIGRATION MANAGER                 ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${CYAN}This operation manages the migration of archived components.${NC}"
    echo ""
    
    # Create migration file template if needed
    TIMESTAMP=$(date +"%Y%m%d%H%M%S")
    MIGRATION_FILE="$ANALYSIS_DIR/migration-plan-$TIMESTAMP.csv"
    
    echo "original_component,replacement_component,reason" > "$MIGRATION_FILE"
    echo "" >> "$MIGRATION_FILE"
    
    # Prompt to add entries
    echo -e "${YELLOW}Creating migration plan...${NC}"
    echo -e "Enter component details (empty original_component to finish):"
    echo ""
    
    while true; do
        read -p "Original component path: " original
        
        if [ -z "$original" ]; then
            break
        fi
        
        read -p "Replacement component path: " replacement
        read -p "Reason for migration: " reason
        
        echo "$original,$replacement,$reason" >> "$MIGRATION_FILE"
        echo "" >> "$MIGRATION_FILE"
        echo -e "${GREEN}✓ Entry added to migration plan${NC}"
        echo ""
    done
    
    # Check if migration file has entries
    entry_count=$(grep -v "^original_component" "$MIGRATION_FILE" | grep -v "^$" | wc -l)
    
    if [ "$entry_count" -eq 0 ]; then
        echo -e "${YELLOW}Migration plan is empty. Operation cancelled.${NC}"
        rm "$MIGRATION_FILE"
        echo ""
        read -p "Press Enter to continue..."
        show_menu
        return
    fi
    
    # Ask if dry run
    echo ""
    read -p "Perform a dry run first (recommended)? [Y/n]: " dry_run_choice
    dry_run_choice=${dry_run_choice:-"y"}
    
    dry_run_flag=""
    if [[ "$dry_run_choice" =~ ^[Yy] ]]; then
        dry_run_flag="--dry-run"
    fi
    
    # Ask if verify after
    echo ""
    read -p "Verify system after migration? [Y/n]: " verify_choice
    verify_choice=${verify_choice:-"y"}
    
    verify_flag=""
    if [[ "$verify_choice" =~ ^[Nn] ]]; then
        verify_flag="--no-verify"
    fi
    
    echo ""
    echo -e "${CYAN}Running migration manager with parameters:${NC}"
    echo -e "  Migration File: $MIGRATION_FILE"
    echo -e "  Dry Run: ${dry_run_flag:+Yes}"
    echo -e "  Verify After: ${verify_flag:+No}"
    echo ""
    
    "$META_PROTOCOLS_DIR/component-migration-manager.sh" -f "$MIGRATION_FILE" $dry_run_flag $verify_flag
    
    echo ""
    read -p "Press Enter to continue..."
    show_menu
}

# Function to verify system integrity
verify_system() {
    clear
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                      SYSTEM VERIFICATION                       ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${CYAN}This operation verifies system integrity after archiving operations.${NC}"
    echo ""
    
    VERIFY_SCRIPT="/Users/XPV/Desktop/anchor-core/mcp-servers/verify-servers.sh"
    
    if [ ! -f "$VERIFY_SCRIPT" ]; then
        echo -e "${RED}Verification script not found: $VERIFY_SCRIPT${NC}"
        echo ""
        read -p "Press Enter to continue..."
        show_menu
        return
    fi
    
    chmod +x "$VERIFY_SCRIPT"
    
    echo -e "${CYAN}Running system verification...${NC}"
    echo ""
    
    "$VERIFY_SCRIPT"
    
    echo ""
    read -p "Press Enter to continue..."
    show_menu
}

# Function to view coherence markers
view_markers() {
    clear
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                     COHERENCE MARKERS                          ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${CYAN}This operation displays coherence markers related to archiving operations.${NC}"
    echo ""
    
    if [ ! -d "$COHERENCE_DIR" ]; then
        echo -e "${RED}Coherence directory not found: $COHERENCE_DIR${NC}"
        echo ""
        read -p "Press Enter to continue..."
        show_menu
        return
    fi
    
    # Count markers by type
    archive_count=$(find "$COHERENCE_DIR" -name "ARCHIVED_*" | wc -l)
    migration_count=$(find "$COHERENCE_DIR" -name "MIGRATION_*" | wc -l)
    analysis_count=$(find "$COHERENCE_DIR" -name "*ANALYSIS_*" | wc -l)
    dashboard_count=$(find "$COHERENCE_DIR" -name "*DASHBOARD_*" | wc -l)
    replacement_count=$(find "$COHERENCE_DIR" -name "REPLACEMENT_*" | wc -l)
    
    echo -e "${YELLOW}Marker Summary:${NC}"
    echo -e "  Archive Operations: $archive_count"
    echo -e "  Migration Operations: $migration_count"
    echo -e "  Analysis Operations: $analysis_count"
    echo -e "  Dashboard Operations: $dashboard_count"
    echo -e "  Replacement Operations: $replacement_count"
    echo ""
    
    echo -e "${YELLOW}Recent Markers:${NC}"
    recent_markers=$(find "$COHERENCE_DIR" -type f -printf "%T@ %p\n" | sort -nr | head -10)
    
    if [ -z "$recent_markers" ]; then
        echo "  No markers found"
    else
        while read -r line; do
            marker_file=$(echo "$line" | cut -d' ' -f2-)
            marker_date=$(date -r "$marker_file" "+%Y-%m-%d %H:%M:%S")
            marker_name=$(basename "$marker_file")
            
            echo -e "  ${CYAN}$marker_date${NC} - $marker_name"
        done <<< "$recent_markers"
    fi
    
    echo ""
    echo -e "${YELLOW}Filter markers by type:${NC}"
    echo "  1) Archived components"
    echo "  2) Migrations"
    echo "  3) Analysis operations"
    echo "  4) Dashboard operations"
    echo "  5) Replacement operations"
    echo "  0) Back to menu"
    echo ""
    read -p "Enter filter number [0-5]: " filter_num
    
    case $filter_num in
        0) 
            show_menu
            return
            ;;
        1) marker_pattern="ARCHIVED_*" ;;
        2) marker_pattern="MIGRATION_*" ;;
        3) marker_pattern="*ANALYSIS_*" ;;
        4) marker_pattern="*DASHBOARD_*" ;;
        5) marker_pattern="REPLACEMENT_*" ;;
        *) 
            echo -e "${RED}Invalid filter number${NC}"
            echo ""
            read -p "Press Enter to continue..."
            view_markers
            return
            ;;
    esac
    
    clear
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                  FILTERED COHERENCE MARKERS                    ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    filtered_markers=$(find "$COHERENCE_DIR" -name "$marker_pattern" -type f -printf "%T@ %p\n" | sort -nr)
    
    if [ -z "$filtered_markers" ]; then
        echo "No markers found matching pattern: $marker_pattern"
    else
        while read -r line; do
            marker_file=$(echo "$line" | cut -d' ' -f2-)
            marker_date=$(date -r "$marker_file" "+%Y-%m-%d %H:%M:%S")
            marker_name=$(basename "$marker_file")
            
            echo -e "${CYAN}$marker_date${NC} - $marker_name"
        done <<< "$filtered_markers"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
    view_markers
}

# Function to view archived components
view_archived() {
    clear
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                    ARCHIVED COMPONENTS                         ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${CYAN}This operation displays components that have been archived.${NC}"
    echo ""
    
    if [ ! -d "$ARCHIVE_DIR" ]; then
        echo -e "${RED}Archive directory not found: $ARCHIVE_DIR${NC}"
        echo ""
        read -p "Press Enter to continue..."
        show_menu
        return
    fi
    
    # Count components by category
    module_count=$(find "$ARCHIVE_DIR/module-system-conflicts" -type f -not -name "*.meta" -not -name "README.md" 2>/dev/null | wc -l || echo 0)
    socket_count=$(find "$ARCHIVE_DIR/socket-connectivity-issues" -type f -not -name "*.meta" -not -name "README.md" 2>/dev/null | wc -l || echo 0)
    schema_count=$(find "$ARCHIVE_DIR/schema-validation-errors" -type f -not -name "*.meta" -not -name "README.md" 2>/dev/null | wc -l || echo 0)
    process_count=$(find "$ARCHIVE_DIR/process-management-issues" -type f -not -name "*.meta" -not -name "README.md" 2>/dev/null | wc -l || echo 0)
    perf_count=$(find "$ARCHIVE_DIR/performance-bottlenecks" -type f -not -name "*.meta" -not -name "README.md" 2>/dev/null | wc -l || echo 0)
    deprecated_count=$(find "$ARCHIVE_DIR/deprecated-implementations" -type f -not -name "*.meta" -not -name "README.md" 2>/dev/null | wc -l || echo 0)
    obsolete_count=$(find "$ARCHIVE_DIR/obsolete-configurations" -type f -not -name "*.meta" -not -name "README.md" 2>/dev/null | wc -l || echo 0)
    legacy_count=$(find "$ARCHIVE_DIR/deprecated-js-files" -type f 2>/dev/null | wc -l || echo 0)
    dup_count=$(find "$ARCHIVE_DIR/duplicate-config" -type f 2>/dev/null | wc -l || echo 0)
    
    total_count=$((module_count + socket_count + schema_count + process_count + perf_count + deprecated_count + obsolete_count + legacy_count + dup_count))
    
    echo -e "${YELLOW}Archive Summary:${NC}"
    echo -e "  Module System Conflicts: $module_count"
    echo -e "  Socket Connectivity Issues: $socket_count"
    echo -e "  Schema Validation Errors: $schema_count"
    echo -e "  Process Management Issues: $process_count"
    echo -e "  Performance Bottlenecks: $perf_count"
    echo -e "  Deprecated Implementations: $deprecated_count"
    echo -e "  Obsolete Configurations: $obsolete_count"
    echo -e "  Legacy JS Files: $legacy_count"
    echo -e "  Duplicate Configs: $dup_count"
    echo -e "  ${CYAN}Total Archived Components: $total_count${NC}"
    echo ""
    
    echo -e "${YELLOW}View components by category:${NC}"
    echo "  1) Module System Conflicts"
    echo "  2) Socket Connectivity Issues"
    echo "  3) Schema Validation Errors"
    echo "  4) Process Management Issues"
    echo "  5) Performance Bottlenecks"
    echo "  6) Deprecated Implementations"
    echo "  7) Obsolete Configurations"
    echo "  8) Legacy JS Files"
    echo "  9) Duplicate Configs"
    echo "  0) Back to menu"
    echo ""
    read -p "Enter category number [0-9]: " category_num
    
    case $category_num in
        0) 
            show_menu
            return
            ;;
        1) category_dir="$ARCHIVE_DIR/module-system-conflicts" ;;
        2) category_dir="$ARCHIVE_DIR/socket-connectivity-issues" ;;
        3) category_dir="$ARCHIVE_DIR/schema-validation-errors" ;;
        4) category_dir="$ARCHIVE_DIR/process-management-issues" ;;
        5) category_dir="$ARCHIVE_DIR/performance-bottlenecks" ;;
        6) category_dir="$ARCHIVE_DIR/deprecated-implementations" ;;
        7) category_dir="$ARCHIVE_DIR/obsolete-configurations" ;;
        8) category_dir="$ARCHIVE_DIR/deprecated-js-files" ;;
        9) category_dir="$ARCHIVE_DIR/duplicate-config" ;;
        *) 
            echo -e "${RED}Invalid category number${NC}"
            echo ""
            read -p "Press Enter to continue..."
            view_archived
            return
            ;;
    esac
    
    clear
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                 ARCHIVED COMPONENTS BY CATEGORY                ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    category_name=$(basename "$category_dir")
    echo -e "${CYAN}Category: $category_name${NC}"
    echo ""
    
    if [ ! -d "$category_dir" ]; then
        echo "No components found in this category"
    else
        # Display components
        components=$(find "$category_dir" -type f -not -name "*.meta" -not -name "README.md" -printf "%T@ %p\n" | sort -nr)
        
        if [ -z "$components" ]; then
            echo "No components found in this category"
        else
            echo -e "${YELLOW}Components:${NC}"
            echo ""
            
            while read -r line; do
                component_file=$(echo "$line" | cut -d' ' -f2-)
                component_date=$(date -r "$component_file" "+%Y-%m-%d %H:%M:%S")
                component_name=$(basename "$component_file")
                
                echo -e "${CYAN}$component_name${NC}"
                echo -e "  Archived on: $component_date"
                
                # Check if metadata exists
                meta_file="${component_file}.meta"
                if [ -f "$meta_file" ]; then
                    reason=$(grep "REASON:" "$meta_file" | cut -d':' -f2- | sed 's/^ //')
                    replacement=$(grep "REPLACEMENT:" "$meta_file" | cut -d':' -f2- | sed 's/^ //')
                    
                    echo -e "  Reason: $reason"
                    if [ -n "$replacement" ] && [ "$replacement" != "None" ]; then
                        echo -e "  Replacement: $replacement"
                    fi
                fi
                
                echo ""
            done <<< "$components"
        fi
    fi
    
    echo ""
    read -p "Press Enter to continue..."
    view_archived
}

# Main program
show_menu

# Process menu choice
while true; do
    read choice
    
    case $choice in
        0) 
            exit 0
            ;;
        1)
            run_analysis
            ;;
        2)
            run_source_analysis
            ;;
        3)
            view_dashboard
            ;;
        4)
            archive_component
            ;;
        5)
            bulk_archive
            ;;
        6)
            create_replacement
            ;;
        7)
            run_migration
            ;;
        8)
            verify_system
            ;;
        9)
            view_markers
            ;;
        10)
            view_archived
            ;;
        *)
            echo -e "${RED}Invalid option${NC}"
            sleep 1
            show_menu
            ;;
    esac
done
