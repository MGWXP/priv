#!/bin/bash
# CNIF Complete Fix Script - Resolves all issues and configures Notion integration
# Created: 2025-05-19

# Define colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Define variables
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
SOCKET_DIR="$ANCHOR_HOME/sockets"
LOG_DIR="/Users/XPV/Library/Logs/Claude"
SRC_DIR="$ANCHOR_HOME/src"
NOTION_TOKEN="secret_kEEhD6D1RhscCGxLZVMzx1a3Av85XsWGkSKueMOq6m8"  # Replace with your actual token
NOTION_PAGE_ID="d56b9aa6e27149fd9ccc0fc3adf2c89d"  # Default page ID, replace if needed

# Print banner
echo -e "${BLUE}======================================================${NC}"
echo -e "${BLUE}  CNIF - Claude-Notion Integration Framework${NC}"
echo -e "${BLUE}  Complete Fix and Configuration Script${NC}"
echo -e "${BLUE}======================================================${NC}"

# Step 1: Stop all running processes
echo -e "${YELLOW}Step 1: Stopping all running processes...${NC}"
if [ -f "$ANCHOR_HOME/webbridge.pid" ]; then
  kill $(cat "$ANCHOR_HOME/webbridge.pid") 2>/dev/null || true
  rm -f "$ANCHOR_HOME/webbridge.pid"
  echo -e "${GREEN}✓ Stopped WebSocket bridge${NC}"
fi

if [ -f "$ANCHOR_HOME/notion-sync.pid" ]; then
  kill $(cat "$ANCHOR_HOME/notion-sync.pid") 2>/dev/null || true
  rm -f "$ANCHOR_HOME/notion-sync.pid"
  echo -e "${GREEN}✓ Stopped Notion sync${NC}"
fi

if [ -f "$ANCHOR_HOME/dashboard.pid" ]; then
  kill $(cat "$ANCHOR_HOME/dashboard.pid") 2>/dev/null || true
  rm -f "$ANCHOR_HOME/dashboard.pid"
  echo -e "${GREEN}✓ Stopped dashboard server${NC}"
fi

# Step 2: Create Notion token directory and set API token
echo -e "${YELLOW}Step 2: Setting up Notion API token...${NC}"
mkdir -p "$HOME/.notion"
echo "$NOTION_TOKEN" > "$HOME/.notion/token"
chmod 600 "$HOME/.notion/token"
echo -e "${GREEN}✓ Set up Notion API token${NC}"

# Step 3: Create necessary directories
echo -e "${YELLOW}Step 3: Creating necessary directories...${NC}"
mkdir -p "$SOCKET_DIR" "$LOG_DIR" "$SRC_DIR/webbridge" "$SRC_DIR/dashboard" "$ANCHOR_HOME/data" "$ANCHOR_HOME/data/notion-cache"
echo -e "${GREEN}✓ Created all required directories${NC}"

# Step 4: Create Notion database configuration
echo -e "${YELLOW}Step 4: Configuring Notion database settings...${NC}"
cat > "$ANCHOR_HOME/data/notion-config.json" << EOF
{
  "rootPageId": "$NOTION_PAGE_ID",
  "enabledDatabases": [],
  "syncInterval": 30000,
  "rateLimitPerSecond": 3
}
EOF
echo -e "${GREEN}✓ Created Notion database configuration${NC}"

# Step 5: Make all scripts executable
echo -e "${YELLOW}Step 5: Making scripts executable...${NC}"
chmod +x "$ANCHOR_HOME/start-webbridge.sh"
chmod +x "$ANCHOR_HOME/verify-cnif.sh"
echo -e "${GREEN}✓ Made scripts executable${NC}"

# Step 6: Update environment file
echo -e "${YELLOW}Step 6: Setting up environment configuration...${NC}"
cat > "$ANCHOR_HOME/.env" << EOF
# CNIF Environment Configuration
NOTION_API_TOKEN=$NOTION_TOKEN
NOTION_PAGE_ID=$NOTION_PAGE_ID
SOCKET_DIR=$SOCKET_DIR
LOG_DIR=$LOG_DIR
WS_PORT=8765
NOTION_SYNC_INTERVAL=30000
ENABLE_DASHBOARD=true
ENABLE_NOTION_SYNC=true
ENABLE_HTTP2=true
NODE_OPTIONS="--max-old-space-size=8192"
UV_THREADPOOL_SIZE=16
NODE_PERFORMANCE_MODE="high"
EOF
echo -e "${GREEN}✓ Created environment configuration${NC}"

# Step 7: Start the services
echo -e "${YELLOW}Step 7: Starting all services...${NC}"
cd "$ANCHOR_HOME"
source "$ANCHOR_HOME/.env"
export NOTION_API_TOKEN SOCKET_DIR LOG_DIR WS_PORT NOTION_SYNC_INTERVAL NODE_OPTIONS UV_THREADPOOL_SIZE NODE_PERFORMANCE_MODE

# Make sure npm dependencies are installed
echo "Checking for required Node.js modules..."
npm install --silent ws express uuid http2-express-bridge @notionhq/client limiter sqlite3 sqlite

# Start the WebSocket bridge
echo "Starting WebSocket bridge..."
node "$SRC_DIR/webbridge/socket-bridge.js" > "$LOG_DIR/webbridge-$(date +%Y%m%d).log" 2>&1 &
SOCKET_BRIDGE_PID=$!
echo $SOCKET_BRIDGE_PID > "$ANCHOR_HOME/webbridge.pid"
echo -e "${GREEN}✓ Started WebSocket bridge with PID $SOCKET_BRIDGE_PID${NC}"
sleep 2

# Start Notion sync
echo "Starting Notion sync..."
node "$SRC_DIR/webbridge/notion-sync.js" > "$LOG_DIR/notion-sync-$(date +%Y%m%d).log" 2>&1 &
NOTION_SYNC_PID=$!
echo $NOTION_SYNC_PID > "$ANCHOR_HOME/notion-sync.pid"
echo -e "${GREEN}✓ Started Notion sync with PID $NOTION_SYNC_PID${NC}"
sleep 1

# Start dashboard
echo "Starting dashboard server..."
cd "$ANCHOR_HOME/dashboard"
npm start > "$LOG_DIR/dashboard-$(date +%Y%m%d).log" 2>&1 &
DASHBOARD_PID=$!
echo $DASHBOARD_PID > "$ANCHOR_HOME/dashboard.pid"
echo -e "${GREEN}✓ Started dashboard server with PID $DASHBOARD_PID${NC}"

# Step 8: Verify all services are running
echo -e "${YELLOW}Step 8: Verifying all services...${NC}"
cd "$ANCHOR_HOME"
if ps -p $SOCKET_BRIDGE_PID > /dev/null; then
  echo -e "${GREEN}✓ WebSocket bridge is running${NC}"
else
  echo -e "${RED}✗ WebSocket bridge is not running. Check logs at $LOG_DIR/webbridge-$(date +%Y%m%d).log${NC}"
fi

if ps -p $NOTION_SYNC_PID > /dev/null; then
  echo -e "${GREEN}✓ Notion sync is running${NC}"
else
  echo -e "${RED}✗ Notion sync is not running. Check logs at $LOG_DIR/notion-sync-$(date +%Y%m%d).log${NC}"
fi

if ps -p $DASHBOARD_PID > /dev/null; then
  echo -e "${GREEN}✓ Dashboard server is running${NC}"
else
  echo -e "${RED}✗ Dashboard server is not running. Check logs at $LOG_DIR/dashboard-$(date +%Y%m%d).log${NC}"
fi

# Final summary
echo -e "${BLUE}======================================================${NC}"
echo -e "${GREEN}✓ CNIF Configuration Complete${NC}"
echo -e "${BLUE}Dashboard: http://localhost:8765${NC}"
echo -e "${BLUE}Socket Directory: $SOCKET_DIR${NC}"
echo -e "${BLUE}Log Directory: $LOG_DIR${NC}"
echo -e "${BLUE}Notion Page ID: $NOTION_PAGE_ID${NC}"
echo -e "${BLUE}======================================================${NC}"
echo "To stop all services: bash -c 'kill \$(cat $ANCHOR_HOME/webbridge.pid $ANCHOR_HOME/notion-sync.pid $ANCHOR_HOME/dashboard.pid 2>/dev/null)'"
echo -e "${BLUE}======================================================${NC}"
