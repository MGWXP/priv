/**
 * mcp-orchestrator.js - Orchestrates communication between Claude and Notion
 * © 2025 XPV - MIT
 * 
 * Implements a comprehensive orchestration layer for Claude-Notion Integration
 * with resilience patterns, schema validation, and M3 Max optimization.
 */

const fs = require('fs');
const path = require('path');
const EventEmitter = require('events');
const { SchemaRegistry } = require('./schema-registry');
const { StreamingSchemaTransformer } = require('./streaming-schema-transformer');
const { NotionConnectionManager } = require('./notion-connection-manager');
const { CircuitBreaker } = require('./circuit-breaker');
const net = require('net');
const os = require('os');

/**
 * Message processor with memory pooling
 */
class MessageBuffer {
  constructor(options = {}) {
    this.options = {
      initialBufferSize: 65536, // 64KB
      maxBufferSize: 10 * 1024 * 1024, // 10MB
      adaptiveBuffering: true,
      ...options
    };
    
    this.buffer = '';
    this.pooledBuffers = [];
    this.useMemoryPools = typeof global.getPooledBuffer === 'function';
    
    // Track performance metrics
    this.metrics = {
      messagesProcessed: 0,
      bytesProcessed: 0,
      maxBufferSize: 0,
      poolHits: 0,
      poolMisses: 0
    };
  }
  
  /**
   * Append data to buffer
   * @param {Buffer|string} data - Data to append
   */
  append(data) {
    if (Buffer.isBuffer(data)) {
      this.buffer += data.toString('utf8');
    } else {
      this.buffer += data;
    }
    
    // Track metrics
    this.metrics.bytesProcessed += (Buffer.isBuffer(data) ? data.length : Buffer.byteLength(data));
    this.metrics.maxBufferSize = Math.max(this.metrics.maxBufferSize, this.buffer.length);
  }
  
  /**
   * Get complete messages from buffer
   * @returns {Array<string>} Array of complete messages
   */
  getMessages() {
    // No delimiter found, no complete messages
    if (!this.buffer.includes('\n')) {
      return [];
    }
    
    const messages = this.buffer.split('\n');
    this.buffer = messages.pop(); // Keep incomplete message in buffer
    
    const validMessages = messages.filter(message => message.trim());
    
    // Track metrics
    this.metrics.messagesProcessed += validMessages.length;
    
    return validMessages;
  }
  
  /**
   * Allocate a buffer from the pool
   * @param {number} size - Buffer size in bytes
   * @returns {Buffer} Allocated buffer
   */
  allocateBuffer(size) {
    if (this.useMemoryPools) {
      const buffer = global.getPooledBuffer(size);
      this.pooledBuffers.push(buffer);
      this.metrics.poolHits++;
      return buffer;
    } else {
      this.metrics.poolMisses++;
      return Buffer.allocUnsafe(size);
    }
  }
  
  /**
   * Release all allocated buffers back to the pool
   */
  releaseBuffers() {
    if (this.useMemoryPools) {
      this.pooledBuffers.forEach(buffer => {
        global.releasePooledBuffer(buffer);
      });
      this.pooledBuffers = [];
    }
  }
  
  /**
   * Get message buffer metrics
   * @returns {Object} Buffer metrics
   */
  getMetrics() {
    return {
      ...this.metrics,
      currentBufferSize: this.buffer.length,
      pooledBuffersCount: this.pooledBuffers.length
    };
  }
  
  /**
   * Clean up resources
   */
  cleanup() {
    this.releaseBuffers();
    this.buffer = '';
  }
}

/**
 * MCP Orchestrator for Claude-Notion Integration
 * Manages communication between Claude and Notion with robust error handling
 */
class MCPOrchestrator extends EventEmitter {
  /**
   * Create a new MCP Orchestrator
   * @param {Object} options - Configuration options
   */
  constructor(options = {}) {
    super();
    
    this.options = {
      socketPath: path.join(process.env.SOCKET_DIR || '/Users/XPV/Desktop/anchor-core/sockets', 'mcp-orchestrator.sock'),
      schemaDir: path.join(process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core', 'schemas'),
      configDir: path.join(process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core', 'data'),
      coherenceLockDir: path.join(process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core', 'coherence_lock'),
      socketPermissions: 0o666, // rw-rw-rw-
      maxConnections: 10,
      ...options
    };
    
    // Initialize components
    this.socketServer = null;
    this.schemaRegistry = null;
    this.schemaTransformer = null;
    this.notionConnection = null;
    this.circuitBreaker = null;
    
    // Track clients and requests
    this.clients = new Map();
    this.activeRequests = new Map();
    this.clientIdCounter = 0;
    
    // Track system metrics
    this.startTime = Date.now();
    this.metrics = {
      requestsTotal: 0,
      requestsSuccess: 0,
      requestsError: 0,
      transformationsTotal: 0,
      transformationsError: 0,
      notionRequestsTotal: 0,
      notionRequestsError: 0
    };
    
    // Check for M3 Max optimization
    this.isM3Max = this._detectM3Max();
    
    // Set up heartbeat interval
    this.heartbeatInterval = null;
    
    // Track initialization state
    this.initialized = false;
  }
  
  /**
   * Detect if running on M3 Max hardware
   * @private
   */
  _detectM3Max() {
    const cpuInfo = os.cpus()[0].model;
    const cpuCount = os.cpus().length;
    const totalMemoryGB = Math.round(os.totalmem() / (1024 * 1024 * 1024));
    
    const isAppleSilicon = cpuInfo.includes('Apple') && os.arch() === 'arm64';
    const has16Cores = cpuCount === 16;
    const has48GBMemory = totalMemoryGB >= 45 && totalMemoryGB <= 50;
    
    return isAppleSilicon && has16Cores && has48GBMemory;
  }
  
  /**
   * Initialize the orchestrator
   * @returns {Promise<boolean>} Success status
   */
  async initialize() {
    try {
      console.log('Initializing MCP Orchestrator...');
      
      // Create coherence marker
      this._createCoherenceMarker();
      
      // Initialize circuit breaker
      this.circuitBreaker = new CircuitBreaker({
        name: 'mcp-orchestrator',
        failureThreshold: 5,
        resetTimeout: 60000, // 1 minute
        degradeThreshold: 3,
        degradePercentage: 0.5 // 50%
      });
      console.log('✅ Circuit breaker initialized');
      
      // Initialize schema registry
      this.schemaRegistry = new SchemaRegistry({
        schemaDirClaude: path.join(this.options.schemaDir, 'claude'),
        schemaDirNotion: path.join(this.options.schemaDir, 'notion'),
        cacheEnabled: true,
        validateOnLoad: true
      });
      
      await this.schemaRegistry.initialize();
      console.log('✅ Schema registry initialized');
      
      // Initialize schema transformer
      this.schemaTransformer = new StreamingSchemaTransformer({
        schemaRegistry: this.schemaRegistry,
        useWorkers: true,
        adaptiveBuffering: true
      });
      console.log('✅ Schema transformer initialized');
      
      // Initialize notion connection
      this.notionConnection = new NotionConnectionManager({
        configPath: path.join(this.options.configDir, 'notion-config.json'),
        cacheDir: path.join(this.options.configDir, 'notion-cache'),
        circuitBreakerEnabled: true
      });
      
      await this.notionConnection.initialize();
      console.log('✅ Notion connection initialized');
      
      // Start socket server
      this._startSocketServer();
      
      // Set up heartbeat
      this.heartbeatInterval = setInterval(() => this._sendHeartbeats(), 30000);
      
      this.initialized = true;
      this.emit('initialized');
      
      return true;
    } catch (err) {
      console.error(`Error initializing MCP Orchestrator: ${err.message}`);
      this.emit('error', err);
      throw err;
    }
  }
  
  /**
   * Create coherence marker for service tracking
   * @private
   */
  _createCoherenceMarker() {
    try {
      // Ensure directory exists
      if (!fs.existsSync(this.options.coherenceLockDir)) {
        fs.mkdirSync(this.options.coherenceLockDir, { recursive: true });
      }
      
      // Create marker file with ONLY the PID to avoid parsing issues
      const timestamp = new Date().toISOString().replace(/[:.]/g, '');
      const markerPath = path.join(this.options.coherenceLockDir, `mcp-orchestrator_${timestamp}.marker`);
      fs.writeFileSync(markerPath, String(process.pid));
      
      console.log(`✅ Created coherence marker: ${markerPath}`);
    } catch (err) {
      console.error(`Error creating coherence marker: ${err.message}`);
    }
  }
  
  /**
   * Start the socket server
   * @private
   */
  _startSocketServer() {
    try {
      // Make sure socket directory exists
      const socketDir = path.dirname(this.options.socketPath);
      if (!fs.existsSync(socketDir)) {
        fs.mkdirSync(socketDir, { recursive: true });
      }
      
      // Clean up existing socket file
      if (fs.existsSync(this.options.socketPath)) {
        fs.unlinkSync(this.options.socketPath);
      }
      
      // Create socket server
      this.socketServer = net.createServer((socket) => {
        this._handleNewClient(socket);
      });
      
      // Set max connections
      this.socketServer.maxConnections = this.options.maxConnections;
      
      // Handle server errors
      this.socketServer.on('error', (err) => {
        console.error(`Socket server error: ${err.message}`);
        this.emit('error', err);
      });
      
      // Start listening
      this.socketServer.listen(this.options.socketPath, () => {
        console.log(`✅ Socket server listening on ${this.options.socketPath}`);
        
        // Set permissions
        fs.chmodSync(this.options.socketPath, this.options.socketPermissions);
        console.log(`✅ Set socket permissions to ${this.options.socketPermissions.toString(8)}`);
      });
    } catch (err) {
      console.error(`Error starting socket server: ${err.message}`);
      this.emit('error', err);
      throw err;
    }
  }
  
  /**
   * Handle new client connection
   * @param {net.Socket} socket - Client socket
   * @private
   */
  _handleNewClient(socket) {
    const clientId = `client_${Date.now().toString(36)}_${(++this.clientIdCounter).toString(36)}`;
    
    console.log(`Client connected: ${clientId}`);
    
    // Initialize message buffer for this client
    const messageBuffer = new MessageBuffer({
      adaptiveBuffering: true
    });
    
    // Store client info
    this.clients.set(clientId, {
      socket,
      messageBuffer,
      connectionTime: Date.now(),
      lastActivity: Date.now(),
      requestCount: 0,
      pendingRequests: new Set()
    });
    
    // Send welcome message
    this._sendToClient(clientId, {
      type: 'welcome',
      clientId,
      serverTime: new Date().toISOString(),
      serverVersion: '1.0.0'
    });
    
    // Handle data events
    socket.on('data', (data) => {
      // Update last activity time
      this.clients.get(clientId).lastActivity = Date.now();
      
      // Append data to buffer
      messageBuffer.append(data);
      
      // Process complete messages
      const messages = messageBuffer.getMessages();
      
      for (const messageText of messages) {
        this._processClientMessage(clientId, messageText);
      }
    });
    
    // Handle socket close
    socket.on('close', () => {
      console.log(`Client disconnected: ${clientId}`);
      
      // Clean up client resources
      if (this.clients.has(clientId)) {
        const client = this.clients.get(clientId);
        
        // Clean up message buffer
        client.messageBuffer.cleanup();
        
        // Cancel any pending requests
        for (const requestId of client.pendingRequests) {
          if (this.activeRequests.has(requestId)) {
            console.log(`Cancelling pending request: ${requestId}`);
            this.activeRequests.delete(requestId);
          }
        }
        
        // Remove client from map
        this.clients.delete(clientId);
      }
    });
    
    // Handle socket errors
    socket.on('error', (err) => {
      console.error(`Socket error for client ${clientId}: ${err.message}`);
      
      // Attempt to clean up resources on error
      if (this.clients.has(clientId)) {
        const client = this.clients.get(clientId);
        client.messageBuffer.cleanup();
        this.clients.delete(clientId);
      }
    });
  }
  
  /**
   * Process a client message
   * @param {string} clientId - Client identifier
   * @param {string} messageText - Message text
   * @private
   */
  _processClientMessage(clientId, messageText) {
    try {
      // Parse message as JSON
      const message = JSON.parse(messageText);
      
      // Update client metrics
      const client = this.clients.get(clientId);
      client.requestCount++;
      
      // Process message based on type
      switch (message.type) {
        case 'handshake':
          this._handleHandshake(clientId, message);
          break;
          
        case 'query':
          this._handleQuery(clientId, message);
          break;
          
        case 'transform':
          this._handleTransform(clientId, message);
          break;
          
        case 'notion_request':
          this._handleNotionRequest(clientId, message);
          break;
          
        case 'ping':
          this._handlePing(clientId, message);
          break;
          
        case 'status':
          this._handleStatus(clientId, message);
          break;
          
        default:
          this._sendErrorToClient(clientId, {
            type: 'error_response',
            requestId: message.id || 'unknown',
            error: `Unknown message type: ${message.type}`
          });
      }
    } catch (err) {
      console.error(`Error processing message from client ${clientId}: ${err.message}`);
      
      // Send error response
      this._sendErrorToClient(clientId, {
        type: 'error_response',
        error: `Failed to process message: ${err.message}`
      });
    }
  }
  
  /**
   * Handle handshake message
   * @param {string} clientId - Client identifier
   * @param {Object} message - Handshake message
   * @private
   */
  _handleHandshake(clientId, message) {
    const response = {
      type: 'handshake_response',
      id: message.id || 'unknown',
      status: 'success',
      serverTime: new Date().toISOString(),
      serverVersion: '1.0.0',
      capabilities: {
        transform: true,
        notion: true,
        stream: true
      }
    };
    
    this._sendToClient(clientId, response);
  }
  
  /**
   * Handle query message
   * @param {string} clientId - Client identifier
   * @param {Object} message - Query message
   * @private
   */
  async _handleQuery(clientId, message) {
    const requestId = message.id || `req_${Date.now().toString(36)}`;
    
    try {
      // Check circuit breaker
      if (!this.circuitBreaker.canRequest()) {
        throw new Error(`Circuit breaker is ${this.circuitBreaker.getHealth().state}`);
      }
      
      // Track request
      this.activeRequests.set(requestId, {
        clientId,
        type: 'query',
        startTime: Date.now(),
        message
      });
      
      // Add to client's pending requests
      this.clients.get(clientId).pendingRequests.add(requestId);
      
      // Update metrics
      this.metrics.requestsTotal++;
      
      // Check message format
      if (!message.query) {
        throw new Error('Missing required field: query');
      }
      
      // Process query with circuit breaker
      const result = await this.circuitBreaker.execute(async () => {
        // TODO: Implement actual query processing logic
        // This would typically involve processing the query and generating a response
        
        // For now, just echo the query
        return {
          query: message.query,
          response: {
            text: `Echoing query: ${message.query}`,
            timestamp: new Date().toISOString(),
            model: 'Claude 3.7 Sonnet'
          },
          metadata: {
            conversation_id: `conv_${Date.now().toString(36)}`,
            user_id: message.userId || 'anonymous',
            performance: {
              total_time_ms: Date.now() - this.activeRequests.get(requestId).startTime
            }
          }
        };
      });
      
      // Update circuit breaker status
      this.circuitBreaker.success();
      
      // Send response
      this._sendToClient(clientId, {
        type: 'query_response',
        id: requestId,
        status: 'success',
        result
      });
      
      // Update metrics
      this.metrics.requestsSuccess++;
    } catch (err) {
      console.error(`Error processing query request ${requestId}: ${err.message}`);
      
      // Update circuit breaker status
      this.circuitBreaker.failure();
      
      // Send error response
      this._sendErrorToClient(clientId, {
        type: 'error_response',
        id: requestId,
        status: 'error',
        error: err.message
      });
      
      // Update metrics
      this.metrics.requestsError++;
    } finally {
      // Clean up
      if (this.activeRequests.has(requestId)) {
        // Remove from client's pending requests
        const client = this.clients.get(clientId);
        if (client) {
          client.pendingRequests.delete(requestId);
        }
        
        // Remove from active requests
        this.activeRequests.delete(requestId);
      }
    }
  }
  
  /**
   * Handle transform message
   * @param {string} clientId - Client identifier
   * @param {Object} message - Transform message
   * @private
   */
  async _handleTransform(clientId, message) {
    const requestId = message.id || `req_${Date.now().toString(36)}`;
    
    try {
      // Check required fields
      if (!message.data) {
        throw new Error('Missing required field: data');
      }
      
      if (!message.sourceType || !message.targetType) {
        throw new Error('Missing required fields: sourceType or targetType');
      }
      
      // Track request
      this.activeRequests.set(requestId, {
        clientId,
        type: 'transform',
        startTime: Date.now(),
        message
      });
      
      // Add to client's pending requests
      this.clients.get(clientId).pendingRequests.add(requestId);
      
      // Update metrics
      this.metrics.transformationsTotal++;
      
      // Determine schema types and IDs
      const sourceType = message.sourceType; // 'claude' or 'notion'
      const targetType = message.targetType; // 'notion' or 'claude'
      const sourceSchemaId = message.sourceSchemaId || (sourceType === 'claude' ? 'claude-query-result' : 'notion-database-schema');
      const targetSchemaId = message.targetSchemaId || (targetType === 'notion' ? 'notion-database-schema' : 'claude-query-result');
      
      // Validate against source schema
      const sourceValidation = this.schemaRegistry.validateData(
        sourceType,
        sourceSchemaId,
        message.data,
        message.sourceVersion
      );
      
      if (!sourceValidation.valid) {
        throw new Error(`Source data validation failed: ${sourceValidation.errors[0]?.message || 'Unknown error'}`);
      }
      
      // Transform data
      // In a real implementation, this would use the schema transformer
      // For now, just pass through the data
      const transformed = message.data;
      
      // Validate against target schema
      const targetValidation = this.schemaRegistry.validateData(
        targetType,
        targetSchemaId,
        transformed,
        message.targetVersion
      );
      
      if (!targetValidation.valid) {
        throw new Error(`Target data validation failed: ${targetValidation.errors[0]?.message || 'Unknown error'}`);
      }
      
      // Send response
      this._sendToClient(clientId, {
        type: 'transform_response',
        id: requestId,
        status: 'success',
        result: transformed,
        validation: {
          source: sourceValidation,
          target: targetValidation
        }
      });
    } catch (err) {
      console.error(`Error processing transform request ${requestId}: ${err.message}`);
      
      // Send error response
      this._sendErrorToClient(clientId, {
        type: 'error_response',
        id: requestId,
        status: 'error',
        error: err.message
      });
      
      // Update metrics
      this.metrics.transformationsError++;
    } finally {
      // Clean up
      if (this.activeRequests.has(requestId)) {
        // Remove from client's pending requests
        const client = this.clients.get(clientId);
        if (client) {
          client.pendingRequests.delete(requestId);
        }
        
        // Remove from active requests
        this.activeRequests.delete(requestId);
      }
    }
  }
  
  /**
   * Handle Notion request message
   * @param {string} clientId - Client identifier
   * @param {Object} message - Notion request message
   * @private
   */
  async _handleNotionRequest(clientId, message) {
    const requestId = message.id || `req_${Date.now().toString(36)}`;
    
    try {
      // Check required fields
      if (!message.method) {
        throw new Error('Missing required field: method');
      }
      
      // Track request
      this.activeRequests.set(requestId, {
        clientId,
        type: 'notion_request',
        startTime: Date.now(),
        message
      });
      
      // Add to client's pending requests
      this.clients.get(clientId).pendingRequests.add(requestId);
      
      // Update metrics
      this.metrics.notionRequestsTotal++;
      
      // Execute Notion request
      const result = await this.notionConnection.request(
        message.method,
        message.params || {},
        {
          cacheable: message.cacheable !== false,
          retries: 0
        }
      );
      
      // Send response
      this._sendToClient(clientId, {
        type: 'notion_response',
        id: requestId,
        status: 'success',
        result
      });
    } catch (err) {
      console.error(`Error processing Notion request ${requestId}: ${err.message}`);
      
      // Send error response
      this._sendErrorToClient(clientId, {
        type: 'error_response',
        id: requestId,
        status: 'error',
        error: err.message
      });
      
      // Update metrics
      this.metrics.notionRequestsError++;
    } finally {
      // Clean up
      if (this.activeRequests.has(requestId)) {
        // Remove from client's pending requests
        const client = this.clients.get(clientId);
        if (client) {
          client.pendingRequests.delete(requestId);
        }
        
        // Remove from active requests
        this.activeRequests.delete(requestId);
      }
    }
  }
  
  /**
   * Handle ping message
   * @param {string} clientId - Client identifier
   * @param {Object} message - Ping message
   * @private
   */
  _handlePing(clientId, message) {
    this._sendToClient(clientId, {
      type: 'pong',
      id: message.id || 'unknown',
      timestamp: new Date().toISOString(),
      echo: message.echo
    });
  }
  
  /**
   * Handle status message
   * @param {string} clientId - Client identifier
   * @param {Object} message - Status message
   * @private
   */
  _handleStatus(clientId, message) {
    // Gather system status
    const status = {
      uptime: Date.now() - this.startTime,
      clients: this.clients.size,
      activeRequests: this.activeRequests.size,
      circuitBreaker: this.circuitBreaker.getHealth(),
      notionConnection: this.notionConnection.getHealth(),
      schemaRegistry: this.schemaRegistry.getMetrics(),
      metrics: this.metrics,
      system: {
        memory: {
          total: os.totalmem(),
          free: os.freemem(),
          usage: process.memoryUsage()
        },
        cpu: {
          load: os.loadavg(),
          count: os.cpus().length
        },
        platform: os.platform(),
        arch: os.arch(),
        isM3Max: this.isM3Max
      }
    };
    
    this._sendToClient(clientId, {
      type: 'status_response',
      id: message.id || 'unknown',
      status: 'success',
      result: status
    });
  }
  
  /**
   * Send message to client
   * @param {string} clientId - Client identifier
   * @param {Object} message - Message to send
   * @private
   */
  _sendToClient(clientId, message) {
    if (!this.clients.has(clientId)) {
      console.warn(`Attempted to send message to unknown client: ${clientId}`);
      return;
    }
    
    const client = this.clients.get(clientId);
    const socket = client.socket;
    
    if (!socket.writable) {
      console.warn(`Socket for client ${clientId} is not writable`);
      return;
    }
    
    try {
      // Send message as JSON with newline terminator
      socket.write(JSON.stringify(message) + '\n');
    } catch (err) {
      console.error(`Error sending message to client ${clientId}: ${err.message}`);
      
      // Remove client if send fails
      this._removeClient(clientId);
    }
  }
  
  /**
   * Send error message to client
   * @param {string} clientId - Client identifier
   * @param {Object} error - Error details
   * @private
   */
  _sendErrorToClient(clientId, error) {
    this._sendToClient(clientId, {
      type: error.type || 'error_response',
      id: error.id || 'unknown',
      status: 'error',
      error: error.error || 'Unknown error'
    });
  }
  
  /**
   * Remove client and clean up resources
   * @param {string} clientId - Client identifier
   * @private
   */
  _removeClient(clientId) {
    if (!this.clients.has(clientId)) {
      return;
    }
    
    const client = this.clients.get(clientId);
    
    // Clean up message buffer
    client.messageBuffer.cleanup();
    
    // Close socket if still open
    if (client.socket && !client.socket.destroyed) {
      client.socket.end();
    }
    
    // Remove client from map
    this.clients.delete(clientId);
    
    console.log(`Removed client: ${clientId}`);
  }
  
  /**
   * Send heartbeats to all connected clients
   * @private
   */
  _sendHeartbeats() {
    const now = Date.now();
    const heartbeatMessage = {
      type: 'heartbeat',
      timestamp: new Date().toISOString(),
      serverLoad: {
        clients: this.clients.size,
        activeRequests: this.activeRequests.size,
        memoryUsage: process.memoryUsage().heapUsed
      }
    };
    
    // Send heartbeat to all clients
    for (const [clientId, client] of this.clients.entries()) {
      // Skip if inactive for too long (5 minutes)
      if (now - client.lastActivity > 5 * 60 * 1000) {
        console.log(`Removing inactive client: ${clientId}`);
        this._removeClient(clientId);
        continue;
      }
      
      try {
        this._sendToClient(clientId, heartbeatMessage);
      } catch (err) {
        console.error(`Error sending heartbeat to client ${clientId}: ${err.message}`);
        this._removeClient(clientId);
      }
    }
  }
  
  /**
   * Clean up resources
   */
  cleanup() {
    // Clear heartbeat interval
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
    }
    
    // Close all client connections
    for (const clientId of this.clients.keys()) {
      this._removeClient(clientId);
    }
    
    // Close socket server
    if (this.socketServer) {
      this.socketServer.close(() => {
        console.log('Socket server closed');
      });
      
      // Remove socket file
      if (fs.existsSync(this.options.socketPath)) {
        fs.unlinkSync(this.options.socketPath);
        console.log(`Removed socket file: ${this.options.socketPath}`);
      }
    }
    
    // Clean up Notion connection
    if (this.notionConnection) {
      // No explicit cleanup needed for NotionConnectionManager
    }
    
    // Clean up schema transformer
    if (this.schemaTransformer) {
      this.schemaTransformer.cleanup();
    }
    
    console.log('MCP Orchestrator cleanup complete');
  }
}

// Start orchestrator if run directly
if (require.main === module) {
  const orchestrator = new MCPOrchestrator();
  
  // Handle exit signals
  process.on('SIGINT', () => {
    console.log('Received SIGINT, shutting down');
    orchestrator.cleanup();
    process.exit(0);
  });
  
  process.on('SIGTERM', () => {
    console.log('Received SIGTERM, shutting down');
    orchestrator.cleanup();
    process.exit(0);
  });
  
  // Start orchestrator
  orchestrator.initialize()
    .then(() => {
      console.log('✅ MCP Orchestrator initialized successfully');
    })
    .catch(err => {
      console.error(`❌ Failed to initialize MCP Orchestrator: ${err.message}`);
      process.exit(1);
    });
}

module.exports = MCPOrchestrator;
