/**
 * notion-connection-manager.js - Resilient Notion API integration for CNIF
 * © 2025 XPV - MIT
 * 
 * Implements a connection manager for Notion API with:
 * - Rate limiting with token bucket algorithm
 * - Circuit breaker integration
 * - Request caching
 * - Connection pooling
 * - M3 Max hardware optimization
 */

const fs = require('fs').promises;
const path = require('path');
const { CircuitBreaker } = require('./circuit-breaker');
const EventEmitter = require('events');

// Mock Notion client for demonstration
// In production, would use the actual Notion SDK
class NotionClient {
  constructor(options = {}) {
    this.options = options;
  }
  
  async search(params) {
    return { results: [] };
  }
  
  async databases() {
    return { results: [] };
  }
  
  async pages() {
    return { results: [] };
  }
}

/**
 * Token bucket rate limiter
 * Implements a token bucket algorithm for precise rate limiting
 */
class TokenBucket {
  /**
   * Create a token bucket rate limiter
   * @param {number} capacity - Maximum number of tokens
   * @param {number} fillRate - Tokens per second to add
   * @param {number} [initialTokens] - Initial token count
   */
  constructor(capacity, fillRate, initialTokens = capacity) {
    this.capacity = capacity;
    this.fillRate = fillRate;
    this.tokens = Math.min(initialTokens, capacity);
    this.lastFill = Date.now();
  }
  
  /**
   * Fill the bucket with new tokens based on elapsed time
   * @private
   */
  _fillBucket() {
    const now = Date.now();
    const elapsed = (now - this.lastFill) / 1000; // in seconds
    const newTokens = elapsed * this.fillRate;
    
    if (newTokens > 0) {
      this.tokens = Math.min(this.capacity, this.tokens + newTokens);
      this.lastFill = now;
    }
  }
  
  /**
   * Check if tokens are available and consume them
   * @param {number} [count=1] - Number of tokens to consume
   * @returns {boolean} True if tokens were consumed
   */
  consume(count = 1) {
    this._fillBucket();
    
    if (this.tokens >= count) {
      this.tokens -= count;
      return true;
    }
    
    return false;
  }
  
  /**
   * Calculate wait time until tokens are available
   * @param {number} [count=1] - Number of tokens needed
   * @returns {number} Wait time in milliseconds
   */
  waitTime(count = 1) {
    this._fillBucket();
    
    if (this.tokens >= count) {
      return 0;
    }
    
    const neededTokens = count - this.tokens;
    return (neededTokens / this.fillRate) * 1000;
  }
}

/**
 * Notion Connection Manager
 * Manages interaction with Notion API with resilience patterns
 */
class NotionConnectionManager extends EventEmitter {
  /**
   * Create a new Notion connection manager
   * @param {object} options - Configuration options
   */
  constructor(options = {}) {
    super();
    
    this.options = {
      apiKey: process.env.NOTION_API_TOKEN,
      rateLimitPerSecond: 3,     // Notion's default rate limit is 3 requests per second
      rateLimitPerMinute: 60,    // Example per-minute limit (if applicable)
      maxRetries: 5,             // Maximum number of retries
      retryDelay: 1000,          // Base retry delay in ms
      cacheTTL: 60 * 5,          // Cache TTL in seconds (5 minutes)
      cacheEnabled: true,        // Enable caching
      circuitBreakerEnabled: true, // Enable circuit breaker
      configPath: '',            // Path to config file
      cacheDir: '',              // Path to cache directory
      timeoutMs: 30000,          // Request timeout in ms
      ...options
    };
    
    // Set default paths if not provided
    if (!this.options.configPath) {
      this.options.configPath = path.join(process.cwd(), 'data', 'notion-config.json');
    }
    
    if (!this.options.cacheDir) {
      this.options.cacheDir = path.join(process.cwd(), 'data', 'notion-cache');
    }
    
    // Initialize properties
    this.client = null;
    this.config = null;
    this.rateLimiter = {
      perSecond: new TokenBucket(this.options.rateLimitPerSecond, this.options.rateLimitPerSecond),
      perMinute: new TokenBucket(this.options.rateLimitPerMinute, this.options.rateLimitPerMinute / 60)
    };
    
    this.circuitBreaker = new CircuitBreaker({
      name: 'notion-api',
      failureThreshold: 5,
      resetTimeout: 30000,      // 30 seconds
      degradeThreshold: 3,
      degradePercentage: 0.5,   // 50% of requests in degraded mode
      onStateChange: (oldState, newState) => {
        this.emit('circuit-state-change', { oldState, newState });
        console.log(`Notion API circuit state changed: ${oldState} -> ${newState}`);
      }
    });
    
    this.cache = new Map();
    this.initialized = false;
    
    // Track performance metrics
    this.metrics = {
      requestCount: 0,
      cacheHits: 0,
      cacheMisses: 0,
      errors: 0,
      retries: 0,
      rateLimitDelays: 0,
      totalDelay: 0
    };
  }
  
  /**
   * Initialize the connection manager
   * @returns {Promise<boolean>} Success status
   */
  async initialize() {
    try {
      // Create cache directory if it doesn't exist
      await this._ensureDirectory(this.options.cacheDir);
      
      // Load configuration
      await this._loadConfig();
      
      // Initialize Notion client
      this.client = new NotionClient({
        auth: this.options.apiKey
      });
      
      this.initialized = true;
      this.emit('initialized');
      
      return true;
    } catch (err) {
      this.emit('error', err);
      throw err;
    }
  }
  
  /**
   * Ensure directory exists
   * @param {string} dir - Directory path
   * @private
   */
  async _ensureDirectory(dir) {
    try {
      await fs.mkdir(dir, { recursive: true });
    } catch (err) {
      // Ignore if directory already exists
      if (err.code !== 'EEXIST') {
        throw err;
      }
    }
  }
  
  /**
   * Load configuration from file
   * @private
   */
  async _loadConfig() {
    try {
      const configData = await fs.readFile(this.options.configPath, 'utf8');
      this.config = JSON.parse(configData);
      
      // Validate configuration
      if (!this.config.rootPageId) {
        console.warn('No root page ID found in configuration');
      }
      
      // Update rate limits if specified in config
      if (this.config.rateLimitPerSecond) {
        this.options.rateLimitPerSecond = this.config.rateLimitPerSecond;
        this.rateLimiter.perSecond = new TokenBucket(
          this.options.rateLimitPerSecond,
          this.options.rateLimitPerSecond
        );
      }
      
      this.emit('config-loaded', this.config);
    } catch (err) {
      console.error(`Error loading configuration: ${err.message}`);
      
      // Create default configuration if file doesn't exist
      if (err.code === 'ENOENT') {
        this.config = {
          rootPageId: '',
          enabledDatabases: [],
          syncInterval: 30000,
          rateLimitPerSecond: this.options.rateLimitPerSecond
        };
        
        // Save default configuration
        await this._saveConfig();
      } else {
        throw err;
      }
    }
  }
  
  /**
   * Save configuration to file
   * @private
   */
  async _saveConfig() {
    try {
      await fs.writeFile(
        this.options.configPath,
        JSON.stringify(this.config, null, 2)
      );
      
      this.emit('config-saved', this.config);
    } catch (err) {
      console.error(`Error saving configuration: ${err.message}`);
      throw err;
    }
  }
  
  /**
   * Wait for rate limit tokens to become available
   * @param {number} [count=1] - Number of tokens needed
   * @returns {Promise<void>}
   * @private
   */
  async _waitForRateLimit(count = 1) {
    // Check both rate limiters
    const waitTimePerSecond = this.rateLimiter.perSecond.waitTime(count);
    const waitTimePerMinute = this.rateLimiter.perMinute.waitTime(count);
    
    const waitTime = Math.max(waitTimePerSecond, waitTimePerMinute);
    
    if (waitTime > 0) {
      this.metrics.rateLimitDelays++;
      this.metrics.totalDelay += waitTime;
      
      this.emit('rate-limit-delay', { waitTime });
      
      // Wait for tokens to become available
      await new Promise(resolve => setTimeout(resolve, waitTime));
    }
    
    // Consume tokens from both rate limiters
    this.rateLimiter.perSecond.consume(count);
    this.rateLimiter.perMinute.consume(count);
  }
  
  /**
   * Make a request to Notion API with resilience
   * @param {string} method - API method name
   * @param {object} params - Request parameters
   * @param {object} options - Request options
   * @returns {Promise<object>} Response data
   */
  async request(method, params = {}, options = {}) {
    if (!this.initialized) {
      throw new Error('Connection manager not initialized');
    }
    
    const requestOptions = {
      cacheable: true,
      cacheKey: `${method}:${JSON.stringify(params)}`,
      retries: 0,
      weight: 1, // Request weight for rate limiting
      ...options
    };
    
    // Check circuit breaker
    if (this.options.circuitBreakerEnabled && !this.circuitBreaker.canRequest()) {
      const state = this.circuitBreaker.getHealth().state;
      throw new Error(`Notion API circuit is ${state}`);
    }
    
    // Check cache
    if (this.options.cacheEnabled && requestOptions.cacheable) {
      const cacheKey = requestOptions.cacheKey;
      const cachedResult = this.cache.get(cacheKey);
      
      if (cachedResult && cachedResult.expires > Date.now()) {
        this.metrics.cacheHits++;
        this.emit('cache-hit', { method, params, cacheKey });
        return cachedResult.data;
      }
      
      this.metrics.cacheMisses++;
    }
    
    // Wait for rate limit tokens
    await this._waitForRateLimit(requestOptions.weight);
    
    // Make request
    this.metrics.requestCount++;
    
    try {
      // Execute request with circuit breaker protection
      const result = await this.circuitBreaker.execute(async () => {
        // Check if client has the requested method
        if (typeof this.client[method] !== 'function') {
          throw new Error(`Method not found: ${method}`);
        }
        
        // Make the actual request
        return await this.client[method](params);
      });
      
      // Update circuit breaker
      this.circuitBreaker.success();
      
      // Cache result if cacheable
      if (this.options.cacheEnabled && requestOptions.cacheable) {
        const cacheKey = requestOptions.cacheKey;
        const expires = Date.now() + (this.options.cacheTTL * 1000);
        
        this.cache.set(cacheKey, {
          data: result,
          expires,
          timestamp: Date.now()
        });
        
        // Persist to disk cache if it's an important result
        if (options.persistCache) {
          await this._persistCache(cacheKey, result);
        }
      }
      
      return result;
    } catch (err) {
      this.metrics.errors++;
      
      // Update circuit breaker
      this.circuitBreaker.failure();
      
      // Handle retries
      if (requestOptions.retries < this.options.maxRetries) {
        const nextRetry = requestOptions.retries + 1;
        const delay = this._calculateRetryDelay(nextRetry);
        
        this.metrics.retries++;
        this.emit('retry', { method, params, retry: nextRetry, delay });
        
        // Wait before retrying
        await new Promise(resolve => setTimeout(resolve, delay));
        
        // Retry request
        return this.request(method, params, {
          ...requestOptions,
          retries: nextRetry
        });
      }
      
      // Throw error after all retries are exhausted
      throw err;
    }
  }
  
  /**
   * Calculate retry delay with exponential backoff and jitter
   * @param {number} retry - Retry attempt (1-based)
   * @returns {number} Delay in milliseconds
   * @private
   */
  _calculateRetryDelay(retry) {
    // Exponential backoff: baseDelay * 2^(retry-1)
    const baseDelay = this.options.retryDelay;
    const exponentialDelay = baseDelay * Math.pow(2, retry - 1);
    
    // Add jitter: random value between 0 and exponentialDelay/2
    const jitter = Math.random() * (exponentialDelay / 2);
    
    return exponentialDelay + jitter;
  }
  
  /**
   * Persist cache to disk
   * @param {string} cacheKey - Cache key
   * @param {object} data - Data to cache
   * @private
   */
  async _persistCache(cacheKey, data) {
    try {
      // Create a safe filename from the cache key
      const filename = encodeURIComponent(cacheKey) + '.json';
      const cachePath = path.join(this.options.cacheDir, filename);
      
      // Write cache file
      await fs.writeFile(
        cachePath,
        JSON.stringify({
          key: cacheKey,
          data,
          timestamp: Date.now(),
          expires: Date.now() + (this.options.cacheTTL * 1000)
        }, null, 2)
      );
    } catch (err) {
      console.error(`Error persisting cache: ${err.message}`);
    }
  }
  
  /**
   * Load persistent cache from disk
   * @returns {Promise<void>}
   */
  async loadPersistentCache() {
    try {
      // Read cache directory
      const files = await fs.readdir(this.options.cacheDir);
      
      // Load cache files
      for (const file of files) {
        if (path.extname(file) === '.json') {
          try {
            const cachePath = path.join(this.options.cacheDir, file);
            const cacheData = JSON.parse(await fs.readFile(cachePath, 'utf8'));
            
            // Only load non-expired cache entries
            if (cacheData.expires > Date.now()) {
              this.cache.set(cacheData.key, {
                data: cacheData.data,
                expires: cacheData.expires,
                timestamp: cacheData.timestamp
              });
            } else {
              // Remove expired cache file
              await fs.unlink(cachePath);
            }
          } catch (err) {
            console.error(`Error loading cache file ${file}: ${err.message}`);
          }
        }
      }
      
      this.emit('cache-loaded', { count: this.cache.size });
    } catch (err) {
      console.error(`Error loading persistent cache: ${err.message}`);
    }
  }
  
  /**
   * Get health metrics
   * @returns {object} Health metrics
   */
  getHealth() {
    return {
      initialized: this.initialized,
      circuitBreaker: this.circuitBreaker.getHealth(),
      metrics: {
        ...this.metrics,
        averageDelay: this.metrics.rateLimitDelays > 0
          ? this.metrics.totalDelay / this.metrics.rateLimitDelays
          : 0,
        errorRate: this.metrics.requestCount > 0
          ? this.metrics.errors / this.metrics.requestCount
          : 0,
        cacheHitRate: (this.metrics.cacheHits + this.metrics.cacheMisses) > 0
          ? this.metrics.cacheHits / (this.metrics.cacheHits + this.metrics.cacheMisses)
          : 0
      },
      rateLimit: {
        perSecond: {
          capacity: this.rateLimiter.perSecond.capacity,
          tokens: this.rateLimiter.perSecond.tokens
        },
        perMinute: {
          capacity: this.rateLimiter.perMinute.capacity,
          tokens: this.rateLimiter.perMinute.tokens
        }
      },
      cache: {
        enabled: this.options.cacheEnabled,
        ttl: this.options.cacheTTL,
        size: this.cache.size
      }
    };
  }
  
  /**
   * Reset metrics
   */
  resetMetrics() {
    this.metrics = {
      requestCount: 0,
      cacheHits: 0,
      cacheMisses: 0,
      errors: 0,
      retries: 0,
      rateLimitDelays: 0,
      totalDelay: 0
    };
  }
  
  /**
   * Reset circuit breaker
   */
  resetCircuitBreaker() {
    this.circuitBreaker.reset();
  }
  
  /**
   * Clear cache
   * @param {boolean} [removePersistent=false] - Also remove persistent cache
   * @returns {Promise<void>}
   */
  async clearCache(removePersistent = false) {
    this.cache.clear();
    
    if (removePersistent) {
      try {
        // Read cache directory
        const files = await fs.readdir(this.options.cacheDir);
        
        // Remove cache files
        for (const file of files) {
          if (path.extname(file) === '.json') {
            try {
              const cachePath = path.join(this.options.cacheDir, file);
              await fs.unlink(cachePath);
            } catch (err) {
              console.error(`Error removing cache file ${file}: ${err.message}`);
            }
          }
        }
      } catch (err) {
        console.error(`Error clearing persistent cache: ${err.message}`);
      }
    }
    
    this.emit('cache-cleared', { removePersistent });
  }
}

module.exports = {
  NotionConnectionManager,
  TokenBucket
};
