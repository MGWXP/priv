/**
 * schema-registry.js - Schema version management for Claude-Notion integration
 * © 2025 XPV - MIT
 * 
 * Implements a versioned schema registry for Claude-Notion integration
 * with SchemaVer versioning (MODEL-REVISION-ADDITION) and validation.
 */

const fs = require('fs');
const path = require('path');
const EventEmitter = require('events');

/**
 * Schema Registry manages schema versioning and lookup
 * Using SchemaVer approach (MODEL-REVISION-ADDITION)
 */
class SchemaRegistry extends EventEmitter {
  /**
   * Create a new SchemaRegistry
   * @param {object} options - Registry options
   */
  constructor(options = {}) {
    super();
    
    this.options = {
      schemaDirClaude: path.join(process.cwd(), 'schemas', 'claude'),
      schemaDirNotion: path.join(process.cwd(), 'schemas', 'notion'),
      cacheEnabled: true,
      validateOnLoad: true,
      ...options
    };
    
    this.claudeSchemas = new Map();
    this.notionSchemas = new Map();
    this.schemaVersions = {
      claude: new Map(),
      notion: new Map()
    };
    
    this.initialized = false;
  }
  
  /**
   * Initialize the registry
   * Loads all schemas from disk
   * @returns {Promise<boolean>} Success status
   */
  async initialize() {
    try {
      // Create schema directories if they don't exist
      await this._ensureDirectory(this.options.schemaDirClaude);
      await this._ensureDirectory(this.options.schemaDirNotion);
      
      // Load Claude schemas
      await this._loadSchemas('claude', this.options.schemaDirClaude, this.claudeSchemas);
      
      // Load Notion schemas
      await this._loadSchemas('notion', this.options.schemaDirNotion, this.notionSchemas);
      
      this.initialized = true;
      this.emit('initialized');
      
      return true;
    } catch (err) {
      this.emit('error', err);
      throw err;
    }
  }
  
  /**
   * Ensure directory exists
   * @param {string} dir - Directory path
   * @private
   */
  async _ensureDirectory(dir) {
    try {
      await fs.promises.mkdir(dir, { recursive: true });
    } catch (err) {
      // Ignore if directory already exists
      if (err.code !== 'EEXIST') {
        throw err;
      }
    }
  }
  
  /**
   * Load schemas from directory
   * @param {string} type - Schema type ('claude' or 'notion')
   * @param {string} dir - Directory path
   * @param {Map} targetMap - Target map to store schemas
   * @private
   */
  async _loadSchemas(type, dir, targetMap) {
    try {
      const files = await fs.promises.readdir(dir);
      
      for (const file of files) {
        if (path.extname(file) === '.json') {
          try {
            const schemaPath = path.join(dir, file);
            const schema = JSON.parse(await fs.promises.readFile(schemaPath, 'utf8'));
            
            // Validate schema structure
            if (this.options.validateOnLoad && !this._validateSchemaStructure(schema)) {
              console.warn('Invalid schema structure: ' + schemaPath);
              continue;
            }
            
            // Extract schema ID and version
            const { id, version } = schema;
            
            if (!id || !version) {
              console.warn('Schema missing id or version: ' + schemaPath);
              continue;
            }
            
            // Store schema
            targetMap.set(id, schema);
            
            // Update version map
            if (!this.schemaVersions[type].has(id)) {
              this.schemaVersions[type].set(id, []);
            }
            
            const versions = this.schemaVersions[type].get(id);
            versions.push(version);
            
            // Sort versions in descending order (latest first)
            versions.sort((a, b) => this._compareVersions(b, a));
            
            this.emit('schema-loaded', { type, id, version, path: schemaPath });
          } catch (err) {
            console.error('Error loading schema ' + file + ': ' + err.message);
          }
        }
      }
    } catch (err) {
      console.error('Error reading schema directory ' + dir + ': ' + err.message);
      throw err;
    }
  }
  
  // Other methods...
  /**
   * Get all registered schemas of a type
   * @param {string} type - Schema type ('claude' or 'notion')
   * @returns {Array} Array of schema objects
   */
  getAllSchemas(type) {
    if (!this.initialized) {
      throw new Error('Schema registry not initialized');
    }
    
    const schemaMap = type === 'claude' ? this.claudeSchemas : this.notionSchemas;
    return Array.from(schemaMap.values());
  }
  
  /**
   * Compare SchemaVer versions (MODEL-REVISION-ADDITION)
   * @param {string} v1 - First version string
   * @param {string} v2 - Second version string
   * @returns {number} Comparison result (-1, 0, 1)
   * @private
   */
  _compareVersions(v1, v2) {
    const parse = (v) => {
      const parts = v.split('-').map(Number);
      return { model: parts[0] || 0, revision: parts[1] || 0, addition: parts[2] || 0 };
    };
    
    const a = parse(v1);
    const b = parse(v2);
    
    if (a.model !== b.model) return a.model - b.model;
    if (a.revision !== b.revision) return a.revision - b.revision;
    return a.addition - b.addition;
  }
  
  /**
   * Validate schema structure
   * @param {object} schema - Schema to validate
   * @returns {boolean} Validation result
   * @private
   */
  _validateSchemaStructure(schema) {
    // Basic structure validation
    if (!schema || typeof schema !== 'object') return false;
    if (!schema.id || typeof schema.id !== 'string') return false;
    if (!schema.version || typeof schema.version !== 'string') return false;
    if (!schema.description || typeof schema.description !== 'string') return false;
    if (!schema.schema || typeof schema.schema !== 'object') return false;
    
    return true;
  }
  
  /**
   * Get schema metrics
   * @returns {object} Schema registry metrics
   */
  getMetrics() {
    return {
      initialized: this.initialized,
      schemaCount: {
        claude: this.claudeSchemas.size,
        notion: this.notionSchemas.size,
        total: this.claudeSchemas.size + this.notionSchemas.size
      }
    };
  }
}

module.exports = SchemaRegistry;
