# Anchor V6 System (formerly Claude-Notion Integration Framework)

## Overview

The Claude-Notion Integration Framework (CNIF) is a sophisticated bidirectional communication system employing Model Context Protocol (MCP) over Unix socket connections. This integration enables seamless communication between Claude and Notion workspaces, optimized specifically for M3 Max hardware.

## System Architecture

The CNIF consists of the following core components:

1. **Socket Server**: Handles MCP communication with Claude using Unix sockets
2. **Schema Registry**: Manages versioned schemas for Claude and Notion data
3. **Streaming Transformer**: Converts between Claude's XML and Notion's JSON formats
4. **Notion Connection Manager**: Handles API communication with Notion
5. **MCP Orchestrator**: Coordinates service communication

## Key Features

- **Resilient Architecture**: Circuit breaker pattern for fault isolation
- **Streaming Transformation**: Efficient handling of large documents
- **M3 Max Optimizations**: Configured for optimal performance on M3 Max hardware
- **Schema Versioning**: SchemaVer approach (MODEL-REVISION-ADDITION)
- **Rate Limiting**: Adaptive rate limiting for Notion API

## Getting Started

### Prerequisites

- macOS Sequoia running on M3 Max hardware
- Node.js 18+ with npm
- Notion API integration token

### Installation

1. Clone the repository:
```bash
git clone https://github.com/your-org/anchor-core.git /Users/XPV/Desktop/anchor-core
cd /Users/XPV/Desktop/anchor-core
```

2. Install dependencies:
```bash
npm install
```

3. Make the launcher executable:
```bash
chmod +x make-launcher-executable.sh
./make-launcher-executable.sh
```

4. Configure Notion API token:
   - Create or edit `/Users/XPV/Desktop/anchor-core/config/notion-config.json`
   - Add your Notion API token to the `apiToken` field

### Starting the Services

Start all services with a single command:
```bash
./cnif-launcher.sh start
```

Or start individual services:
```bash
./cnif-launcher.sh start schema-registry
```

### Checking Status

Check the status of all services:
```bash
./cnif-launcher.sh status
```

### Viewing Logs

View logs for a specific service:
```bash
./cnif-launcher.sh logs notion
```

### Stopping Services

Stop all services:
```bash
./cnif-launcher.sh stop
```

## Directory Structure

```
/Users/XPV/Desktop/anchor-core/
├── core/                     # Core server components (.cjs files)
│   ├── circuit-breaker.cjs
│   ├── mcp-orchestrator.cjs
│   ├── notion-connection-manager.cjs
│   ├── schema-registry.cjs
│   ├── socket-server.cjs
│   └── streaming-transformer.cjs
├── entry-points/             # Entry point files (.js)
│   ├── mcp-orchestrator-main.js
│   ├── notion-connection-main.js
│   ├── schema-registry-main.js
│   ├── socket-server-main.js
│   └── streaming-transformer-main.js
├── schemas/                  # Schema definitions
│   ├── claude/
│   └── notion/
├── archive/                  # Archived components
│   ├── module-system-conflicts/
│   ├── socket-connectivity-issues/
│   ├── schema-validation-errors/
│   ├── process-management-issues/
│   ├── performance-bottlenecks/
│   ├── deprecated-implementations/
│   └── obsolete-configurations/
├── meta-protocols/           # System maintenance tools
│   ├── analyze-archive-candidates.sh
│   ├── archive-component.sh
│   ├── bulk-archive-components.sh
│   └── create-replacement-component.sh
├── sockets/                  # Unix socket files
├── logs/                     # Application logs
├── config/                   # Configuration files
├── coherence_lock/           # Coherence markers
└── cnif-launcher.sh          # Unified launcher script
```

## Performance Metrics

The system is optimized for M3 Max hardware with the following performance characteristics:

| Metric | Value |
|--------|-------|
| Memory Allocation | 8GB per service |
| Thread Pool Size | 12 threads |
| Socket Buffer Size | 64KB |
| Request Throughput | 200+ messages/second |
| Response Latency | < 100ms (95th percentile) |

## System Maintenance

### Archiving Protocol

Anchor V6 implements a systematic archiving protocol for managing component lifecycle:

1. **Initialize Protocol**:
   ```bash
   ./setup-archiving-protocol.sh
   ./initiate-archiving-protocol.sh
   ```

2. **Identify Archiving Candidates**:
   ```bash
   ./meta-protocols/analyze-archive-candidates.sh [days] [min_errors]
   ```

3. **Archive Components**:
   ```bash
   ./meta-protocols/archive-component.sh [component_path] [category] [reason] [replacement_path]
   ```

4. **Create Replacements**:
   ```bash
   ./meta-protocols/create-replacement-component.sh [archived_path] [replacement_path] [type]
   ```

5. **Example Usage**:
   ```bash
   ./example-archive-component.sh
   ```

Complete documentation available in `SYSTEMATIC_ARCHIVING_PROTOCOL.md`

### Coherence Markers

Anchor V6 uses coherence markers to track system state and component lifecycle:

```bash
# List all coherence markers
find /Users/XPV/Desktop/anchor-core/coherence_lock -type f -name "*.marker" | sort

# Check markers for a specific component
find /Users/XPV/Desktop/anchor-core/coherence_lock -type f -name "schema-registry_*.marker" | sort
```

Coherence markers provide a chronological record of system state changes and successful operations.

## Troubleshooting

### Socket Connection Issues

If socket connections fail:
1. Check socket file permissions (should be 0666)
2. Verify socket directory exists and is writable
3. Ensure no existing socket file is blocking creation

### Schema Registry Errors

If schema validation fails:
1. Check schema files in `/Users/XPV/Desktop/anchor-core/schemas/`
2. Verify schema structure matches expected format
3. Run the schema registry with debug logging

### Notion API Rate Limiting

If encountering rate limit errors:
1. Check rate limit settings in configuration
2. Verify API token has appropriate permissions
3. Implement request batching for bulk operations

### Archiving and Refactoring Issues

If you encounter issues with the archiving protocol:
1. Check for coherence markers in `/Users/XPV/Desktop/anchor-core/coherence_lock/`
2. Verify that archived components have proper metadata files
3. Ensure replacement components are properly referenced in dependent modules

## License

MIT
