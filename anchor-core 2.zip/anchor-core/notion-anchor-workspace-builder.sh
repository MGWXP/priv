#!/bin/bash
# notion-anchor-workspace-builder.sh - Creates the comprehensive Anchor workspace in Notion
# For M3 Max (48GB unified memory) hardware

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

NOTION_PAGE_ID="1f7e48c2bbbd80df86edd35832916f80"

echo -e "${BLUE}=== Creating Anchor V6 MCP Workspace in Notion ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e "Target page: https://www.notion.so/Anchor-${NOTION_PAGE_ID}"
echo -e ""

# Check if NOTION_API_KEY is set
if [ -z "${NOTION_API_KEY}" ]; then
    echo -e "${RED}Error: NOTION_API_KEY environment variable is not set${NC}"
    echo -e "Please set your Notion API key first with:"
    echo -e "export NOTION_API_KEY=\"your_notion_api_key\""
    exit 1
fi

# Create main structure with top-level pages
echo -e "${BLUE}Creating main workspace structure...${NC}"

curl -X PATCH "https://api.notion.com/v1/blocks/${NOTION_PAGE_ID}/children" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "children": [
      {
        "object": "block",
        "type": "callout",
        "callout": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "anchor Notion Workspace — Master Implementation v1.0",
                "link": null
              }
            }
          ],
          "icon": {
            "emoji": "🏗️"
          },
          "color": "blue_background"
        }
      },
      {
        "object": "block",
        "type": "paragraph",
        "paragraph": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Purpose: Provide a semantically-typed, automation-ready, performance-optimised workspace for the solo-developer anchor stack (local git, Notion API bridge, Frontier model switcher).",
                "link": null
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "paragraph",
        "paragraph": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Scope: Full lifecycle orchestration of agents, integrations, projects, metrics, docs, and ops.",
                "link": null
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "divider",
        "divider": {}
      },
      {
        "object": "block",
        "type": "heading_2",
        "heading_2": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Top-Level Page Map",
                "link": null
              }
            }
          ],
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "callout",
        "callout": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "🏠 anchor Command Center\n├── 📊 System Dashboard\n├── 🧭 Navigation Hub\n├── 🗄️ Master Databases\n├── 🚀 Operations Center\n└── ⚙️ System Config\n\nEach node is an atomic page with linked-DB views and quick-action blocks.",
                "link": null
              }
            }
          ],
          "icon": {
            "emoji": "🔖"
          },
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "heading_2",
        "heading_2": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Navigation Hub (Quick Links)",
                "link": null
              }
            }
          ],
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "callout",
        "callout": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "📋 Mission Control\n│   ├── System Status\n│   ├── Active Ops\n│   └── Deployment Queue\n👤 Agent Ops\n│   ├── Agent Registry (DB)\n│   ├── Skill Matrix\n│   ├── Performance Analytics\n│   └── Assignment Tracker\n🔧 System Architecture\n│   ├── Component Library (DB)\n│   ├── API Docs\n│   └── Config Center\n📚 Knowledge Base\n    ├── Tech Docs\n    ├── Ops Guides\n    ├── Troubleshooting\n    └── Best Practices",
                "link": null
              }
            }
          ],
          "icon": {
            "emoji": "🧭"
          },
          "color": "gray_background"
        }
      },
      {
        "object": "block",
        "type": "heading_2",
        "heading_2": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Master Databases",
                "link": null
              }
            }
          ],
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "table",
        "table": {
          "table_width": 4,
          "has_column_header": true,
          "has_row_header": false,
          "children": [
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "Database"}}],
                  [{"type": "text", "text": {"content": "Key"}}],
                  [{"type": "text", "text": {"content": "Core Function"}}],
                  [{"type": "text", "text": {"content": "Status"}}]
                ]
              }
            },
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "Agent Registry"}}],
                  [{"type": "text", "text": {"content": "Agent ID"}}],
                  [{"type": "text", "text": {"content": "Track local/remote agents, skills, uptime"}}],
                  [{"type": "text", "text": {"content": "To Create"}}]
                ]
              }
            },
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "Component Library"}}],
                  [{"type": "text", "text": {"content": "Comp ID"}}],
                  [{"type": "text", "text": {"content": "Manage services (git, notion, frontier)"}}],
                  [{"type": "text", "text": {"content": "To Create"}}]
                ]
              }
            },
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "Project Tracker"}}],
                  [{"type": "text", "text": {"content": "Proj ID"}}],
                  [{"type": "text", "text": {"content": "Plan / execute dev projects"}}],
                  [{"type": "text", "text": {"content": "To Create"}}]
                ]
              }
            },
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "System Metrics"}}],
                  [{"type": "text", "text": {"content": "Metric ID"}}],
                  [{"type": "text", "text": {"content": "Monitor RAM, sockets, errors, uptime"}}],
                  [{"type": "text", "text": {"content": "To Create"}}]
                ]
              }
            },
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "Documentation"}}],
                  [{"type": "text", "text": {"content": "Title"}}],
                  [{"type": "text", "text": {"content": "Central tech + ops docs"}}],
                  [{"type": "text", "text": {"content": "To Create"}}]
                ]
              }
            },
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "Meeting Notes"}}],
                  [{"type": "text", "text": {"content": "Title"}}],
                  [{"type": "text", "text": {"content": "Record design / retro decisions"}}],
                  [{"type": "text", "text": {"content": "To Create"}}]
                ]
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "paragraph",
        "paragraph": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "All DBs include full relation & roll-up matrices (see JSON schemas below).",
                "link": null
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "heading_2",
        "heading_2": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Condensed Schemas (JSON Style)",
                "link": null
              }
            }
          ],
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "heading_3",
        "heading_3": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Agent Registry",
                "link": null
              }
            }
          ],
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "code",
        "code": {
          "caption": [],
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "{\n  \"Agent ID\": \"AGT-0001\",\n  \"Kind\": [\"Core\",\"Utility\",\"Frontier\"],\n  \"Status\": [\"Active\",\"Idle\",\"Maintenance\"],\n  \"Skills\": [\"Git\",\"Notion API\",\"LLM Routing\"],\n  \"Perf Score\": \"Formula: weighted last-24h success %\", \n  \"Last Active\": \"Date\",\n  \"Load %\": \"Roll-up from Project assignments\",\n  \"Relations\": [\"Projects\",\"Components\",\"Activity Log\"]\n}",
                "link": null
              }
            }
          ],
          "language": "json"
        }
      },
      {
        "object": "block",
        "type": "heading_3",
        "heading_3": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Component Library",
                "link": null
              }
            }
          ],
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "code",
        "code": {
          "caption": [],
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "{\n  \"Comp ID\": \"CMP-git-local\",\n  \"Type\": [\"Service\",\"API\",\"Gateway\"],\n  \"Version\": \"SemVer\",\n  \"State\": [\"Prod\",\"Beta\",\"Deprecated\"],\n  \"Uptime %\": \"Roll-up last-30d\",\n  \"Health\": \"🟢 / 🟡 / 🔴 formula\",\n  \"Config Blob\": \"JSON\",\n  \"Relations\": [\"Agents\",\"Projects\",\"Dependencies\"]\n}",
                "link": null
              }
            }
          ],
          "language": "json"
        }
      },
      {
        "object": "block",
        "type": "heading_3",
        "heading_3": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Project Tracker",
                "link": null
              }
            }
          ],
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "code",
        "code": {
          "caption": [],
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "{\n  \"Proj ID\": \"PRJ-2025-001\",\n  \"Stage\": [\"Planning\",\"Build\",\"Review\",\"Done\"],\n  \"Progress %\": \"Auto from Milestones\",\n  \"Risk\": [\"Low\",\"Med\",\"High\"],\n  \"Budget (h)\": \"Number\",\n  \"Due\": \"Date\",\n  \"Relations\": [\"Agents\",\"Components\",\"Notes\"]\n}",
                "link": null
              }
            }
          ],
          "language": "json"
        }
      },
      {
        "object": "block",
        "type": "paragraph",
        "paragraph": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "(Full property lists with roll-ups, status formulas, and icon sets are embedded in each DB template.)",
                "link": null
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "heading_2",
        "heading_2": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Reusable Templates",
                "link": null
              }
            }
          ],
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "table",
        "table": {
          "table_width": 2,
          "has_column_header": true,
          "has_row_header": false,
          "children": [
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "Template"}}],
                  [{"type": "text", "text": {"content": "Highlights"}}]
                ]
              }
            },
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "Agent"}}],
                  [{"type": "text", "text": {"content": "Auto-ID ➜ owner ➜ primary/secondary skills ➜ runtime block (Node/TS) ➜ inline perf sparkline ➜ checklist"}}]
                ]
              }
            },
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "Component"}}],
                  [{"type": "text", "text": {"content": "SemVer, Mermaid diagram, API spec block, LaunchAgent plist snippet, alert thresholds, change-log timeline"}}]
                ]
              }
            },
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "Project"}}],
                  [{"type": "text", "text": {"content": "Charter, milestone kanban, risk matrix, auto budget burn-down, Slack/Teams embed"}}]
                ]
              }
            },
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "Doc Page"}}],
                  [{"type": "text", "text": {"content": "MDX section switcher, call-outs, synced-block footers, GPT-index by topic"}}]
                ]
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "paragraph",
        "paragraph": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "All templates auto-link to databases on creation via Notion template button.",
                "link": null
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "heading_2",
        "heading_2": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Automations (Notion → anchor CLI Hooks)",
                "link": null
              }
            }
          ],
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "paragraph",
        "paragraph": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Implement with Notion Database Automation, plus TypeScript hexa CLI web-hooks.",
                "link": null
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "table",
        "table": {
          "table_width": 3,
          "has_column_header": true,
          "has_row_header": false,
          "children": [
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "Trigger (DB)"}}],
                  [{"type": "text", "text": {"content": "Condition"}}],
                  [{"type": "text", "text": {"content": "Action"}}]
                ]
              }
            },
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "Agent Registry"}}],
                  [{"type": "text", "text": {"content": "Last Active > 24 h"}}],
                  [{"type": "text", "text": {"content": "Move Status → Idle & notify via macOS push"}}]
                ]
              }
            },
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "Component Library"}}],
                  [{"type": "text", "text": {"content": "Health = 🔴"}}],
                  [{"type": "text", "text": {"content": "Run hexa restart <Comp ID>"}}]
                ]
              }
            },
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "Project Tracker"}}],
                  [{"type": "text", "text": {"content": "Milestone% drift > 15"}}],
                  [{"type": "text", "text": {"content": "Auto-escalate Risk to High"}}]
                ]
              }
            },
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "System Metrics"}}],
                  [{"type": "text", "text": {"content": "CPU > 300 % for > 1 min"}}],
                  [{"type": "text", "text": {"content": "Log incident & create Ops Guide page"}}]
                ]
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "heading_2",
        "heading_2": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Dashboards (all ↔ linked views)",
                "link": null
              }
            }
          ],
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "paragraph",
        "paragraph": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Live System Board — high-priority components sorted by Health.",
                "link": null
              },
              "annotations": {
                "bold": true
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "paragraph",
        "paragraph": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Agent Leaderboard — gallery view by Perf Score (descending).",
                "link": null
              },
              "annotations": {
                "bold": true
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "paragraph",
        "paragraph": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Project Gantt — timeline with risk-color bars.",
                "link": null
              },
              "annotations": {
                "bold": true
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "paragraph",
        "paragraph": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Error Heatmap — 24-hour metric pivot (requires metric DB + Notion Board chart).",
                "link": null
              },
              "annotations": {
                "bold": true
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "paragraph",
        "paragraph": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Embed quick-action buttons (/callout ➜ hexa status, hexa logs) for one-click troubleshooting.",
                "link": null
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "heading_2",
        "heading_2": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Implementation Timeline (7-Day Solo Roll-out)",
                "link": null
              }
            }
          ],
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "table",
        "table": {
          "table_width": 3,
          "has_column_header": true,
          "has_row_header": false,
          "children": [
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "Day"}}],
                  [{"type": "text", "text": {"content": "Focus"}}],
                  [{"type": "text", "text": {"content": "Key Deliverables"}}]
                ]
              }
            },
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "0"}}],
                  [{"type": "text", "text": {"content": "Prep"}}],
                  [{"type": "text", "text": {"content": "Export any legacy pages, clear workspace"}}]
                ]
              }
            },
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "1"}}],
                  [{"type": "text", "text": {"content": "Foundation"}}],
                  [{"type": "text", "text": {"content": "Create Top-Level pages + 3 core DBs"}}]
                ]
              }
            },
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "2"}}],
                  [{"type": "text", "text": {"content": "Schema + Templates"}}],
                  [{"type": "text", "text": {"content": "Define full property sets, formulas, & reusable templates"}}]
                ]
              }
            },
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "3"}}],
                  [{"type": "text", "text": {"content": "Migration"}}],
                  [{"type": "text", "text": {"content": "Import docs, back-fill projects, link agents/components"}}]
                ]
              }
            },
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "4"}}],
                  [{"type": "text", "text": {"content": "Automation"}}],
                  [{"type": "text", "text": {"content": "Set all DB automations + hexa CLI web-hooks"}}]
                ]
              }
            },
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "5"}}],
                  [{"type": "text", "text": {"content": "Dashboards"}}],
                  [{"type": "text", "text": {"content": "Build live boards, KPI roll-ups, dark-mode UI polish"}}]
                ]
              }
            },
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "6"}}],
                  [{"type": "text", "text": {"content": "QA & Training"}}],
                  [{"type": "text", "text": {"content": "Self-test all flows, record Loom mini-guides"}}]
                ]
              }
            },
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [{"type": "text", "text": {"content": "7"}}],
                  [{"type": "text", "text": {"content": "Go-Live"}}],
                  [{"type": "text", "text": {"content": "Delete legacy, set permissions, snapshot backup"}}]
                ]
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "heading_2",
        "heading_2": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Security / Maintenance",
                "link": null
              }
            }
          ],
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "paragraph",
        "paragraph": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "RBAC — Only Owner role has write on System Config; all else read.",
                "link": null
              },
              "annotations": {
                "bold": true
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "paragraph",
        "paragraph": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Backups — Weekly notion-export zip; stored in /local/git repo.",
                "link": null
              },
              "annotations": {
                "bold": true
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "paragraph",
        "paragraph": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Performance Hygiene — Quarterly formula audit; image compress pass.",
                "link": null
              },
              "annotations": {
                "bold": true
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "paragraph",
        "paragraph": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Change Log — Every DB template appends to a global Changelog DB via automation.",
                "link": null
              },
              "annotations": {
                "bold": true
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "paragraph",
        "paragraph": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Compliance — Workspace Health page lists UMASK (0660) & LaunchAgent plist hashes for audit.",
                "link": null
              },
              "annotations": {
                "bold": true
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "heading_2",
        "heading_2": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "System Configuration",
                "link": null
              }
            }
          ],
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "heading_3",
        "heading_3": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Current MCP Server Configuration",
                "link": null
              }
            }
          ],
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "code",
        "code": {
          "caption": [],
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "{\n  \"mcpServers\": {\n    \"filesystem\": {\n      \"command\": \"npx\",\n      \"args\": [\n        \"-y\",\n        \"@modelcontextprotocol/server-filesystem\",\n        \"/Users/XPV/Desktop\",\n        \"/Users/XPV/Library\",\n        \"/Users/XPV/Documents\"\n      ],\n      \"env\": {\n        \"NODE_OPTIONS\": \"--max-old-space-size=8192\",\n        \"UV_THREADPOOL_SIZE\": \"12\"\n      }\n    },\n    \"notion\": {\n      \"command\": \"npx\",\n      \"args\": [\n        \"-y\",\n        \"@notionhq/notion-mcp-server\"\n      ],\n      \"env\": {\n        \"NODE_OPTIONS\": \"--max-old-space-size=8192\",\n        \"UV_THREADPOOL_SIZE\": \"12\",\n        \"OPENAPI_MCP_HEADERS\": \"{\\\"Authorization\\\": \\\"Bearer ${NOTION_API_KEY}\\\", \\\"Notion-Version\\\": \\\"2022-06-28\\\" }\"\n      }\n    },\n    \"slack\": {\n      \"command\": \"npx\",\n      \"args\": [\n        \"-y\",\n        \"@modelcontextprotocol/server-slack\"\n      ],\n      \"env\": {\n        \"NODE_OPTIONS\": \"--max-old-space-size=8192\",\n        \"UV_THREADPOOL_SIZE\": \"12\",\n        \"SLACK_BOT_TOKEN\": \"${SLACK_BOT_TOKEN}\",\n        \"SLACK_TEAM_ID\": \"${SLACK_TEAM_ID}\"\n      }\n    }\n  }\n}",
                "link": null
              }
            }
          ],
          "language": "json"
        }
      },
      {
        "object": "block",
        "type": "heading_3",
        "heading_3": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Node-/M3-tuning defaults",
                "link": null
              }
            }
          ],
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "code",
        "code": {
          "caption": [],
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "NODE_OPTIONS=\"--max-old-space-size=8192 --expose-gc\"\nUV_THREADPOOL_SIZE=\"12\"          # matches 12 performance threads\nMCP_WORKER_THREADS=\"11\"\nMCP_MAX_PARALLEL=\"7\"\nMCP_USE_NEURAL_ENGINE=\"1\"        # enable ANE hinting\nPATH=\"/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin\"\nUMASK=\"007\"",
                "link": null
              }
            }
          ],
          "language": "bash"
        }
      },
      {
        "object": "block",
        "type": "heading_2",
        "heading_2": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Next Steps",
                "link": null
              }
            }
          ],
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "to_do",
        "to_do": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Create Agent Registry Database",
                "link": null
              }
            }
          ],
          "checked": false,
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "to_do",
        "to_do": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Create Component Library Database",
                "link": null
              }
            }
          ],
          "checked": false,
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "to_do",
        "to_do": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Create Project Tracker Database",
                "link": null
              }
            }
          ],
          "checked": false,
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "to_do",
        "to_do": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Create System Metrics Database",
                "link": null
              }
            }
          ],
          "checked": false,
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "to_do",
        "to_do": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Create Documentation Database",
                "link": null
              }
            }
          ],
          "checked": false,
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "to_do",
        "to_do": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Create Meeting Notes Database",
                "link": null
              }
            }
          ],
          "checked": false,
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "to_do",
        "to_do": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Set Up Dashboard Views",
                "link": null
              }
            }
          ],
          "checked": false,
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "to_do",
        "to_do": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Configure Slack Integration",
                "link": null
              }
            }
          ],
          "checked": false,
          "color": "default"
        }
      }
    ]
  }'

echo -e "\n${GREEN}✓ Anchor workspace structure created successfully!${NC}"
echo -e "${YELLOW}View your workspace at: https://www.notion.so/Anchor-${NOTION_PAGE_ID}${NC}"
