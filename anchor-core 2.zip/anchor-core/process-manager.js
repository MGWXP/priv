#!/usr/bin/env node
/**
 * process-manager.js - Enhanced Process Manager for Anchor System V6
 * Implements health monitoring, automatic recovery, and lifecycle management
 * © 2025 XPV - MIT
 */

const fs = require('fs').promises;
const fsSync = require('fs');
const { spawn, exec } = require('child_process');
const path = require('path');
const os = require('os');
const { promisify } = require('util');
const execAsync = promisify(exec);

/**
 * ProcessManager handles all aspects of process lifecycle management
 * - Process initialization with dependency resolution
 * - Health monitoring
 * - Automatic recovery
 * - Graceful termination
 */
class ProcessManager {
  /**
   * Create a new ProcessManager
   * @param {object} options - Configuration options
   */
  constructor(options = {}) {
    this.options = {
      checkInterval: 5000,     // Check health every 5 seconds
      restartDelay: 1000,      // Initial delay before restarting
      maxRestarts: 5,          // Maximum restart attempts
      restartBackoff: true,    // Use exponential backoff for restarts
      logDirectory: path.join(os.homedir(), 'Library/Logs/Claude'),
      ...options
    };
    
    this.processes = new Map();
    this.checkTimer = null;
    this.restartCounts = {};
    this.logger = options.logger || console;
    
    // Ensure log directory exists
    this._ensureLogDirectory();
  }
  
  /**
   * Register a process with the manager
   * @param {string} name - Process name
   * @param {object} config - Process configuration
   * @returns {ProcessManager} - Self for chaining
   */
  registerProcess(name, config) {
    this.processes.set(name, {
      name,
      command: config.command,
      args: config.args || [],
      cwd: config.cwd || process.cwd(),
      env: config.env || {},
      pidFile: config.pidFile,
      socketPath: config.socketPath,
      logPath: config.logPath || path.join(this.options.logDirectory, `mcp-server-${name}.log`),
      process: null,
      status: 'stopped',
      lastRestart: 0,
      healthCheck: config.healthCheck || (async () => true)
    });
    
    this.restartCounts[name] = 0;
    
    return this;
  }
  
  /**
   * Start all registered processes
   * @returns {Promise<ProcessManager>} - Self for chaining
   */
  async startAll() {
    // Map process names to start operations
    const startOperations = Array.from(this.processes.keys()).map(name => this.start(name));
    
    // Wait for all processes to start
    await Promise.all(startOperations);
    
    // Start health check interval
    this.checkTimer = setInterval(() => this.checkHealth(), this.options.checkInterval);
    this.checkTimer.unref(); // Don't keep process alive just for checks
    
    return this;
  }
  
  /**
   * Start a specific process
   * @param {string} name - Process name
   * @returns {Promise<boolean>} - True if started successfully
   */
  async start(name) {
    const procInfo = this.processes.get(name);
    if (!procInfo) {
      throw new Error(`Process ${name} not registered`);
    }
    
    if (procInfo.status === 'running') {
      this.logger.info(`Process ${name} already running`);
      return true;
    }
    
    // Check for stale PID file
    if (procInfo.pidFile && await this._fileExists(procInfo.pidFile)) {
      const pid = (await fs.readFile(procInfo.pidFile, 'utf8')).trim();
      const isRunning = await this._isProcessRunning(pid);
      
      if (isRunning) {
        this.logger.info(`Process ${name} already running with PID ${pid}`);
        procInfo.process = { pid };
        procInfo.status = 'running';
        return true;
      } else {
        this.logger.info(`Removing stale PID file for ${name}`);
        await fs.unlink(procInfo.pidFile);
      }
    }
    
    // Check for stale socket file
    if (procInfo.socketPath && await this._fileExists(procInfo.socketPath)) {
      try {
        await fs.unlink(procInfo.socketPath);
        this.logger.info(`Removed stale socket for ${name}`);
      } catch (err) {
        this.logger.error(`Error removing stale socket: ${err.message}`);
      }
    }
    
    // Ensure log file exists and is writable
    await this._ensureLogFile(procInfo.logPath);
    
    // Start the process
    this.logger.info(`Starting ${name}...`);
    
    try {
      // Open log file for output
      const logStream = fsSync.createWriteStream(procInfo.logPath, { flags: 'a' });
      
      // Start the process with proper environment
      const proc = spawn(procInfo.command, procInfo.args, {
        cwd: procInfo.cwd,
        env: { ...process.env, ...procInfo.env },
        stdio: ['ignore', logStream, logStream],
        detached: true
      });
      
      procInfo.process = proc;
      
      // Handle process events
      proc.on('error', (err) => {
        this.logger.error(`Failed to start ${name}: ${err.message}`);
        procInfo.status = 'error';
        logStream.write(`Process error: ${err.message}\n`);
      });
      
      proc.on('exit', (code, signal) => {
        this.logger.info(`Process ${name} exited with code ${code} and signal ${signal}`);
        procInfo.status = 'stopped';
        procInfo.process = null;
        logStream.end(`Process exited with code ${code} and signal ${signal}\n`);
        
        // Remove PID file if it exists
        if (procInfo.pidFile && fsSync.existsSync(procInfo.pidFile)) {
          try {
            fsSync.unlinkSync(procInfo.pidFile);
          } catch (err) {
            this.logger.error(`Failed to remove PID file: ${err.message}`);
          }
        }
        
        // Auto-restart if enabled
        if (this.options.restartBackoff) {
          this._scheduleRestart(name);
        }
      });
      
      // Write PID file
      if (procInfo.pidFile) {
        await fs.writeFile(procInfo.pidFile, proc.pid.toString());
      }
      
      procInfo.status = 'running';
      this.logger.info(`Started ${name} with PID ${proc.pid}`);
      
      // Wait a bit to ensure process is stable
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Verify process is still running
      const isRunning = await this._isProcessRunning(proc.pid);
      if (isRunning) {
        return true;
      } else {
        this.logger.error(`Process ${name} failed to start`);
        procInfo.status = 'error';
        return false;
      }
    } catch (err) {
      this.logger.error(`Error starting ${name}: ${err.message}`);
      procInfo.status = 'error';
      return false;
    }
  }
  
  /**
   * Stop a specific process
   * @param {string} name - Process name
   * @returns {Promise<void>}
   */
  async stop(name) {
    const procInfo = this.processes.get(name);
    if (!procInfo || !procInfo.process) {
      this.logger.info(`Process ${name} not running`);
      return;
    }
    
    this.logger.info(`Stopping ${name}...`);
    
    // Try graceful termination first
    if (procInfo.process.pid) {
      try {
        process.kill(procInfo.process.pid, 'SIGTERM');
        
        // Give it a chance to terminate gracefully
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Check if it's still running
        const isRunning = await this._isProcessRunning(procInfo.process.pid);
        if (isRunning) {
          // Force kill
          process.kill(procInfo.process.pid, 'SIGKILL');
        }
      } catch (err) {
        this.logger.error(`Error stopping ${name}: ${err.message}`);
      }
    }
    
    // Clear status
    procInfo.status = 'stopped';
    procInfo.process = null;
    
    // Remove PID file
    if (procInfo.pidFile && await this._fileExists(procInfo.pidFile)) {
      await fs.unlink(procInfo.pidFile);
    }
    
    this.logger.info(`Stopped ${name}`);
  }
  
  /**
   * Stop all processes
   * @returns {Promise<void>}
   */
  async stopAll() {
    // Map process names to stop operations
    const stopOperations = Array.from(this.processes.keys()).map(name => this.stop(name));
    
    // Wait for all processes to stop
    await Promise.all(stopOperations);
    
    // Clear health check timer
    if (this.checkTimer) {
      clearInterval(this.checkTimer);
      this.checkTimer = null;
    }
  }
  
  /**
   * Check health of all processes
   * @returns {Promise<void>}
   */
  async checkHealth() {
    for (const [name, procInfo] of this.processes) {
      if (procInfo.status !== 'running' || !procInfo.process) {
        continue;
      }
      
      // Basic process check
      const isRunning = await this._isProcessRunning(procInfo.process.pid);
      if (!isRunning) {
        this.logger.error(`Process ${name} not running but marked as running`);
        procInfo.status = 'stopped';
        procInfo.process = null;
        
        if (this.options.restartBackoff) {
          this._scheduleRestart(name);
        }
        continue;
      }
      
      // Custom health check if provided
      try {
        const isHealthy = await procInfo.healthCheck(procInfo);
        if (!isHealthy) {
          this.logger.error(`Process ${name} failed health check`);
          await this.stop(name);
          
          if (this.options.restartBackoff) {
            this._scheduleRestart(name);
          }
        }
      } catch (err) {
        this.logger.error(`Error in health check for ${name}: ${err.message}`);
      }
    }
  }
  
  /**
   * Get status of all processes
   * @returns {object} - Status object
   */
  getStatus() {
    const status = {};
    for (const [name, procInfo] of this.processes) {
      status[name] = {
        status: procInfo.status,
        pid: procInfo.process ? procInfo.process.pid : null,
        restarts: this.restartCounts[name] || 0,
        socket: procInfo.socketPath ? fsSync.existsSync(procInfo.socketPath) : false
      };
    }
    return status;
  }
  
  /**
   * Schedule a process restart with exponential backoff
   * @param {string} name - Process name
   * @private
   */
  _scheduleRestart(name) {
    const procInfo = this.processes.get(name);
    if (!procInfo) return;
    
    this.restartCounts[name]++;
    
    if (this.restartCounts[name] > this.options.maxRestarts) {
      this.logger.error(`Process ${name} exceeded maximum restart attempts (${this.options.maxRestarts})`);
      return;
    }
    
    const delay = this.options.restartBackoff
      ? Math.min(30000, this.options.restartDelay * Math.pow(2, this.restartCounts[name] - 1))
      : this.options.restartDelay;
    
    this.logger.info(`Scheduling restart of ${name} in ${delay}ms (attempt ${this.restartCounts[name]})`);
    
    setTimeout(() => {
      this.start(name).catch(err => {
        this.logger.error(`Error restarting ${name}: ${err.message}`);
      });
    }, delay);
  }
  
  /**
   * Check if a process is running
   * @param {string|number} pid - Process ID
   * @returns {Promise<boolean>} - True if running
   * @private
   */
  async _isProcessRunning(pid) {
    if (!pid) {
      return false;
    }
    
    try {
      // Different process check based on platform
      if (os.platform() === 'win32') {
        const { stdout } = await execAsync(`tasklist /FI "PID eq ${pid}"`);
        return stdout.includes(pid.toString());
      } else {
        // Unix-based platforms
        const { stdout } = await execAsync(`ps -p ${pid} -o pid=`);
        return !!stdout.trim();
      }
    } catch (err) {
      // Process not running
      return false;
    }
  }
  
  /**
   * Check if a file exists
   * @param {string} filePath - File path
   * @returns {Promise<boolean>} - True if exists
   * @private
   */
  async _fileExists(filePath) {
    try {
      await fs.access(filePath);
      return true;
    } catch (err) {
      return false;
    }
  }
  
  /**
   * Ensure log directory exists
   * @private
   */
  async _ensureLogDirectory() {
    try {
      await fs.mkdir(this.options.logDirectory, { recursive: true });
    } catch (err) {
      // Ignore if directory already exists
      if (err.code !== 'EEXIST') {
        this.logger.error(`Error creating log directory: ${err.message}`);
      }
    }
  }
  
  /**
   * Ensure log file exists and is writable
   * @param {string} logPath - Log file path
   * @private
   */
  async _ensureLogFile(logPath) {
    try {
      // Ensure directory exists
      await fs.mkdir(path.dirname(logPath), { recursive: true });
      
      // Touch the file to ensure it exists
      const handle = await fs.open(logPath, 'a');
      await handle.close();
    } catch (err) {
      this.logger.error(`Error creating log file: ${err.message}`);
    }
  }
}

module.exports = ProcessManager;
