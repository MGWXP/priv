#!/bin/bash
# alternate-dashboard-approach.sh - Alternative approach using iframe embedding
# For M3 Max (48GB unified memory) hardware

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

echo -e "${BLUE}=== Alternative Dashboard Approach with iframes ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e ""

# Check if NOTION_API_KEY is set
if [ -z "${NOTION_API_KEY}" ]; then
    echo -e "${YELLOW}NOTION_API_KEY environment variable is not set${NC}"
    echo -e "Would you like to set it now? (y/n)"
    read -r response
    if [[ "$response" =~ ^([yY][eE][sS]|[yY])$ ]]; then
        echo -e "Enter your Notion API Key:"
        read -s NOTION_KEY
        export NOTION_API_KEY="$NOTION_KEY"
        echo -e "${GREEN}✓ NOTION_API_KEY set${NC}"
    else
        echo -e "${RED}Cannot proceed without Notion API Key${NC}"
        exit 1
    fi
fi

# Load database IDs and other necessary information
MAIN_DASHBOARD_ID=$(cat /Users/XPV/Desktop/anchor-core/notion-dashboard-ids/main-dashboard-id.txt)
AGENT_REGISTRY_ID=$(cat /Users/XPV/Desktop/anchor-core/notion-db-ids/agent-registry-id.txt | head -1)
COMPONENT_LIBRARY_ID=$(cat /Users/XPV/Desktop/anchor-core/notion-db-ids/component-library-id.txt | head -1)
PROJECT_TRACKER_ID=$(cat /Users/XPV/Desktop/anchor-core/notion-db-ids/project-tracker-id.txt | head -1)

# Create HTML files with embedded iframes for each database
echo -e "${YELLOW}Creating HTML files with embedded iframes...${NC}"

# Create directory for HTML files if it doesn't exist
mkdir -p /Users/XPV/Desktop/anchor-core/notion-embeds

# Create HTML file for Agent Registry
cat > /Users/XPV/Desktop/anchor-core/notion-embeds/agent-registry.html << EOF
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agent Registry</title>
    <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            overflow: hidden;
        }
        iframe {
            width: 100%;
            height: 100%;
            border: none;
        }
    </style>
</head>
<body>
    <iframe src="https://notion.so/${AGENT_REGISTRY_ID}" allowfullscreen></iframe>
</body>
</html>
EOF

# Create HTML file for Component Library
cat > /Users/XPV/Desktop/anchor-core/notion-embeds/component-library.html << EOF
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Component Library</title>
    <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            overflow: hidden;
        }
        iframe {
            width: 100%;
            height: 100%;
            border: none;
        }
    </style>
</head>
<body>
    <iframe src="https://notion.so/${COMPONENT_LIBRARY_ID}" allowfullscreen></iframe>
</body>
</html>
EOF

# Create HTML file for Project Tracker
cat > /Users/XPV/Desktop/anchor-core/notion-embeds/project-tracker.html << EOF
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Tracker</title>
    <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            overflow: hidden;
        }
        iframe {
            width: 100%;
            height: 100%;
            border: none;
        }
    </style>
</head>
<body>
    <iframe src="https://notion.so/${PROJECT_TRACKER_ID}" allowfullscreen></iframe>
</body>
</html>
EOF

# Create Master Dashboard HTML
cat > /Users/XPV/Desktop/anchor-core/notion-embeds/master-dashboard.html << EOF
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anchor Master Dashboard</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, "Open Sans", "Helvetica Neue", sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #191919;
            color: #ffffff;
        }
        h1, h2 {
            color: #ffffff;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        .card {
            background-color: #2d2d2d;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }
        .button-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 20px;
        }
        .button {
            background-color: #2d2d2d;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            display: inline-block;
            margin-right: 10px;
            cursor: pointer;
        }
        .button.blue {
            background-color: #0070f3;
        }
        .button.green {
            background-color: #10b981;
        }
        .button.yellow {
            background-color: #f59e0b;
        }
        .dashboard {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .dashboard-item {
            flex: 1;
            min-width: 300px;
            height: 400px;
            background-color: #2d2d2d;
            border-radius: 8px;
            overflow: hidden;
        }
        .dashboard-item iframe {
            width: 100%;
            height: 100%;
            border: none;
        }
        .note {
            background-color: #374151;
            border-radius: 8px;
            padding: 15px;
            margin: 20px 0;
            border-left: 4px solid #0070f3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Anchor System Dashboard</h1>
        <p>Main operational dashboard for the Anchor workspace. Last updated: $(date '+%Y-%m-%d %H:%M:%S')</p>

        <div class="card">
            <h2>Quick Access</h2>
            <div class="button-container">
                <a href="https://notion.so/${COMPONENT_LIBRARY_ID}" target="_blank" class="button blue">Component Library</a>
                <a href="https://notion.so/${AGENT_REGISTRY_ID}" target="_blank" class="button green">Agent Registry</a>
                <a href="https://notion.so/${PROJECT_TRACKER_ID}" target="_blank" class="button yellow">Project Tracker</a>
            </div>
        </div>

        <div class="note">
            <strong>Note:</strong> This dashboard provides iframe embeds of Notion databases. For the best experience, ensure you're logged into Notion in your browser. If you encounter any issues with the embeds, use the Quick Access links above to open the databases directly.
        </div>
        
        <div class="dashboard">
            <div class="dashboard-item">
                <h2>Component Library</h2>
                <iframe src="component-library.html" allowfullscreen></iframe>
            </div>
            <div class="dashboard-item">
                <h2>Agent Registry</h2>
                <iframe src="agent-registry.html" allowfullscreen></iframe>
            </div>
        </div>
        
        <div class="dashboard">
            <div class="dashboard-item" style="flex: 1 1 100%;">
                <h2>Project Tracker</h2>
                <iframe src="project-tracker.html" allowfullscreen></iframe>
            </div>
        </div>
    </div>
</body>
</html>
EOF

echo -e "${GREEN}✓ HTML files created successfully!${NC}"
echo -e "${YELLOW}Files are located in: /Users/XPV/Desktop/anchor-core/notion-embeds/${NC}"

# Create README for the embed approach
cat > /Users/XPV/Desktop/anchor-core/notion-embeds/README.md << EOF
# Notion Database Embedding Workaround

## Overview
This directory contains HTML files that provide an alternative approach to embedding Notion databases by using iframes. Since the Notion API does not support creating linked databases programmatically, this approach uses HTML iframe embedding as a workaround.

## Files Included
- **master-dashboard.html**: Main dashboard that embeds all databases
- **agent-registry.html**: Embed for the Agent Registry database
- **component-library.html**: Embed for the Component Library database
- **project-tracker.html**: Embed for the Project Tracker database

## How to Use
1. Open the HTML files in a web browser
2. Ensure you're logged into Notion in the same browser
3. The embedded databases should load in the iframes

## Benefits of This Approach
- Provides a visual dashboard experience
- Allows viewing multiple databases simultaneously
- Works independently of API limitations
- Can be hosted on a simple web server if needed

## Limitations
- Requires the user to be logged into Notion
- May have cross-origin restrictions in some environments
- Iframe embedding may have limited functionality compared to native Notion embedding

## Technical Notes
The iframe approach works by loading the Notion database URLs directly in embedded frames. This is a client-side solution that bypasses the API limitations but requires proper authentication in the browser.

## Database IDs
- Agent Registry: ${AGENT_REGISTRY_ID}
- Component Library: ${COMPONENT_LIBRARY_ID}
- Project Tracker: ${PROJECT_TRACKER_ID}

---

Created: $(date '+%Y-%m-%d %H:%M:%S')
EOF

# Create a simple server script to view the dashboard
cat > /Users/XPV/Desktop/anchor-core/start-dashboard-server.sh << EOF
#!/bin/bash
# Simple HTTP server to view the dashboard locally

echo "Starting HTTP server for the dashboard..."
echo "Please open http://localhost:8000/master-dashboard.html in your browser"
echo "Press Ctrl+C to stop the server"

cd /Users/XPV/Desktop/anchor-core/notion-embeds/
python3 -m http.server 8000
EOF

# Make the server script executable
chmod +x /Users/XPV/Desktop/anchor-core/start-dashboard-server.sh

echo -e "${GREEN}✓ Dashboard server script created!${NC}"
echo -e "${YELLOW}To start the dashboard server, run:${NC}"
echo -e "./start-dashboard-server.sh"
echo -e "${YELLOW}Then open http://localhost:8000/master-dashboard.html in your browser${NC}"

echo -e "\n${BLUE}Alternative Dashboard Approach Summary:${NC}"
echo -e "1. HTML files with iframe embeds created for each database"
echo -e "2. Master dashboard HTML created to display all databases together"
echo -e "3. Simple HTTP server script provided for local viewing"
echo -e "4. Documentation added explaining the approach"

echo -e "\n${GREEN}✅ Alternative Dashboard Approach Ready!${NC}"
echo -e "${YELLOW}This approach bypasses the API limitations by using direct iframe embedding.${NC}"
echo -e "${YELLOW}While not a perfect solution, it provides a visual dashboard experience.${NC}"
