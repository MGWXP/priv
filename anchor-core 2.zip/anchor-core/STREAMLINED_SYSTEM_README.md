# CNIF System Streamlining and Consolidation

## Overview

This repository contains a streamlined and consolidated version of the Claude-Notion Integration Framework (CNIF). The system has been optimized for M3 Max hardware and improved for development flow.

## Key Improvements

### 1. Unified Directory Structure

The system now follows a clear directory structure:

- **`/core/`**: Core server components (.cjs files)
- **`/admin/`**: Administrative scripts (CLI, monitoring)
- **`/config/`**: Configuration files (.json, .env)
- **`/tools/`**: Utility tools and scripts
- **`/archive/`**: Archived legacy files

### 2. Unified M3 Optimizer

A new unified M3 optimizer has been created that combines the functionality of:
- m3-optimizer.js
- m3_optimizer.js
- m3_optimizer.cjs
- m3-mcp-optimizer.js

The optimizer provides:
- Optimized memory allocation
- Thread pool configuration
- Memory pooling
- Metal acceleration if available
- Safe NODE_OPTIONS settings

### 3. Unified Admin CLI

A powerful CLI tool has been created for all operations:
- `start`: Start all CNIF services
- `stop`: Stop all CNIF services
- `restart`: Restart all CNIF services
- `status`: Show status of all CNIF services
- `logs`: Show logs for a specific service or all services
- `optimize`: Run M3 optimizer
- `clean`: Clean up stale PID files and socket files
- `dashboard`: Start the web dashboard

### 4. Module System Consistency

- All server implementation files now use the `.cjs` extension for CommonJS
- Entry points follow a consistent pattern
- Package.json is properly configured for CommonJS

### 5. Streamlined Development Workflow

- Single command to start all services
- Comprehensive logging and status reporting
- Unified error handling and recovery

## Getting Started

1. **Initial Setup**:
   ```bash
   chmod +x /Users/XPV/Desktop/anchor-core/make-unified-optimizer-executable.sh
   /Users/XPV/Desktop/anchor-core/make-unified-optimizer-executable.sh
   ```

2. **Using the CLI**:
   ```bash
   # Start all services
   /Users/XPV/Desktop/anchor-core/cnif start
   
   # Check system status
   /Users/XPV/Desktop/anchor-core/cnif status
   
   # View logs
   /Users/XPV/Desktop/anchor-core/cnif logs
   ```

3. **Advanced Usage**:
   ```bash
   # Run optimizer to tune for best performance
   /Users/XPV/Desktop/anchor-core/cnif optimize
   
   # Start web dashboard
   /Users/XPV/Desktop/anchor-core/cnif dashboard
   ```

## System Architecture

The CNIF system consists of the following components:

1. **Socket Server**: Handles MCP communication with Claude
2. **Schema Registry**: Manages versioned schemas for Claude and Notion data
3. **Streaming Transformer**: Converts between Claude's XML and Notion's JSON
4. **Notion Connection Manager**: Handles API communication with Notion
5. **MCP Orchestrator**: Coordinates service communication

## Best Practices

1. **Module Format**: Use CommonJS (.cjs) for server implementations
2. **Memory Management**: Use memory pooling for better performance
3. **Error Handling**: Implement circuit breaker pattern for resilience
4. **Configuration**: Store all config in the /config directory
5. **Logging**: Use structured logging for better debugging

## Troubleshooting

- **Services Won't Start**: Check logs with `cnif logs`
- **Performance Issues**: Run `cnif optimize` to tune system
- **Socket Errors**: Run `cnif clean` to remove stale socket files
- **Config Issues**: Check .env file in root directory
