#!/bin/bash
# Master script to set up the complete Anchor V6 MCP Project in Notion

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

echo -e "${BLUE}=== Anchor V6 MCP Project Notion Setup ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e ""

# Make all scripts executable
chmod +x /Users/XPV/Desktop/anchor-core/notion-anchor-workspace-builder.sh
chmod +x /Users/XPV/Desktop/anchor-core/create-agent-registry.sh
chmod +x /Users/XPV/Desktop/anchor-core/run-workspace-builder.sh

# Check if NOTION_API_KEY is set
if [ -z "${NOTION_API_KEY}" ]; then
    echo -e "${YELLOW}NOTION_API_KEY environment variable is not set${NC}"
    echo -e "Would you like to set it now? (y/n)"
    read -r response
    if [[ "$response" =~ ^([yY][eE][sS]|[yY])$ ]]; then
        echo -e "Enter your Notion API Key:"
        read -s NOTION_KEY
        export NOTION_API_KEY="$NOTION_KEY"
        echo -e "${GREEN}✓ NOTION_API_KEY set${NC}"
    else
        echo -e "${RED}Cannot proceed without Notion API Key${NC}"
        exit 1
    fi
fi

# Display menu
echo -e "${BLUE}Please select an action:${NC}"
echo -e "1. Build complete workspace structure"
echo -e "2. Create Agent Registry database (after structure is built)"
echo -e "3. Run both steps in sequence"
echo -e "4. Exit"
read -p "Enter your choice (1-4): " choice

case $choice in
    1)
        echo -e "\n${YELLOW}Building workspace structure...${NC}"
        /Users/XPV/Desktop/anchor-core/run-workspace-builder.sh
        ;;
    2)
        echo -e "\n${YELLOW}Creating Agent Registry database...${NC}"
        /Users/XPV/Desktop/anchor-core/create-agent-registry.sh
        ;;
    3)
        echo -e "\n${YELLOW}Running complete setup...${NC}"
        /Users/XPV/Desktop/anchor-core/run-workspace-builder.sh
        echo -e "\n${YELLOW}Waiting 5 seconds for Notion to process...${NC}"
        sleep 5
        /Users/XPV/Desktop/anchor-core/create-agent-registry.sh
        ;;
    4)
        echo -e "\n${YELLOW}Exiting. No changes made.${NC}"
        exit 0
        ;;
    *)
        echo -e "\n${RED}Invalid choice. Please select 1-4.${NC}"
        exit 1
        ;;
esac

echo -e "\n${GREEN}✓ Anchor V6 MCP Project Notion setup complete!${NC}"
echo -e "${YELLOW}View your workspace at: https://www.notion.so/Anchor-1f7e48c2bbbd80df86edd35832916f80${NC}"
