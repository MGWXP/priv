#!/bin/bash
# create-meeting-notes-db.sh - Creates Meeting Notes Database in Notion
# For M3 Max (48GB unified memory) hardware

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

NOTION_PAGE_ID="1f7e48c2-bbbd-80df-86ed-d35832916f80"

echo -e "${BLUE}=== Creating Meeting Notes Database in Notion ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e ""

# Check if NOTION_API_KEY is set
if [ -z "${NOTION_API_KEY}" ]; then
    echo -e "${YELLOW}NOTION_API_KEY environment variable is not set${NC}"
    echo -e "Would you like to set it now? (y/n)"
    read -r response
    if [[ "$response" =~ ^([yY][eE][sS]|[yY])$ ]]; then
        echo -e "Enter your Notion API Key:"
        read -s NOTION_KEY
        export NOTION_API_KEY="$NOTION_KEY"
        echo -e "${GREEN}✓ NOTION_API_KEY set${NC}"
    else
        echo -e "${RED}Cannot proceed without Notion API Key${NC}"
        exit 1
    fi
fi

# Create Meeting Notes database
echo -e "Creating Meeting Notes database..."
RESPONSE=$(curl -s -X POST "https://api.notion.com/v1/databases" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "parent": {
        "type": "page_id",
        "page_id": "'"${NOTION_PAGE_ID}"'"
    },
    "title": [
        {
            "type": "text",
            "text": {
                "content": "Meeting Notes"
            }
        }
    ],
    "properties": {
        "Meeting ID": {
            "title": {}
        },
        "Date": {
            "date": {}
        },
        "Type": {
            "select": {
                "options": [
                    {"name": "Sprint Planning", "color": "blue"},
                    {"name": "Standup", "color": "green"},
                    {"name": "Retro", "color": "purple"},
                    {"name": "Design", "color": "orange"},
                    {"name": "Review", "color": "yellow"}
                ]
            }
        },
        "Attendees": {
            "multi_select": {
                "options": [
                    {"name": "Team A", "color": "blue"},
                    {"name": "Team B", "color": "green"},
                    {"name": "Leadership", "color": "red"},
                    {"name": "Client", "color": "orange"}
                ]
            }
        },
        "Duration": {
            "number": {
                "format": "number"
            }
        },
        "Related Projects": {
            "relation": {
                "database_id": "1f8e48c2-bbbd-81b0-a8be-e86035c189ae",
                "single_property": {}
            }
        },
        "Action Items": {
            "checkbox": {}
        }
    }
}')

# Extract database ID from response
DB_ID=$(echo $RESPONSE | grep -o '"id":"[^"]*' | cut -d'"' -f4)

if [ -z "$DB_ID" ]; then
    echo -e "${RED}Failed to create Meeting Notes database${NC}"
    echo $RESPONSE
    exit 1
fi

echo -e "${GREEN}✓ Meeting Notes database created successfully!${NC}"
echo -e "Database ID: ${DB_ID}"

# Extract property IDs for reference
echo $RESPONSE | grep -o '"id":"[^"]*' | cut -d'"' -f4

# Create sample meeting note entry
echo -e "Creating sample meeting note for Sprint Planning..."
MEETING_RESPONSE=$(curl -s -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "parent": {
        "database_id": "'"${DB_ID}"'"
    },
    "properties": {
        "Meeting ID": {
            "title": [
                {
                    "text": {
                        "content": "MTG-0001"
                    }
                }
            ]
        },
        "Date": {
            "date": {
                "start": "'"$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")"'"
            }
        },
        "Type": {
            "select": {
                "name": "Sprint Planning"
            }
        },
        "Attendees": {
            "multi_select": [
                {"name": "Team A"},
                {"name": "Leadership"}
            ]
        },
        "Duration": {
            "number": 60
        },
        "Action Items": {
            "checkbox": true
        }
    },
    "children": [
        {
            "object": "block",
            "type": "heading_1",
            "heading_1": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Sprint Planning - Q2 Goals"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "paragraph",
            "paragraph": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Discussion on Q2 goals and sprint objectives for the MCP Integration project."
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Action Items"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "to_do",
            "to_do": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Complete System Metrics Database setup"
                        }
                    }
                ],
                "checked": false
            }
        },
        {
            "object": "block",
            "type": "to_do",
            "to_do": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Initialize Slack integration module"
                        }
                    }
                ],
                "checked": false
            }
        }
    ]
}')

if echo $MEETING_RESPONSE | grep -q "error"; then
    echo -e "${YELLOW}Sample meeting note created with warnings${NC}"
else
    echo -e "${GREEN}✓ Sample meeting note created successfully!${NC}"
fi

# Save database ID for future reference
echo "${DB_ID}" > /Users/XPV/Desktop/anchor-core/meeting-notes-db-id.txt
mkdir -p /Users/XPV/Desktop/anchor-core/notion-db-ids
echo "${DB_ID}" > /Users/XPV/Desktop/anchor-core/notion-db-ids/meeting-notes-id.txt

echo -e "\n${GREEN}✓ Meeting Notes database setup complete!${NC}"
echo -e "${YELLOW}View your database at: https://www.notion.so/${DB_ID}${NC}"

# Mark the Meeting Notes task as completed
curl -X PATCH "https://api.notion.com/v1/blocks/1f8e48c2-cdee-430a-b2e8-f91c4b7c3a2d" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "to_do": {
        "checked": true
    }
  }'
