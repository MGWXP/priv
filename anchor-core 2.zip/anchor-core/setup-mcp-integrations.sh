#!/bin/bash

# Set directory paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
LOG_DIR="${ANCHOR_HOME}/logs"
SCHEMA_DIR="${ANCHOR_HOME}/schemas"
SOCKET_DIR="${ANCHOR_HOME}/sockets"

# Create necessary directories
mkdir -p "${LOG_DIR}"
mkdir -p "${SCHEMA_DIR}/claude"
mkdir -p "${SCHEMA_DIR}/notion"
mkdir -p "${SOCKET_DIR}"

# Log function
log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "${LOG_DIR}/setup-mcp-integrations.log"
}

log "Starting CNIF GitHub MCP integration setup"

# Make scripts executable
log "Making scripts executable"
chmod +x "${ANCHOR_HOME}/install-github-mcp.sh"
chmod +x "${ANCHOR_HOME}/update-claude-config.sh"

# Install GitHub MCP server
log "Installing GitHub MCP server"
"${ANCHOR_HOME}/install-github-mcp.sh"

# Prompt for Notion API token
log "Configuring Notion integration"
read -p "Notion API Token: " NOTION_TOKEN

# Save Notion token
echo "NOTION_API_TOKEN=${NOTION_TOKEN}" > "${ANCHOR_HOME}/.notion-env"
chmod 600 "${ANCHOR_HOME}/.notion-env"

# Update Claude Desktop config
log "Updating Claude Desktop configuration"
"${ANCHOR_HOME}/update-claude-config.sh"

# Create a unified launcher
cat > "${ANCHOR_HOME}/launch-mcp-integrations.sh" << 'EOF'
#!/bin/bash

# Set directory paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
LOG_DIR="${ANCHOR_HOME}/logs"

# Create log directory if it doesn't exist
mkdir -p "${LOG_DIR}"

# Log function
log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "${LOG_DIR}/mcp-integrations.log"
}

log "Starting all MCP integrations"

# Stop any running instances
if [ -f "${ANCHOR_HOME}/stop-github-mcp.sh" ]; then
  log "Stopping GitHub MCP server if running"
  "${ANCHOR_HOME}/stop-github-mcp.sh"
fi

# Start GitHub MCP server
if [ -f "${ANCHOR_HOME}/start-github-mcp.sh" ]; then
  log "Starting GitHub MCP server"
  "${ANCHOR_HOME}/start-github-mcp.sh"
fi

# Start CNIF services
if [ -f "${ANCHOR_HOME}/launch-optimized.sh" ]; then
  log "Starting CNIF services"
  "${ANCHOR_HOME}/launch-optimized.sh"
fi

log "✅ All MCP integrations started"
EOF

chmod +x "${ANCHOR_HOME}/launch-mcp-integrations.sh"

# Create a unified stop script
cat > "${ANCHOR_HOME}/stop-mcp-integrations.sh" << 'EOF'
#!/bin/bash

# Set directory paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
LOG_DIR="${ANCHOR_HOME}/logs"

# Create log directory if it doesn't exist
mkdir -p "${LOG_DIR}"

# Log function
log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "${LOG_DIR}/mcp-integrations.log"
}

log "Stopping all MCP integrations"

# Stop GitHub MCP server
if [ -f "${ANCHOR_HOME}/stop-github-mcp.sh" ]; then
  log "Stopping GitHub MCP server"
  "${ANCHOR_HOME}/stop-github-mcp.sh"
fi

# Stop CNIF services
if [ -f "${ANCHOR_HOME}/mcp-restart-all.sh" ]; then
  log "Stopping CNIF services"
  # Assuming mcp-restart-all.sh has stop functionality, otherwise implement stop logic here
  "${ANCHOR_HOME}/mcp-restart-all.sh" stop
fi

log "✅ All MCP integrations stopped"
EOF

chmod +x "${ANCHOR_HOME}/stop-mcp-integrations.sh"

log "✅ Setup complete"
log "To start all integrations, run: ${ANCHOR_HOME}/launch-mcp-integrations.sh"
log "To stop all integrations, run: ${ANCHOR_HOME}/stop-mcp-integrations.sh"
log "Please restart Claude Desktop to apply configuration changes"
