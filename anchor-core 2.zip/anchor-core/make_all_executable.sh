#!/bin/bash
# make_all_executable.sh - Make all scripts executable
# © 2025 XPV - MIT

ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"

# Make all shell scripts executable
find "${ANCHOR_HOME}" -name "*.sh" -exec chmod +x {} \;

# Make all server scripts executable
find "${ANCHOR_HOME}" -name "*server.js" -exec chmod +x {} \;

echo "✅ All scripts are now executable."
