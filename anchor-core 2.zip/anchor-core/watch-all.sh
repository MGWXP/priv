#!/bin/bash
cd /Users/XPV/Desktop/anchor-core
tail -f git-local.log notion.log anchor-manager.log
