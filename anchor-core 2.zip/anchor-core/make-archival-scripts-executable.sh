#!/bin/bash
# make-archival-scripts-executable.sh - Makes all archival protocol scripts executable

# Set strict error handling
set -e

# ANSI color codes for output formatting
GREEN='\033[0;32m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Make this script executable
chmod +x $0

echo -e "${CYAN}Making all archival protocol scripts executable...${NC}"

# Main controller script
chmod +x /Users/XPV/Desktop/anchor-core/archival-protocol-controller.sh
echo -e "${GREEN}✅ Made executable: archival-protocol-controller.sh${NC}"

# Meta-protocols scripts
META_PROTOCOLS_DIR="/Users/XPV/Desktop/anchor-core/meta-protocols"
chmod +x "$META_PROTOCOLS_DIR/analyze-archive-candidates.sh" 2>/dev/null || true
echo -e "${GREEN}✅ Made executable: meta-protocols/analyze-archive-candidates.sh${NC}"

chmod +x "$META_PROTOCOLS_DIR/archive-component.sh" 2>/dev/null || true
echo -e "${GREEN}✅ Made executable: meta-protocols/archive-component.sh${NC}"

chmod +x "$META_PROTOCOLS_DIR/bulk-archive-components.sh" 2>/dev/null || true
echo -e "${GREEN}✅ Made executable: meta-protocols/bulk-archive-components.sh${NC}"

chmod +x "$META_PROTOCOLS_DIR/create-replacement-component.sh" 2>/dev/null || true
echo -e "${GREEN}✅ Made executable: meta-protocols/create-replacement-component.sh${NC}"

chmod +x "$META_PROTOCOLS_DIR/archive-dashboard.sh" 2>/dev/null || true
echo -e "${GREEN}✅ Made executable: meta-protocols/archive-dashboard.sh${NC}"

chmod +x "$META_PROTOCOLS_DIR/identify-archive-candidates.sh" 2>/dev/null || true
echo -e "${GREEN}✅ Made executable: meta-protocols/identify-archive-candidates.sh${NC}"

chmod +x "$META_PROTOCOLS_DIR/component-migration-manager.sh" 2>/dev/null || true
echo -e "${GREEN}✅ Made executable: meta-protocols/component-migration-manager.sh${NC}"

# Create coherence marker
MARKER_DIR="/Users/XPV/Desktop/anchor-core/coherence_lock"
mkdir -p "$MARKER_DIR"
TIMESTAMP=$(date +"%Y-%m-%dT%H%M%S%3N%z")
touch "$MARKER_DIR/ARCHIVAL_SCRIPTS_EXECUTABLE_$TIMESTAMP.marker"

echo -e "${GREEN}✅ All archival protocol scripts are now executable${NC}"
echo -e "${GREEN}✅ Created coherence marker: ARCHIVAL_SCRIPTS_EXECUTABLE_$TIMESTAMP.marker${NC}"

exit 0
