#!/bin/bash
# mcp-quick-fix.sh - Quick fix for Anchor System V6 MCP issues
# © 2025 XPV - MIT License

set -e

# Define colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Define paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
SCRIPTS=("launch-mcp-servers.sh" "verify-mcp-servers.sh" "mcp-socket-server.js")

echo -e "${BLUE}=== Anchor System V6 MCP Quick Fix ====${NC}"
echo "Timestamp: $(date '+%Y-%m-%d %H:%M:%S')"

# Step 1: Make all scripts executable
echo -e "\n${YELLOW}Step 1: Setting executable permissions...${NC}"
for script in "${SCRIPTS[@]}"; do
  if [ -f "${ANCHOR_HOME}/${script}" ]; then
    chmod +x "${ANCHOR_HOME}/${script}"
    echo -e "${GREEN}✓${NC} Made ${script} executable"
  else
    echo -e "${RED}✗${NC} Script not found: ${script}"
  fi
done

# Step 2: Launch MCP servers
echo -e "\n${YELLOW}Step 2: Launching MCP servers...${NC}"
"${ANCHOR_HOME}/launch-mcp-servers.sh"

# Step 3: Verify servers
echo -e "\n${YELLOW}Step 3: Verifying MCP servers...${NC}"
"${ANCHOR_HOME}/verify-mcp-servers.sh"

# Success marker
touch "${ANCHOR_HOME}/MCP_FIX_SUCCESS_$(date '+%Y%m%d_%H%M%S').marker"

echo -e "\n${BLUE}=== Fix Applied Successfully ====${NC}"
echo -e "${YELLOW}Important: Make sure to restart Claude Desktop to connect to the MCP servers${NC}"
