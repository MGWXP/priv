#!/bin/bash
# quick-fix.sh - Apply quick fix for CNIF startup issues

chmod +x /Users/XPV/Desktop/anchor-core/fix-sequenced-launcher.sh
echo "✅ Made fix script executable, now running it..."
/Users/XPV/Desktop/anchor-core/fix-sequenced-launcher.sh
