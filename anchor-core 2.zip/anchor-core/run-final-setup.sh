#!/bin/bash
# Run this to execute the final setup script
chmod +x /Users/XPV/Desktop/anchor-core/cnif-final-setup.sh
/Users/XPV/Desktop/anchor-core/cnif-final-setup.sh
