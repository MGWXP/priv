#!/bin/bash
# fix-notion-config.sh - Script to fix Notion MCP server configuration

# Color codes for better output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}=== Claude MCP Configuration Fix Script ===${NC}"
echo -e "${BLUE}This script will update your Claude Desktop configuration to use the official Notion MCP server${NC}"

# Configuration variables
CLAUDE_CONFIG_DIR="$HOME/Library/Application Support/Claude"
CLAUDE_CONFIG_FILE="$CLAUDE_CONFIG_DIR/claude_desktop_config.json"
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
BACKUP_DIR="$ANCHOR_HOME/backups/$(date +%Y%m%d)"
NPX_PATH=$(which npx)

# Create backup directory if it doesn't exist
mkdir -p "$BACKUP_DIR"
echo -e "${GREEN}✅ Created backup directory: $BACKUP_DIR${NC}"

# Check for Node.js and npx
if [ -z "$NPX_PATH" ]; then
    echo -e "${RED}❌ Error: npx not found in PATH${NC}"
    echo -e "${YELLOW}Installing Node.js and npm...${NC}"
    
    # Check if brew is installed
    if command -v brew &> /dev/null; then
        brew install node
    else
        echo -e "${RED}❌ Error: Homebrew not found. Please install Node.js manually and try again.${NC}"
        exit 1
    fi
    
    NPX_PATH=$(which npx)
    if [ -z "$NPX_PATH" ]; then
        echo -e "${RED}❌ Error: Failed to install npx. Please install Node.js manually and try again.${NC}"
        exit 1
    fi
fi

echo -e "${GREEN}✅ Found npx at: $NPX_PATH${NC}"

# Back up the current configuration
if [ -f "$CLAUDE_CONFIG_FILE" ]; then
    echo -e "${BLUE}Backing up current Claude configuration...${NC}"
    cp "$CLAUDE_CONFIG_FILE" "$BACKUP_DIR/claude_desktop_config.json.bak"
    echo -e "${GREEN}✅ Backup created at: $BACKUP_DIR/claude_desktop_config.json.bak${NC}"
fi

# Create the new configuration
echo -e "${BLUE}Creating new configuration...${NC}"

cat > "$ANCHOR_HOME/claude_desktop_config.json" << EOF
{
  "mcpServers": {
    "filesystem": {
      "command": "$NPX_PATH",
      "args": [
        "-y",
        "@modelcontextprotocol/server-filesystem",
        "/Users/XPV/Desktop",
        "/Users/XPV/Library",
        "/Users/XPV/Downloads"
      ]
    },
    "notion": {
      "command": "$NPX_PATH",
      "args": [
        "-y",
        "@notionhq/notion-mcp-server"
      ],
      "env": {
        "OPENAPI_MCP_HEADERS": "{\\\"Authorization\\\": \\\"Bearer YOUR_NOTION_API_TOKEN\\\", \\\"Notion-Version\\\": \\\"2022-06-28\\\"}"
      }
    }
  }
}
EOF

echo -e "${GREEN}✅ Created new configuration at: $ANCHOR_HOME/claude_desktop_config.json${NC}"

# Ask for Notion API token
echo -e "${YELLOW}Do you want to enter your Notion API token now? (y/n)${NC}"
read -r SET_TOKEN

if [[ "$SET_TOKEN" =~ ^[Yy]$ ]]; then
    echo -e "${BLUE}Please enter your Notion API token:${NC}"
    read -r NOTION_TOKEN
    
    if [ -n "$NOTION_TOKEN" ]; then
        # Update the token in the configuration file
        sed -i '' "s/YOUR_NOTION_API_TOKEN/$NOTION_TOKEN/" "$ANCHOR_HOME/claude_desktop_config.json"
        echo -e "${GREEN}✅ Notion API token has been set${NC}"
    else
        echo -e "${YELLOW}No token entered. You'll need to edit the configuration file manually later.${NC}"
    fi
else
    echo -e "${YELLOW}You'll need to edit $ANCHOR_HOME/claude_desktop_config.json to add your Notion API token.${NC}"
fi

# Ensure the Claude configuration directory exists
mkdir -p "$CLAUDE_CONFIG_DIR"

# Copy the configuration to Claude's directory
echo -e "${BLUE}Installing the new configuration...${NC}"
cp "$ANCHOR_HOME/claude_desktop_config.json" "$CLAUDE_CONFIG_FILE"
echo -e "${GREEN}✅ Installed new configuration at: $CLAUDE_CONFIG_FILE${NC}"

echo -e "\n${GREEN}=== Configuration update complete ===${NC}"
echo -e "${YELLOW}Important notes:${NC}"
echo -e "1. You will need to restart Claude Desktop for the changes to take effect."
echo -e "2. If you didn't set your Notion API token, edit $CLAUDE_CONFIG_FILE and replace YOUR_NOTION_API_TOKEN with your actual token."
echo -e "3. If you haven't already, you'll need to create a Notion integration at https://www.notion.so/my-integrations and share your pages with it."

echo -e "\n${BLUE}Would you like to install the official Notion MCP server now? (y/n)${NC}"
read -r INSTALL_SERVER

if [[ "$INSTALL_SERVER" =~ ^[Yy]$ ]]; then
    echo -e "${BLUE}Installing @notionhq/notion-mcp-server...${NC}"
    npm install -g @notionhq/notion-mcp-server
    echo -e "${GREEN}✅ Notion MCP server installed${NC}"
else
    echo -e "${YELLOW}Skip installation. The server will be installed automatically when Claude Desktop starts.${NC}"
fi

echo -e "\n${GREEN}Done!${NC}"
