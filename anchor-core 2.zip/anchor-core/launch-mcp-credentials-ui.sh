#!/bin/bash
# launch-mcp-credentials-ui.sh
# Launcher for the MCP Credentials Manager UI
# © 2025 XPV - MIT License

# Set directory paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
LOG_DIR="${ANCHOR_HOME}/logs"
UI_LAUNCHER="${ANCHOR_HOME}/utils/mcp-credentials-ui-launcher.js"
HTML_FILE="${ANCHOR_HOME}/utils/mcp-credentials-ui.html"

# Create log directory if it doesn't exist
mkdir -p "${LOG_DIR}"

# Log function
log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "${LOG_DIR}/mcp-credentials-ui.log"
}

# Check if Electron is installed
if ! command -v npm &> /dev/null; then
  log "ERROR: npm is not installed or not in PATH"
  echo "❌ Error: npm is required but not found."
  echo "Please install Node.js and npm, then try again."
  exit 1
fi

# Check if the necessary files exist
if [ ! -f "${UI_LAUNCHER}" ]; then
  log "ERROR: UI launcher script not found at ${UI_LAUNCHER}"
  echo "❌ Error: UI launcher script not found."
  exit 1
fi

if [ ! -f "${HTML_FILE}" ]; then
  log "ERROR: UI HTML file not found at ${HTML_FILE}"
  echo "❌ Error: UI HTML file not found."
  exit 1
fi

# Ensure the script is executable
chmod +x "${UI_LAUNCHER}"

# Install Electron if not already installed
if ! npm list -g electron &> /dev/null; then
  log "INFO: Installing Electron globally"
  echo "Installing Electron globally (this may take a moment)..."
  npm install -g electron
fi

# Start the UI
log "Starting MCP Credentials Manager UI"
echo "Starting MCP Credentials Manager UI..."
cd "${ANCHOR_HOME}/utils"
electron "${UI_LAUNCHER}"

exit 0
