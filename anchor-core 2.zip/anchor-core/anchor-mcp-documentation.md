# Anchor V6 MCP Project Documentation

## 🏗️ Project Structure

The Anchor V6 MCP Project integrates Model Context Protocol servers to create a unified AI development environment. The primary components are:

### MCP Servers
- **Filesystem Server**: Provides file access and management capabilities
- **Notion Server**: Enables interaction with Notion workspaces for knowledge management
- **Slack Server**: Facilitates team communication and collaboration (pending configuration)

### Management Tools
- **Dashboard**: Interactive terminal interface for monitoring and managing MCP servers
- **Environment Verifier**: Ensures all required packages and configurations are present
- **Alias Setup**: Creates convenient shell commands for common tasks
- **System Documentation**: Comprehensive guides and reference materials

## 📊 System Configuration

The system is optimized for M3 Max hardware with 48GB unified memory:

```json
{
  "mcpServers": {
    "filesystem": {
      "command": "npx",
      "args": [
        "-y",
        "@modelcontextprotocol/server-filesystem",
        "/Users/XPV/Desktop",
        "/Users/XPV/Library",
        "/Users/XPV/Documents"
      ],
      "env": {
        "NODE_OPTIONS": "--max-old-space-size=8192",
        "UV_THREADPOOL_SIZE": "12"
      }
    },
    "notion": {
      "command": "npx",
      "args": [
        "-y",
        "@notionhq/notion-mcp-server"
      ],
      "env": {
        "NODE_OPTIONS": "--max-old-space-size=8192",
        "UV_THREADPOOL_SIZE": "12",
        "OPENAPI_MCP_HEADERS": "{\"Authorization\": \"Bearer ${NOTION_API_KEY}\", \"Notion-Version\": \"2022-06-28\" }"
      }
    },
    "slack": {
      "command": "npx",
      "args": [
        "-y",
        "@modelcontextprotocol/server-slack"
      ],
      "env": {
        "NODE_OPTIONS": "--max-old-space-size=8192",
        "UV_THREADPOOL_SIZE": "12",
        "SLACK_BOT_TOKEN": "${SLACK_BOT_TOKEN}",
        "SLACK_TEAM_ID": "${SLACK_TEAM_ID}"
      }
    }
  }
}
```

## 🧠 Notion Integration

The Notion integration provides a centralized workspace for project management and documentation. Key features include:

- **Configuration Management**: Store and update MCP server configurations
- **Tool Documentation**: Comprehensive documentation for all available MCP tools
- **Task Tracking**: Manage project tasks and track progress
- **Knowledge Base**: Maintain a shared knowledge repository for the team

The Notion workspace is accessible at:
https://www.notion.so/Anchor-1f7e48c2bbbd80df86edd35832916f80

## 🔧 Command Reference

| Command | Description |
|---------|-------------|
| `mcp-verify` | Verify MCP environment and installed packages |
| `mcp-status` | Check status of all MCP servers |
| `mcp-docs` | Open MCP system documentation |
| `mcp-restart` | Restart all MCP servers and Claude Desktop |
| `mcp-env-setup` | Set up environment variables interactively |
| `mcp-env-save` | Save environment variables permanently |
| `mcp-dashboard` | Launch the interactive MCP management dashboard |

## 📋 Development Roadmap

1. **Phase 1: Notion Integration** ✅
   - Configure Notion MCP server
   - Create project workspace
   - Establish documentation structure

2. **Phase 2: Slack Integration** ⏳
   - Set up Slack API tokens
   - Configure Slack MCP server
   - Establish team communication channels

3. **Phase 3: Automation** 📆
   - Create automated health monitoring
   - Implement backup and restore procedures
   - Develop continuous integration workflow

4. **Phase 4: Expansion** 📆
   - Add additional MCP servers as needed
   - Integrate with other team tools
   - Scale system for larger deployments

## 📊 Performance Metrics

The system is optimized for M3 Max hardware with 48GB unified memory:

| Setting | Value | Description |
|---------|-------|-------------|
| NODE_OPTIONS | --max-old-space-size=8192 | Allocates 8GB memory to Node.js processes |
| UV_THREADPOOL_SIZE | 12 | Optimizes thread pool for M3 Max CPU |
| Architecture | MCP | Model Context Protocol for AI integration |
| Base Directory | /Users/XPV/Desktop/anchor-core | Project root location |
