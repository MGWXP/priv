#!/bin/bash
# Executable setter for anchor-system-fix.sh
echo "🔧 Making anchor-system-fix.sh executable..."
chmod +x /Users/XPV/Desktop/anchor-core/anchor-system-fix.sh
echo "✅ Done! You can now run: ./anchor-system-fix.sh"
