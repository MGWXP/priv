#!/bin/bash
echo "=== Claude MCP Logs ==="
cat ~/Library/Logs/Claude/mcp*.log | tail -n 50
echo ""
echo "=== Claude Main Logs ==="
cat ~/Library/Logs/Claude/main*.log | tail -n 50
