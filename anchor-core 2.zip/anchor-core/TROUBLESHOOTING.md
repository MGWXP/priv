# CNIF System Troubleshooting Guide

This guide provides step-by-step instructions for troubleshooting and resolving issues with the Claude-Notion Integration Framework (CNIF).

## Quick Start

If you're encountering issues with CNIF, follow these steps:

1. Run the recovery script:
   ```bash
   cd /Users/XPV/Desktop/anchor-core
   chmod +x recover-cnif.sh
   ./recover-cnif.sh
   ```

2. Verify basic Node.js functionality:
   ```bash
   ./run-basic-test.sh
   ```

3. Test individual components:
   ```bash
   ./debug-server.sh socket-server
   ```

4. Launch the system:
   ```bash
   ./launch-optimized.sh
   ```

5. Verify system status:
   ```bash
   ./verify-socket-servers.sh
   ```

## Detailed Troubleshooting Steps

### Step 1: Verify Environment Configuration

If you're experiencing issues, first check if the NODE_OPTIONS environment variable has valid settings:

```bash
echo $NODE_OPTIONS
```

Only the following flags are permitted in NODE_OPTIONS:
- `--max-old-space-size=8192`

Other flags like `--optimize_for_size`, `--use-largepages=silent`, etc. are NOT allowed and will cause failures.

### Step 2: Test Basic Node.js Functionality

Run the basic test script to verify that Node.js is working correctly and can create sockets with proper permissions:

```bash
./run-basic-test.sh
```

This test should:
- Create a test directory
- Write a test file
- Create a Unix socket
- Set permissions on the socket
- Connect to the socket

If this test fails, there may be a more fundamental issue with the Node.js environment.

### Step 3: Debug Individual Components

Test each component individually to isolate issues:

```bash
./debug-server.sh schema-registry
./debug-server.sh streaming-transformer
./debug-server.sh socket-server
./debug-server.sh notion
./debug-server.sh mcp-orchestrator
```

For more detailed debugging output, use the `--debug` flag:

```bash
./debug-server.sh socket-server --debug
```

### Step 4: Check Log Files

Examine log files for specific error messages:

```bash
cat ~/Library/Logs/Claude/socket-server.log
cat ~/Library/Logs/Claude/schema-registry.log
cat ~/Library/Logs/Claude/streaming-transformer.log
cat ~/Library/Logs/Claude/notion.log
cat ~/Library/Logs/Claude/mcp-orchestrator.log
```

For debug logs, check:

```bash
cat ~/Library/Logs/Claude/socket-server_debug.log
```

### Step 5: Fix Socket Permissions

If you encounter socket permission issues:

```bash
./fix-socket-permissions.sh
```

### Step 6: Clean Coherence Markers

If coherence markers are causing issues:

```bash
./clean-coherence-markers.sh
```

### Step 7: Full System Recovery

For a comprehensive system recovery (cleans all files and performs validation tests):

```bash
./recover-cnif.sh
```

## Common Issues and Solutions

### 1. Invalid NODE_OPTIONS Flags

**Symptom**: Services start but immediately fail with error message: `node: --optimize_for_size is not allowed in NODE_OPTIONS`

**Solution**: 
- Update `launch-optimized.sh` to only include allowed flags
- Run the recovery script to reset the environment

### 2. Socket Permission Issues

**Symptom**: Services cannot create or connect to sockets, "permission denied" errors

**Solution**:
- Run `fix-socket-permissions.sh`
- Ensure socket directory has permissions 755
- Ensure socket files have permissions 666

### 3. PID Files Not Being Removed

**Symptom**: Stale PID files causing confusion about whether services are running

**Solution**:
- Run `recover-cnif.sh` to clean up PID files
- Check if processes are actually running: `ps -ef | grep node`

### 4. Coherence Markers With Invalid Format

**Symptom**: Parsing errors when reading coherence markers

**Solution**:
- Run `clean-coherence-markers.sh`
- Ensure coherence markers only contain the PID as plain text

### 5. Socket Files Not Being Created

**Symptom**: Socket server starts but no socket file appears

**Solution**:
- Check permissions on the socket directory
- Run `debug-server.sh socket-server --debug` to see detailed output
- Verify the basic test works: `run-basic-test.sh`

## Next Steps

If all troubleshooting steps have been followed and issues persist, consider:

1. Checking Node.js installation: `node --version`
2. Verifying system permissions: `ls -la /Users/XPV/Desktop/anchor-core`
3. Reinstalling dependencies: `npm install` (if applicable)
