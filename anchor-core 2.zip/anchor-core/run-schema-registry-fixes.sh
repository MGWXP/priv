#!/bin/bash
# run-schema-registry-fixes.sh - Make and run the schema registry fixes
# © 2025 XPV - MIT

# Make the script executable
chmod +x /Users/XPV/Desktop/anchor-core/create-schema-registry-index.sh

# Run the script
/Users/XPV/Desktop/anchor-core/create-schema-registry-index.sh

# Now run the test
echo "Running schema registry test..."
node /Users/XPV/Desktop/anchor-core/mcp-servers/test-schema-registry.js
