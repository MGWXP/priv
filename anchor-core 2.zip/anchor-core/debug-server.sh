#!/bin/bash
# debug-server.sh - Test individual server components
# © 2025 XPV - MIT

set -e

# Define colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color
BLUE='\033[0;34m'

# Base paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
LOG_DIR="$HOME/Library/Logs/Claude"
SOCKET_DIR="$ANCHOR_HOME/sockets"
COHERENCE_LOCK_DIR="$ANCHOR_HOME/coherence_lock"
CONFIG_DIR="$ANCHOR_HOME/data"
MCP_DIR="$ANCHOR_HOME/mcp-servers"
PID_DIR="$MCP_DIR"

# Check if a server name was provided
if [ $# -lt 1 ]; then
  echo -e "${RED}Error: No server name provided${NC}"
  echo -e "Usage: $0 <server-name> [--debug]"
  echo -e "Available servers: schema-registry, streaming-transformer, socket-server, notion, mcp-orchestrator"
  exit 1
fi

SERVER_NAME=$1
DEBUG_MODE=0
if [ "$2" = "--debug" ]; then
  DEBUG_MODE=1
fi

# Define server scripts mapping
case "$SERVER_NAME" in
  "schema-registry")
    SCRIPT="$MCP_DIR/schema-registry.js"
    ;;
  "streaming-transformer")
    SCRIPT="$MCP_DIR/streaming-schema-transformer.js"
    ;;
  "socket-server")
    SCRIPT="$MCP_DIR/socket-server-implementation.js"
    ;;
  "notion")
    SCRIPT="$MCP_DIR/notion-connection-manager.js"
    ;;
  "mcp-orchestrator")
    SCRIPT="$MCP_DIR/mcp-orchestrator.js"
    ;;
  *)
    echo -e "${RED}Error: Unknown server name: $SERVER_NAME${NC}"
    echo -e "Available servers: schema-registry, streaming-transformer, socket-server, notion, mcp-orchestrator"
    exit 1
    ;;
esac

# Check if script exists
if [ ! -f "$SCRIPT" ]; then
  echo -e "${RED}Error: Script not found: $SCRIPT${NC}"
  exit 1
fi

echo -e "${BLUE}=========================================${NC}"
echo -e "${BLUE}Debugging server: $SERVER_NAME${NC}"
echo -e "${BLUE}Script path: $SCRIPT${NC}"
echo -e "${BLUE}=========================================${NC}"

# Clean up existing PID file and socket
if [ -f "$PID_DIR/$SERVER_NAME.pid" ]; then
  pid=$(cat "$PID_DIR/$SERVER_NAME.pid")
  if ps -p "$pid" > /dev/null 2>&1; then
    echo -e "${YELLOW}Stopping existing process (PID: $pid)...${NC}"
    kill -15 "$pid" 2>/dev/null || kill -9 "$pid" 2>/dev/null || true
  fi
  rm -f "$PID_DIR/$SERVER_NAME.pid"
fi

if [ -e "$SOCKET_DIR/$SERVER_NAME.sock" ]; then
  echo -e "${YELLOW}Removing existing socket file...${NC}"
  rm -f "$SOCKET_DIR/$SERVER_NAME.sock"
fi

# Create required directories
mkdir -p "$LOG_DIR"
mkdir -p "$SOCKET_DIR"
mkdir -p "$COHERENCE_LOCK_DIR"

# Set environment variables
export NODE_OPTIONS="--max-old-space-size=8192"
export UV_THREADPOOL_SIZE=12
export ANCHOR_HOME="$ANCHOR_HOME"
export MCP_DIR="$MCP_DIR"
export SOCKET_DIR="$SOCKET_DIR"
export LOG_DIR="$LOG_DIR"
export CONFIG_DIR="$CONFIG_DIR"
export MCP_SERVER_NAME="$SERVER_NAME"
export DEBUG=1

# Create debug log file
DEBUG_LOG="$LOG_DIR/${SERVER_NAME}_debug.log"
rm -f "$DEBUG_LOG"
touch "$DEBUG_LOG"

echo -e "${BLUE}Starting $SERVER_NAME in debug mode...${NC}"
echo -e "${BLUE}Log file: $DEBUG_LOG${NC}"

if [ $DEBUG_MODE -eq 1 ]; then
  # Run in foreground for debugging
  echo -e "${YELLOW}Running in foreground mode. Press Ctrl+C to stop.${NC}"
  node --expose-gc --inspect "$SCRIPT" 2>&1 | tee "$DEBUG_LOG"
else
  # Run in background
  node --expose-gc "$SCRIPT" > "$DEBUG_LOG" 2>&1 &
  pid=$!
  
  # Save PID
  echo "$pid" > "$PID_DIR/$SERVER_NAME.pid"
  
  echo -e "${GREEN}Started $SERVER_NAME (PID: $pid)${NC}"
  
  # Wait a moment for startup
  sleep 2
  
  # Check if process is still running
  if ps -p "$pid" > /dev/null; then
    echo -e "${GREEN}✅ Process is still running${NC}"
    
    # Check for socket file if it's the socket server
    if [ "$SERVER_NAME" = "socket-server" ]; then
      if [ -e "$SOCKET_DIR/$SERVER_NAME.sock" ]; then
        perms=$(stat -f "%p" "$SOCKET_DIR/$SERVER_NAME.sock" | cut -c 3-5)
        echo -e "${GREEN}✅ Socket file created: $SOCKET_DIR/$SERVER_NAME.sock (permissions: $perms)${NC}"
      else
        echo -e "${RED}❌ Socket file not created!${NC}"
      fi
    fi
    
    # Check for coherence marker
    markers=$(find "$COHERENCE_LOCK_DIR" -name "${SERVER_NAME}_*.marker" | wc -l)
    if [ "$markers" -gt 0 ]; then
      echo -e "${GREEN}✅ Coherence marker created${NC}"
    else
      echo -e "${RED}❌ No coherence marker created!${NC}"
    fi
    
    # Display recent log entries
    echo -e "${BLUE}Recent log entries:${NC}"
    tail -n 20 "$DEBUG_LOG"
    
    echo -e "\n${BLUE}To stop this server, run:${NC}"
    echo -e "  kill $pid"
  else
    echo -e "${RED}❌ Process has already terminated!${NC}"
    echo -e "${YELLOW}Log output:${NC}"
    cat "$DEBUG_LOG"
  fi
fi
