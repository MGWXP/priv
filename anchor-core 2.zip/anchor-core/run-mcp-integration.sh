#!/bin/bash
# Launch script to execute the MCP integration setup

echo "=== Executing MCP Integration Setup ==="
echo "Date: $(date '+%Y-%m-%d %H:%M:%S')"

# Make the integration script executable
chmod +x /Users/XPV/Desktop/anchor-core/make-scripts-executable.sh
chmod +x /Users/XPV/Desktop/anchor-core/setup-mcp-integrations.sh

# Run the scripts
/Users/XPV/Desktop/anchor-core/make-scripts-executable.sh
/Users/XPV/Desktop/anchor-core/setup-mcp-integrations.sh

echo "=== MCP Integration Complete ==="
echo "Please restart Claude Desktop to apply changes"
