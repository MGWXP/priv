#!/bin/bash
# anchor-system-fix.sh - Master fix script for Anchor System V6
# © 2025 XPV - MIT

set -e

ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"

# Make the fix script executable
chmod +x "${ANCHOR_HOME}/one-step-mcp-fix.sh"

# Make all scripts executable
chmod +x "${ANCHOR_HOME}/make_all_executable.sh"
"${ANCHOR_HOME}/make_all_executable.sh"

# Execute the one-step fix
"${ANCHOR_HOME}/one-step-mcp-fix.sh"

# Create success marker
touch "${ANCHOR_HOME}/FIXED_SUCCESS_20250518.marker"

echo "✅ Anchor System V6 has been successfully fixed."
echo "Please restart Claude Desktop application to connect to the enhanced servers."
