import {Command, Flags} from '@oclif/core'
import * as fs from 'fs'
import * as path from 'path'
import * as crypto from 'crypto'
import fetch from 'node-fetch'

export default class PushContext extends Command {
  static description = 'Push an MCP context payload to the local gateway'

  static flags = {
    file: Flags.string({
      char: 'f',
      description: 'Path to JSON file containing the MCP payload',
      required: false
    }),
    raw: Flags.boolean({
      description: 'Send raw stdin as JSON body',
      default: false
    }),
    id: Flags.boolean({
      char: 'i',
      description: 'Only print returned context_id',
      default: false
    }),
    key: Flags.string({
      description: 'HMAC key to sign payload',
      env: 'MCP_HMAC_KEY',
      required: false,
      default: 'changeme'
    })
  }

  async run(): Promise<void> {
    const {flags} = await this.parse(PushContext)

    let body: Buffer
    if (flags.raw) {
      body = await new Promise((res, rej) => {
        let chunks: Buffer[] = []
        process.stdin.on('data', chunk => chunks.push(chunk))
        process.stdin.on('end', () => res(Buffer.concat(chunks)))
        process.stdin.on('error', err => rej(err))
      })
    } else {
      const filepath = flags.file ?? '/tmp/test_mcp.json'
      body = fs.readFileSync(path.resolve(filepath))
    }

    const sig = crypto.createHmac('sha256', flags.key).update(body).digest('hex')
    const res = await fetch('http://127.0.0.1:3213/mcp', {
      method: 'POST',
      headers: {
        'X-MCP-Sig': sig,
        'Content-Type': 'application/json'
      },
      body
    })

    const json = await res.json()
    if (flags.id && json.context_id) {
      this.log(json.context_id)
    } else {
      this.log(JSON.stringify(json, null, 2))
    }
  }
}
