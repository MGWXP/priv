/**
 * dashboard-optimizations.js - React Optimization Utilities for High-Frequency Updates
 * 
 * This module provides optimized React utilities for high-performance dashboards
 * with real-time data. It includes efficient update handling, selective subscriptions,
 * and differential rendering optimizations.
 * 
 * © 2025 XPV - MIT License
 */

import React, { useState, useEffect, useRef, useCallback, useMemo, useReducer, useTransition } from 'react';

/**
 * Custom hook for WebSocket connection with reconnection and message buffering
 */
export function useWebSocketConnection(socketUrl, options = {}) {
  const {
    reconnectInterval = 2000,
    maxReconnectAttempts = 10,
    reconnectBackoff = 1.5,
    autoReconnect = true,
    bufferMessages = true,
    maxBufferSize = 100,
    heartbeatInterval = 30000
  } = options;
  
  // Connection state
  const [connectionState, setConnectionState] = useState('disconnected');
  const [error, setError] = useState(null);
  
  // WebSocket and reconnection state
  const socketRef = useRef(null);
  const reconnectAttemptsRef = useRef(0);
  const reconnectTimeoutRef = useRef(null);
  const messageBufferRef = useRef([]);
  const heartbeatTimeoutRef = useRef(null);
  const lastHeartbeatResponseRef = useRef(Date.now());
  
  // Message handling state
  const [messages, dispatchMessage] = useReducer((state, action) => {
    switch (action.type) {
      case 'received':
        return [...state, action.message];
      case 'clear':
        return [];
      default:
        return state;
    }
  }, []);
  
  // Clean up function for resources
  const cleanup = useCallback(() => {
    if (heartbeatTimeoutRef.current) {
      clearTimeout(heartbeatTimeoutRef.current);
      heartbeatTimeoutRef.current = null;
    }
    
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }
    
    if (socketRef.current) {
      socketRef.current.close();
      socketRef.current = null;
    }
  }, []);
  
  // Connect to WebSocket
  const connect = useCallback(() => {
    // Clean up any existing resources
    cleanup();
    
    try {
      setConnectionState('connecting');
      
      // Create new WebSocket
      socketRef.current = new WebSocket(socketUrl);
      
      // Set up event handlers
      socketRef.current.addEventListener('open', () => {
        console.log('WebSocket connected');
        setConnectionState('connected');
        setError(null);
        reconnectAttemptsRef.current = 0;
        
        // Send any buffered messages
        if (bufferMessages && messageBufferRef.current.length > 0) {
          console.log(`Sending ${messageBufferRef.current.length} buffered messages`);
          
          messageBufferRef.current.forEach(msg => {
            socketRef.current.send(JSON.stringify(msg));
          });
          
          messageBufferRef.current = [];
        }
        
        // Start heartbeat
        startHeartbeat();
      });
      
      socketRef.current.addEventListener('message', (event) => {
        try {
          const message = JSON.parse(event.data);
          
          // Handle heartbeat response
          if (message.type === 'heartbeat_response') {
            lastHeartbeatResponseRef.current = Date.now();
            return;
          }
          
          // Dispatch other messages to the reducer
          dispatchMessage({ type: 'received', message });
        } catch (err) {
          console.error('Error parsing WebSocket message:', err);
        }
      });
      
      socketRef.current.addEventListener('close', (event) => {
        console.log(`WebSocket disconnected, code: ${event.code}, reason: ${event.reason}`);
        setConnectionState('disconnected');
        
        // Attempt to reconnect if not a clean close
        if (autoReconnect && !event.wasClean) {
          scheduleReconnect();
        }
      });
      
      socketRef.current.addEventListener('error', (event) => {
        console.error('WebSocket error:', event);
        setError(`WebSocket error: ${event.message || 'Unknown error'}`);
      });
    } catch (err) {
      console.error('Failed to create WebSocket:', err);
      setError(`Failed to create WebSocket: ${err.message}`);
      setConnectionState('error');
      
      // Attempt to reconnect
      if (autoReconnect) {
        scheduleReconnect();
      }
    }
  }, [socketUrl, autoReconnect, bufferMessages, cleanup]);
  
  // Schedule reconnection with exponential backoff
  const scheduleReconnect = useCallback(() => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }
    
    if (reconnectAttemptsRef.current >= maxReconnectAttempts) {
      console.log(`Maximum reconnection attempts (${maxReconnectAttempts}) reached`);
      setConnectionState('failed');
      return;
    }
    
    const delay = reconnectInterval * Math.pow(reconnectBackoff, reconnectAttemptsRef.current);
    const jitter = delay * 0.1 * Math.random();
    const actualDelay = delay + jitter;
    
    console.log(`Scheduling reconnect in ${Math.round(actualDelay)}ms (attempt ${reconnectAttemptsRef.current + 1})`);
    
    reconnectTimeoutRef.current = setTimeout(() => {
      reconnectAttemptsRef.current++;
      connect();
    }, actualDelay);
  }, [reconnectInterval, maxReconnectAttempts, reconnectBackoff, connect]);
  
  // Start heartbeat to detect connection issues
  const startHeartbeat = useCallback(() => {
    if (heartbeatTimeoutRef.current) {
      clearTimeout(heartbeatTimeoutRef.current);
    }
    
    heartbeatTimeoutRef.current = setTimeout(() => {
      if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
        // Check if we've received a heartbeat recently
        const timeSinceLastResponse = Date.now() - lastHeartbeatResponseRef.current;
        
        if (timeSinceLastResponse > heartbeatInterval * 2) {
          console.log(`No heartbeat response for ${timeSinceLastResponse}ms, reconnecting...`);
          
          // Force reconnection
          if (socketRef.current) {
            socketRef.current.close();
          }
          
          return;
        }
        
        // Send heartbeat
        try {
          socketRef.current.send(JSON.stringify({ 
            type: 'heartbeat', 
            timestamp: Date.now() 
          }));
          
          // Schedule next heartbeat
          startHeartbeat();
        } catch (err) {
          console.error('Error sending heartbeat:', err);
        }
      }
    }, heartbeatInterval);
  }, [heartbeatInterval]);
  
  // Send a message through the WebSocket
  const sendMessage = useCallback((message) => {
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(typeof message === 'string' ? message : JSON.stringify(message));
      return true;
    } else if (bufferMessages) {
      // Buffer message for when connection is established
      if (messageBufferRef.current.length < maxBufferSize) {
        messageBufferRef.current.push(message);
        console.log(`Message buffered (${messageBufferRef.current.length}/${maxBufferSize})`);
        return true;
      } else {
        console.error(`Message buffer full (${maxBufferSize}), dropping message`);
        return false;
      }
    } else {
      console.error('WebSocket not connected and buffering disabled');
      return false;
    }
  }, [bufferMessages, maxBufferSize]);
  
  // Initialize connection on mount
  useEffect(() => {
    connect();
    
    // Clean up on unmount
    return cleanup;
  }, [socketUrl, connect, cleanup]);
  
  return {
    connectionState,
    error,
    messages,
    sendMessage,
    reconnect: connect,
    clearMessages: () => dispatchMessage({ type: 'clear' })
  };
}

/**
 * Message buffer for batching high-frequency updates
 */
export class MessageBuffer {
  constructor(options = {}) {
    this.buffer = [];
    this.flushCallback = options.onFlush || null;
    this.flushInterval = options.flushInterval || 100;
    this.maxSize = options.maxSize || 50;
    this.enabled = options.enabled !== false;
    this.timer = null;
    
    if (this.enabled) {
      this.startTimer();
    }
  }
  
  startTimer() {
    this.timer = setInterval(() => this.flush(), this.flushInterval);
  }
  
  stopTimer() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }
  
  add(message) {
    if (!this.enabled) {
      return this.flushCallback ? this.flushCallback([message]) : false;
    }
    
    this.buffer.push(message);
    
    if (this.buffer.length >= this.maxSize) {
      this.flush();
    }
    
    return true;
  }
  
  flush() {
    if (this.buffer.length > 0 && this.flushCallback) {
      this.flushCallback([...this.buffer]);
      this.buffer = [];
    }
  }
  
  destroy() {
    this.stopTimer();
    this.buffer = [];
  }
  
  enable() {
    this.enabled = true;
    this.startTimer();
  }
  
  disable() {
    this.enabled = false;
    this.stopTimer();
    // Flush any remaining messages
    this.flush();
  }
}

/**
 * Custom hook for efficient dashboard data subscription
 */
export function useDashboardSubscription(channels = [], options = {}) {
  const {
    socketUrl = 'ws://localhost:8765',
    autoSubscribe = true,
    batchUpdates = true,
    batchInterval = 100,
    throttleUpdates = true,
    throttleInterval = 1000,
    differentialUpdates = true
  } = options;
  
  // Current data state
  const [isPending, startTransition] = useTransition();
  const [data, setData] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // Track current subscriptions
  const currentSubscriptions = useRef(new Set());
  
  // WebSocket connection
  const { 
    connectionState, 
    sendMessage, 
    messages, 
    reconnect 
  } = useWebSocketConnection(socketUrl, {
    reconnectInterval: 2000,
    maxReconnectAttempts: 10,
    autoReconnect: true,
    bufferMessages: true
  });
  
  // Update data with throttling
  const throttledUpdateRef = useRef(null);
  
  // Last update timestamp per channel
  const lastUpdateRef = useRef({});
  
  // Process received messages
  useEffect(() => {
    if (messages.length === 0) return;
    
    // Use React 18 transitions for smoother UI
    startTransition(() => {
      for (const message of messages) {
        // Process different message types
        if (message.type === 'update' && message.channel) {
          // Check if we're subscribed to this channel
          if (!currentSubscriptions.current.has(message.channel)) continue;
          
          // Throttle updates if enabled
          if (throttleUpdates) {
            const now = Date.now();
            const lastUpdate = lastUpdateRef.current[message.channel] || 0;
            
            if (now - lastUpdate < throttleInterval) {
              continue;
            }
            
            lastUpdateRef.current[message.channel] = now;
          }
          
          // Apply update to data
          if (differentialUpdates && message.diff) {
            // Apply differential update
            setData(prevData => {
              const channelData = prevData[message.channel] || {};
              
              // Apply diffs
              const updated = { ...channelData };
              for (const [key, value] of Object.entries(message.diff)) {
                if (value === null) {
                  // Remove key
                  delete updated[key];
                } else {
                  // Update key
                  updated[key] = value;
                }
              }
              
              return {
                ...prevData,
                [message.channel]: updated
              };
            });
          } else {
            // Apply full update
            setData(prevData => ({
              ...prevData,
              [message.channel]: message.data
            }));
          }
        } else if (message.type === 'batch') {
          // Process batch of updates
          if (message.messages && Array.isArray(message.messages)) {
            startTransition(() => {
              const updates = {};
              
              // Group updates by channel
              for (const batchMessage of message.messages) {
                if (batchMessage.type === 'update' && batchMessage.channel) {
                  // Check if we're subscribed to this channel
                  if (!currentSubscriptions.current.has(batchMessage.channel)) continue;
                  
                  if (!updates[batchMessage.channel]) {
                    updates[batchMessage.channel] = batchMessage.data;
                  } else if (differentialUpdates && batchMessage.diff) {
                    // Apply differential update
                    for (const [key, value] of Object.entries(batchMessage.diff)) {
                      if (value === null) {
                        // Remove key
                        delete updates[batchMessage.channel][key];
                      } else {
                        // Update key
                        updates[batchMessage.channel][key] = value;
                      }
                    }
                  } else {
                    // Replace with newer data
                    updates[batchMessage.channel] = batchMessage.data;
                  }
                }
              }
              
              // Apply all updates at once
              setData(prevData => ({
                ...prevData,
                ...updates
              }));
            });
          }
        } else if (message.type === 'error') {
          setError(message.error || 'Unknown error');
        }
      }
    });
  }, [messages, throttleUpdates, throttleInterval, differentialUpdates]);
  
  // Update subscriptions when channels change
  useEffect(() => {
    if (connectionState !== 'connected' || !autoSubscribe) return;
    
    const newChannels = new Set(channels);
    
    // Unsubscribe from channels no longer needed
    for (const channel of currentSubscriptions.current) {
      if (!newChannels.has(channel)) {
        sendMessage({
          type: 'unsubscribe',
          channel
        });
      }
    }
    
    // Subscribe to new channels
    for (const channel of newChannels) {
      if (!currentSubscriptions.current.has(channel)) {
        sendMessage({
          type: 'subscribe',
          channel
        });
      }
    }
    
    // Update current subscriptions
    currentSubscriptions.current = newChannels;
  }, [channels, connectionState, sendMessage, autoSubscribe]);
  
  // Subscribe to specific channel
  const subscribe = useCallback((channel) => {
    if (!channel || currentSubscriptions.current.has(channel)) return;
    
    currentSubscriptions.current.add(channel);
    
    if (connectionState === 'connected') {
      sendMessage({
        type: 'subscribe',
        channel
      });
    }
  }, [connectionState, sendMessage]);
  
  // Unsubscribe from specific channel
  const unsubscribe = useCallback((channel) => {
    if (!channel || !currentSubscriptions.current.has(channel)) return;
    
    currentSubscriptions.current.delete(channel);
    
    if (connectionState === 'connected') {
      sendMessage({
        type: 'unsubscribe',
        channel
      });
    }
  }, [connectionState, sendMessage]);
  
  // Update loading state based on connection
  useEffect(() => {
    if (connectionState === 'connected') {
      setIsLoading(false);
    } else {
      setIsLoading(true);
    }
  }, [connectionState]);
  
  return {
    data,
    isPending,
    isLoading,
    error,
    connectionState,
    subscribe,
    unsubscribe,
    reconnect
  };
}

/**
 * Optimized memo comparison function for preventing unnecessary re-renders
 */
export function createDeepCompare(options = {}) {
  const {
    ignoreFields = [],
    compareArrays = true,
    compareObjects = true,
    numberTolerance = 0
  } = options;
  
  return function deepCompare(prevProps, nextProps) {
    // If references are the same, they are equal
    if (prevProps === nextProps) return true;
    
    // If either is null/undefined, they are equal only if both are
    if (prevProps == null || nextProps == null) return prevProps === nextProps;
    
    // Get all keys from both objects
    const prevKeys = Object.keys(prevProps);
    const nextKeys = Object.keys(nextProps);
    
    // If number of keys differ, they are not equal
    if (prevKeys.length !== nextKeys.length) return false;
    
    // Check each key
    for (let key of prevKeys) {
      // Skip ignored fields
      if (ignoreFields.includes(key)) continue;
      
      const prevValue = prevProps[key];
      const nextValue = nextProps[key];
      
      // If references are the same, they are equal
      if (prevValue === nextValue) continue;
      
      // If either is null/undefined, they are equal only if both are
      if (prevValue == null || nextValue == null) {
        if (prevValue !== nextValue) return false;
        continue;
      }
      
      // Handle special types
      const prevType = typeof prevValue;
      const nextType = typeof nextValue;
      
      // Types must match
      if (prevType !== nextType) return false;
      
      // For numbers, check tolerance
      if (prevType === 'number' && !isNaN(prevValue) && !isNaN(nextValue)) {
        if (Math.abs(prevValue - nextValue) > numberTolerance) return false;
        continue;
      }
      
      // For functions, compare string representations
      if (prevType === 'function') {
        if (prevValue.toString() !== nextValue.toString()) return false;
        continue;
      }
      
      // For dates, compare timestamps
      if (prevValue instanceof Date && nextValue instanceof Date) {
        if (prevValue.getTime() !== nextValue.getTime()) return false;
        continue;
      }
      
      // For arrays, compare items
      if (Array.isArray(prevValue) && Array.isArray(nextValue)) {
        if (!compareArrays) return false; // Skip deep comparison
        if (prevValue.length !== nextValue.length) return false;
        
        for (let i = 0; i < prevValue.length; i++) {
          if (!deepEqual(prevValue[i], nextValue[i])) return false;
        }
        continue;
      }
      
      // For objects, recurse
      if (prevType === 'object') {
        if (!compareObjects) return false; // Skip deep comparison
        if (!deepEqual(prevValue, nextValue)) return false;
        continue;
      }
      
      // For all other types, use strict equality
      if (prevValue !== nextValue) return false;
    }
    
    return true;
  };
}

/**
 * Deep equality comparison
 */
function deepEqual(a, b) {
  // If references are the same, they are equal
  if (a === b) return true;
  
  // If either is null/undefined, they are equal only if both are
  if (a == null || b == null) return a === b;
  
  // Get type
  const aType = typeof a;
  const bType = typeof b;
  
  // Types must match
  if (aType !== bType) return false;
  
  // For dates, compare timestamps
  if (a instanceof Date && b instanceof Date) {
    return a.getTime() === b.getTime();
  }
  
  // For arrays, compare items
  if (Array.isArray(a) && Array.isArray(b)) {
    if (a.length !== b.length) return false;
    
    for (let i = 0; i < a.length; i++) {
      if (!deepEqual(a[i], b[i])) return false;
    }
    
    return true;
  }
  
  // For objects, recurse
  if (aType === 'object') {
    const aKeys = Object.keys(a);
    const bKeys = Object.keys(b);
    
    if (aKeys.length !== bKeys.length) return false;
    
    for (let key of aKeys) {
      if (!b.hasOwnProperty(key)) return false;
      if (!deepEqual(a[key], b[key])) return false;
    }
    
    return true;
  }
  
  // For all other types, use strict equality
  return a === b;
}

/**
 * Calculate object differences for differential updates
 */
export function calculateDiff(newObj, oldObj) {
  const diff = {};
  
  // Find changed or added properties
  for (const key in newObj) {
    if (!oldObj.hasOwnProperty(key) || 
        !deepEqual(newObj[key], oldObj[key])) {
      diff[key] = newObj[key];
    }
  }
  
  // Find deleted properties
  for (const key in oldObj) {
    if (!newObj.hasOwnProperty(key)) {
      diff[key] = null; // Mark as deleted
    }
  }
  
  return diff;
}

/**
 * React component for visual smooth transitions
 */
export const SmoothTransition = React.memo(({ value, duration = 500 }) => {
  const [displayValue, setDisplayValue] = useState(value);
  const prevValueRef = useRef(value);
  
  useEffect(() => {
    let startTime;
    let animationFrame;
    
    // Skip animation for initial value
    if (prevValueRef.current === value) {
      setDisplayValue(value);
      return;
    }
    
    // Animate value change
    const startValue = prevValueRef.current;
    const endValue = value;
    const valueChange = endValue - startValue;
    
    // Only animate numbers
    if (typeof startValue !== 'number' || typeof endValue !== 'number') {
      setDisplayValue(value);
      prevValueRef.current = value;
      return;
    }
    
    // Update function
    const updateValue = (timestamp) => {
      if (!startTime) startTime = timestamp;
      const elapsed = timestamp - startTime;
      
      if (elapsed < duration) {
        // Easing function - easeOutCubic
        const progress = 1 - Math.pow(1 - elapsed / duration, 3);
        const currentValue = startValue + valueChange * progress;
        
        setDisplayValue(currentValue);
        animationFrame = requestAnimationFrame(updateValue);
      } else {
        // Animation complete
        setDisplayValue(endValue);
        prevValueRef.current = endValue;
      }
    };
    
    // Start animation
    animationFrame = requestAnimationFrame(updateValue);
    
    // Clean up
    return () => {
      if (animationFrame) {
        cancelAnimationFrame(animationFrame);
      }
    };
  }, [value, duration]);
  
  return (
    <span className="smooth-transition">
      {typeof displayValue === 'number' ? displayValue.toFixed(2) : displayValue}
    </span>
  );
}, createDeepCompare());

/**
 * Memoized metric card for high-performance dashboards
 */
export const MetricCard = React.memo(function MetricCard({ 
  title, 
  value, 
  previousValue, 
  change, 
  formatter = (v) => v, 
  animate = true 
}) {
  const displayValue = useMemo(() => formatter(value), [value, formatter]);
  
  const changeClassName = useMemo(() => {
    if (change === 0) return 'neutral';
    return change > 0 ? 'positive' : 'negative';
  }, [change]);
  
  const formattedChange = useMemo(() => {
    if (change === null || change === undefined) return null;
    return `${change > 0 ? '+' : ''}${change.toFixed(1)}%`;
  }, [change]);
  
  return (
    <div className="metric-card">
      <h3 className="metric-title">{title}</h3>
      <div className="metric-value">
        {animate ? (
          <SmoothTransition value={value} />
        ) : displayValue}
      </div>
      {formattedChange && (
        <div className={`metric-change ${changeClassName}`}>
          {formattedChange}
        </div>
      )}
    </div>
  );
}, createDeepCompare({ numberTolerance: 0.001 }));

/**
 * Error boundary component for dashboard sections
 */
export class DashboardErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }
  
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  
  componentDidCatch(error, errorInfo) {
    console.error('Dashboard error:', error, errorInfo);
    
    // Report error to monitoring service
    if (this.props.onError) {
      this.props.onError(error, errorInfo);
    }
  }
  
  render() {
    if (this.state.hasError) {
      return (
        <div className="error-boundary">
          <h3>Dashboard Component Error</h3>
          <p>Something went wrong in this dashboard component.</p>
          <button onClick={() => this.setState({ hasError: false, error: null })}>
            Try Again
          </button>
        </div>
      );
    }
    
    return this.props.children;
  }
}
