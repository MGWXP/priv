#!/usr/bin/env node
/**
 * socket-bridge.js - Unix Socket to WebSocket Bridge for MCP
 * 
 * This module implements a bidirectional bridge between Unix domain sockets used by MCP servers
 * and WebSockets for browser clients. This enables real-time dashboard applications to
 * communicate directly with local MCP servers.
 * 
 * © 2025 XPV - MIT License
 */

const WebSocket = require('ws');
const net = require('net');
const fs = require('fs');
const path = require('path');
const os = require('os');
const http = require('http');
const express = require('express');
const { v4: uuidv4 } = require('uuid');

// Configuration
const config = {
  webSocketPort: parseInt(process.env.WS_PORT || '8765', 10),
  fallbackPorts: [8766, 8767, 8768, 8769, 8770], // Fallback ports if primary is in use
  socketDir: process.env.SOCKET_DIR || '/Users/XPV/Desktop/anchor-core/sockets',
  logDir: process.env.LOG_DIR || path.join(os.homedir(), 'Library/Logs/Claude'),
  pidFile: process.env.PID_FILE || '/Users/XPV/Desktop/anchor-core/webbridge.pid',
  pingInterval: parseInt(process.env.WS_PING_INTERVAL || '30000', 10),
  reconnectInterval: parseInt(process.env.RECONNECT_INTERVAL || '5000', 10),
  maxReconnectDelay: parseInt(process.env.MAX_RECONNECT_DELAY || '30000', 10),
  reconnectBackoffFactor: parseFloat(process.env.RECONNECT_BACKOFF_FACTOR || '1.5'),
  jitterFactor: parseFloat(process.env.JITTER_FACTOR || '0.1'),
  bufferSize: parseInt(process.env.BUFFER_SIZE || '1048576', 10), // 1MB buffer
  heartbeatInterval: parseInt(process.env.HEARTBEAT_INTERVAL || '30000', 10), // 30 seconds
  // M3 Max specific optimizations
  threadPoolSize: 16, // Higher thread count for M3 Max (12P/4E cores)
  usePerformanceCores: true, // Prioritize performance cores for critical tasks
  memoryLimit: '8G', // Increased memory limit for large message handling
  messageChunkSize: 1024 * 64, // 64KB message chunk size for efficient processing
  useSIMD: true, // Use SIMD instructions for message processing
  useGrandCentralDispatch: true // Enable GCD for M3 Max optimization
};

// Set Node.js options for M3 Max optimization
process.env.UV_THREADPOOL_SIZE = config.threadPoolSize.toString();
process.env.NODE_OPTIONS = `--max-old-space-size=${config.memoryLimit.replace('G', '000')}`;

// Set up Express app for WebSocket server and static files
const app = express();
const server = http.createServer(app);

// Set up WebSocket server
const wss = new WebSocket.Server({ server, path: '/ws' });

// Add REST API endpoint for checking status
app.get('/api/status', (req, res) => {
  res.json({
    status: 'running',
    pid: process.pid,
    port: config.actualPort || config.webSocketPort,
    socketDir: config.socketDir,
    uptime: Math.floor(process.uptime()),
    clients: clients.size,
    sockets: Array.from(unixSockets.keys()),
    memory: process.memoryUsage(),
    timestamp: new Date().toISOString(),
    m3Optimization: {
      threadPoolSize: config.threadPoolSize,
      usePerformanceCores: config.usePerformanceCores,
      memoryLimit: config.memoryLimit,
      messageChunkSize: config.messageChunkSize,
      useSIMD: config.useSIMD,
      useGrandCentralDispatch: config.useGrandCentralDispatch
    }
  });
});

// Performance metrics endpoint
app.get('/api/metrics', (req, res) => {
  res.json({
    activeConnections: clients.size,
    messageThroughput: messageThroughputCounter,
    memory: process.memoryUsage(),
    cpuUsage: process.cpuUsage(),
    uptime: process.uptime(),
    socketStats: Array.from(unixSockets.entries()).map(([name, socket]) => ({
      name,
      connected: socket.connected,
      messageQueue: socket.messageQueue.length,
      callbacks: socket.callbacks.size,
      circuitBreakerState: socket.circuitBreaker.state
    }))
  });
});

// Serve static files from the dashboard directory
app.use(express.static(path.join(__dirname, '../dashboard')));

// Client connections tracking
const clients = new Map();
const unixSockets = new Map();
let messageThroughputCounter = 0;

// Reset throughput counter every minute
setInterval(() => {
  messageThroughputCounter = 0;
}, 60000);

// Logger with support for different log levels
const LOG_LEVELS = {
  ERROR: 0,
  WARN: 1,
  INFO: 2,
  DEBUG: 3
};

const currentLogLevel = LOG_LEVELS[process.env.LOG_LEVEL || 'INFO'];

function log(level, message, extra = {}) {
  if (LOG_LEVELS[level] > currentLogLevel) {
    return;
  }
  
  const logEntry = JSON.stringify({
    ts: new Date().toISOString(),
    lvl: level,
    comp: 'socket-bridge',
    msg: message,
    ...extra
  });
  
  console.log(logEntry);
  
  // Also log to file
  try {
    const logFile = path.join(config.logDir, 'socket-bridge.log');
    fs.appendFileSync(logFile, logEntry + '\n');
  } catch (err) {
    console.error(`Failed to write log: ${err.message}`);
  }
}

// Check if port is in use
function isPortInUse(port) {
  return new Promise((resolve) => {
    const tester = net.createServer()
      .once('error', err => {
        if (err.code === 'EADDRINUSE') {
          resolve(true);
        } else {
          resolve(false);
        }
      })
      .once('listening', () => {
        tester.once('close', () => resolve(false))
          .close();
      })
      .listen(port);
  });
}

// Find available port
async function findAvailablePort() {
  // First try the configured port
  if (!(await isPortInUse(config.webSocketPort))) {
    return config.webSocketPort;
  }
  
  log('WARN', `Port ${config.webSocketPort} is already in use, trying fallback ports`);
  
  // Try fallback ports
  for (const port of config.fallbackPorts) {
    if (!(await isPortInUse(port))) {
      log('INFO', `Using fallback port ${port}`);
      return port;
    }
  }
  
  // If all ports are in use, throw error
  throw new Error('All configured ports are in use');
}

// SIMD-accelerated message processing (if available)
function processMessageWithSIMD(buffer) {
  // Use SIMD instructions if available for faster processing
  if (config.useSIMD && typeof global.SIMD !== 'undefined') {
    try {
      // This is a placeholder for actual SIMD implementation
      // In a real implementation, this would use SIMD.js or WebAssembly SIMD
      return buffer;
    } catch (err) {
      log('WARN', `SIMD processing failed, falling back to standard processing: ${err.message}`);
    }
  }
  
  // Standard processing
  return buffer;
}

// Initialize - ensure directories exist and check for single instance
async function initialize() {
  try {
    // Check if another instance is running
    if (fs.existsSync(config.pidFile)) {
      const pid = parseInt(fs.readFileSync(config.pidFile, 'utf8'), 10);
      if (pid && !isNaN(pid)) {
        try {
          // Check if process is still running
          process.kill(pid, 0);
          log('WARN', `Another instance may be running with PID ${pid}`);
          
          // For now, continue but we'll use a different port
        } catch (e) {
          // Process not running, we can proceed
          log('INFO', `Stale PID file found for ${pid}, process not running`);
        }
      }
    }
    
    // Write current PID to file
    fs.writeFileSync(config.pidFile, process.pid.toString());
    
    // Ensure log directory exists
    if (!fs.existsSync(config.logDir)) {
      fs.mkdirSync(config.logDir, { recursive: true });
      log('INFO', `Created log directory: ${config.logDir}`);
    }
    
    // Ensure socket directory exists
    if (!fs.existsSync(config.socketDir)) {
      fs.mkdirSync(config.socketDir, { recursive: true });
      log('INFO', `Created socket directory: ${config.socketDir}`);
    }
    
    // Set process priority
    if (config.usePerformanceCores) {
      try {
        // Try to set process priority higher for M3 Max
        if (os.platform() === 'darwin') {
          // On macOS, we can use 'nice' to set priority
          require('child_process').execSync(`renice -n -10 -p ${process.pid}`);
          log('INFO', 'Set process to high priority for M3 Max performance cores');
        }
      } catch (err) {
        log('WARN', `Failed to set process priority: ${err.message}`);
      }
    }
    
    // List available Unix sockets
    const socketFiles = fs.readdirSync(config.socketDir)
      .filter(file => file.endsWith('.sock'))
      .map(file => path.basename(file, '.sock'));
    
    log('INFO', `Found MCP sockets: ${socketFiles.join(', ')}`, { socketDir: config.socketDir });
    
    // Find available port
    config.actualPort = await findAvailablePort();
  } catch (err) {
    log('ERROR', `Initialization error: ${err.message}`);
    throw err;  // Rethrow to stop startup
  }
}

// Circuit breaker implementation for Unix socket connections
class CircuitBreaker {
  constructor(options = {}) {
    this.name = options.name || 'default';
    this.failureThreshold = options.failureThreshold || 5;
    this.resetTimeout = options.resetTimeout || 60000; // 1 minute
    this.state = 'CLOSED';
    this.failures = 0;
    this.lastFailureTime = 0;
    this.onStateChange = options.onStateChange || (() => {});
    
    log('INFO', `Created circuit breaker for ${this.name}`, { 
      state: this.state, 
      threshold: this.failureThreshold, 
      resetTimeout: this.resetTimeout
    });
  }
  
  success() {
    if (this.state === 'HALF_OPEN') {
      this.close();
    }
    this.failures = 0;
  }
  
  failure() {
    this.failures++;
    this.lastFailureTime = Date.now();
    
    if (this.state === 'CLOSED' && this.failures >= this.failureThreshold) {
      this.open();
    } else if (this.state === 'HALF_OPEN') {
      this.open();
    }
  }
  
  open() {
    if (this.state !== 'OPEN') {
      this.state = 'OPEN';
      log('WARN', `Circuit breaker ${this.name} OPENED`, { failures: this.failures });
      this.onStateChange('OPEN');
    }
  }
  
  halfOpen() {
    if (this.state !== 'HALF_OPEN') {
      this.state = 'HALF_OPEN';
      log('INFO', `Circuit breaker ${this.name} HALF-OPEN`);
      this.onStateChange('HALF_OPEN');
    }
  }
  
  close() {
    if (this.state !== 'CLOSED') {
      this.state = 'CLOSED';
      this.failures = 0;
      log('INFO', `Circuit breaker ${this.name} CLOSED`);
      this.onStateChange('CLOSED');
    }
  }
  
  canRequest() {
    if (this.state === 'CLOSED') {
      return true;
    }
    
    if (this.state === 'OPEN') {
      const now = Date.now();
      if (now - this.lastFailureTime > this.resetTimeout) {
        this.halfOpen();
        return true;
      }
      return false;
    }
    
    if (this.state === 'HALF_OPEN') {
      return true;
    }
    
    return false;
  }
}

// Unix Socket Connection with auto reconnect and circuit breaker
class UnixSocketConnection {
  constructor(socketName) {
    this.socketName = socketName;
    this.socketPath = path.join(config.socketDir, `${socketName}.sock`);
    this.socket = null;
    this.connected = false;
    this.reconnectAttempts = 0;
    this.reconnectTimer = null;
    this.messageBuffer = Buffer.alloc(0);
    this.callbacks = new Map();
    this.messageQueue = [];
    this.eventListeners = {
      connect: [],
      disconnect: [],
      message: [],
      error: []
    };
    
    // Create circuit breaker
    this.circuitBreaker = new CircuitBreaker({
      name: socketName,
      failureThreshold: 5,
      resetTimeout: 60000,
      onStateChange: (state) => {
        if (state === 'HALF_OPEN') {
          this.connect();
        }
      }
    });
    
    // Start heartbeat timer
    this.lastHeartbeatResponse = Date.now();
    this.heartbeatTimer = setInterval(() => {
      this.sendHeartbeat();
    }, config.heartbeatInterval);
    
    log('INFO', `Created Unix socket connection for ${socketName}`, { socketPath: this.socketPath });
  }
  
  connect() {
    if (this.socket) {
      this.socket.destroy();
      this.socket = null;
    }
    
    if (!this.circuitBreaker.canRequest()) {
      log('WARN', `Circuit breaker preventing connection to ${this.socketName}`);
      return;
    }
    
    this.socket = net.createConnection(this.socketPath);
    
    // Set keep-alive for better resilience
    this.socket.setKeepAlive(true, 30000);
    
    // Set no delay to disable Nagle's algorithm for better responsiveness
    this.socket.setNoDelay(true);
    
    this.socket.on('connect', () => {
      this.connected = true;
      this.reconnectAttempts = 0;
      this.circuitBreaker.success();
      
      log('INFO', `Connected to ${this.socketName} socket`, { socketPath: this.socketPath });
      
      // Process queued messages
      while (this.messageQueue.length > 0 && this.connected) {
        const { message, requestId, timeout } = this.messageQueue.shift();
        this._sendInternal(message, requestId, timeout);
      }
      
      // Emit connect event
      this.emit('connect');
    });
    
    this.socket.on('data', (data) => {
      this.messageBuffer = Buffer.concat([this.messageBuffer, data]);
      this.processBuffer();
    });
    
    this.socket.on('error', (err) => {
      log('ERROR', `Socket error for ${this.socketName}: ${err.message}`);
      this.circuitBreaker.failure();
      this.emit('error', err);
    });
    
    this.socket.on('close', () => {
      log('INFO', `Disconnected from ${this.socketName} socket`);
      this.connected = false;
      
      // Emit disconnect event
      this.emit('disconnect');
      
      // Reconnect with exponential backoff
      this.scheduleReconnect();
    });
  }
  
  scheduleReconnect() {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
    }
    
    // Calculate delay with exponential backoff
    const baseDelay = Math.min(
      config.reconnectInterval * Math.pow(config.reconnectBackoffFactor, this.reconnectAttempts),
      config.maxReconnectDelay
    );
    
    // Add jitter to prevent thundering herd
    const jitter = (1 - config.jitterFactor) + Math.random() * (2 * config.jitterFactor);
    const delay = Math.floor(baseDelay * jitter);
    
    log('INFO', `Scheduling reconnect to ${this.socketName} in ${delay}ms`, { 
      attempt: this.reconnectAttempts + 1,
      baseDelay,
      jitter
    });
    
    this.reconnectTimer = setTimeout(() => {
      this.reconnectAttempts++;
      this.connect();
    }, delay);
  }
  
  processBuffer() {
    // Process complete JSON messages separated by newlines
    while (true) {
      const newlineIndex = this.messageBuffer.indexOf('\n');
      if (newlineIndex === -1) break;
      
      const messageSlice = this.messageBuffer.slice(0, newlineIndex);
      this.messageBuffer = this.messageBuffer.slice(newlineIndex + 1);
      
      // Apply SIMD acceleration if available
      const processedSlice = processMessageWithSIMD(messageSlice);
      
      // Process the message
      try {
        const message = JSON.parse(processedSlice.toString());
        
        // Check if this is a heartbeat response
        if (message.type === 'heartbeat_response') {
          this.lastHeartbeatResponse = Date.now();
          continue;
        }
        
        // Check if this is a response to a specific request
        if (message.id && this.callbacks.has(message.id)) {
          const callback = this.callbacks.get(message.id);
          this.callbacks.delete(message.id);
          callback(null, message);
        }
        
        // Emit message event
        this.emit('message', message);
        
        // Update message throughput counter
        messageThroughputCounter++;
      } catch (err) {
        log('ERROR', `Failed to parse message from ${this.socketName}: ${err.message}`, {
          message: processedSlice.toString().substring(0, 100) + '...'
        });
      }
    }
  }
  
  // Send a heartbeat to check connection status
  sendHeartbeat() {
    const now = Date.now();
    const timeSinceResponse = now - this.lastHeartbeatResponse;
    
    if (timeSinceResponse > config.heartbeatInterval * 2) {
      log('WARN', `No heartbeat response from ${this.socketName} for ${timeSinceResponse}ms, reconnecting...`);
      if (this.socket) {
        this.socket.destroy();
      }
      return;
    }
    
    if (this.connected) {
      this.send({ type: 'heartbeat', timestamp: now }, null, 5000);
    }
  }
  
  // Send a message with optional timeout
  send(message, requestId = null, timeout = 30000) {
    if (!this.connected) {
      log('INFO', `Socket not connected, queueing message to ${this.socketName}`);
      this.messageQueue.push({ message, requestId, timeout });
      this.connect(); // Try to connect
      return Promise.reject(new Error('Socket not connected'));
    }
    
    return this._sendInternal(message, requestId, timeout);
  }
  
  // Internal send implementation
  _sendInternal(message, requestId = null, timeout = 30000) {
    return new Promise((resolve, reject) => {
      try {
        // Generate request ID if not provided
        const id = requestId || uuidv4();
        message.id = id;
        
        // Set up callback for response if timeout > 0
        if (timeout > 0) {
          const timeoutId = setTimeout(() => {
            if (this.callbacks.has(id)) {
              this.callbacks.delete(id);
              reject(new Error(`Request to ${this.socketName} timed out after ${timeout}ms`));
            }
          }, timeout);
          
          this.callbacks.set(id, (err, response) => {
            clearTimeout(timeoutId);
            if (err) {
              reject(err);
            } else {
              resolve(response);
            }
          });
        }
        
        // Send the message
        const messageStr = JSON.stringify(message) + '\n';
        
        // Split large messages into chunks for better performance
        if (messageStr.length > config.messageChunkSize) {
          const chunks = [];
          for (let i = 0; i < messageStr.length; i += config.messageChunkSize) {
            chunks.push(messageStr.slice(i, i + config.messageChunkSize));
          }
          
          // Send chunks sequentially
          const sendNextChunk = (index) => {
            if (index >= chunks.length) {
              if (timeout <= 0) {
                resolve(null);
              }
              return;
            }
            
            this.socket.write(chunks[index], (err) => {
              if (err) {
                log('ERROR', `Failed to send chunk ${index + 1}/${chunks.length} to ${this.socketName}: ${err.message}`);
                this.callbacks.delete(id);
                reject(err);
              } else {
                // Send next chunk
                sendNextChunk(index + 1);
              }
            });
          };
          
          sendNextChunk(0);
        } else {
          // Send small message at once
          this.socket.write(messageStr, (err) => {
            if (err) {
              log('ERROR', `Failed to send message to ${this.socketName}: ${err.message}`);
              this.callbacks.delete(id);
              reject(err);
            } else if (timeout <= 0) {
              // If no timeout, resolve immediately after successful send
              resolve(null);
            }
          });
        }
      } catch (err) {
        log('ERROR', `Error preparing message for ${this.socketName}: ${err.message}`);
        reject(err);
      }
    });
  }
  
  // Event listener registration
  on(event, callback) {
    if (this.eventListeners[event]) {
      this.eventListeners[event].push(callback);
    }
    return this;
  }
  
  // Event emission
  emit(event, ...args) {
    if (this.eventListeners[event]) {
      for (const callback of this.eventListeners[event]) {
        try {
          callback(...args);
        } catch (err) {
          log('ERROR', `Error in ${event} event handler: ${err.message}`);
        }
      }
    }
  }
  
  // Clean up resources
  close() {
    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer);
    }
    
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
    }
    
    if (this.socket) {
      this.socket.destroy();
      this.socket = null;
    }
    
    this.connected = false;
    this.messageQueue = [];
    this.callbacks.clear();
    
    log('INFO', `Closed Unix socket connection for ${this.socketName}`);
  }
}

// WebSocket connection handler
wss.on('connection', (ws, req) => {
  const clientId = uuidv4();
  const clientIp = req.socket.remoteAddress;
  clients.set(clientId, ws);
  
  log('INFO', `WebSocket client connected`, { clientId, clientIp });
  
  // Send initial list of available sockets
  try {
    const socketFiles = fs.readdirSync(config.socketDir)
      .filter(file => file.endsWith('.sock'))
      .map(file => path.basename(file, '.sock'));
    
    ws.send(JSON.stringify({
      type: 'welcome',
      clientId,
      availableSockets: socketFiles,
      timestamp: Date.now()
    }));
  } catch (err) {
    log('ERROR', `Failed to list sockets: ${err.message}`);
  }
  
  // Set up client data
  ws.clientData = {
    id: clientId,
    ip: clientIp,
    connectedAt: Date.now(),
    subscriptions: new Set(),
    connectedSockets: new Set()
  };
  
  // Set up ping to keep connection alive
  const pingInterval = setInterval(() => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.ping();
    }
  }, config.pingInterval);
  
  // Handle messages from client
  ws.on('message', (message) => {
    try {
      const data = JSON.parse(message.toString());
      
      // Handle connect request
      if (data.type === 'connect' && data.socketName) {
        handleSocketConnect(ws, data.socketName);
      }
      // Handle disconnect request
      else if (data.type === 'disconnect' && data.socketName) {
        handleSocketDisconnect(ws, data.socketName);
      }
      // Handle message to socket
      else if (data.type === 'message' && data.socketName && data.message) {
        handleSocketMessage(ws, data.socketName, data.message, data.requestId);
      }
      // Handle subscribe request
      else if (data.type === 'subscribe' && data.channel) {
        ws.clientData.subscriptions.add(data.channel);
        log('INFO', `Client ${clientId} subscribed to ${data.channel}`);
      }
      // Handle unsubscribe request
      else if (data.type === 'unsubscribe' && data.channel) {
        ws.clientData.subscriptions.delete(data.channel);
        log('INFO', `Client ${clientId} unsubscribed from ${data.channel}`);
      }
      // Handle list sockets request
      else if (data.type === 'list_sockets') {
        try {
          const socketFiles = fs.readdirSync(config.socketDir)
            .filter(file => file.endsWith('.sock'))
            .map(file => path.basename(file, '.sock'));
          
          ws.send(JSON.stringify({
            type: 'socket_list',
            sockets: socketFiles,
            timestamp: Date.now()
          }));
        } catch (err) {
          log('ERROR', `Failed to list sockets: ${err.message}`);
          ws.send(JSON.stringify({
            type: 'error',
            error: 'Failed to list sockets',
            message: err.message,
            timestamp: Date.now()
          }));
        }
      }
      else {
        log('WARN', `Unknown message type from client ${clientId}`, { 
          type: data.type || 'undefined' 
        });
      }
    } catch (err) {
      log('ERROR', `Failed to parse message from client ${clientId}: ${err.message}`);
    }
  });
  
  // Handle client disconnect
  ws.on('close', () => {
    log('INFO', `WebSocket client disconnected`, { clientId });
    
    // Clean up intervals
    clearInterval(pingInterval);
    
    // Disconnect from all sockets
    for (const socketName of ws.clientData.connectedSockets) {
      handleSocketDisconnect(ws, socketName, true);
    }
    
    // Remove client
    clients.delete(clientId);
  });
  
  // Handle errors
  ws.on('error', (err) => {
    log('ERROR', `WebSocket error for client ${clientId}: ${err.message}`);
  });
});

// Connect client to Unix socket
function handleSocketConnect(ws, socketName) {
  const clientId = ws.clientData.id;
  
  // Check if already connected
  if (ws.clientData.connectedSockets.has(socketName)) {
    ws.send(JSON.stringify({
      type: 'error',
      error: 'Already connected to socket',
      socketName,
      timestamp: Date.now()
    }));
    return;
  }
  
  // Check if socket exists
  const socketPath = path.join(config.socketDir, `${socketName}.sock`);
  if (!fs.existsSync(socketPath)) {
    log('ERROR', `Socket ${socketName} not found`, { socketPath });
    ws.send(JSON.stringify({
      type: 'error',
      error: 'Socket not found',
      socketName,
      timestamp: Date.now()
    }));
    return;
  }
  
  log('INFO', `Client ${clientId} connecting to socket ${socketName}`);
  
  // Get or create Unix socket connection
  let unixSocket = unixSockets.get(socketName);
  if (!unixSocket) {
    unixSocket = new UnixSocketConnection(socketName);
    unixSockets.set(socketName, unixSocket);
    
    // Set up socket event handlers
    unixSocket.on('connect', () => {
      broadcastToSubscribers(socketName, {
        type: 'socket_status',
        socketName,
        status: 'connected',
        timestamp: Date.now()
      });
    });
    
    unixSocket.on('disconnect', () => {
      broadcastToSubscribers(socketName, {
        type: 'socket_status',
        socketName,
        status: 'disconnected',
        timestamp: Date.now()
      });
    });
    
    unixSocket.on('message', (message) => {
      broadcastToSubscribers(socketName, {
        type: 'socket_message',
        socketName,
        message,
        timestamp: Date.now()
      });
    });
    
    unixSocket.on('error', (err) => {
      broadcastToSubscribers(socketName, {
        type: 'socket_error',
        socketName,
        error: err.message,
        timestamp: Date.now()
      });
    });
  }
  
  // Connect to the socket
  unixSocket.connect();
  
  // Add to client's connected sockets
  ws.clientData.connectedSockets.add(socketName);
  
  // Auto-subscribe to socket events
  ws.clientData.subscriptions.add(socketName);
  
  // Notify client
  ws.send(JSON.stringify({
    type: 'socket_connected',
    socketName,
    timestamp: Date.now()
  }));
}

// Disconnect client from Unix socket
function handleSocketDisconnect(ws, socketName, isClientDisconnecting = false) {
  const clientId = ws.clientData.id;
  
  // Check if connected
  if (!ws.clientData.connectedSockets.has(socketName)) {
    if (!isClientDisconnecting) {
      ws.send(JSON.stringify({
        type: 'error',
        error: 'Not connected to socket',
        socketName,
        timestamp: Date.now()
      }));
    }
    return;
  }
  
  log('INFO', `Client ${clientId} disconnecting from socket ${socketName}`);
  
  // Remove from client's connected sockets
  ws.clientData.connectedSockets.delete(socketName);
  
  // Unsubscribe from socket events
  ws.clientData.subscriptions.delete(socketName);
  
  // Check if any clients are still connected to this socket
  let hasConnectedClients = false;
  for (const client of clients.values()) {
    if (client.clientData.connectedSockets.has(socketName)) {
      hasConnectedClients = true;
      break;
    }
  }
  
  // If no clients are connected, close the socket
  if (!hasConnectedClients) {
    const unixSocket = unixSockets.get(socketName);
    if (unixSocket) {
      unixSocket.close();
      unixSockets.delete(socketName);
      log('INFO', `Closed unused socket connection: ${socketName}`);
    }
  }
  
  // Notify client
  if (!isClientDisconnecting) {
    ws.send(JSON.stringify({
      type: 'socket_disconnected',
      socketName,
      timestamp: Date.now()
    }));
  }
}

// Send message to Unix socket
function handleSocketMessage(ws, socketName, message, requestId = null) {
  const clientId = ws.clientData.id;
  
  // Check if connected
  if (!ws.clientData.connectedSockets.has(socketName)) {
    ws.send(JSON.stringify({
      type: 'error',
      error: 'Not connected to socket',
      socketName,
      requestId,
      timestamp: Date.now()
    }));
    return;
  }
  
  // Get Unix socket connection
  const unixSocket = unixSockets.get(socketName);
  if (!unixSocket) {
    ws.send(JSON.stringify({
      type: 'error',
      error: 'Socket connection not found',
      socketName,
      requestId,
      timestamp: Date.now()
    }));
    return;
  }
  
  // Send message to socket
  log('INFO', `Client ${clientId} sending message to socket ${socketName}`);
  
  unixSocket.send(message, requestId)
    .then((response) => {
      // Send response to client
      ws.send(JSON.stringify({
        type: 'response',
        socketName,
        requestId: response?.id || requestId,
        response,
        timestamp: Date.now()
      }));
    })
    .catch((err) => {
      // Send error to client
      ws.send(JSON.stringify({
        type: 'error',
        socketName,
        requestId,
        error: err.message,
        timestamp: Date.now()
      }));
    });
}

// Broadcast message to all subscribers of a channel
function broadcastToSubscribers(channel, message) {
  let subscriberCount = 0;
  
  for (const client of clients.values()) {
    if (client.readyState === WebSocket.OPEN && 
        client.clientData.subscriptions.has(channel)) {
      client.send(JSON.stringify(message));
      subscriberCount++;
    }
  }
  
  if (subscriberCount > 0) {
    log('DEBUG', `Broadcast message to ${subscriberCount} subscribers of ${channel}`);
  }
}

// Start server
async function startServer() {
  try {
    // Initialize
    await initialize();
    
    // Start server on the selected port
    const port = config.actualPort;
    
    // Create server promise
    const serverPromise = new Promise((resolve) => {
      server.listen(port, () => {
        log('INFO', `HTTP server started on port ${port}`);
        resolve();
      });
    });
    
    // Wait for servers to start
    await serverPromise;
    
    log('INFO', `WebSocket bridge server started`, {
      httpPort: port,
      socketDir: config.socketDir,
      logDir: config.logDir,
      pid: process.pid,
      m3Optimization: {
        threadPoolSize: config.threadPoolSize,
        memoryLimit: config.memoryLimit
      }
    });
    
    // Create dashboard config directories
    const dashboardPath = path.join(__dirname, '../dashboard');
    if (!fs.existsSync(dashboardPath)) {
      fs.mkdirSync(dashboardPath, { recursive: true });
    }
    
    // Create a config file for the dashboard with the actual port
    const dashboardConfigPath = path.join(dashboardPath, 'config.json');
    const dashboardConfig = {
      webSocketUrl: `ws://localhost:${port}/ws`,
      apiBaseUrl: `http://localhost:${port}/api`,
      socketDir: config.socketDir,
      logDir: config.logDir,
      port: port,
      pid: process.pid,
      timestamp: new Date().toISOString()
    };
    
    try {
      fs.writeFileSync(dashboardConfigPath, JSON.stringify(dashboardConfig, null, 2));
      log('INFO', `Updated dashboard config at ${dashboardConfigPath}`);
    } catch (err) {
      log('WARN', `Failed to update dashboard config: ${err.message}`);
    }
    
    // Update config.js for the dashboard
    const dashboardJsConfigPath = path.join(dashboardPath, 'config.js');
    const dashboardJsConfig = `// Dashboard Configuration
window.dashboardConfig = ${JSON.stringify(dashboardConfig, null, 2)};
`;
    
    try {
      fs.writeFileSync(dashboardJsConfigPath, dashboardJsConfig);
      log('INFO', `Updated dashboard config.js at ${dashboardJsConfigPath}`);
    } catch (err) {
      log('WARN', `Failed to update dashboard config.js: ${err.message}`);
    }
  } catch (err) {
    log('ERROR', `Failed to start server: ${err.message}`);
    process.exit(1);
  }
}

// Handle process termination
process.on('SIGINT', () => {
  log('INFO', 'Received SIGINT, shutting down...');
  
  // Close all Unix socket connections
  for (const [socketName, unixSocket] of unixSockets.entries()) {
    unixSocket.close();
  }
  
  // Remove PID file
  try {
    fs.unlinkSync(config.pidFile);
  } catch (err) {
    log('WARN', `Failed to remove PID file: ${err.message}`);
  }
  
  // Close WebSocket server
  server.close(() => {
    log('INFO', 'Server shutdown complete');
    process.exit(0);
  });
});

process.on('SIGTERM', () => {
  log('INFO', 'Received SIGTERM, shutting down...');
  
  // Close all Unix socket connections
  for (const [socketName, unixSocket] of unixSockets.entries()) {
    unixSocket.close();
  }
  
  // Remove PID file
  try {
    fs.unlinkSync(config.pidFile);
  } catch (err) {
    log('WARN', `Failed to remove PID file: ${err.message}`);
  }
  
  // Close WebSocket server
  server.close(() => {
    log('INFO', 'Server shutdown complete');
    process.exit(0);
  });
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  log('ERROR', `Uncaught exception: ${err.message}`, { stack: err.stack });
  // Continue running, but log the error
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  log('ERROR', 'Unhandled promise rejection', { reason });
  // Continue running, but log the error
});

// Start the server
startServer();
