#!/usr/bin/env node
/**
 * webbridge-init.js - WebSocket Bridge Initializer
 * 
 * This initializes the WebSocket bridge for real-time dashboard communication,
 * Notion synchronization, and sets up the necessary directories and configurations.
 * 
 * © 2025 XPV - MIT License
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn } = require('child_process');
const { program } = require('commander');

// Configuration
const config = {
  socketDir: process.env.SOCKET_DIR || '/Users/XPV/Desktop/anchor-core/sockets',
  logDir: process.env.LOG_DIR || path.join(os.homedir(), 'Library/Logs/Claude'),
  dashboardDir: process.env.DASHBOARD_DIR || '/Users/XPV/Desktop/anchor-core/dashboard',
  webSocketPort: parseInt(process.env.WS_PORT || '8765', 10),
  notionSyncInterval: parseInt(process.env.NOTION_SYNC_INTERVAL || '10000', 10),
  notionApiToken: process.env.NOTION_API_TOKEN || '',
  enableDashboard: process.env.ENABLE_DASHBOARD !== 'false',
  enableNotionSync: process.env.ENABLE_NOTION_SYNC !== 'false',
  anchorHome: process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core'
};

// Logger
function log(level, message, extra = {}) {
  const logEntry = JSON.stringify({
    ts: new Date().toISOString(),
    lvl: level,
    comp: 'webbridge-init',
    msg: message,
    ...extra
  });
  
  console.log(logEntry);
  
  // Also log to file
  try {
    const logFile = path.join(config.logDir, 'webbridge-init.log');
    fs.appendFileSync(logFile, logEntry + '\n');
  } catch (err) {
    console.error(`Failed to write log: ${err.message}`);
  }
}

// Command line interface
program
  .name('webbridge-init')
  .description('Initialize WebSocket bridge for real-time dashboard communication')
  .version('1.0.0');

program
  .option('-p, --port <number>', 'WebSocket server port', config.webSocketPort)
  .option('-d, --dashboard', 'Enable dashboard server', config.enableDashboard)
  .option('-n, --notion-sync', 'Enable Notion synchronization', config.enableNotionSync)
  .option('-s, --socket-dir <path>', 'Socket directory', config.socketDir)
  .option('-l, --log-dir <path>', 'Log directory', config.logDir)
  .option('--no-dashboard', 'Disable dashboard server')
  .option('--no-notion-sync', 'Disable Notion synchronization');

program.parse();

// Update configuration with command line options
const options = program.opts();
config.webSocketPort = parseInt(options.port, 10);
config.enableDashboard = options.dashboard;
config.enableNotionSync = options.notionSync;
config.socketDir = options.socketDir;
config.logDir = options.logDir;

// Ensure directories exist
function ensureDirectories() {
  const directories = [
    config.socketDir,
    config.logDir,
    config.dashboardDir,
    path.join(config.anchorHome, 'data'),
    path.join(config.anchorHome, 'data/sqlite'),
    path.join(config.anchorHome, 'data/notion-cache')
  ];
  
  for (const dir of directories) {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
      log('INFO', `Created directory: ${dir}`);
    }
  }
}

// Start WebSocket bridge
function startSocketBridge() {
  const bridgePath = path.join(config.anchorHome, 'src/webbridge/socket-bridge.js');
  
  if (!fs.existsSync(bridgePath)) {
    log('ERROR', `Socket bridge script not found: ${bridgePath}`);
    process.exit(1);
  }
  
  const process_env = {
    ...process.env,
    WS_PORT: String(config.webSocketPort),
    SOCKET_DIR: config.socketDir,
    LOG_DIR: config.logDir,
    ANCHOR_HOME: config.anchorHome
  };
  
  log('INFO', 'Starting WebSocket bridge', { 
    port: config.webSocketPort,
    socketDir: config.socketDir 
  });
  
  const socketBridge = spawn('node', [bridgePath], { 
    env: process_env,
    detached: true,
    stdio: 'ignore'
  });
  
  socketBridge.unref();
  
  // Save PID to file
  const pidFile = path.join(config.anchorHome, 'webbridge.pid');
  fs.writeFileSync(pidFile, String(socketBridge.pid));
  
  log('INFO', `WebSocket bridge started with PID ${socketBridge.pid}`);
  
  return socketBridge.pid;
}

// Start Notion sync if enabled
function startNotionSync() {
  if (!config.enableNotionSync) {
    log('INFO', 'Notion synchronization disabled');
    return null;
  }
  
  if (!config.notionApiToken) {
    log('WARN', 'Notion API token not provided, sync will not work properly');
  }
  
  const syncPath = path.join(config.anchorHome, 'src/webbridge/notion-sync.js');
  
  if (!fs.existsSync(syncPath)) {
    log('ERROR', `Notion sync script not found: ${syncPath}`);
    return null;
  }
  
  const process_env = {
    ...process.env,
    NOTION_API_TOKEN: config.notionApiToken,
    NOTION_SYNC_INTERVAL: String(config.notionSyncInterval),
    LOG_DIR: config.logDir,
    ANCHOR_HOME: config.anchorHome
  };
  
  log('INFO', 'Starting Notion synchronization', { 
    syncInterval: config.notionSyncInterval,
    databasesPath: path.join(config.anchorHome, 'data/notion-sync.db')
  });
  
  const notionSync = spawn('node', [syncPath], { 
    env: process_env,
    detached: true,
    stdio: 'ignore'
  });
  
  notionSync.unref();
  
  // Save PID to file
  const pidFile = path.join(config.anchorHome, 'notion-sync.pid');
  fs.writeFileSync(pidFile, String(notionSync.pid));
  
  log('INFO', `Notion sync started with PID ${notionSync.pid}`);
  
  return notionSync.pid;
}

// Create configuration file for the dashboard
function createDashboardConfig() {
  const configPath = path.join(config.dashboardDir, 'config.json');
  
  const dashboardConfig = {
    webSocketUrl: `ws://localhost:${config.webSocketPort}`,
    apiBaseUrl: `http://localhost:${config.webSocketPort}/api`,
    socketDir: config.socketDir,
    enableNotionSync: config.enableNotionSync,
    notionSyncInterval: config.notionSyncInterval,
    timestamp: new Date().toISOString()
  };
  
  fs.writeFileSync(configPath, JSON.stringify(dashboardConfig, null, 2));
  
  log('INFO', `Created dashboard configuration at ${configPath}`);
}

// Create startup script
function createStartupScript() {
  const scriptPath = path.join(config.anchorHome, 'start-webbridge.sh');
  
  const scriptContent = `#!/bin/bash
# WebSocket Bridge Startup Script
# Generated: ${new Date().toISOString()}

# Define variables
ANCHOR_HOME="${config.anchorHome}"
SOCKET_DIR="${config.socketDir}"
LOG_DIR="${config.logDir}"
WS_PORT=${config.webSocketPort}
NOTION_SYNC_INTERVAL=${config.notionSyncInterval}
ENABLE_DASHBOARD=${config.enableDashboard}
ENABLE_NOTION_SYNC=${config.enableNotionSync}

# Export environment variables
export ANCHOR_HOME SOCKET_DIR LOG_DIR WS_PORT NOTION_SYNC_INTERVAL

# Start WebSocket bridge
node "$ANCHOR_HOME/src/webbridge/socket-bridge.js" &
SOCKET_BRIDGE_PID=$!
echo $SOCKET_BRIDGE_PID > "$ANCHOR_HOME/webbridge.pid"
echo "Started WebSocket bridge with PID $SOCKET_BRIDGE_PID"

# Start Notion sync if enabled
if [ "$ENABLE_NOTION_SYNC" = "true" ]; then
  node "$ANCHOR_HOME/src/webbridge/notion-sync.js" &
  NOTION_SYNC_PID=$!
  echo $NOTION_SYNC_PID > "$ANCHOR_HOME/notion-sync.pid"
  echo "Started Notion sync with PID $NOTION_SYNC_PID"
fi

# Start dashboard server if enabled
if [ "$ENABLE_DASHBOARD" = "true" ]; then
  cd "$ANCHOR_HOME/dashboard"
  npm start &
  DASHBOARD_PID=$!
  echo $DASHBOARD_PID > "$ANCHOR_HOME/dashboard.pid"
  echo "Started dashboard server with PID $DASHBOARD_PID"
fi

echo "WebSocket bridge initialization complete"
`;
  
  fs.writeFileSync(scriptPath, scriptContent);
  fs.chmodSync(scriptPath, '755');
  
  log('INFO', `Created startup script at ${scriptPath}`);
}

// Stop any existing processes
function stopExistingProcesses() {
  const pidFiles = [
    path.join(config.anchorHome, 'webbridge.pid'),
    path.join(config.anchorHome, 'notion-sync.pid'),
    path.join(config.anchorHome, 'dashboard.pid')
  ];
  
  for (const pidFile of pidFiles) {
    if (fs.existsSync(pidFile)) {
      try {
        const pid = parseInt(fs.readFileSync(pidFile, 'utf8').trim(), 10);
        
        if (pid && !isNaN(pid)) {
          log('INFO', `Stopping process with PID ${pid}`);
          
          try {
            process.kill(pid);
          } catch (err) {
            if (err.code !== 'ESRCH') {
              log('WARN', `Failed to stop process with PID ${pid}: ${err.message}`);
            }
          }
        }
        
        fs.unlinkSync(pidFile);
      } catch (err) {
        log('WARN', `Error processing PID file ${pidFile}: ${err.message}`);
      }
    }
  }
}

// Create dashboard index.html if it doesn't exist
function createDashboardFiles() {
  const indexPath = path.join(config.dashboardDir, 'index.html');
  
  if (!fs.existsSync(indexPath)) {
    const indexContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MCP Dashboard</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <div id="app"></div>
  <script src="config.js"></script>
  <script src="bundle.js"></script>
</body>
</html>
`;
    
    fs.writeFileSync(indexPath, indexContent);
    log('INFO', `Created dashboard index.html at ${indexPath}`);
  }
  
  // Create a basic CSS file
  const cssPath = path.join(config.dashboardDir, 'styles.css');
  
  if (!fs.existsSync(cssPath)) {
    const cssContent = `/* Dashboard Styles */
body {
  margin: 0;
  padding: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
  background-color: #f5f5f7;
  color: #333;
}

#app {
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
}

.dashboard-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
  border-bottom: 1px solid #e0e0e0;
  padding-bottom: 1rem;
}

.dashboard-title {
  font-size: 1.5rem;
  font-weight: 600;
  color: #1d1d1f;
}

.dashboard-controls {
  display: flex;
  gap: 1rem;
}

.dashboard-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
}

.metric-card {
  background-color: white;
  border-radius: 8px;
  padding: 1.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
  transition: all 0.3s ease;
}

.metric-card:hover {
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  transform: translateY(-2px);
}

.metric-title {
  font-size: 0.875rem;
  font-weight: 500;
  color: #6e6e73;
  margin: 0 0 0.5rem 0;
}

.metric-value {
  font-size: 2rem;
  font-weight: 600;
  color: #1d1d1f;
  margin: 0 0 0.5rem 0;
}

.metric-change {
  font-size: 0.875rem;
  font-weight: 500;
}

.metric-change.positive {
  color: #34c759;
}

.metric-change.negative {
  color: #ff3b30;
}

.metric-change.neutral {
  color: #8e8e93;
}

.error-boundary {
  background-color: #fff;
  border: 1px solid #ff3b30;
  border-radius: 8px;
  padding: 1rem;
  margin-bottom: 1rem;
}

.error-boundary h3 {
  color: #ff3b30;
  margin-top: 0;
}

.error-boundary button {
  background-color: #007aff;
  color: white;
  border: none;
  border-radius: 4px;
  padding: 0.5rem 1rem;
  cursor: pointer;
}

.error-boundary button:hover {
  background-color: #0062cc;
}

.dashboard-status {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.875rem;
  padding: 0.25rem 0.5rem;
  border-radius: 4px;
  background-color: #f5f5f7;
}

.dashboard-status.connected {
  background-color: #e4f8ed;
  color: #34c759;
}

.dashboard-status.disconnected {
  background-color: #ffe5e5;
  color: #ff3b30;
}

.dashboard-status.connecting {
  background-color: #fff9e5;
  color: #ff9500;
}
`;
    
    fs.writeFileSync(cssPath, cssContent);
    log('INFO', `Created dashboard styles.css at ${cssPath}`);
  }
  
  // Create a basic config.js file
  const configJsPath = path.join(config.dashboardDir, 'config.js');
  
  if (!fs.existsSync(configJsPath)) {
    const configJsContent = `// Dashboard Configuration
window.dashboardConfig = {
  webSocketUrl: 'ws://localhost:${config.webSocketPort}',
  apiBaseUrl: 'http://localhost:${config.webSocketPort}/api',
  socketDir: '${config.socketDir}',
  enableNotionSync: ${config.enableNotionSync},
  notionSyncInterval: ${config.notionSyncInterval},
  timestamp: '${new Date().toISOString()}'
};
`;
    
    fs.writeFileSync(configJsPath, configJsContent);
    log('INFO', `Created dashboard config.js at ${configJsPath}`);
  }
}

// Main function
function main() {
  log('INFO', 'Initializing WebSocket bridge', config);
  
  // Stop existing processes
  stopExistingProcesses();
  
  // Ensure directories exist
  ensureDirectories();
  
  // Create dashboard files
  createDashboardFiles();
  
  // Create dashboard configuration
  createDashboardConfig();
  
  // Create startup script
  createStartupScript();
  
  // Start WebSocket bridge
  const socketBridgePid = startSocketBridge();
  
  // Start Notion sync if enabled
  const notionSyncPid = startNotionSync();
  
  // Log completion
  log('INFO', 'WebSocket bridge initialization complete', {
    socketBridgePid,
    notionSyncPid,
    webSocketPort: config.webSocketPort,
    enableNotionSync: config.enableNotionSync
  });
  
  // Output status for user
  console.log('\n========================================');
  console.log('WebSocket Bridge Initialization Complete');
  console.log('========================================');
  console.log(`WebSocket Server: ws://localhost:${config.webSocketPort}`);
  console.log(`Socket Directory: ${config.socketDir}`);
  console.log(`Notion Sync: ${config.enableNotionSync ? 'Enabled' : 'Disabled'}`);
  
  if (socketBridgePid) {
    console.log(`WebSocket Bridge PID: ${socketBridgePid}`);
  }
  
  if (notionSyncPid) {
    console.log(`Notion Sync PID: ${notionSyncPid}`);
  }
  
  console.log('\nTo start manually:');
  console.log(`  ${path.join(config.anchorHome, 'start-webbridge.sh')}`);
  console.log('\nTo stop:');
  console.log(`  kill ${socketBridgePid}${notionSyncPid ? ` ${notionSyncPid}` : ''}`);
  console.log('========================================\n');
}

// Run main function
main();
