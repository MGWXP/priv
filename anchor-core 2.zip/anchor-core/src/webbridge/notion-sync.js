#!/usr/bin/env node
/**
 * notion-sync.js - Synchronization service between Notion API and MCP
 * 
 * This module handles bidirectional synchronization between the Notion API and
 * the Model Context Protocol (MCP) system. It maintains a local cache and implements
 * proper rate limiting for the Notion API.
 * 
 * © 2025 XPV - MIT License
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const { Client } = require('@notionhq/client');
const net = require('net');
const { v4: uuidv4 } = require('uuid');
const { promisify } = require('util');
const crypto = require('crypto');
const SQLite3 = require('sqlite3').verbose();
const { open } = require('sqlite');

// Configuration
const config = {
  socketName: 'notion',
  socketDir: process.env.SOCKET_DIR || '/Users/XPV/Desktop/anchor-core/sockets',
  logDir: process.env.LOG_DIR || path.join(os.homedir(), 'Library/Logs/Claude'),
  dataDir: process.env.DATA_DIR || '/Users/XPV/Desktop/anchor-core/data',
  cacheDir: process.env.CACHE_DIR || '/Users/XPV/Desktop/anchor-core/data/notion-cache',
  pidFile: process.env.NOTION_PID_FILE || '/Users/XPV/Desktop/anchor-core/notion-sync.pid',
  syncInterval: parseInt(process.env.NOTION_SYNC_INTERVAL || '10000', 10), // 10 seconds
  rateLimitPerSecond: parseFloat(process.env.NOTION_RATE_LIMIT || '3'), // 3 requests per second
  credentialsPath: process.env.NOTION_CREDENTIALS_PATH || path.join(os.homedir(), '.notion', 'token'),
  enabledDatabases: process.env.NOTION_ENABLED_DATABASES
    ? process.env.NOTION_ENABLED_DATABASES.split(',')
    : [],
  // M3 Max specific optimizations
  threadPoolSize: 8, // Use 8 threads for the Notion sync (less than socket-bridge)
  usePerformanceCores: true, // Prioritize performance cores for critical tasks
  memoryLimit: '4G', // 4GB memory limit for Notion sync
  enableCache: true, // Enable caching for better performance
  cacheExpiryTime: 60 * 60 * 1000, // 1 hour cache expiry
  useCompression: true, // Use compression for cache files
  // Resilience settings
  maxRetries: 5, // Maximum number of retries for failed API calls
  retryDelayBase: 1000, // Base delay for retry in ms
  maxRetryDelay: 30000, // Maximum retry delay in ms
  circuitBreakerThreshold: 5, // Number of failures before opening circuit
  circuitBreakerResetTimeout: 60000 // Time before trying to close circuit in ms
};

// Set Node.js options for M3 Max optimization
process.env.UV_THREADPOOL_SIZE = config.threadPoolSize.toString();
process.env.NODE_OPTIONS = `--max-old-space-size=${config.memoryLimit.replace('G', '000')}`;

// Database
let db;

// Notion Client
let notionClient;

// Simple rate limiter implementation
class RateLimiter {
  constructor(tokensPerInterval, interval) {
    this.tokensPerInterval = tokensPerInterval;
    this.interval = interval === 'second' ? 1000 : interval;
    this.tokens = tokensPerInterval;
    this.lastRefill = Date.now();
  }
  
  async removeTokens(count) {
    // Refill tokens if needed
    this._refillTokens();
    
    if (this.tokens >= count) {
      this.tokens -= count;
      return count;
    }
    
    // Wait for tokens to be available
    const waitTime = Math.ceil((count - this.tokens) * (this.interval / this.tokensPerInterval));
    await new Promise(resolve => setTimeout(resolve, waitTime));
    
    // Refill after waiting
    this._refillTokens();
    this.tokens -= count;
    
    return count;
  }
  
  _refillTokens() {
    const now = Date.now();
    const timePassed = now - this.lastRefill;
    
    if (timePassed >= this.interval) {
      const tokensToAdd = Math.floor(timePassed / this.interval) * this.tokensPerInterval;
      this.tokens = Math.min(this.tokens + tokensToAdd, this.tokensPerInterval);
      this.lastRefill = now;
    }
  }
}

// Create a rate limiter
const rateLimiter = new RateLimiter(config.rateLimitPerSecond, 'second');

// Unix Socket server
let server;

// Current sync state
const syncState = {
  lastSync: 0,
  activeRequests: 0,
  activeClients: new Set(),
  pendingMessages: [],
  isSyncActive: false,
  syncError: null,
  circuitBreaker: {
    failures: 0,
    state: 'CLOSED', // CLOSED, OPEN, HALF_OPEN
    lastFailure: 0
  }
};

// Database schemas
const schemas = {
  metadata: `
    CREATE TABLE IF NOT EXISTS metadata (
      key TEXT PRIMARY KEY,
      value TEXT,
      updated_at INTEGER
    )
  `,
  pages: `
    CREATE TABLE IF NOT EXISTS pages (
      id TEXT PRIMARY KEY,
      parent_id TEXT,
      title TEXT,
      content TEXT,
      json_data TEXT,
      last_edited_time TEXT,
      created_time TEXT,
      updated_at INTEGER,
      etag TEXT,
      is_deleted INTEGER DEFAULT 0
    )
  `,
  databases: `
    CREATE TABLE IF NOT EXISTS databases (
      id TEXT PRIMARY KEY,
      parent_id TEXT,
      title TEXT,
      description TEXT,
      json_data TEXT,
      last_edited_time TEXT,
      created_time TEXT,
      updated_at INTEGER,
      etag TEXT,
      is_deleted INTEGER DEFAULT 0
    )
  `,
  blocks: `
    CREATE TABLE IF NOT EXISTS blocks (
      id TEXT PRIMARY KEY,
      parent_id TEXT,
      type TEXT,
      content TEXT,
      json_data TEXT,
      last_edited_time TEXT,
      created_time TEXT,
      updated_at INTEGER,
      etag TEXT,
      is_deleted INTEGER DEFAULT 0
    )
  `,
  sync_log: `
    CREATE TABLE IF NOT EXISTS sync_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp INTEGER,
      operation TEXT,
      object_type TEXT,
      object_id TEXT,
      status TEXT,
      error TEXT
    )
  `
};

// Logger
function log(level, message, extra = {}) {
  const logEntry = JSON.stringify({
    ts: new Date().toISOString(),
    lvl: level,
    comp: 'notion-sync',
    msg: message,
    ...extra
  });
  
  console.log(logEntry);
  
  // Also log to file
  try {
    const logFile = path.join(config.logDir, 'notion-sync.log');
    fs.appendFileSync(logFile, logEntry + '\n');
  } catch (err) {
    console.error(`Failed to write log: ${err.message}`);
  }
}

// Generate an ETag for caching
function generateETag(data) {
  return crypto.createHash('md5').update(JSON.stringify(data)).digest('hex');
}

// Rate limited API call with circuit breaker
async function callNotionApi(method, params = {}) {
  // Check circuit breaker
  if (syncState.circuitBreaker.state === 'OPEN') {
    const now = Date.now();
    if (now - syncState.circuitBreaker.lastFailure < config.circuitBreakerResetTimeout) {
      throw new Error('Circuit breaker is open, API calls suspended');
    }
    
    // Try half-open state
    syncState.circuitBreaker.state = 'HALF_OPEN';
    log('INFO', 'Circuit breaker entering half-open state');
  }
  
  // Wait for rate limit token
  await rateLimiter.removeTokens(1);
  
  syncState.activeRequests++;
  
  try {
    // Check if notionClient exists
    if (!notionClient) {
      throw new Error('Notion client not initialized');
    }
    
    // Check if method exists
    if (typeof notionClient[method] !== 'function') {
      throw new Error(`Invalid API method: ${method}`);
    }
    
    const response = await notionClient[method](params);
    
    // Reset circuit breaker on success
    if (syncState.circuitBreaker.state === 'HALF_OPEN') {
      syncState.circuitBreaker.state = 'CLOSED';
      syncState.circuitBreaker.failures = 0;
      log('INFO', 'Circuit breaker closed after successful API call');
    }
    
    return response;
  } catch (err) {
    // Handle rate limiting
    if (err.status === 429) {
      const retryAfter = parseInt(err.headers?.['retry-after'] || '5', 10);
      log('WARN', `Rate limited by Notion API, retrying after ${retryAfter}s`);
      
      // Wait for retry-after period
      await new Promise(resolve => setTimeout(resolve, retryAfter * 1000));
      
      // Retry the call recursively
      return callNotionApi(method, params);
    }
    
    // Update circuit breaker
    syncState.circuitBreaker.failures++;
    syncState.circuitBreaker.lastFailure = Date.now();
    
    if (syncState.circuitBreaker.state === 'CLOSED' && 
        syncState.circuitBreaker.failures >= config.circuitBreakerThreshold) {
      syncState.circuitBreaker.state = 'OPEN';
      log('WARN', 'Circuit breaker opened due to API failures', { 
        failures: syncState.circuitBreaker.failures 
      });
    }
    
    throw err;
  } finally {
    syncState.activeRequests--;
  }
}

// Initialize the database
async function initializeDatabase() {
  try {
    // Ensure data directory exists
    if (!fs.existsSync(config.dataDir)) {
      fs.mkdirSync(config.dataDir, { recursive: true });
      log('INFO', `Created data directory: ${config.dataDir}`);
    }
    
    // Ensure cache directory exists
    if (!fs.existsSync(config.cacheDir)) {
      fs.mkdirSync(config.cacheDir, { recursive: true });
      log('INFO', `Created cache directory: ${config.cacheDir}`);
    }
    
    // Connect to SQLite database
    const dbPath = path.join(config.dataDir, 'notion-metadata.db');
    db = await open({
      filename: dbPath,
      driver: SQLite3.Database
    });
    
    // Enable WAL mode for better performance and concurrency
    await db.exec('PRAGMA journal_mode = WAL;');
    
    // Optimize for M3 Max
    await db.exec('PRAGMA synchronous = NORMAL;');
    await db.exec('PRAGMA temp_store = MEMORY;');
    await db.exec('PRAGMA mmap_size = 268435456;'); // 256MB memory mapping
    
    // Create tables if they don't exist
    for (const [name, schema] of Object.entries(schemas)) {
      await db.exec(schema);
    }
    
    // Create indices for better performance
    await db.exec('CREATE INDEX IF NOT EXISTS idx_pages_parent ON pages(parent_id);');
    await db.exec('CREATE INDEX IF NOT EXISTS idx_blocks_parent ON blocks(parent_id);');
    await db.exec('CREATE INDEX IF NOT EXISTS idx_databases_parent ON databases(parent_id);');
    
    log('INFO', 'Database initialized successfully', { path: dbPath });
    
    return true;
  } catch (err) {
    log('ERROR', `Database initialization failed: ${err.message}`);
    throw err;
  }
}

// Initialize Notion API client
async function initializeNotionClient() {
  try {
    let apiToken = process.env.NOTION_API_TOKEN;
    
    // Try to load from credentials file if not in environment
    if (!apiToken && fs.existsSync(config.credentialsPath)) {
      apiToken = fs.readFileSync(config.credentialsPath, 'utf8').trim();
      log('INFO', 'Loaded Notion API token from credential file');
    }
    
    if (!apiToken) {
      log('WARN', 'No Notion API token provided, sync will be disabled');
      return false;
    }
    
    // Create Notion client
    notionClient = new Client({
      auth: apiToken,
      timeoutMs: 60000, // 60 second timeout
      notionVersion: '2022-06-28' // Use the latest stable API version
    });
    
    // Verify API token
    try {
      const user = await callNotionApi('users.me');
      log('INFO', 'Notion API client initialized successfully', { 
        user: user.name, 
        userId: user.id 
      });
      return true;
    } catch (err) {
      log('ERROR', `Notion API token validation failed: ${err.message}`);
      return false;
    }
  } catch (err) {
    log('ERROR', `Notion API client initialization failed: ${err.message}`);
    return false;
  }
}

// Start Unix socket server
function startSocketServer() {
  return new Promise((resolve, reject) => {
    try {
      const socketPath = path.join(config.socketDir, `${config.socketName}.sock`);
      
      // Remove existing socket file if it exists
      if (fs.existsSync(socketPath)) {
        fs.unlinkSync(socketPath);
      }
      
      // Create server
      server = net.createServer((socket) => {
        const clientId = uuidv4();
        log('INFO', `Client connected: ${clientId}`);
        
        syncState.activeClients.add(clientId);
        
        let buffer = '';
        
        socket.on('data', (data) => {
          buffer += data.toString();
          
          while (buffer.includes('\n')) {
            const messages = buffer.split('\n');
            buffer = messages.pop(); // Keep incomplete message in buffer
            
            for (const message of messages) {
              if (message.trim()) {
                handleClientMessage(clientId, socket, message);
              }
            }
          }
        });
        
        socket.on('error', (err) => {
          log('ERROR', `Client ${clientId} error: ${err.message}`);
          syncState.activeClients.delete(clientId);
          socket.end();
        });
        
        socket.on('close', () => {
          log('INFO', `Client disconnected: ${clientId}`);
          syncState.activeClients.delete(clientId);
        });
        
        // Send welcome message
        sendToClient(socket, {
          type: 'welcome',
          clientId,
          notionSyncEnabled: notionClient !== null,
          timestamp: Date.now()
        });
      });
      
      // Handle server errors
      server.on('error', (err) => {
        log('ERROR', `Socket server error: ${err.message}`);
        reject(err);
      });
      
      // Start listening
      server.listen(socketPath, () => {
        log('INFO', `Socket server listening at ${socketPath}`);
        resolve(true);
      });
      
      // Set socket permissions
      fs.chmodSync(socketPath, 0o777);
    } catch (err) {
      log('ERROR', `Failed to start socket server: ${err.message}`);
      reject(err);
    }
  });
}

// Handle a message from a client
async function handleClientMessage(clientId, socket, messageData) {
  try {
    const message = JSON.parse(messageData);
    log('DEBUG', `Received message from client ${clientId}`, { type: message.type });
    
    // Add response ID if needed
    const responseId = message.id || uuidv4();
    
    let response;
    
    // Handle different message types
    switch (message.type) {
      case 'ping':
        response = { 
          type: 'pong', 
          timestamp: Date.now() 
        };
        break;
        
      case 'status':
        response = {
          type: 'status',
          enabled: notionClient !== null,
          activeSync: syncState.isSyncActive,
          lastSync: syncState.lastSync,
          activeRequests: syncState.activeRequests,
          circuitBreakerState: syncState.circuitBreaker.state,
          timestamp: Date.now()
        };
        break;
        
      case 'database_list':
        response = await handleDatabaseListRequest();
        break;
        
      case 'database_query':
        if (!message.databaseId) {
          throw new Error('Missing databaseId parameter');
        }
        response = await handleDatabaseQueryRequest(message.databaseId, message.query || {});
        break;
        
      case 'page_get':
        if (!message.pageId) {
          throw new Error('Missing pageId parameter');
        }
        response = await handlePageGetRequest(message.pageId);
        break;
        
      case 'page_create':
        if (!message.parentId || !message.properties) {
          throw new Error('Missing required parameters for page creation');
        }
        response = await handlePageCreateRequest(message.parentId, message.properties, message.children);
        break;
        
      case 'page_update':
        if (!message.pageId || !message.properties) {
          throw new Error('Missing required parameters for page update');
        }
        response = await handlePageUpdateRequest(message.pageId, message.properties);
        break;
        
      case 'block_children':
        if (!message.blockId) {
          throw new Error('Missing blockId parameter');
        }
        response = await handleBlockChildrenRequest(message.blockId);
        break;
        
      case 'block_append':
        if (!message.blockId || !message.children) {
          throw new Error('Missing required parameters for block append');
        }
        response = await handleBlockAppendRequest(message.blockId, message.children);
        break;
        
      case 'sync_now':
        // Trigger immediate sync
        if (!syncState.isSyncActive) {
          syncData().catch(err => {
            log('ERROR', `Sync error: ${err.message}`);
          });
        }
        response = { 
          type: 'sync_triggered',
          alreadyActive: syncState.isSyncActive, 
          timestamp: Date.now() 
        };
        break;
        
      case 'heartbeat':
        // Respond to heartbeat
        response = { 
          type: 'heartbeat_response', 
          timestamp: Date.now() 
        };
        break;
        
      default:
        log('WARN', `Unknown message type from client ${clientId}: ${message.type}`);
        response = { 
          type: 'error', 
          error: `Unknown message type: ${message.type}`,
          timestamp: Date.now() 
        };
    }
    
    // Send response
    sendToClient(socket, {
      ...response,
      id: responseId
    });
  } catch (err) {
    log('ERROR', `Error handling message from client ${clientId}: ${err.message}`);
    sendToClient(socket, {
      type: 'error',
      id: messageData.id || null,
      error: err.message,
      timestamp: Date.now()
    });
  }
}

// Handle database list request
async function handleDatabaseListRequest() {
  try {
    // Check cache first
    const cacheFile = path.join(config.cacheDir, 'database_list.json');
    const now = Date.now();
    
    if (config.enableCache && fs.existsSync(cacheFile)) {
      const cacheData = JSON.parse(fs.readFileSync(cacheFile, 'utf8'));
      
      // Use cache if it's still valid
      if (now - cacheData.timestamp < config.cacheExpiryTime) {
        return {
          type: 'database_list',
          databases: cacheData.databases,
          fromCache: true,
          timestamp: now
        };
      }
    }
    
    // Check if API is available
    if (!notionClient) {
      throw new Error('Notion API not available');
    }
    
    // Get databases from API
    const response = await callNotionApi('search', {
      filter: {
        property: 'object',
        value: 'database'
      }
    });
    
    const databases = response.results.map(db => ({
      id: db.id,
      title: db.title.map(t => t.plain_text).join(''),
      createdTime: db.created_time,
      lastEditedTime: db.last_edited_time,
      url: db.url
    }));
    
    // Save to cache
    if (config.enableCache) {
      fs.writeFileSync(cacheFile, JSON.stringify({
        databases,
        timestamp: now
      }, null, 2));
    }
    
    return {
      type: 'database_list',
      databases,
      timestamp: now
    };
  } catch (err) {
    log('ERROR', `Database list error: ${err.message}`);
    throw err;
  }
}

// Handle database query request
async function handleDatabaseQueryRequest(databaseId, queryParams = {}) {
  try {
    // Generate cache key from database ID and query parameters
    const cacheKey = generateETag({ databaseId, queryParams });
    const cacheFile = path.join(config.cacheDir, `db_query_${cacheKey}.json`);
    const now = Date.now();
    
    // Check cache first
    if (config.enableCache && fs.existsSync(cacheFile)) {
      const cacheData = JSON.parse(fs.readFileSync(cacheFile, 'utf8'));
      
      // Use cache if it's still valid
      if (now - cacheData.timestamp < config.cacheExpiryTime) {
        return {
          type: 'database_query_result',
          databaseId,
          pages: cacheData.pages,
          fromCache: true,
          timestamp: now
        };
      }
    }
    
    // Check if API is available
    if (!notionClient) {
      throw new Error('Notion API not available');
    }
    
    // Query database from API
    const response = await callNotionApi('databases.query', {
      database_id: databaseId,
      ...queryParams
    });
    
    // Process page results
    const pages = response.results.map(page => {
      // Extract properties
      const properties = {};
      for (const [key, value] of Object.entries(page.properties)) {
        properties[key] = processNotionProperty(value);
      }
      
      return {
        id: page.id,
        properties,
        createdTime: page.created_time,
        lastEditedTime: page.last_edited_time,
        url: page.url
      };
    });
    
    // Save to cache
    if (config.enableCache) {
      fs.writeFileSync(cacheFile, JSON.stringify({
        pages,
        timestamp: now
      }, null, 2));
    }
    
    // Store in database
    try {
      await db.run(
        'INSERT OR REPLACE INTO metadata (key, value, updated_at) VALUES (?, ?, ?)',
        [`database_query_${databaseId}`, JSON.stringify({ pages }), now]
      );
    } catch (dbErr) {
      log('WARN', `Failed to save database query to local DB: ${dbErr.message}`);
    }
    
    return {
      type: 'database_query_result',
      databaseId,
      pages,
      timestamp: now
    };
  } catch (err) {
    log('ERROR', `Database query error for ${databaseId}: ${err.message}`);
    throw err;
  }
}

// Handle page get request
async function handlePageGetRequest(pageId) {
  try {
    // Generate cache key
    const cacheKey = `page_${pageId}`;
    const cacheFile = path.join(config.cacheDir, `${cacheKey}.json`);
    const now = Date.now();
    
    // Check cache first
    if (config.enableCache && fs.existsSync(cacheFile)) {
      const cacheData = JSON.parse(fs.readFileSync(cacheFile, 'utf8'));
      
      // Use cache if it's still valid
      if (now - cacheData.timestamp < config.cacheExpiryTime) {
        return {
          type: 'page',
          pageId,
          page: cacheData.page,
          fromCache: true,
          timestamp: now
        };
      }
    }
    
    // Check if API is available
    if (!notionClient) {
      throw new Error('Notion API not available');
    }
    
    // Get page from API
    const page = await callNotionApi('pages.retrieve', {
      page_id: pageId
    });
    
    // Get page content (blocks)
    const blocks = await callNotionApi('blocks.children.list', {
      block_id: pageId
    });
    
    // Process properties
    const properties = {};
    for (const [key, value] of Object.entries(page.properties)) {
      properties[key] = processNotionProperty(value);
    }
    
    // Process blocks
    const content = blocks.results.map(processNotionBlock);
    
    const pageData = {
      id: page.id,
      properties,
      content,
      createdTime: page.created_time,
      lastEditedTime: page.last_edited_time,
      url: page.url
    };
    
    // Save to cache
    if (config.enableCache) {
      fs.writeFileSync(cacheFile, JSON.stringify({
        page: pageData,
        timestamp: now
      }, null, 2));
    }
    
    // Store in database
    try {
      const title = properties.title || properties.Name || '';
      await db.run(
        'INSERT OR REPLACE INTO pages (id, title, content, json_data, last_edited_time, created_time, updated_at, etag) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        [pageId, title, JSON.stringify(content), JSON.stringify(pageData), page.last_edited_time, page.created_time, now, generateETag(pageData)]
      );
    } catch (dbErr) {
      log('WARN', `Failed to save page to local DB: ${dbErr.message}`);
    }
    
    return {
      type: 'page',
      pageId,
      page: pageData,
      timestamp: now
    };
  } catch (err) {
    log('ERROR', `Page get error for ${pageId}: ${err.message}`);
    throw err;
  }
}

// Handle page create request
async function handlePageCreateRequest(parentId, properties, children = []) {
  try {
    // Check if API is available
    if (!notionClient) {
      throw new Error('Notion API not available');
    }
    
    // Convert properties to Notion format
    const notionProperties = {};
    for (const [key, value] of Object.entries(properties)) {
      notionProperties[key] = convertToNotionProperty(value);
    }
    
    // Create page
    const response = await callNotionApi('pages.create', {
      parent: { page_id: parentId },
      properties: notionProperties,
      children: children.map(convertToNotionBlock)
    });
    
    // Process the response
    const result = {
      id: response.id,
      url: response.url,
      createdTime: response.created_time,
      lastEditedTime: response.last_edited_time
    };
    
    // Log to sync log
    await db.run(
      'INSERT INTO sync_log (timestamp, operation, object_type, object_id, status) VALUES (?, ?, ?, ?, ?)',
      [Date.now(), 'create', 'page', response.id, 'success']
    );
    
    return {
      type: 'page_created',
      parentId,
      page: result,
      timestamp: Date.now()
    };
  } catch (err) {
    log('ERROR', `Page create error: ${err.message}`);
    
    // Log to sync log
    await db.run(
      'INSERT INTO sync_log (timestamp, operation, object_type, object_id, status, error) VALUES (?, ?, ?, ?, ?, ?)',
      [Date.now(), 'create', 'page', parentId, 'error', err.message]
    );
    
    throw err;
  }
}

// Handle page update request
async function handlePageUpdateRequest(pageId, properties) {
  try {
    // Check if API is available
    if (!notionClient) {
      throw new Error('Notion API not available');
    }
    
    // Convert properties to Notion format
    const notionProperties = {};
    for (const [key, value] of Object.entries(properties)) {
      notionProperties[key] = convertToNotionProperty(value);
    }
    
    // Update page
    const response = await callNotionApi('pages.update', {
      page_id: pageId,
      properties: notionProperties
    });
    
    // Process the response
    const result = {
      id: response.id,
      url: response.url,
      lastEditedTime: response.last_edited_time
    };
    
    // Invalidate cache
    const cacheFile = path.join(config.cacheDir, `page_${pageId}.json`);
    if (fs.existsSync(cacheFile)) {
      fs.unlinkSync(cacheFile);
    }
    
    // Log to sync log
    await db.run(
      'INSERT INTO sync_log (timestamp, operation, object_type, object_id, status) VALUES (?, ?, ?, ?, ?)',
      [Date.now(), 'update', 'page', pageId, 'success']
    );
    
    return {
      type: 'page_updated',
      pageId,
      page: result,
      timestamp: Date.now()
    };
  } catch (err) {
    log('ERROR', `Page update error for ${pageId}: ${err.message}`);
    
    // Log to sync log
    await db.run(
      'INSERT INTO sync_log (timestamp, operation, object_type, object_id, status, error) VALUES (?, ?, ?, ?, ?, ?)',
      [Date.now(), 'update', 'page', pageId, 'error', err.message]
    );
    
    throw err;
  }
}

// Handle block children request
async function handleBlockChildrenRequest(blockId) {
  try {
    // Generate cache key
    const cacheKey = `block_children_${blockId}`;
    const cacheFile = path.join(config.cacheDir, `${cacheKey}.json`);
    const now = Date.now();
    
    // Check cache first
    if (config.enableCache && fs.existsSync(cacheFile)) {
      const cacheData = JSON.parse(fs.readFileSync(cacheFile, 'utf8'));
      
      // Use cache if it's still valid
      if (now - cacheData.timestamp < config.cacheExpiryTime) {
        return {
          type: 'block_children',
          blockId,
          children: cacheData.children,
          fromCache: true,
          timestamp: now
        };
      }
    }
    
    // Check if API is available
    if (!notionClient) {
      throw new Error('Notion API not available');
    }
    
    // Get block children from API
    const response = await callNotionApi('blocks.children.list', {
      block_id: blockId
    });
    
    // Process blocks
    const children = response.results.map(processNotionBlock);
    
    // Save to cache
    if (config.enableCache) {
      fs.writeFileSync(cacheFile, JSON.stringify({
        children,
        timestamp: now
      }, null, 2));
    }
    
    return {
      type: 'block_children',
      blockId,
      children,
      timestamp: now
    };
  } catch (err) {
    log('ERROR', `Block children error for ${blockId}: ${err.message}`);
    throw err;
  }
}

// Handle block append request
async function handleBlockAppendRequest(blockId, children) {
  try {
    // Check if API is available
    if (!notionClient) {
      throw new Error('Notion API not available');
    }
    
    // Convert children to Notion format
    const notionChildren = children.map(convertToNotionBlock);
    
    // Append blocks
    const response = await callNotionApi('blocks.children.append', {
      block_id: blockId,
      children: notionChildren
    });
    
    // Process the response
    const result = {
      blockId,
      children: response.results.map(processNotionBlock)
    };
    
    // Invalidate cache
    const cacheFile = path.join(config.cacheDir, `block_children_${blockId}.json`);
    if (fs.existsSync(cacheFile)) {
      fs.unlinkSync(cacheFile);
    }
    
    // Log to sync log
    await db.run(
      'INSERT INTO sync_log (timestamp, operation, object_type, object_id, status) VALUES (?, ?, ?, ?, ?)',
      [Date.now(), 'append', 'block', blockId, 'success']
    );
    
    return {
      type: 'blocks_appended',
      blockId,
      result,
      timestamp: Date.now()
    };
  } catch (err) {
    log('ERROR', `Block append error for ${blockId}: ${err.message}`);
    
    // Log to sync log
    await db.run(
      'INSERT INTO sync_log (timestamp, operation, object_type, object_id, status, error) VALUES (?, ?, ?, ?, ?, ?)',
      [Date.now(), 'append', 'block', blockId, 'error', err.message]
    );
    
    throw err;
  }
}

// Process Notion property value
function processNotionProperty(property) {
  if (!property) return null;
  
  const type = property.type;
  
  switch (type) {
    case 'title':
    case 'rich_text':
      return property[type].map(t => t.plain_text).join('');
      
    case 'number':
      return property.number;
      
    case 'select':
      return property.select ? property.select.name : null;
      
    case 'multi_select':
      return property.multi_select ? property.multi_select.map(item => item.name) : [];
      
    case 'date':
      return property.date ? {
        start: property.date.start,
        end: property.date.end
      } : null;
      
    case 'checkbox':
      return property.checkbox;
      
    case 'url':
      return property.url;
      
    case 'email':
      return property.email;
      
    case 'phone_number':
      return property.phone_number;
      
    case 'files':
      return property.files.map(file => ({
        name: file.name,
        url: file.type === 'external' ? file.external.url : file.file.url
      }));
      
    case 'relation':
      return property.relation.map(rel => rel.id);
      
    case 'people':
      return property.people.map(person => ({
        id: person.id,
        name: person.name,
        avatar_url: person.avatar_url
      }));
      
    case 'formula':
      return property.formula.type === 'string' ? property.formula.string :
             property.formula.type === 'number' ? property.formula.number :
             property.formula.type === 'boolean' ? property.formula.boolean :
             property.formula.type === 'date' ? property.formula.date : null;
      
    default:
      return null;
  }
}

// Process Notion block
function processNotionBlock(block) {
  if (!block) return null;
  
  const type = block.type;
  
  // Common block data
  const result = {
    id: block.id,
    type: type,
    hasChildren: block.has_children
  };
  
  // Process specific block type
  switch (type) {
    case 'paragraph':
      result.content = block.paragraph.rich_text.map(t => t.plain_text).join('');
      break;
      
    case 'heading_1':
    case 'heading_2':
    case 'heading_3':
      result.content = block[type].rich_text.map(t => t.plain_text).join('');
      break;
      
    case 'bulleted_list_item':
    case 'numbered_list_item':
      result.content = block[type].rich_text.map(t => t.plain_text).join('');
      break;
      
    case 'to_do':
      result.content = block.to_do.rich_text.map(t => t.plain_text).join('');
      result.checked = block.to_do.checked;
      break;
      
    case 'toggle':
      result.content = block.toggle.rich_text.map(t => t.plain_text).join('');
      break;
      
    case 'code':
      result.content = block.code.rich_text.map(t => t.plain_text).join('');
      result.language = block.code.language;
      break;
      
    case 'image':
      result.url = block.image.type === 'external' ? 
                   block.image.external.url : 
                   block.image.file.url;
      break;
      
    case 'video':
      result.url = block.video.type === 'external' ? 
                   block.video.external.url : 
                   block.video.file.url;
      break;
      
    case 'file':
      result.url = block.file.type === 'external' ? 
                   block.file.external.url : 
                   block.file.file.url;
      result.name = block.file.caption.map(t => t.plain_text).join('');
      break;
      
    case 'divider':
    case 'equation':
    case 'table':
    case 'column_list':
    case 'table_of_contents':
      // These blocks don't have text content
      break;
      
    default:
      // For other block types, store the raw JSON
      result.raw = block[type];
  }
  
  return result;
}

// Convert value to Notion property format
function convertToNotionProperty(value) {
  if (value === null || value === undefined) {
    return null;
  }
  
  if (typeof value === 'string') {
    // Assume it's a title or rich_text property
    return {
      rich_text: [{
        type: 'text',
        text: { content: value }
      }]
    };
  }
  
  if (typeof value === 'number') {
    return { number: value };
  }
  
  if (typeof value === 'boolean') {
    return { checkbox: value };
  }
  
  if (Array.isArray(value)) {
    // Assume it's a multi_select property
    return {
      multi_select: value.map(item => ({ name: item }))
    };
  }
  
  if (typeof value === 'object') {
    if (value.type) {
      // Object already has a type, assuming it's already in Notion format
      return value;
    }
    
    if (value.url) {
      return { url: value.url };
    }
    
    if (value.email) {
      return { email: value.email };
    }
    
    if (value.start || value.end) {
      return {
        date: {
          start: value.start || null,
          end: value.end || null
        }
      };
    }
  }
  
  // Default: convert to string
  return {
    rich_text: [{
      type: 'text',
      text: { content: String(value) }
    }]
  };
}

// Convert block data to Notion block format
function convertToNotionBlock(block) {
  if (!block || !block.type) {
    throw new Error('Invalid block format');
  }
  
  const { type, content } = block;
  const result = { type };
  
  switch (type) {
    case 'paragraph':
      result.paragraph = {
        rich_text: [{
          type: 'text',
          text: { content: content || '' }
        }]
      };
      break;
      
    case 'heading_1':
    case 'heading_2':
    case 'heading_3':
      result[type] = {
        rich_text: [{
          type: 'text',
          text: { content: content || '' }
        }]
      };
      break;
      
    case 'bulleted_list_item':
    case 'numbered_list_item':
      result[type] = {
        rich_text: [{
          type: 'text',
          text: { content: content || '' }
        }]
      };
      break;
      
    case 'to_do':
      result.to_do = {
        rich_text: [{
          type: 'text',
          text: { content: content || '' }
        }],
        checked: block.checked || false
      };
      break;
      
    case 'toggle':
      result.toggle = {
        rich_text: [{
          type: 'text',
          text: { content: content || '' }
        }]
      };
      break;
      
    case 'code':
      result.code = {
        rich_text: [{
          type: 'text',
          text: { content: content || '' }
        }],
        language: block.language || 'plain text'
      };
      break;
      
    case 'divider':
      result.divider = {};
      break;
      
    default:
      // For other types, use raw data if provided
      if (block.raw) {
        result[type] = block.raw;
      } else {
        // Default to paragraph if type is not recognized
        result.type = 'paragraph';
        result.paragraph = {
          rich_text: [{
            type: 'text',
            text: { content: content || '' }
          }]
        };
      }
  }
  
  return result;
}

// Send a message to a client
function sendToClient(socket, message) {
  try {
    const messageStr = JSON.stringify(message) + '\n';
    socket.write(messageStr);
  } catch (err) {
    log('ERROR', `Failed to send message to client: ${err.message}`);
  }
}

// Broadcast a message to all clients
function broadcastToClients(message) {
  const messageStr = JSON.stringify(message) + '\n';
  
  for (const clientId of syncState.activeClients) {
    try {
      const socket = server.getConnections()[clientId];
      if (socket && socket.writable) {
        socket.write(messageStr);
      }
    } catch (err) {
      log('ERROR', `Failed to broadcast to client ${clientId}: ${err.message}`);
    }
  }
}

// Sync data between Notion and local database
async function syncData() {
  if (syncState.isSyncActive) {
    log('INFO', 'Sync already in progress, skipping');
    return;
  }
  
  syncState.isSyncActive = true;
  syncState.syncError = null;
  
  try {
    log('INFO', 'Starting data sync');
    
    // Check if API is available
    if (!notionClient) {
      throw new Error('Notion API not available');
    }
    
    // Get databases to sync
    const databases = config.enabledDatabases.length > 0 
      ? config.enabledDatabases 
      : await getEnabledDatabases();
    
    if (databases.length === 0) {
      log('INFO', 'No databases enabled for sync');
      return;
    }
    
    // Sync each database
    for (const databaseId of databases) {
      await syncDatabase(databaseId);
    }
    
    // Update last sync time
    syncState.lastSync = Date.now();
    
    log('INFO', 'Data sync completed successfully', { 
      databases: databases.length 
    });
    
    // Broadcast sync complete event
    broadcastToClients({
      type: 'sync_complete',
      timestamp: syncState.lastSync
    });
  } catch (err) {
    syncState.syncError = err.message;
    log('ERROR', `Data sync failed: ${err.message}`);
    
    // Broadcast sync error event
    broadcastToClients({
      type: 'sync_error',
      error: err.message,
      timestamp: Date.now()
    });
  } finally {
    syncState.isSyncActive = false;
  }
}

// Get enabled databases for sync
async function getEnabledDatabases() {
  try {
    // Try to get from database first
    const enabledDb = await db.get('SELECT value FROM metadata WHERE key = ?', ['enabled_databases']);
    
    if (enabledDb && enabledDb.value) {
      try {
        return JSON.parse(enabledDb.value);
      } catch {
        // Invalid JSON, ignore
      }
    }
    
    // If not in database, search for databases
    if (notionClient) {
      const response = await callNotionApi('search', {
        filter: {
          property: 'object',
          value: 'database'
        },
        page_size: 100
      });
      
      const databaseIds = response.results.map(db => db.id);
      
      // Save to database for future use
      await db.run(
        'INSERT OR REPLACE INTO metadata (key, value, updated_at) VALUES (?, ?, ?)',
        ['enabled_databases', JSON.stringify(databaseIds), Date.now()]
      );
      
      return databaseIds;
    }
    
    return [];
  } catch (err) {
    log('ERROR', `Failed to get enabled databases: ${err.message}`);
    return [];
  }
}

// Sync a specific database
async function syncDatabase(databaseId) {
  try {
    log('INFO', `Syncing database ${databaseId}`);
    
    // Get database metadata
    const database = await callNotionApi('databases.retrieve', {
      database_id: databaseId
    });
    
    // Save database metadata
    const title = database.title.map(t => t.plain_text).join('');
    const description = database.description.map(t => t.plain_text).join('');
    const etag = generateETag(database);
    const now = Date.now();
    
    await db.run(
      'INSERT OR REPLACE INTO databases (id, title, description, json_data, last_edited_time, created_time, updated_at, etag) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [databaseId, title, description, JSON.stringify(database), database.last_edited_time, database.created_time, now, etag]
    );
    
    // Query database for pages
    const response = await callNotionApi('databases.query', {
      database_id: databaseId,
      page_size: 100
    });
    
    // Process pages
    let processedCount = 0;
    for (const page of response.results) {
      try {
        // Check if page exists in local database
        const existingPage = await db.get('SELECT id, etag FROM pages WHERE id = ?', [page.id]);
        const pageEtag = generateETag(page);
        
        // Skip if page hasn't changed
        if (existingPage && existingPage.etag === pageEtag) {
          continue;
        }
        
        // Extract page title
        let pageTitle = '';
        for (const [key, value] of Object.entries(page.properties)) {
          if (value.type === 'title' && value.title.length > 0) {
            pageTitle = value.title.map(t => t.plain_text).join('');
            break;
          }
        }
        
        // Save page to database
        await db.run(
          'INSERT OR REPLACE INTO pages (id, parent_id, title, json_data, last_edited_time, created_time, updated_at, etag) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
          [page.id, databaseId, pageTitle, JSON.stringify(page), page.last_edited_time, page.created_time, now, pageEtag]
        );
        
        processedCount++;
      } catch (pageErr) {
        log('ERROR', `Failed to process page ${page.id}: ${pageErr.message}`);
      }
    }
    
    log('INFO', `Database sync completed for ${databaseId}`, { 
      pages: response.results.length,
      processedCount 
    });
    
    return processedCount;
  } catch (err) {
    log('ERROR', `Database sync failed for ${databaseId}: ${err.message}`);
    throw err;
  }
}

// Main sync loop
async function startSyncLoop() {
  try {
    // Initial sync
    await syncData();
    
    // Set up sync interval
    setInterval(async () => {
      try {
        await syncData();
      } catch (err) {
        log('ERROR', `Scheduled sync error: ${err.message}`);
      }
    }, config.syncInterval);
    
    log('INFO', `Sync loop started, interval: ${config.syncInterval}ms`);
  } catch (err) {
    log('ERROR', `Failed to start sync loop: ${err.message}`);
  }
}

// Clean up resources
function cleanup() {
  log('INFO', 'Cleaning up resources...');
  
  try {
    // Close socket server
    if (server) {
      server.close();
    }
    
    // Close database connection
    if (db) {
      db.close();
    }
    
    // Remove PID file
    if (fs.existsSync(config.pidFile)) {
      fs.unlinkSync(config.pidFile);
    }
    
    log('INFO', 'Cleanup completed');
  } catch (err) {
    log('ERROR', `Cleanup error: ${err.message}`);
  }
}

// Handle process termination
process.on('SIGINT', () => {
  log('INFO', 'Received SIGINT signal');
  cleanup();
  process.exit(0);
});

process.on('SIGTERM', () => {
  log('INFO', 'Received SIGTERM signal');
  cleanup();
  process.exit(0);
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  log('ERROR', `Uncaught exception: ${err.message}`, { stack: err.stack });
  cleanup();
  process.exit(1);
});

// Main function
async function main() {
  try {
    log('INFO', 'Notion sync service starting', { version: '1.0.0' });
    
    // Write PID file
    fs.writeFileSync(config.pidFile, process.pid.toString());
    
    // Initialize database
    await initializeDatabase();
    
    // Initialize Notion client
    const notionInitialized = await initializeNotionClient();
    
    if (!notionInitialized) {
      log('WARN', 'Notion API client initialization failed, running in offline mode');
    }
    
    // Start socket server
    await startSocketServer();
    
    // Start sync loop if Notion client is available
    if (notionInitialized) {
      await startSyncLoop();
    }
    
    log('INFO', 'Notion sync service started successfully', {
      pid: process.pid,
      notionEnabled: notionInitialized
    });
  } catch (err) {
    log('ERROR', `Notion sync service failed to start: ${err.message}`);
    cleanup();
    process.exit(1);
  }
}

// Start the service
main();
