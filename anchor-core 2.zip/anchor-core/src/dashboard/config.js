// Dashboard Configuration
window.dashboardConfig = {
  "webSocketUrl": "ws://localhost:8765/ws",
  "apiBaseUrl": "http://localhost:8765/api",
  "socketDir": "/Users/XPV/Desktop/anchor-core/sockets",
  "logDir": "/Users/XPV/Library/Logs/Claude",
  "port": 8765,
  "pid": 86804,
  "timestamp": "2025-05-19T15:13:35.426Z"
};
