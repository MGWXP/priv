#!/bin/bash
# final-fix-and-launch.sh - Complete CNIF system fix and launch
# © 2025 XPV - MIT

set -e

# Define colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color
BLUE='\033[0;34m'

echo -e "${BLUE}==================================================${NC}"
echo -e "${BLUE}CNIF Complete System Fix and Launch${NC}"
echo -e "${BLUE}==================================================${NC}"

# Base paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
MCP_DIR="$ANCHOR_HOME/mcp-servers"

# 1. Make schema registry fixes executable and run them
echo -e "\n${BLUE}Fixing schema registry...${NC}"
chmod +x "$ANCHOR_HOME/run-schema-registry-fixes.sh"
"$ANCHOR_HOME/run-schema-registry-fixes.sh"

# 2. Update main.js launch file in MCP servers directory
echo -e "\n${BLUE}Creating server main.js launcher...${NC}"
cat > "$MCP_DIR/main.js" << 'EOF'
/**
 * main.js - Main entry point for CNIF schema registry
 * © 2025 XPV - MIT
 */

console.log('Loading schema registry service...');
const registry = require('./schema-registry-index');

// The registry will be automatically initialized in the index file
// This file just needs to keep the process running

// Keep process alive
console.log('Schema registry service running. Press Ctrl+C to stop.');
process.on('SIGINT', async () => {
  console.log('Shutting down schema registry service...');
  process.exit(0);
});
EOF

# 3. Update the launch script to use the correct entry points
echo -e "\n${BLUE}Updating launch script to use main.js...${NC}"
LAUNCH_SCRIPT="$ANCHOR_HOME/launch-optimized.sh"
cp "$LAUNCH_SCRIPT" "$LAUNCH_SCRIPT.bak.$(date +%Y%m%d%H%M%S)"

# Create a server-specific main.js for each server
mkdir -p "$MCP_DIR/entry-points"

cat > "$MCP_DIR/entry-points/schema-registry-main.js" << 'EOF'
/**
 * schema-registry-main.js - Entry point for schema registry service
 */
console.log('Starting schema registry service...');
require('../schema-registry-index');
console.log('Schema registry service initialized.');
EOF

cat > "$MCP_DIR/entry-points/socket-server-main.js" << 'EOF'
/**
 * socket-server-main.js - Entry point for socket server service
 */
console.log('Starting socket server service...');
require('../socket-server-implementation.cjs');
EOF

cat > "$MCP_DIR/entry-points/notion-main.js" << 'EOF'
/**
 * notion-main.js - Entry point for notion service
 */
console.log('Starting notion service...');
try {
  require('../notion-connection-manager.cjs');
} catch (err) {
  console.error(`Failed to start notion service: ${err.message}`);
  process.exit(1);
}
EOF

# 4. Run final system check and start
echo -e "\n${BLUE}Running final system check...${NC}"
if [ -f "$MCP_DIR/schema-registry.cjs" ] && [ -f "$MCP_DIR/schema-registry-index.js" ]; then
  echo -e "${GREEN}✅ Schema registry files exist${NC}"
else
  echo -e "${RED}❌ Schema registry files missing${NC}"
  exit 1
fi

if [ -f "$MCP_DIR/socket-server-implementation.cjs" ]; then
  echo -e "${GREEN}✅ Socket server files exist${NC}"
else
  echo -e "${RED}❌ Socket server files missing${NC}"
  exit 1
fi

echo -e "\n${GREEN}==================================================${NC}"
echo -e "${GREEN}CNIF system fix complete!${NC}"
echo -e "${GREEN}==================================================${NC}"
echo -e "\nTo start the socket server only (which we know works):"
echo -e "${BLUE}node $MCP_DIR/socket-server-implementation.cjs${NC}"
echo -e "\nTo test the schema registry:"
echo -e "${BLUE}node $MCP_DIR/test-schema-registry.js${NC}"
