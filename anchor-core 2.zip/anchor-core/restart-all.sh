#!/bin/bash
# restart-all.sh - Restart all MCP servers
# © 2025 XPV - MIT

set -e  # Exit on error

echo "🔄 Restarting all MCP servers..."

# Define core paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
MCP_DIR="${ANCHOR_HOME}/mcp-servers"
LOG_DIR="${HOME}/Library/Logs/Claude"
SOCKET_DIR="${ANCHOR_HOME}/sockets"

# Set optimization parameters - using only valid flags
export NODE_OPTIONS="--max-old-space-size=8192"
export UV_THREADPOOL_SIZE=12
export ANCHOR_HOME="${ANCHOR_HOME}"
export MCP_DIR="${MCP_DIR}"
export SOCKET_DIR="${SOCKET_DIR}"

# Stop running servers
echo "🛑 Stopping existing servers..."
pkill -f "git-local-optimized.js" 2>/dev/null || true
pkill -f "notion-v5-wrapper.js" 2>/dev/null || true
pkill -f "anchor-manager-optimized.js" 2>/dev/null || true
sleep 2

# Clean up PID files
rm -f "${MCP_DIR}"/*.pid 2>/dev/null || true

# Create socket directory if it doesn't exist
mkdir -p "${SOCKET_DIR}"
mkdir -p "${LOG_DIR}"

# Start Git Local server
echo "🚀 Starting Git Local server..."
node "${MCP_DIR}/git-local-optimized.js" > "${LOG_DIR}/mcp-server-git-local.log" 2>&1 &
echo $! > "${MCP_DIR}/git-local.pid"

# Start Notion server
echo "🚀 Starting Notion server..."
node "${MCP_DIR}/notion-v5-wrapper.js" > "${LOG_DIR}/mcp-server-notion.log" 2>&1 &
echo $! > "${MCP_DIR}/notion.pid"

# Start Anchor Manager server
echo "🚀 Starting Anchor Manager server..."
node "${MCP_DIR}/anchor-manager-optimized.js" > "${LOG_DIR}/mcp-server-anchor-manager.log" 2>&1 &
echo $! > "${MCP_DIR}/anchor-manager.pid"

echo "✅ All servers have been restarted!"
echo "To verify, run: ${MCP_DIR}/verify-servers.sh"
