#!/bin/bash
# anchor-system-optimize.sh - Complete one-click MCP optimization for Anchor System
# Part of Anchor System MCP optimization (2025-05-18)

# Set terminal colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
RESET='\033[0m'
BOLD='\033[1m'

# Critical paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
MCP_DIR="$ANCHOR_HOME/mcp-servers"
SOCKET_DIR="$ANCHOR_HOME/sockets"
LOG_DIR="$HOME/Library/Logs/Claude"
COHERENCE_DIR="$ANCHOR_HOME/coherence_lock"
CONFIG_DIR="$HOME/Library/Application Support/Claude"
CONFIG_FILE="$CONFIG_DIR/claude_desktop_config.json"
TIMESTAMP=$(date '+%Y%m%d_%H%M%S')
LOG_FILE="$LOG_DIR/anchor-system-optimize-$TIMESTAMP.log"

# Create log directory
mkdir -p "$LOG_DIR"

# Initialize log file
echo "=== Anchor System MCP Optimization Log ===" > "$LOG_FILE"
echo "Date: $(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"
echo "System: $(uname -a)" >> "$LOG_FILE"
echo "" >> "$LOG_FILE"

# Function to log messages
log() {
  local level="$1"
  local message="$2"
  local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
  
  case "$level" in
    "INFO")
      echo -e "${GREEN}[INFO]${RESET} $message"
      ;;
    "WARN")
      echo -e "${YELLOW}[WARN]${RESET} $message"
      ;;
    "ERROR")
      echo -e "${RED}[ERROR]${RESET} $message"
      ;;
    *)
      echo -e "[${level}] $message"
      ;;
  esac
  
  echo "[$level] [$timestamp] $message" >> "$LOG_FILE"
}

# Function to make scripts executable
make_executable() {
  local script="$1"
  
  if [ -f "$script" ]; then
    chmod +x "$script"
    log "INFO" "Made $script executable"
  else
    log "ERROR" "Script not found: $script"
    return 1
  fi
}

# Function to run a script and log results
run_script() {
  local script="$1"
  local description="$2"
  
  log "INFO" "Running $description: $script"
  
  if [ -f "$script" ]; then
    if [ ! -x "$script" ]; then
      chmod +x "$script"
      log "INFO" "Made $script executable"
    fi
    
    log "INFO" "Executing $script..."
    "$script" | tee -a "$LOG_FILE"
    
    if [ ${PIPESTATUS[0]} -eq 0 ]; then
      log "INFO" "Successfully completed $description"
    else
      log "ERROR" "Failed to complete $description"
      return 1
    fi
  else
    log "ERROR" "Script not found: $script"
    return 1
  fi
}

# Main function
main() {
  echo -e "${BOLD}=== Anchor System MCP Optimization ===${RESET}"
  echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
  echo ""
  
  log "INFO" "Starting Anchor System MCP optimization"
  
  # Step 1: Create backup of current configuration
  if [ -f "$CONFIG_FILE" ]; then
    cp "$CONFIG_FILE" "$ANCHOR_HOME/backups/claude_desktop_config.json.bak.$TIMESTAMP"
    log "INFO" "Created backup of Claude Desktop configuration"
  fi
  
  # Step 2: Make all scripts executable
  log "INFO" "Making optimization scripts executable"
  make_executable "$ANCHOR_HOME/fix-socket-permissions.sh"
  make_executable "$ANCHOR_HOME/mcp-restart-all.sh"
  make_executable "$ANCHOR_HOME/mcp-dashboard.sh"
  make_executable "$MCP_DIR/enhanced-socket-server.js"
  make_executable "$MCP_DIR/notion-v5-optimized.js"
  make_executable "$MCP_DIR/git-local-optimized.js"
  make_executable "$MCP_DIR/anchor-manager-optimized.js"
  
  # Step 3: Fix socket permissions
  log "INFO" "Fixing socket directory permissions"
  run_script "$ANCHOR_HOME/fix-socket-permissions.sh" "socket permission fix"
  
  # Step 4: Update Claude Desktop configuration
  log "INFO" "Updating Claude Desktop configuration"
  
  # Create config directory if it doesn't exist
  mkdir -p "$CONFIG_DIR"
  
  # Copy new config
  cp "$ANCHOR_HOME/new_claude_config.json" "$CONFIG_FILE"
  log "INFO" "Copied new configuration to $CONFIG_FILE"
  
  # Step 5: Restart MCP servers
  log "INFO" "Restarting MCP servers"
  run_script "$ANCHOR_HOME/mcp-restart-all.sh" "MCP server restart"
  
  # Step 6: Create marker file
  log "INFO" "Creating optimization marker file"
  touch "$ANCHOR_HOME/MCP_OPTIMIZATION_COMPLETE_$TIMESTAMP.marker"
  log "INFO" "Created marker file: $ANCHOR_HOME/MCP_OPTIMIZATION_COMPLETE_$TIMESTAMP.marker"
  
  # Step 7: Launch dashboard
  log "INFO" "Optimization complete! Launching MCP dashboard"
  echo ""
  echo -e "${GREEN}✓ Anchor System MCP optimization complete!${RESET}"
  echo "Log file: $LOG_FILE"
  echo ""
  echo -e "${BOLD}Launching MCP dashboard...${RESET}"
  echo ""
  
  # Launch dashboard in a new terminal window if possible
  if command -v osascript &> /dev/null; then
    osascript -e "tell application \"Terminal\" to do script \"$ANCHOR_HOME/mcp-dashboard.sh\""
  else
    # Otherwise, just run the dashboard script directly
    exec "$ANCHOR_HOME/mcp-dashboard.sh"
  fi
}

# Run main function
main
