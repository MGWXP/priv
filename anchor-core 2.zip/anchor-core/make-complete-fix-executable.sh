chmod +x /Users/XPV/Desktop/anchor-core/run-complete-fix.sh
echo "✅ Made run-complete-fix.sh executable. Run it with:"
echo "./run-complete-fix.sh"
