#!/bin/bash
# notion-quickstart.sh
# One-step script to set up and launch the enhanced Notion integration

set -e

ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
cd "$ANCHOR_HOME"

# Colors for better output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}===== Notion Integration QuickStart =====${NC}"

# 1. Make scripts executable
echo -e "${BLUE}1. Making scripts executable...${NC}"
chmod +x make-notion-scripts-executable.sh
./make-notion-scripts-executable.sh

# 2. Setup Notion integration
echo -e "\n${BLUE}2. Setting up Notion integration...${NC}"
./setup-notion-integration.sh

# 3. Update Claude Desktop configuration
echo -e "\n${BLUE}3. Updating Claude Desktop configuration...${NC}"
./update-claude-config.sh

# 4. Start the MCP servers
echo -e "\n${BLUE}4. Starting MCP servers...${NC}"
npm run start

echo -e "\n${GREEN}===== Setup Complete =====${NC}"
echo -e "${YELLOW}You can now launch Claude Desktop and start using the Notion integration!${NC}"
echo -e "${YELLOW}See NOTION_INTEGRATION_GUIDE.md for usage examples.${NC}"

# Ask if user wants to open Claude Desktop
read -p "Do you want to open Claude Desktop now? (y/n): " OPEN_CLAUDE
if [ "$OPEN_CLAUDE" = "y" ] || [ "$OPEN_CLAUDE" = "Y" ]; then
    echo -e "${BLUE}Opening Claude Desktop...${NC}"
    open -a "Claude"
fi
