#!/bin/bash
# mcp-credential-management.sh
# Integration script for CNIF launch scripts
# © 2025 XPV - MIT License

# Set directory paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
LOG_DIR="${ANCHOR_HOME}/logs"
CREDENTIALS_MANAGER="${ANCHOR_HOME}/utils/mcp-credentials-manager.js"
UI_LAUNCHER="${ANCHOR_HOME}/launch-mcp-credentials-ui.sh"
CONFIG_UPDATER="${ANCHOR_HOME}/update-claude-config-from-mcp.sh"

# Create log directory if it doesn't exist
mkdir -p "${LOG_DIR}"

# Log function
log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "${LOG_DIR}/mcp-credential-management.log"
}

# Display menu
show_menu() {
  clear
  echo "╔════════════════════════════════════════╗"
  echo "║         MCP CREDENTIAL MANAGER         ║"
  echo "╚════════════════════════════════════════╝"
  echo
  echo "1. Launch Graphical Credentials Manager (recommended)"
  echo "2. Run Command-Line Credentials Manager"
  echo "3. Quick Update GitHub Token Only"
  echo "4. View Claude Desktop Configuration"
  echo "5. Restart Claude Desktop"
  echo "0. Exit"
  echo
  echo -n "Enter your choice [0-5]: "
}

# Launch UI
launch_ui() {
  log "Launching MCP Credentials Manager UI"
  chmod +x "${UI_LAUNCHER}"
  "${UI_LAUNCHER}"
}

# Run CLI version
run_cli() {
  log "Running MCP Credentials Manager CLI"
  chmod +x "${ANCHOR_HOME}/mcp-credentials-manager.sh"
  "${ANCHOR_HOME}/mcp-credentials-manager.sh"
}

# Quick update GitHub token
update_github_token() {
  log "Running quick GitHub token update"
  chmod +x "${CONFIG_UPDATER}"
  "${CONFIG_UPDATER}"
}

# View Claude config
view_config() {
  log "Viewing Claude Desktop config"
  CLAUDE_CONFIG_FILE="${HOME}/Library/Application Support/Claude/claude_desktop_config.json"
  
  if [ -f "${CLAUDE_CONFIG_FILE}" ]; then
    echo "Claude Desktop Configuration:"
    echo "----------------------------"
    cat "${CLAUDE_CONFIG_FILE}" | grep -v "_TOKEN" | grep -v "PASSWORD" | grep -v "API_KEY"
    echo "----------------------------"
    echo "Note: Token values have been hidden for security."
    echo
    read -p "Press Enter to continue..."
  else
    echo "❌ Claude config file not found at: ${CLAUDE_CONFIG_FILE}"
    read -p "Press Enter to continue..."
  fi
}

# Restart Claude
restart_claude() {
  log "Restarting Claude Desktop"
  echo "Restarting Claude Desktop..."
  
  # Attempt to close Claude Desktop gracefully
  pkill -x "Claude"
  
  # Wait a moment for the app to close
  sleep 2
  
  # Launch Claude Desktop
  open -a "Claude"
  
  log "Claude Desktop restarted"
  echo "✅ Claude Desktop has been restarted."
  read -p "Press Enter to continue..."
}

# Main loop
while true; do
  show_menu
  read choice
  
  case "${choice}" in
    1) launch_ui ;;
    2) run_cli ;;
    3) update_github_token ;;
    4) view_config ;;
    5) restart_claude ;;
    0) 
      log "Exiting MCP Credential Management"
      exit 0
      ;;
    *)
      echo "Invalid option. Please try again."
      sleep 1
      ;;
  esac
done

exit 0
