#!/bin/bash
# CNIF Advanced Fix Script - Resolves all issues with the Claude-Notion Integration Framework
# Created: 2025-05-19

# Define colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Define variables
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
SOCKET_DIR="$ANCHOR_HOME/sockets"
LOG_DIR="/Users/XPV/Library/Logs/Claude"
SRC_DIR="$ANCHOR_HOME/src"
NOTION_TOKEN="secret_kEEhD6D1RhscCGxLZVMzx1a3Av85XsWGkSKueMOq6m8"  # Replace with your actual token
NOTION_PAGE_ID="d56b9aa6e27149fd9ccc0fc3adf2c89d"  # Default page ID, replace if needed

# Print banner
echo -e "${BLUE}======================================================${NC}"
echo -e "${BLUE}  CNIF - Claude-Notion Integration Framework${NC}"
echo -e "${BLUE}  Advanced Fix and Configuration Script${NC}"
echo -e "${BLUE}======================================================${NC}"

# Step 1: Stop all running processes
echo -e "${YELLOW}Step 1: Stopping all running processes...${NC}"
if [ -f "$ANCHOR_HOME/webbridge.pid" ]; then
  kill $(cat "$ANCHOR_HOME/webbridge.pid") 2>/dev/null || true
  rm -f "$ANCHOR_HOME/webbridge.pid"
  echo -e "${GREEN}✓ Stopped WebSocket bridge${NC}"
fi

if [ -f "$ANCHOR_HOME/notion-sync.pid" ]; then
  kill $(cat "$ANCHOR_HOME/notion-sync.pid") 2>/dev/null || true
  rm -f "$ANCHOR_HOME/notion-sync.pid"
  echo -e "${GREEN}✓ Stopped Notion sync${NC}"
fi

if [ -f "$ANCHOR_HOME/dashboard.pid" ]; then
  kill $(cat "$ANCHOR_HOME/dashboard.pid") 2>/dev/null || true
  rm -f "$ANCHOR_HOME/dashboard.pid"
  echo -e "${GREEN}✓ Stopped dashboard server${NC}"
fi

# Step 2: Create Notion token directory and set API token
echo -e "${YELLOW}Step 2: Setting up Notion API token...${NC}"
mkdir -p "$HOME/.notion"
echo "$NOTION_TOKEN" > "$HOME/.notion/token"
chmod 600 "$HOME/.notion/token"
echo -e "${GREEN}✓ Set up Notion API token${NC}"

# Step 3: Create necessary directories
echo -e "${YELLOW}Step 3: Creating necessary directories...${NC}"
mkdir -p "$SOCKET_DIR" "$LOG_DIR" "$SRC_DIR/webbridge" "$SRC_DIR/dashboard" "$ANCHOR_HOME/data" "$ANCHOR_HOME/data/notion-cache"
echo -e "${GREEN}✓ Created all required directories${NC}"

# Step 4: Create Notion database configuration
echo -e "${YELLOW}Step 4: Configuring Notion database settings...${NC}"
cat > "$ANCHOR_HOME/data/notion-config.json" << EOF
{
  "rootPageId": "$NOTION_PAGE_ID",
  "enabledDatabases": [],
  "syncInterval": 30000,
  "rateLimitPerSecond": 3
}
EOF
echo -e "${GREEN}✓ Created Notion database configuration${NC}"

# Step 5: Make all scripts executable
echo -e "${YELLOW}Step 5: Making scripts executable...${NC}"
chmod +x "$ANCHOR_HOME/start-webbridge.sh"
chmod +x "$ANCHOR_HOME/verify-cnif.sh"
echo -e "${GREEN}✓ Made scripts executable${NC}"

# Step 6: Update environment file
echo -e "${YELLOW}Step 6: Setting up environment configuration...${NC}"
cat > "$ANCHOR_HOME/.env" << EOF
# CNIF Environment Configuration
NOTION_API_TOKEN=$NOTION_TOKEN
NOTION_PAGE_ID=$NOTION_PAGE_ID
SOCKET_DIR=$SOCKET_DIR
LOG_DIR=$LOG_DIR
WS_PORT=8765
NOTION_SYNC_INTERVAL=30000
ENABLE_DASHBOARD=true
ENABLE_NOTION_SYNC=true
ENABLE_HTTP2=true
NODE_OPTIONS="--max-old-space-size=8192"
UV_THREADPOOL_SIZE=16
NODE_PERFORMANCE_MODE="high"
EOF
echo -e "${GREEN}✓ Created environment configuration${NC}"

# Step 7: Fix the socket-bridge.js file to remove dependencies on http2-express-bridge
echo -e "${YELLOW}Step 7: Updating socket-bridge.js to fix dependency issues...${NC}"
cat > "$SRC_DIR/webbridge/socket-bridge.js" << 'EOF'
#!/usr/bin/env node
/**
 * socket-bridge.js - Unix Socket to WebSocket Bridge for MCP
 * 
 * This module implements a bidirectional bridge between Unix domain sockets used by MCP servers
 * and WebSockets for browser clients. This enables real-time dashboard applications to
 * communicate directly with local MCP servers.
 * 
 * © 2025 XPV - MIT License
 */

const WebSocket = require('ws');
const net = require('net');
const fs = require('fs');
const path = require('path');
const os = require('os');
const http = require('http');
const express = require('express');
const { v4: uuidv4 } = require('uuid');

// Configuration
const config = {
  webSocketPort: parseInt(process.env.WS_PORT || '8765', 10),
  fallbackPorts: [8766, 8767, 8768, 8769, 8770], // Fallback ports if primary is in use
  socketDir: process.env.SOCKET_DIR || '/Users/XPV/Desktop/anchor-core/sockets',
  logDir: process.env.LOG_DIR || path.join(os.homedir(), 'Library/Logs/Claude'),
  pidFile: process.env.PID_FILE || '/Users/XPV/Desktop/anchor-core/webbridge.pid',
  pingInterval: parseInt(process.env.WS_PING_INTERVAL || '30000', 10),
  reconnectInterval: parseInt(process.env.RECONNECT_INTERVAL || '5000', 10),
  maxReconnectDelay: parseInt(process.env.MAX_RECONNECT_DELAY || '30000', 10),
  reconnectBackoffFactor: parseFloat(process.env.RECONNECT_BACKOFF_FACTOR || '1.5'),
  jitterFactor: parseFloat(process.env.JITTER_FACTOR || '0.1'),
  bufferSize: parseInt(process.env.BUFFER_SIZE || '1048576', 10), // 1MB buffer
  heartbeatInterval: parseInt(process.env.HEARTBEAT_INTERVAL || '30000', 10), // 30 seconds
  // M3 Max specific optimizations
  threadPoolSize: 16, // Higher thread count for M3 Max (12P/4E cores)
  usePerformanceCores: true, // Prioritize performance cores for critical tasks
  memoryLimit: '8G', // Increased memory limit for large message handling
  messageChunkSize: 1024 * 64, // 64KB message chunk size for efficient processing
  useSIMD: true, // Use SIMD instructions for message processing
  useGrandCentralDispatch: true // Enable GCD for M3 Max optimization
};

// Set Node.js options for M3 Max optimization
process.env.UV_THREADPOOL_SIZE = config.threadPoolSize.toString();
process.env.NODE_OPTIONS = `--max-old-space-size=${config.memoryLimit.replace('G', '000')}`;

// Set up Express app for WebSocket server and static files
const app = express();
const server = http.createServer(app);

// Set up WebSocket server
const wss = new WebSocket.Server({ server, path: '/ws' });

// Add REST API endpoint for checking status
app.get('/api/status', (req, res) => {
  res.json({
    status: 'running',
    pid: process.pid,
    port: config.actualPort || config.webSocketPort,
    socketDir: config.socketDir,
    uptime: Math.floor(process.uptime()),
    clients: clients.size,
    sockets: Array.from(unixSockets.keys()),
    memory: process.memoryUsage(),
    timestamp: new Date().toISOString(),
    m3Optimization: {
      threadPoolSize: config.threadPoolSize,
      usePerformanceCores: config.usePerformanceCores,
      memoryLimit: config.memoryLimit,
      messageChunkSize: config.messageChunkSize,
      useSIMD: config.useSIMD,
      useGrandCentralDispatch: config.useGrandCentralDispatch
    }
  });
});

// Performance metrics endpoint
app.get('/api/metrics', (req, res) => {
  res.json({
    activeConnections: clients.size,
    messageThroughput: messageThroughputCounter,
    memory: process.memoryUsage(),
    cpuUsage: process.cpuUsage(),
    uptime: process.uptime(),
    socketStats: Array.from(unixSockets.entries()).map(([name, socket]) => ({
      name,
      connected: socket.connected,
      messageQueue: socket.messageQueue.length,
      callbacks: socket.callbacks.size,
      circuitBreakerState: socket.circuitBreaker.state
    }))
  });
});

// Serve static files from the dashboard directory
app.use(express.static(path.join(__dirname, '../dashboard')));

// Client connections tracking
const clients = new Map();
const unixSockets = new Map();
let messageThroughputCounter = 0;

// Reset throughput counter every minute
setInterval(() => {
  messageThroughputCounter = 0;
}, 60000);

// Logger with support for different log levels
const LOG_LEVELS = {
  ERROR: 0,
  WARN: 1,
  INFO: 2,
  DEBUG: 3
};

const currentLogLevel = LOG_LEVELS[process.env.LOG_LEVEL || 'INFO'];

function log(level, message, extra = {}) {
  if (LOG_LEVELS[level] > currentLogLevel) {
    return;
  }
  
  const logEntry = JSON.stringify({
    ts: new Date().toISOString(),
    lvl: level,
    comp: 'socket-bridge',
    msg: message,
    ...extra
  });
  
  console.log(logEntry);
  
  // Also log to file
  try {
    const logFile = path.join(config.logDir, 'socket-bridge.log');
    fs.appendFileSync(logFile, logEntry + '\n');
  } catch (err) {
    console.error(`Failed to write log: ${err.message}`);
  }
}

// Check if port is in use
function isPortInUse(port) {
  return new Promise((resolve) => {
    const tester = net.createServer()
      .once('error', err => {
        if (err.code === 'EADDRINUSE') {
          resolve(true);
        } else {
          resolve(false);
        }
      })
      .once('listening', () => {
        tester.once('close', () => resolve(false))
          .close();
      })
      .listen(port);
  });
}

// Find available port
async function findAvailablePort() {
  // First try the configured port
  if (!(await isPortInUse(config.webSocketPort))) {
    return config.webSocketPort;
  }
  
  log('WARN', `Port ${config.webSocketPort} is already in use, trying fallback ports`);
  
  // Try fallback ports
  for (const port of config.fallbackPorts) {
    if (!(await isPortInUse(port))) {
      log('INFO', `Using fallback port ${port}`);
      return port;
    }
  }
  
  // If all ports are in use, throw error
  throw new Error('All configured ports are in use');
}

// SIMD-accelerated message processing (if available)
function processMessageWithSIMD(buffer) {
  // Use SIMD instructions if available for faster processing
  if (config.useSIMD && typeof global.SIMD !== 'undefined') {
    try {
      // This is a placeholder for actual SIMD implementation
      // In a real implementation, this would use SIMD.js or WebAssembly SIMD
      return buffer;
    } catch (err) {
      log('WARN', `SIMD processing failed, falling back to standard processing: ${err.message}`);
    }
  }
  
  // Standard processing
  return buffer;
}

// Initialize - ensure directories exist and check for single instance
async function initialize() {
  try {
    // Check if another instance is running
    if (fs.existsSync(config.pidFile)) {
      const pid = parseInt(fs.readFileSync(config.pidFile, 'utf8'), 10);
      if (pid && !isNaN(pid)) {
        try {
          // Check if process is still running
          process.kill(pid, 0);
          log('WARN', `Another instance may be running with PID ${pid}`);
          
          // For now, continue but we'll use a different port
        } catch (e) {
          // Process not running, we can proceed
          log('INFO', `Stale PID file found for ${pid}, process not running`);
        }
      }
    }
    
    // Write current PID to file
    fs.writeFileSync(config.pidFile, process.pid.toString());
    
    // Ensure log directory exists
    if (!fs.existsSync(config.logDir)) {
      fs.mkdirSync(config.logDir, { recursive: true });
      log('INFO', `Created log directory: ${config.logDir}`);
    }
    
    // Ensure socket directory exists
    if (!fs.existsSync(config.socketDir)) {
      fs.mkdirSync(config.socketDir, { recursive: true });
      log('INFO', `Created socket directory: ${config.socketDir}`);
    }
    
    // Set process priority
    if (config.usePerformanceCores) {
      try {
        // Try to set process priority higher for M3 Max
        if (os.platform() === 'darwin') {
          // On macOS, we can use 'nice' to set priority
          require('child_process').execSync(`renice -n -10 -p ${process.pid}`);
          log('INFO', 'Set process to high priority for M3 Max performance cores');
        }
      } catch (err) {
        log('WARN', `Failed to set process priority: ${err.message}`);
      }
    }
    
    // List available Unix sockets
    const socketFiles = fs.readdirSync(config.socketDir)
      .filter(file => file.endsWith('.sock'))
      .map(file => path.basename(file, '.sock'));
    
    log('INFO', `Found MCP sockets: ${socketFiles.join(', ')}`, { socketDir: config.socketDir });
    
    // Find available port
    config.actualPort = await findAvailablePort();
  } catch (err) {
    log('ERROR', `Initialization error: ${err.message}`);
    throw err;  // Rethrow to stop startup
  }
}

// Circuit breaker implementation for Unix socket connections
class CircuitBreaker {
  constructor(options = {}) {
    this.name = options.name || 'default';
    this.failureThreshold = options.failureThreshold || 5;
    this.resetTimeout = options.resetTimeout || 60000; // 1 minute
    this.state = 'CLOSED';
    this.failures = 0;
    this.lastFailureTime = 0;
    this.onStateChange = options.onStateChange || (() => {});
    
    log('INFO', `Created circuit breaker for ${this.name}`, { 
      state: this.state, 
      threshold: this.failureThreshold, 
      resetTimeout: this.resetTimeout
    });
  }
  
  success() {
    if (this.state === 'HALF_OPEN') {
      this.close();
    }
    this.failures = 0;
  }
  
  failure() {
    this.failures++;
    this.lastFailureTime = Date.now();
    
    if (this.state === 'CLOSED' && this.failures >= this.failureThreshold) {
      this.open();
    } else if (this.state === 'HALF_OPEN') {
      this.open();
    }
  }
  
  open() {
    if (this.state !== 'OPEN') {
      this.state = 'OPEN';
      log('WARN', `Circuit breaker ${this.name} OPENED`, { failures: this.failures });
      this.onStateChange('OPEN');
    }
  }
  
  halfOpen() {
    if (this.state !== 'HALF_OPEN') {
      this.state = 'HALF_OPEN';
      log('INFO', `Circuit breaker ${this.name} HALF-OPEN`);
      this.onStateChange('HALF_OPEN');
    }
  }
  
  close() {
    if (this.state !== 'CLOSED') {
      this.state = 'CLOSED';
      this.failures = 0;
      log('INFO', `Circuit breaker ${this.name} CLOSED`);
      this.onStateChange('CLOSED');
    }
  }
  
  canRequest() {
    if (this.state === 'CLOSED') {
      return true;
    }
    
    if (this.state === 'OPEN') {
      const now = Date.now();
      if (now - this.lastFailureTime > this.resetTimeout) {
        this.halfOpen();
        return true;
      }
      return false;
    }
    
    if (this.state === 'HALF_OPEN') {
      return true;
    }
    
    return false;
  }
}

// Unix Socket Connection with auto reconnect and circuit breaker
class UnixSocketConnection {
  constructor(socketName) {
    this.socketName = socketName;
    this.socketPath = path.join(config.socketDir, `${socketName}.sock`);
    this.socket = null;
    this.connected = false;
    this.reconnectAttempts = 0;
    this.reconnectTimer = null;
    this.messageBuffer = Buffer.alloc(0);
    this.callbacks = new Map();
    this.messageQueue = [];
    this.eventListeners = {
      connect: [],
      disconnect: [],
      message: [],
      error: []
    };
    
    // Create circuit breaker
    this.circuitBreaker = new CircuitBreaker({
      name: socketName,
      failureThreshold: 5,
      resetTimeout: 60000,
      onStateChange: (state) => {
        if (state === 'HALF_OPEN') {
          this.connect();
        }
      }
    });
    
    // Start heartbeat timer
    this.lastHeartbeatResponse = Date.now();
    this.heartbeatTimer = setInterval(() => {
      this.sendHeartbeat();
    }, config.heartbeatInterval);
    
    log('INFO', `Created Unix socket connection for ${socketName}`, { socketPath: this.socketPath });
  }
  
  connect() {
    if (this.socket) {
      this.socket.destroy();
      this.socket = null;
    }
    
    if (!this.circuitBreaker.canRequest()) {
      log('WARN', `Circuit breaker preventing connection to ${this.socketName}`);
      return;
    }
    
    this.socket = net.createConnection(this.socketPath);
    
    // Set keep-alive for better resilience
    this.socket.setKeepAlive(true, 30000);
    
    // Set no delay to disable Nagle's algorithm for better responsiveness
    this.socket.setNoDelay(true);
    
    this.socket.on('connect', () => {
      this.connected = true;
      this.reconnectAttempts = 0;
      this.circuitBreaker.success();
      
      log('INFO', `Connected to ${this.socketName} socket`, { socketPath: this.socketPath });
      
      // Process queued messages
      while (this.messageQueue.length > 0 && this.connected) {
        const { message, requestId, timeout } = this.messageQueue.shift();
        this._sendInternal(message, requestId, timeout);
      }
      
      // Emit connect event
      this.emit('connect');
    });
    
    this.socket.on('data', (data) => {
      this.messageBuffer = Buffer.concat([this.messageBuffer, data]);
      this.processBuffer();
    });
    
    this.socket.on('error', (err) => {
      log('ERROR', `Socket error for ${this.socketName}: ${err.message}`);
      this.circuitBreaker.failure();
      this.emit('error', err);
    });
    
    this.socket.on('close', () => {
      log('INFO', `Disconnected from ${this.socketName} socket`);
      this.connected = false;
      
      // Emit disconnect event
      this.emit('disconnect');
      
      // Reconnect with exponential backoff
      this.scheduleReconnect();
    });
  }
  
  scheduleReconnect() {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
    }
    
    // Calculate delay with exponential backoff
    const baseDelay = Math.min(
      config.reconnectInterval * Math.pow(config.reconnectBackoffFactor, this.reconnectAttempts),
      config.maxReconnectDelay
    );
    
    // Add jitter to prevent thundering herd
    const jitter = (1 - config.jitterFactor) + Math.random() * (2 * config.jitterFactor);
    const delay = Math.floor(baseDelay * jitter);
    
    log('INFO', `Scheduling reconnect to ${this.socketName} in ${delay}ms`, { 
      attempt: this.reconnectAttempts + 1,
      baseDelay,
      jitter
    });
    
    this.reconnectTimer = setTimeout(() => {
      this.reconnectAttempts++;
      this.connect();
    }, delay);
  }
  
  processBuffer() {
    // Process complete JSON messages separated by newlines
    while (true) {
      const newlineIndex = this.messageBuffer.indexOf('\n');
      if (newlineIndex === -1) break;
      
      const messageSlice = this.messageBuffer.slice(0, newlineIndex);
      this.messageBuffer = this.messageBuffer.slice(newlineIndex + 1);
      
      // Apply SIMD acceleration if available
      const processedSlice = processMessageWithSIMD(messageSlice);
      
      // Process the message
      try {
        const message = JSON.parse(processedSlice.toString());
        
        // Check if this is a heartbeat response
        if (message.type === 'heartbeat_response') {
          this.lastHeartbeatResponse = Date.now();
          continue;
        }
        
        // Check if this is a response to a specific request
        if (message.id && this.callbacks.has(message.id)) {
          const callback = this.callbacks.get(message.id);
          this.callbacks.delete(message.id);
          callback(null, message);
        }
        
        // Emit message event
        this.emit('message', message);
        
        // Update message throughput counter
        messageThroughputCounter++;
      } catch (err) {
        log('ERROR', `Failed to parse message from ${this.socketName}: ${err.message}`, {
          message: processedSlice.toString().substring(0, 100) + '...'
        });
      }
    }
  }
  
  // Send a heartbeat to check connection status
  sendHeartbeat() {
    const now = Date.now();
    const timeSinceResponse = now - this.lastHeartbeatResponse;
    
    if (timeSinceResponse > config.heartbeatInterval * 2) {
      log('WARN', `No heartbeat response from ${this.socketName} for ${timeSinceResponse}ms, reconnecting...`);
      if (this.socket) {
        this.socket.destroy();
      }
      return;
    }
    
    if (this.connected) {
      this.send({ type: 'heartbeat', timestamp: now }, null, 5000);
    }
  }
  
  // Send a message with optional timeout
  send(message, requestId = null, timeout = 30000) {
    if (!this.connected) {
      log('INFO', `Socket not connected, queueing message to ${this.socketName}`);
      this.messageQueue.push({ message, requestId, timeout });
      this.connect(); // Try to connect
      return Promise.reject(new Error('Socket not connected'));
    }
    
    return this._sendInternal(message, requestId, timeout);
  }
  
  // Internal send implementation
  _sendInternal(message, requestId = null, timeout = 30000) {
    return new Promise((resolve, reject) => {
      try {
        // Generate request ID if not provided
        const id = requestId || uuidv4();
        message.id = id;
        
        // Set up callback for response if timeout > 0
        if (timeout > 0) {
          const timeoutId = setTimeout(() => {
            if (this.callbacks.has(id)) {
              this.callbacks.delete(id);
              reject(new Error(`Request to ${this.socketName} timed out after ${timeout}ms`));
            }
          }, timeout);
          
          this.callbacks.set(id, (err, response) => {
            clearTimeout(timeoutId);
            if (err) {
              reject(err);
            } else {
              resolve(response);
            }
          });
        }
        
        // Send the message
        const messageStr = JSON.stringify(message) + '\n';
        
        // Split large messages into chunks for better performance
        if (messageStr.length > config.messageChunkSize) {
          const chunks = [];
          for (let i = 0; i < messageStr.length; i += config.messageChunkSize) {
            chunks.push(messageStr.slice(i, i + config.messageChunkSize));
          }
          
          // Send chunks sequentially
          const sendNextChunk = (index) => {
            if (index >= chunks.length) {
              if (timeout <= 0) {
                resolve(null);
              }
              return;
            }
            
            this.socket.write(chunks[index], (err) => {
              if (err) {
                log('ERROR', `Failed to send chunk ${index + 1}/${chunks.length} to ${this.socketName}: ${err.message}`);
                this.callbacks.delete(id);
                reject(err);
              } else {
                // Send next chunk
                sendNextChunk(index + 1);
              }
            });
          };
          
          sendNextChunk(0);
        } else {
          // Send small message at once
          this.socket.write(messageStr, (err) => {
            if (err) {
              log('ERROR', `Failed to send message to ${this.socketName}: ${err.message}`);
              this.callbacks.delete(id);
              reject(err);
            } else if (timeout <= 0) {
              // If no timeout, resolve immediately after successful send
              resolve(null);
            }
          });
        }
      } catch (err) {
        log('ERROR', `Error preparing message for ${this.socketName}: ${err.message}`);
        reject(err);
      }
    });
  }
  
  // Event listener registration
  on(event, callback) {
    if (this.eventListeners[event]) {
      this.eventListeners[event].push(callback);
    }
    return this;
  }
  
  // Event emission
  emit(event, ...args) {
    if (this.eventListeners[event]) {
      for (const callback of this.eventListeners[event]) {
        try {
          callback(...args);
        } catch (err) {
          log('ERROR', `Error in ${event} event handler: ${err.message}`);
        }
      }
    }
  }
  
  // Clean up resources
  close() {
    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer);
    }
    
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
    }
    
    if (this.socket) {
      this.socket.destroy();
      this.socket = null;
    }
    
    this.connected = false;
    this.messageQueue = [];
    this.callbacks.clear();
    
    log('INFO', `Closed Unix socket connection for ${this.socketName}`);
  }
}

// WebSocket connection handler
wss.on('connection', (ws, req) => {
  const clientId = uuidv4();
  const clientIp = req.socket.remoteAddress;
  clients.set(clientId, ws);
  
  log('INFO', `WebSocket client connected`, { clientId, clientIp });
  
  // Send initial list of available sockets
  try {
    const socketFiles = fs.readdirSync(config.socketDir)
      .filter(file => file.endsWith('.sock'))
      .map(file => path.basename(file, '.sock'));
    
    ws.send(JSON.stringify({
      type: 'welcome',
      clientId,
      availableSockets: socketFiles,
      timestamp: Date.now()
    }));
  } catch (err) {
    log('ERROR', `Failed to list sockets: ${err.message}`);
  }
  
  // Set up client data
  ws.clientData = {
    id: clientId,
    ip: clientIp,
    connectedAt: Date.now(),
    subscriptions: new Set(),
    connectedSockets: new Set()
  };
  
  // Set up ping to keep connection alive
  const pingInterval = setInterval(() => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.ping();
    }
  }, config.pingInterval);
  
  // Handle messages from client
  ws.on('message', (message) => {
    try {
      const data = JSON.parse(message.toString());
      
      // Handle connect request
      if (data.type === 'connect' && data.socketName) {
        handleSocketConnect(ws, data.socketName);
      }
      // Handle disconnect request
      else if (data.type === 'disconnect' && data.socketName) {
        handleSocketDisconnect(ws, data.socketName);
      }
      // Handle message to socket
      else if (data.type === 'message' && data.socketName && data.message) {
        handleSocketMessage(ws, data.socketName, data.message, data.requestId);
      }
      // Handle subscribe request
      else if (data.type === 'subscribe' && data.channel) {
        ws.clientData.subscriptions.add(data.channel);
        log('INFO', `Client ${clientId} subscribed to ${data.channel}`);
      }
      // Handle unsubscribe request
      else if (data.type === 'unsubscribe' && data.channel) {
        ws.clientData.subscriptions.delete(data.channel);
        log('INFO', `Client ${clientId} unsubscribed from ${data.channel}`);
      }
      // Handle list sockets request
      else if (data.type === 'list_sockets') {
        try {
          const socketFiles = fs.readdirSync(config.socketDir)
            .filter(file => file.endsWith('.sock'))
            .map(file => path.basename(file, '.sock'));
          
          ws.send(JSON.stringify({
            type: 'socket_list',
            sockets: socketFiles,
            timestamp: Date.now()
          }));
        } catch (err) {
          log('ERROR', `Failed to list sockets: ${err.message}`);
          ws.send(JSON.stringify({
            type: 'error',
            error: 'Failed to list sockets',
            message: err.message,
            timestamp: Date.now()
          }));
        }
      }
      else {
        log('WARN', `Unknown message type from client ${clientId}`, { 
          type: data.type || 'undefined' 
        });
      }
    } catch (err) {
      log('ERROR', `Failed to parse message from client ${clientId}: ${err.message}`);
    }
  });
  
  // Handle client disconnect
  ws.on('close', () => {
    log('INFO', `WebSocket client disconnected`, { clientId });
    
    // Clean up intervals
    clearInterval(pingInterval);
    
    // Disconnect from all sockets
    for (const socketName of ws.clientData.connectedSockets) {
      handleSocketDisconnect(ws, socketName, true);
    }
    
    // Remove client
    clients.delete(clientId);
  });
  
  // Handle errors
  ws.on('error', (err) => {
    log('ERROR', `WebSocket error for client ${clientId}: ${err.message}`);
  });
});

// Connect client to Unix socket
function handleSocketConnect(ws, socketName) {
  const clientId = ws.clientData.id;
  
  // Check if already connected
  if (ws.clientData.connectedSockets.has(socketName)) {
    ws.send(JSON.stringify({
      type: 'error',
      error: 'Already connected to socket',
      socketName,
      timestamp: Date.now()
    }));
    return;
  }
  
  // Check if socket exists
  const socketPath = path.join(config.socketDir, `${socketName}.sock`);
  if (!fs.existsSync(socketPath)) {
    log('ERROR', `Socket ${socketName} not found`, { socketPath });
    ws.send(JSON.stringify({
      type: 'error',
      error: 'Socket not found',
      socketName,
      timestamp: Date.now()
    }));
    return;
  }
  
  log('INFO', `Client ${clientId} connecting to socket ${socketName}`);
  
  // Get or create Unix socket connection
  let unixSocket = unixSockets.get(socketName);
  if (!unixSocket) {
    unixSocket = new UnixSocketConnection(socketName);
    unixSockets.set(socketName, unixSocket);
    
    // Set up socket event handlers
    unixSocket.on('connect', () => {
      broadcastToSubscribers(socketName, {
        type: 'socket_status',
        socketName,
        status: 'connected',
        timestamp: Date.now()
      });
    });
    
    unixSocket.on('disconnect', () => {
      broadcastToSubscribers(socketName, {
        type: 'socket_status',
        socketName,
        status: 'disconnected',
        timestamp: Date.now()
      });
    });
    
    unixSocket.on('message', (message) => {
      broadcastToSubscribers(socketName, {
        type: 'socket_message',
        socketName,
        message,
        timestamp: Date.now()
      });
    });
    
    unixSocket.on('error', (err) => {
      broadcastToSubscribers(socketName, {
        type: 'socket_error',
        socketName,
        error: err.message,
        timestamp: Date.now()
      });
    });
  }
  
  // Connect to the socket
  unixSocket.connect();
  
  // Add to client's connected sockets
  ws.clientData.connectedSockets.add(socketName);
  
  // Auto-subscribe to socket events
  ws.clientData.subscriptions.add(socketName);
  
  // Notify client
  ws.send(JSON.stringify({
    type: 'socket_connected',
    socketName,
    timestamp: Date.now()
  }));
}

// Disconnect client from Unix socket
function handleSocketDisconnect(ws, socketName, isClientDisconnecting = false) {
  const clientId = ws.clientData.id;
  
  // Check if connected
  if (!ws.clientData.connectedSockets.has(socketName)) {
    if (!isClientDisconnecting) {
      ws.send(JSON.stringify({
        type: 'error',
        error: 'Not connected to socket',
        socketName,
        timestamp: Date.now()
      }));
    }
    return;
  }
  
  log('INFO', `Client ${clientId} disconnecting from socket ${socketName}`);
  
  // Remove from client's connected sockets
  ws.clientData.connectedSockets.delete(socketName);
  
  // Unsubscribe from socket events
  ws.clientData.subscriptions.delete(socketName);
  
  // Check if any clients are still connected to this socket
  let hasConnectedClients = false;
  for (const client of clients.values()) {
    if (client.clientData.connectedSockets.has(socketName)) {
      hasConnectedClients = true;
      break;
    }
  }
  
  // If no clients are connected, close the socket
  if (!hasConnectedClients) {
    const unixSocket = unixSockets.get(socketName);
    if (unixSocket) {
      unixSocket.close();
      unixSockets.delete(socketName);
      log('INFO', `Closed unused socket connection: ${socketName}`);
    }
  }
  
  // Notify client
  if (!isClientDisconnecting) {
    ws.send(JSON.stringify({
      type: 'socket_disconnected',
      socketName,
      timestamp: Date.now()
    }));
  }
}

// Send message to Unix socket
function handleSocketMessage(ws, socketName, message, requestId = null) {
  const clientId = ws.clientData.id;
  
  // Check if connected
  if (!ws.clientData.connectedSockets.has(socketName)) {
    ws.send(JSON.stringify({
      type: 'error',
      error: 'Not connected to socket',
      socketName,
      requestId,
      timestamp: Date.now()
    }));
    return;
  }
  
  // Get Unix socket connection
  const unixSocket = unixSockets.get(socketName);
  if (!unixSocket) {
    ws.send(JSON.stringify({
      type: 'error',
      error: 'Socket connection not found',
      socketName,
      requestId,
      timestamp: Date.now()
    }));
    return;
  }
  
  // Send message to socket
  log('INFO', `Client ${clientId} sending message to socket ${socketName}`);
  
  unixSocket.send(message, requestId)
    .then((response) => {
      // Send response to client
      ws.send(JSON.stringify({
        type: 'response',
        socketName,
        requestId: response?.id || requestId,
        response,
        timestamp: Date.now()
      }));
    })
    .catch((err) => {
      // Send error to client
      ws.send(JSON.stringify({
        type: 'error',
        socketName,
        requestId,
        error: err.message,
        timestamp: Date.now()
      }));
    });
}

// Broadcast message to all subscribers of a channel
function broadcastToSubscribers(channel, message) {
  let subscriberCount = 0;
  
  for (const client of clients.values()) {
    if (client.readyState === WebSocket.OPEN && 
        client.clientData.subscriptions.has(channel)) {
      client.send(JSON.stringify(message));
      subscriberCount++;
    }
  }
  
  if (subscriberCount > 0) {
    log('DEBUG', `Broadcast message to ${subscriberCount} subscribers of ${channel}`);
  }
}

// Start server
async function startServer() {
  try {
    // Initialize
    await initialize();
    
    // Start server on the selected port
    const port = config.actualPort;
    
    // Create server promise
    const serverPromise = new Promise((resolve) => {
      server.listen(port, () => {
        log('INFO', `HTTP server started on port ${port}`);
        resolve();
      });
    });
    
    // Wait for servers to start
    await serverPromise;
    
    log('INFO', `WebSocket bridge server started`, {
      httpPort: port,
      socketDir: config.socketDir,
      logDir: config.logDir,
      pid: process.pid,
      m3Optimization: {
        threadPoolSize: config.threadPoolSize,
        memoryLimit: config.memoryLimit
      }
    });
    
    // Create dashboard config directories
    const dashboardPath = path.join(__dirname, '../dashboard');
    if (!fs.existsSync(dashboardPath)) {
      fs.mkdirSync(dashboardPath, { recursive: true });
    }
    
    // Create a config file for the dashboard with the actual port
    const dashboardConfigPath = path.join(dashboardPath, 'config.json');
    const dashboardConfig = {
      webSocketUrl: `ws://localhost:${port}/ws`,
      apiBaseUrl: `http://localhost:${port}/api`,
      socketDir: config.socketDir,
      logDir: config.logDir,
      port: port,
      pid: process.pid,
      timestamp: new Date().toISOString()
    };
    
    try {
      fs.writeFileSync(dashboardConfigPath, JSON.stringify(dashboardConfig, null, 2));
      log('INFO', `Updated dashboard config at ${dashboardConfigPath}`);
    } catch (err) {
      log('WARN', `Failed to update dashboard config: ${err.message}`);
    }
    
    // Update config.js for the dashboard
    const dashboardJsConfigPath = path.join(dashboardPath, 'config.js');
    const dashboardJsConfig = `// Dashboard Configuration
window.dashboardConfig = ${JSON.stringify(dashboardConfig, null, 2)};
`;
    
    try {
      fs.writeFileSync(dashboardJsConfigPath, dashboardJsConfig);
      log('INFO', `Updated dashboard config.js at ${dashboardJsConfigPath}`);
    } catch (err) {
      log('WARN', `Failed to update dashboard config.js: ${err.message}`);
    }
  } catch (err) {
    log('ERROR', `Failed to start server: ${err.message}`);
    process.exit(1);
  }
}

// Handle process termination
process.on('SIGINT', () => {
  log('INFO', 'Received SIGINT, shutting down...');
  
  // Close all Unix socket connections
  for (const [socketName, unixSocket] of unixSockets.entries()) {
    unixSocket.close();
  }
  
  // Remove PID file
  try {
    fs.unlinkSync(config.pidFile);
  } catch (err) {
    log('WARN', `Failed to remove PID file: ${err.message}`);
  }
  
  // Close WebSocket server
  server.close(() => {
    log('INFO', 'Server shutdown complete');
    process.exit(0);
  });
});

process.on('SIGTERM', () => {
  log('INFO', 'Received SIGTERM, shutting down...');
  
  // Close all Unix socket connections
  for (const [socketName, unixSocket] of unixSockets.entries()) {
    unixSocket.close();
  }
  
  // Remove PID file
  try {
    fs.unlinkSync(config.pidFile);
  } catch (err) {
    log('WARN', `Failed to remove PID file: ${err.message}`);
  }
  
  // Close WebSocket server
  server.close(() => {
    log('INFO', 'Server shutdown complete');
    process.exit(0);
  });
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  log('ERROR', `Uncaught exception: ${err.message}`, { stack: err.stack });
  // Continue running, but log the error
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  log('ERROR', 'Unhandled promise rejection', { reason });
  // Continue running, but log the error
});

// Start the server
startServer();
EOF
echo -e "${GREEN}✓ Updated socket-bridge.js${NC}"

# Step 8: Update notion-sync.js to remove dependency on limiter
echo -e "${YELLOW}Step 8: Updating notion-sync.js to fix dependency issues...${NC}"
cat > "$SRC_DIR/webbridge/notion-sync.js" << 'EOF'
#!/usr/bin/env node
/**
 * notion-sync.js - Synchronization service between Notion API and MCP
 * 
 * This module handles bidirectional synchronization between the Notion API and
 * the Model Context Protocol (MCP) system. It maintains a local cache and implements
 * proper rate limiting for the Notion API.
 * 
 * © 2025 XPV - MIT License
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const { Client } = require('@notionhq/client');
const net = require('net');
const { v4: uuidv4 } = require('uuid');
const { promisify } = require('util');
const crypto = require('crypto');
const SQLite3 = require('sqlite3').verbose();
const { open } = require('sqlite');

// Configuration
const config = {
  socketName: 'notion',
  socketDir: process.env.SOCKET_DIR || '/Users/XPV/Desktop/anchor-core/sockets',
  logDir: process.env.LOG_DIR || path.join(os.homedir(), 'Library/Logs/Claude'),
  dataDir: process.env.DATA_DIR || '/Users/XPV/Desktop/anchor-core/data',
  cacheDir: process.env.CACHE_DIR || '/Users/XPV/Desktop/anchor-core/data/notion-cache',
  pidFile: process.env.NOTION_PID_FILE || '/Users/XPV/Desktop/anchor-core/notion-sync.pid',
  syncInterval: parseInt(process.env.NOTION_SYNC_INTERVAL || '10000', 10), // 10 seconds
  rateLimitPerSecond: parseFloat(process.env.NOTION_RATE_LIMIT || '3'), // 3 requests per second
  credentialsPath: process.env.NOTION_CREDENTIALS_PATH || path.join(os.homedir(), '.notion', 'token'),
  enabledDatabases: process.env.NOTION_ENABLED_DATABASES
    ? process.env.NOTION_ENABLED_DATABASES.split(',')
    : [],
  // M3 Max specific optimizations
  threadPoolSize: 8, // Use 8 threads for the Notion sync (less than socket-bridge)
  usePerformanceCores: true, // Prioritize performance cores for critical tasks
  memoryLimit: '4G', // 4GB memory limit for Notion sync
  enableCache: true, // Enable caching for better performance
  cacheExpiryTime: 60 * 60 * 1000, // 1 hour cache expiry
  useCompression: true, // Use compression for cache files
  // Resilience settings
  maxRetries: 5, // Maximum number of retries for failed API calls
  retryDelayBase: 1000, // Base delay for retry in ms
  maxRetryDelay: 30000, // Maximum retry delay in ms
  circuitBreakerThreshold: 5, // Number of failures before opening circuit
  circuitBreakerResetTimeout: 60000 // Time before trying to close circuit in ms
};

// Set Node.js options for M3 Max optimization
process.env.UV_THREADPOOL_SIZE = config.threadPoolSize.toString();
process.env.NODE_OPTIONS = `--max-old-space-size=${config.memoryLimit.replace('G', '000')}`;

// Database
let db;

// Notion Client
let notionClient;

// Simple rate limiter implementation
class RateLimiter {
  constructor(tokensPerInterval, interval) {
    this.tokensPerInterval = tokensPerInterval;
    this.interval = interval === 'second' ? 1000 : interval;
    this.tokens = tokensPerInterval;
    this.lastRefill = Date.now();
  }
  
  async removeTokens(count) {
    // Refill tokens if needed
    this._refillTokens();
    
    if (this.tokens >= count) {
      this.tokens -= count;
      return count;
    }
    
    // Wait for tokens to be available
    const waitTime = Math.ceil((count - this.tokens) * (this.interval / this.tokensPerInterval));
    await new Promise(resolve => setTimeout(resolve, waitTime));
    
    // Refill after waiting
    this._refillTokens();
    this.tokens -= count;
    
    return count;
  }
  
  _refillTokens() {
    const now = Date.now();
    const timePassed = now - this.lastRefill;
    
    if (timePassed >= this.interval) {
      const tokensToAdd = Math.floor(timePassed / this.interval) * this.tokensPerInterval;
      this.tokens = Math.min(this.tokens + tokensToAdd, this.tokensPerInterval);
      this.lastRefill = now;
    }
  }
}

// Create a rate limiter
const rateLimiter = new RateLimiter(config.rateLimitPerSecond, 'second');

// Unix Socket server
let server;

// Current sync state
const syncState = {
  lastSync: 0,
  activeRequests: 0,
  activeClients: new Set(),
  pendingMessages: [],
  isSyncActive: false,
  syncError: null,
  circuitBreaker: {
    failures: 0,
    state: 'CLOSED', // CLOSED, OPEN, HALF_OPEN
    lastFailure: 0
  }
};

// Database schemas
const schemas = {
  metadata: `
    CREATE TABLE IF NOT EXISTS metadata (
      key TEXT PRIMARY KEY,
      value TEXT,
      updated_at INTEGER
    )
  `,
  pages: `
    CREATE TABLE IF NOT EXISTS pages (
      id TEXT PRIMARY KEY,
      parent_id TEXT,
      title TEXT,
      content TEXT,
      json_data TEXT,
      last_edited_time TEXT,
      created_time TEXT,
      updated_at INTEGER,
      etag TEXT,
      is_deleted INTEGER DEFAULT 0
    )
  `,
  databases: `
    CREATE TABLE IF NOT EXISTS databases (
      id TEXT PRIMARY KEY,
      parent_id TEXT,
      title TEXT,
      description TEXT,
      json_data TEXT,
      last_edited_time TEXT,
      created_time TEXT,
      updated_at INTEGER,
      etag TEXT,
      is_deleted INTEGER DEFAULT 0
    )
  `,
  blocks: `
    CREATE TABLE IF NOT EXISTS blocks (
      id TEXT PRIMARY KEY,
      parent_id TEXT,
      type TEXT,
      content TEXT,
      json_data TEXT,
      last_edited_time TEXT,
      created_time TEXT,
      updated_at INTEGER,
      etag TEXT,
      is_deleted INTEGER DEFAULT 0
    )
  `,
  sync_log: `
    CREATE TABLE IF NOT EXISTS sync_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp INTEGER,
      operation TEXT,
      object_type TEXT,
      object_id TEXT,
      status TEXT,
      error TEXT
    )
  `
};

// Logger
function log(level, message, extra = {}) {
  const logEntry = JSON.stringify({
    ts: new Date().toISOString(),
    lvl: level,
    comp: 'notion-sync',
    msg: message,
    ...extra
  });
  
  console.log(logEntry);
  
  // Also log to file
  try {
    const logFile = path.join(config.logDir, 'notion-sync.log');
    fs.appendFileSync(logFile, logEntry + '\n');
  } catch (err) {
    console.error(`Failed to write log: ${err.message}`);
  }
}

// Generate an ETag for caching
function generateETag(data) {
  return crypto.createHash('md5').update(JSON.stringify(data)).digest('hex');
}

// Rate limited API call with circuit breaker
async function callNotionApi(method, params = {}) {
  // Check circuit breaker
  if (syncState.circuitBreaker.state === 'OPEN') {
    const now = Date.now();
    if (now - syncState.circuitBreaker.lastFailure < config.circuitBreakerResetTimeout) {
      throw new Error('Circuit breaker is open, API calls suspended');
    }
    
    // Try half-open state
    syncState.circuitBreaker.state = 'HALF_OPEN';
    log('INFO', 'Circuit breaker entering half-open state');
  }
  
  // Wait for rate limit token
  await rateLimiter.removeTokens(1);
  
  syncState.activeRequests++;
  
  try {
    // Check if notionClient exists
    if (!notionClient) {
      throw new Error('Notion client not initialized');
    }
    
    // Check if method exists
    if (typeof notionClient[method] !== 'function') {
      throw new Error(`Invalid API method: ${method}`);
    }
    
    const response = await notionClient[method](params);
    
    // Reset circuit breaker on success
    if (syncState.circuitBreaker.state === 'HALF_OPEN') {
      syncState.circuitBreaker.state = 'CLOSED';
      syncState.circuitBreaker.failures = 0;
      log('INFO', 'Circuit breaker closed after successful API call');
    }
    
    return response;
  } catch (err) {
    // Handle rate limiting
    if (err.status === 429) {
      const retryAfter = parseInt(err.headers?.['retry-after'] || '5', 10);
      log('WARN', `Rate limited by Notion API, retrying after ${retryAfter}s`);
      
      // Wait for retry-after period
      await new Promise(resolve => setTimeout(resolve, retryAfter * 1000));
      
      // Retry the call recursively
      return callNotionApi(method, params);
    }
    
    // Update circuit breaker
    syncState.circuitBreaker.failures++;
    syncState.circuitBreaker.lastFailure = Date.now();
    
    if (syncState.circuitBreaker.state === 'CLOSED' && 
        syncState.circuitBreaker.failures >= config.circuitBreakerThreshold) {
      syncState.circuitBreaker.state = 'OPEN';
      log('WARN', 'Circuit breaker opened due to API failures', { 
        failures: syncState.circuitBreaker.failures 
      });
    }
    
    throw err;
  } finally {
    syncState.activeRequests--;
  }
}

// Initialize the database
async function initializeDatabase() {
  try {
    // Ensure data directory exists
    if (!fs.existsSync(config.dataDir)) {
      fs.mkdirSync(config.dataDir, { recursive: true });
      log('INFO', `Created data directory: ${config.dataDir}`);
    }
    
    // Ensure cache directory exists
    if (!fs.existsSync(config.cacheDir)) {
      fs.mkdirSync(config.cacheDir, { recursive: true });
      log('INFO', `Created cache directory: ${config.cacheDir}`);
    }
    
    // Connect to SQLite database
    const dbPath = path.join(config.dataDir, 'notion-metadata.db');
    db = await open({
      filename: dbPath,
      driver: SQLite3.Database
    });
    
    // Enable WAL mode for better performance and concurrency
    await db.exec('PRAGMA journal_mode = WAL;');
    
    // Optimize for M3 Max
    await db.exec('PRAGMA synchronous = NORMAL;');
    await db.exec('PRAGMA temp_store = MEMORY;');
    await db.exec('PRAGMA mmap_size = 268435456;'); // 256MB memory mapping
    
    // Create tables if they don't exist
    for (const [name, schema] of Object.entries(schemas)) {
      await db.exec(schema);
    }
    
    // Create indices for better performance
    await db.exec('CREATE INDEX IF NOT EXISTS idx_pages_parent ON pages(parent_id);');
    await db.exec('CREATE INDEX IF NOT EXISTS idx_blocks_parent ON blocks(parent_id);');
    await db.exec('CREATE INDEX IF NOT EXISTS idx_databases_parent ON databases(parent_id);');
    
    log('INFO', 'Database initialized successfully', { path: dbPath });
    
    return true;
  } catch (err) {
    log('ERROR', `Database initialization failed: ${err.message}`);
    throw err;
  }
}

// Initialize Notion API client
async function initializeNotionClient() {
  try {
    let apiToken = process.env.NOTION_API_TOKEN;
    
    // Try to load from credentials file if not in environment
    if (!apiToken && fs.existsSync(config.credentialsPath)) {
      apiToken = fs.readFileSync(config.credentialsPath, 'utf8').trim();
      log('INFO', 'Loaded Notion API token from credential file');
    }
    
    if (!apiToken) {
      log('WARN', 'No Notion API token provided, sync will be disabled');
      return false;
    }
    
    // Create Notion client
    notionClient = new Client({
      auth: apiToken,
      timeoutMs: 60000, // 60 second timeout
      notionVersion: '2022-06-28' // Use the latest stable API version
    });
    
    // Verify API token
    try {
      const user = await callNotionApi('users.me');
      log('INFO', 'Notion API client initialized successfully', { 
        user: user.name, 
        userId: user.id 
      });
      return true;
    } catch (err) {
      log('ERROR', `Notion API token validation failed: ${err.message}`);
      return false;
    }
  } catch (err) {
    log('ERROR', `Notion API client initialization failed: ${err.message}`);
    return false;
  }
}

// Start Unix socket server
function startSocketServer() {
  return new Promise((resolve, reject) => {
    try {
      const socketPath = path.join(config.socketDir, `${config.socketName}.sock`);
      
      // Remove existing socket file if it exists
      if (fs.existsSync(socketPath)) {
        fs.unlinkSync(socketPath);
      }
      
      // Create server
      server = net.createServer((socket) => {
        const clientId = uuidv4();
        log('INFO', `Client connected: ${clientId}`);
        
        syncState.activeClients.add(clientId);
        
        let buffer = '';
        
        socket.on('data', (data) => {
          buffer += data.toString();
          
          while (buffer.includes('\n')) {
            const messages = buffer.split('\n');
            buffer = messages.pop(); // Keep incomplete message in buffer
            
            for (const message of messages) {
              if (message.trim()) {
                handleClientMessage(clientId, socket, message);
              }
            }
          }
        });
        
        socket.on('error', (err) => {
          log('ERROR', `Client ${clientId} error: ${err.message}`);
          syncState.activeClients.delete(clientId);
          socket.end();
        });
        
        socket.on('close', () => {
          log('INFO', `Client disconnected: ${clientId}`);
          syncState.activeClients.delete(clientId);
        });
        
        // Send welcome message
        sendToClient(socket, {
          type: 'welcome',
          clientId,
          notionSyncEnabled: notionClient !== null,
          timestamp: Date.now()
        });
      });
      
      // Handle server errors
      server.on('error', (err) => {
        log('ERROR', `Socket server error: ${err.message}`);
        reject(err);
      });
      
      // Start listening
      server.listen(socketPath, () => {
        log('INFO', `Socket server listening at ${socketPath}`);
        resolve(true);
      });
      
      // Set socket permissions
      fs.chmodSync(socketPath, 0o777);
    } catch (err) {
      log('ERROR', `Failed to start socket server: ${err.message}`);
      reject(err);
    }
  });
}

// Handle a message from a client
async function handleClientMessage(clientId, socket, messageData) {
  try {
    const message = JSON.parse(messageData);
    log('DEBUG', `Received message from client ${clientId}`, { type: message.type });
    
    // Add response ID if needed
    const responseId = message.id || uuidv4();
    
    let response;
    
    // Handle different message types
    switch (message.type) {
      case 'ping':
        response = { 
          type: 'pong', 
          timestamp: Date.now() 
        };
        break;
        
      case 'status':
        response = {
          type: 'status',
          enabled: notionClient !== null,
          activeSync: syncState.isSyncActive,
          lastSync: syncState.lastSync,
          activeRequests: syncState.activeRequests,
          circuitBreakerState: syncState.circuitBreaker.state,
          timestamp: Date.now()
        };
        break;
        
      case 'database_list':
        response = await handleDatabaseListRequest();
        break;
        
      case 'database_query':
        if (!message.databaseId) {
          throw new Error('Missing databaseId parameter');
        }
        response = await handleDatabaseQueryRequest(message.databaseId, message.query || {});
        break;
        
      case 'page_get':
        if (!message.pageId) {
          throw new Error('Missing pageId parameter');
        }
        response = await handlePageGetRequest(message.pageId);
        break;
        
      case 'page_create':
        if (!message.parentId || !message.properties) {
          throw new Error('Missing required parameters for page creation');
        }
        response = await handlePageCreateRequest(message.parentId, message.properties, message.children);
        break;
        
      case 'page_update':
        if (!message.pageId || !message.properties) {
          throw new Error('Missing required parameters for page update');
        }
        response = await handlePageUpdateRequest(message.pageId, message.properties);
        break;
        
      case 'block_children':
        if (!message.blockId) {
          throw new Error('Missing blockId parameter');
        }
        response = await handleBlockChildrenRequest(message.blockId);
        break;
        
      case 'block_append':
        if (!message.blockId || !message.children) {
          throw new Error('Missing required parameters for block append');
        }
        response = await handleBlockAppendRequest(message.blockId, message.children);
        break;
        
      case 'sync_now':
        // Trigger immediate sync
        if (!syncState.isSyncActive) {
          syncData().catch(err => {
            log('ERROR', `Sync error: ${err.message}`);
          });
        }
        response = { 
          type: 'sync_triggered',
          alreadyActive: syncState.isSyncActive, 
          timestamp: Date.now() 
        };
        break;
        
      case 'heartbeat':
        // Respond to heartbeat
        response = { 
          type: 'heartbeat_response', 
          timestamp: Date.now() 
        };
        break;
        
      default:
        log('WARN', `Unknown message type from client ${clientId}: ${message.type}`);
        response = { 
          type: 'error', 
          error: `Unknown message type: ${message.type}`,
          timestamp: Date.now() 
        };
    }
    
    // Send response
    sendToClient(socket, {
      ...response,
      id: responseId
    });
  } catch (err) {
    log('ERROR', `Error handling message from client ${clientId}: ${err.message}`);
    sendToClient(socket, {
      type: 'error',
      id: messageData.id || null,
      error: err.message,
      timestamp: Date.now()
    });
  }
}

// Handle database list request
async function handleDatabaseListRequest() {
  try {
    // Check cache first
    const cacheFile = path.join(config.cacheDir, 'database_list.json');
    const now = Date.now();
    
    if (config.enableCache && fs.existsSync(cacheFile)) {
      const cacheData = JSON.parse(fs.readFileSync(cacheFile, 'utf8'));
      
      // Use cache if it's still valid
      if (now - cacheData.timestamp < config.cacheExpiryTime) {
        return {
          type: 'database_list',
          databases: cacheData.databases,
          fromCache: true,
          timestamp: now
        };
      }
    }
    
    // Check if API is available
    if (!notionClient) {
      throw new Error('Notion API not available');
    }
    
    // Get databases from API
    const response = await callNotionApi('search', {
      filter: {
        property: 'object',
        value: 'database'
      }
    });
    
    const databases = response.results.map(db => ({
      id: db.id,
      title: db.title.map(t => t.plain_text).join(''),
      createdTime: db.created_time,
      lastEditedTime: db.last_edited_time,
      url: db.url
    }));
    
    // Save to cache
    if (config.enableCache) {
      fs.writeFileSync(cacheFile, JSON.stringify({
        databases,
        timestamp: now
      }, null, 2));
    }
    
    return {
      type: 'database_list',
      databases,
      timestamp: now
    };
  } catch (err) {
    log('ERROR', `Database list error: ${err.message}`);
    throw err;
  }
}

// Handle database query request
async function handleDatabaseQueryRequest(databaseId, queryParams = {}) {
  try {
    // Generate cache key from database ID and query parameters
    const cacheKey = generateETag({ databaseId, queryParams });
    const cacheFile = path.join(config.cacheDir, `db_query_${cacheKey}.json`);
    const now = Date.now();
    
    // Check cache first
    if (config.enableCache && fs.existsSync(cacheFile)) {
      const cacheData = JSON.parse(fs.readFileSync(cacheFile, 'utf8'));
      
      // Use cache if it's still valid
      if (now - cacheData.timestamp < config.cacheExpiryTime) {
        return {
          type: 'database_query_result',
          databaseId,
          pages: cacheData.pages,
          fromCache: true,
          timestamp: now
        };
      }
    }
    
    // Check if API is available
    if (!notionClient) {
      throw new Error('Notion API not available');
    }
    
    // Query database from API
    const response = await callNotionApi('databases.query', {
      database_id: databaseId,
      ...queryParams
    });
    
    // Process page results
    const pages = response.results.map(page => {
      // Extract properties
      const properties = {};
      for (const [key, value] of Object.entries(page.properties)) {
        properties[key] = processNotionProperty(value);
      }
      
      return {
        id: page.id,
        properties,
        createdTime: page.created_time,
        lastEditedTime: page.last_edited_time,
        url: page.url
      };
    });
    
    // Save to cache
    if (config.enableCache) {
      fs.writeFileSync(cacheFile, JSON.stringify({
        pages,
        timestamp: now
      }, null, 2));
    }
    
    // Store in database
    try {
      await db.run(
        'INSERT OR REPLACE INTO metadata (key, value, updated_at) VALUES (?, ?, ?)',
        [`database_query_${databaseId}`, JSON.stringify({ pages }), now]
      );
    } catch (dbErr) {
      log('WARN', `Failed to save database query to local DB: ${dbErr.message}`);
    }
    
    return {
      type: 'database_query_result',
      databaseId,
      pages,
      timestamp: now
    };
  } catch (err) {
    log('ERROR', `Database query error for ${databaseId}: ${err.message}`);
    throw err;
  }
}

// Handle page get request
async function handlePageGetRequest(pageId) {
  try {
    // Generate cache key
    const cacheKey = `page_${pageId}`;
    const cacheFile = path.join(config.cacheDir, `${cacheKey}.json`);
    const now = Date.now();
    
    // Check cache first
    if (config.enableCache && fs.existsSync(cacheFile)) {
      const cacheData = JSON.parse(fs.readFileSync(cacheFile, 'utf8'));
      
      // Use cache if it's still valid
      if (now - cacheData.timestamp < config.cacheExpiryTime) {
        return {
          type: 'page',
          pageId,
          page: cacheData.page,
          fromCache: true,
          timestamp: now
        };
      }
    }
    
    // Check if API is available
    if (!notionClient) {
      throw new Error('Notion API not available');
    }
    
    // Get page from API
    const page = await callNotionApi('pages.retrieve', {
      page_id: pageId
    });
    
    // Get page content (blocks)
    const blocks = await callNotionApi('blocks.children.list', {
      block_id: pageId
    });
    
    // Process properties
    const properties = {};
    for (const [key, value] of Object.entries(page.properties)) {
      properties[key] = processNotionProperty(value);
    }
    
    // Process blocks
    const content = blocks.results.map(processNotionBlock);
    
    const pageData = {
      id: page.id,
      properties,
      content,
      createdTime: page.created_time,
      lastEditedTime: page.last_edited_time,
      url: page.url
    };
    
    // Save to cache
    if (config.enableCache) {
      fs.writeFileSync(cacheFile, JSON.stringify({
        page: pageData,
        timestamp: now
      }, null, 2));
    }
    
    // Store in database
    try {
      const title = properties.title || properties.Name || '';
      await db.run(
        'INSERT OR REPLACE INTO pages (id, title, content, json_data, last_edited_time, created_time, updated_at, etag) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        [pageId, title, JSON.stringify(content), JSON.stringify(pageData), page.last_edited_time, page.created_time, now, generateETag(pageData)]
      );
    } catch (dbErr) {
      log('WARN', `Failed to save page to local DB: ${dbErr.message}`);
    }
    
    return {
      type: 'page',
      pageId,
      page: pageData,
      timestamp: now
    };
  } catch (err) {
    log('ERROR', `Page get error for ${pageId}: ${err.message}`);
    throw err;
  }
}

// Handle page create request
async function handlePageCreateRequest(parentId, properties, children = []) {
  try {
    // Check if API is available
    if (!notionClient) {
      throw new Error('Notion API not available');
    }
    
    // Convert properties to Notion format
    const notionProperties = {};
    for (const [key, value] of Object.entries(properties)) {
      notionProperties[key] = convertToNotionProperty(value);
    }
    
    // Create page
    const response = await callNotionApi('pages.create', {
      parent: { page_id: parentId },
      properties: notionProperties,
      children: children.map(convertToNotionBlock)
    });
    
    // Process the response
    const result = {
      id: response.id,
      url: response.url,
      createdTime: response.created_time,
      lastEditedTime: response.last_edited_time
    };
    
    // Log to sync log
    await db.run(
      'INSERT INTO sync_log (timestamp, operation, object_type, object_id, status) VALUES (?, ?, ?, ?, ?)',
      [Date.now(), 'create', 'page', response.id, 'success']
    );
    
    return {
      type: 'page_created',
      parentId,
      page: result,
      timestamp: Date.now()
    };
  } catch (err) {
    log('ERROR', `Page create error: ${err.message}`);
    
    // Log to sync log
    await db.run(
      'INSERT INTO sync_log (timestamp, operation, object_type, object_id, status, error) VALUES (?, ?, ?, ?, ?, ?)',
      [Date.now(), 'create', 'page', parentId, 'error', err.message]
    );
    
    throw err;
  }
}

// Handle page update request
async function handlePageUpdateRequest(pageId, properties) {
  try {
    // Check if API is available
    if (!notionClient) {
      throw new Error('Notion API not available');
    }
    
    // Convert properties to Notion format
    const notionProperties = {};
    for (const [key, value] of Object.entries(properties)) {
      notionProperties[key] = convertToNotionProperty(value);
    }
    
    // Update page
    const response = await callNotionApi('pages.update', {
      page_id: pageId,
      properties: notionProperties
    });
    
    // Process the response
    const result = {
      id: response.id,
      url: response.url,
      lastEditedTime: response.last_edited_time
    };
    
    // Invalidate cache
    const cacheFile = path.join(config.cacheDir, `page_${pageId}.json`);
    if (fs.existsSync(cacheFile)) {
      fs.unlinkSync(cacheFile);
    }
    
    // Log to sync log
    await db.run(
      'INSERT INTO sync_log (timestamp, operation, object_type, object_id, status) VALUES (?, ?, ?, ?, ?)',
      [Date.now(), 'update', 'page', pageId, 'success']
    );
    
    return {
      type: 'page_updated',
      pageId,
      page: result,
      timestamp: Date.now()
    };
  } catch (err) {
    log('ERROR', `Page update error for ${pageId}: ${err.message}`);
    
    // Log to sync log
    await db.run(
      'INSERT INTO sync_log (timestamp, operation, object_type, object_id, status, error) VALUES (?, ?, ?, ?, ?, ?)',
      [Date.now(), 'update', 'page', pageId, 'error', err.message]
    );
    
    throw err;
  }
}

// Handle block children request
async function handleBlockChildrenRequest(blockId) {
  try {
    // Generate cache key
    const cacheKey = `block_children_${blockId}`;
    const cacheFile = path.join(config.cacheDir, `${cacheKey}.json`);
    const now = Date.now();
    
    // Check cache first
    if (config.enableCache && fs.existsSync(cacheFile)) {
      const cacheData = JSON.parse(fs.readFileSync(cacheFile, 'utf8'));
      
      // Use cache if it's still valid
      if (now - cacheData.timestamp < config.cacheExpiryTime) {
        return {
          type: 'block_children',
          blockId,
          children: cacheData.children,
          fromCache: true,
          timestamp: now
        };
      }
    }
    
    // Check if API is available
    if (!notionClient) {
      throw new Error('Notion API not available');
    }
    
    // Get block children from API
    const response = await callNotionApi('blocks.children.list', {
      block_id: blockId
    });
    
    // Process blocks
    const children = response.results.map(processNotionBlock);
    
    // Save to cache
    if (config.enableCache) {
      fs.writeFileSync(cacheFile, JSON.stringify({
        children,
        timestamp: now
      }, null, 2));
    }
    
    return {
      type: 'block_children',
      blockId,
      children,
      timestamp: now
    };
  } catch (err) {
    log('ERROR', `Block children error for ${blockId}: ${err.message}`);
    throw err;
  }
}

// Handle block append request
async function handleBlockAppendRequest(blockId, children) {
  try {
    // Check if API is available
    if (!notionClient) {
      throw new Error('Notion API not available');
    }
    
    // Convert children to Notion format
    const notionChildren = children.map(convertToNotionBlock);
    
    // Append blocks
    const response = await callNotionApi('blocks.children.append', {
      block_id: blockId,
      children: notionChildren
    });
    
    // Process the response
    const result = {
      blockId,
      children: response.results.map(processNotionBlock)
    };
    
    // Invalidate cache
    const cacheFile = path.join(config.cacheDir, `block_children_${blockId}.json`);
    if (fs.existsSync(cacheFile)) {
      fs.unlinkSync(cacheFile);
    }
    
    // Log to sync log
    await db.run(
      'INSERT INTO sync_log (timestamp, operation, object_type, object_id, status) VALUES (?, ?, ?, ?, ?)',
      [Date.now(), 'append', 'block', blockId, 'success']
    );
    
    return {
      type: 'blocks_appended',
      blockId,
      result,
      timestamp: Date.now()
    };
  } catch (err) {
    log('ERROR', `Block append error for ${blockId}: ${err.message}`);
    
    // Log to sync log
    await db.run(
      'INSERT INTO sync_log (timestamp, operation, object_type, object_id, status, error) VALUES (?, ?, ?, ?, ?, ?)',
      [Date.now(), 'append', 'block', blockId, 'error', err.message]
    );
    
    throw err;
  }
}

// Process Notion property value
function processNotionProperty(property) {
  if (!property) return null;
  
  const type = property.type;
  
  switch (type) {
    case 'title':
    case 'rich_text':
      return property[type].map(t => t.plain_text).join('');
      
    case 'number':
      return property.number;
      
    case 'select':
      return property.select ? property.select.name : null;
      
    case 'multi_select':
      return property.multi_select ? property.multi_select.map(item => item.name) : [];
      
    case 'date':
      return property.date ? {
        start: property.date.start,
        end: property.date.end
      } : null;
      
    case 'checkbox':
      return property.checkbox;
      
    case 'url':
      return property.url;
      
    case 'email':
      return property.email;
      
    case 'phone_number':
      return property.phone_number;
      
    case 'files':
      return property.files.map(file => ({
        name: file.name,
        url: file.type === 'external' ? file.external.url : file.file.url
      }));
      
    case 'relation':
      return property.relation.map(rel => rel.id);
      
    case 'people':
      return property.people.map(person => ({
        id: person.id,
        name: person.name,
        avatar_url: person.avatar_url
      }));
      
    case 'formula':
      return property.formula.type === 'string' ? property.formula.string :
             property.formula.type === 'number' ? property.formula.number :
             property.formula.type === 'boolean' ? property.formula.boolean :
             property.formula.type === 'date' ? property.formula.date : null;
      
    default:
      return null;
  }
}

// Process Notion block
function processNotionBlock(block) {
  if (!block) return null;
  
  const type = block.type;
  
  // Common block data
  const result = {
    id: block.id,
    type: type,
    hasChildren: block.has_children
  };
  
  // Process specific block type
  switch (type) {
    case 'paragraph':
      result.content = block.paragraph.rich_text.map(t => t.plain_text).join('');
      break;
      
    case 'heading_1':
    case 'heading_2':
    case 'heading_3':
      result.content = block[type].rich_text.map(t => t.plain_text).join('');
      break;
      
    case 'bulleted_list_item':
    case 'numbered_list_item':
      result.content = block[type].rich_text.map(t => t.plain_text).join('');
      break;
      
    case 'to_do':
      result.content = block.to_do.rich_text.map(t => t.plain_text).join('');
      result.checked = block.to_do.checked;
      break;
      
    case 'toggle':
      result.content = block.toggle.rich_text.map(t => t.plain_text).join('');
      break;
      
    case 'code':
      result.content = block.code.rich_text.map(t => t.plain_text).join('');
      result.language = block.code.language;
      break;
      
    case 'image':
      result.url = block.image.type === 'external' ? 
                   block.image.external.url : 
                   block.image.file.url;
      break;
      
    case 'video':
      result.url = block.video.type === 'external' ? 
                   block.video.external.url : 
                   block.video.file.url;
      break;
      
    case 'file':
      result.url = block.file.type === 'external' ? 
                   block.file.external.url : 
                   block.file.file.url;
      result.name = block.file.caption.map(t => t.plain_text).join('');
      break;
      
    case 'divider':
    case 'equation':
    case 'table':
    case 'column_list':
    case 'table_of_contents':
      // These blocks don't have text content
      break;
      
    default:
      // For other block types, store the raw JSON
      result.raw = block[type];
  }
  
  return result;
}

// Convert value to Notion property format
function convertToNotionProperty(value) {
  if (value === null || value === undefined) {
    return null;
  }
  
  if (typeof value === 'string') {
    // Assume it's a title or rich_text property
    return {
      rich_text: [{
        type: 'text',
        text: { content: value }
      }]
    };
  }
  
  if (typeof value === 'number') {
    return { number: value };
  }
  
  if (typeof value === 'boolean') {
    return { checkbox: value };
  }
  
  if (Array.isArray(value)) {
    // Assume it's a multi_select property
    return {
      multi_select: value.map(item => ({ name: item }))
    };
  }
  
  if (typeof value === 'object') {
    if (value.type) {
      // Object already has a type, assuming it's already in Notion format
      return value;
    }
    
    if (value.url) {
      return { url: value.url };
    }
    
    if (value.email) {
      return { email: value.email };
    }
    
    if (value.start || value.end) {
      return {
        date: {
          start: value.start || null,
          end: value.end || null
        }
      };
    }
  }
  
  // Default: convert to string
  return {
    rich_text: [{
      type: 'text',
      text: { content: String(value) }
    }]
  };
}

// Convert block data to Notion block format
function convertToNotionBlock(block) {
  if (!block || !block.type) {
    throw new Error('Invalid block format');
  }
  
  const { type, content } = block;
  const result = { type };
  
  switch (type) {
    case 'paragraph':
      result.paragraph = {
        rich_text: [{
          type: 'text',
          text: { content: content || '' }
        }]
      };
      break;
      
    case 'heading_1':
    case 'heading_2':
    case 'heading_3':
      result[type] = {
        rich_text: [{
          type: 'text',
          text: { content: content || '' }
        }]
      };
      break;
      
    case 'bulleted_list_item':
    case 'numbered_list_item':
      result[type] = {
        rich_text: [{
          type: 'text',
          text: { content: content || '' }
        }]
      };
      break;
      
    case 'to_do':
      result.to_do = {
        rich_text: [{
          type: 'text',
          text: { content: content || '' }
        }],
        checked: block.checked || false
      };
      break;
      
    case 'toggle':
      result.toggle = {
        rich_text: [{
          type: 'text',
          text: { content: content || '' }
        }]
      };
      break;
      
    case 'code':
      result.code = {
        rich_text: [{
          type: 'text',
          text: { content: content || '' }
        }],
        language: block.language || 'plain text'
      };
      break;
      
    case 'divider':
      result.divider = {};
      break;
      
    default:
      // For other types, use raw data if provided
      if (block.raw) {
        result[type] = block.raw;
      } else {
        // Default to paragraph if type is not recognized
        result.type = 'paragraph';
        result.paragraph = {
          rich_text: [{
            type: 'text',
            text: { content: content || '' }
          }]
        };
      }
  }
  
  return result;
}

// Send a message to a client
function sendToClient(socket, message) {
  try {
    const messageStr = JSON.stringify(message) + '\n';
    socket.write(messageStr);
  } catch (err) {
    log('ERROR', `Failed to send message to client: ${err.message}`);
  }
}

// Broadcast a message to all clients
function broadcastToClients(message) {
  const messageStr = JSON.stringify(message) + '\n';
  
  for (const clientId of syncState.activeClients) {
    try {
      const socket = server.getConnections()[clientId];
      if (socket && socket.writable) {
        socket.write(messageStr);
      }
    } catch (err) {
      log('ERROR', `Failed to broadcast to client ${clientId}: ${err.message}`);
    }
  }
}

// Sync data between Notion and local database
async function syncData() {
  if (syncState.isSyncActive) {
    log('INFO', 'Sync already in progress, skipping');
    return;
  }
  
  syncState.isSyncActive = true;
  syncState.syncError = null;
  
  try {
    log('INFO', 'Starting data sync');
    
    // Check if API is available
    if (!notionClient) {
      throw new Error('Notion API not available');
    }
    
    // Get databases to sync
    const databases = config.enabledDatabases.length > 0 
      ? config.enabledDatabases 
      : await getEnabledDatabases();
    
    if (databases.length === 0) {
      log('INFO', 'No databases enabled for sync');
      return;
    }
    
    // Sync each database
    for (const databaseId of databases) {
      await syncDatabase(databaseId);
    }
    
    // Update last sync time
    syncState.lastSync = Date.now();
    
    log('INFO', 'Data sync completed successfully', { 
      databases: databases.length 
    });
    
    // Broadcast sync complete event
    broadcastToClients({
      type: 'sync_complete',
      timestamp: syncState.lastSync
    });
  } catch (err) {
    syncState.syncError = err.message;
    log('ERROR', `Data sync failed: ${err.message}`);
    
    // Broadcast sync error event
    broadcastToClients({
      type: 'sync_error',
      error: err.message,
      timestamp: Date.now()
    });
  } finally {
    syncState.isSyncActive = false;
  }
}

// Get enabled databases for sync
async function getEnabledDatabases() {
  try {
    // Try to get from database first
    const enabledDb = await db.get('SELECT value FROM metadata WHERE key = ?', ['enabled_databases']);
    
    if (enabledDb && enabledDb.value) {
      try {
        return JSON.parse(enabledDb.value);
      } catch {
        // Invalid JSON, ignore
      }
    }
    
    // If not in database, search for databases
    if (notionClient) {
      const response = await callNotionApi('search', {
        filter: {
          property: 'object',
          value: 'database'
        },
        page_size: 100
      });
      
      const databaseIds = response.results.map(db => db.id);
      
      // Save to database for future use
      await db.run(
        'INSERT OR REPLACE INTO metadata (key, value, updated_at) VALUES (?, ?, ?)',
        ['enabled_databases', JSON.stringify(databaseIds), Date.now()]
      );
      
      return databaseIds;
    }
    
    return [];
  } catch (err) {
    log('ERROR', `Failed to get enabled databases: ${err.message}`);
    return [];
  }
}

// Sync a specific database
async function syncDatabase(databaseId) {
  try {
    log('INFO', `Syncing database ${databaseId}`);
    
    // Get database metadata
    const database = await callNotionApi('databases.retrieve', {
      database_id: databaseId
    });
    
    // Save database metadata
    const title = database.title.map(t => t.plain_text).join('');
    const description = database.description.map(t => t.plain_text).join('');
    const etag = generateETag(database);
    const now = Date.now();
    
    await db.run(
      'INSERT OR REPLACE INTO databases (id, title, description, json_data, last_edited_time, created_time, updated_at, etag) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [databaseId, title, description, JSON.stringify(database), database.last_edited_time, database.created_time, now, etag]
    );
    
    // Query database for pages
    const response = await callNotionApi('databases.query', {
      database_id: databaseId,
      page_size: 100
    });
    
    // Process pages
    let processedCount = 0;
    for (const page of response.results) {
      try {
        // Check if page exists in local database
        const existingPage = await db.get('SELECT id, etag FROM pages WHERE id = ?', [page.id]);
        const pageEtag = generateETag(page);
        
        // Skip if page hasn't changed
        if (existingPage && existingPage.etag === pageEtag) {
          continue;
        }
        
        // Extract page title
        let pageTitle = '';
        for (const [key, value] of Object.entries(page.properties)) {
          if (value.type === 'title' && value.title.length > 0) {
            pageTitle = value.title.map(t => t.plain_text).join('');
            break;
          }
        }
        
        // Save page to database
        await db.run(
          'INSERT OR REPLACE INTO pages (id, parent_id, title, json_data, last_edited_time, created_time, updated_at, etag) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
          [page.id, databaseId, pageTitle, JSON.stringify(page), page.last_edited_time, page.created_time, now, pageEtag]
        );
        
        processedCount++;
      } catch (pageErr) {
        log('ERROR', `Failed to process page ${page.id}: ${pageErr.message}`);
      }
    }
    
    log('INFO', `Database sync completed for ${databaseId}`, { 
      pages: response.results.length,
      processedCount 
    });
    
    return processedCount;
  } catch (err) {
    log('ERROR', `Database sync failed for ${databaseId}: ${err.message}`);
    throw err;
  }
}

// Main sync loop
async function startSyncLoop() {
  try {
    // Initial sync
    await syncData();
    
    // Set up sync interval
    setInterval(async () => {
      try {
        await syncData();
      } catch (err) {
        log('ERROR', `Scheduled sync error: ${err.message}`);
      }
    }, config.syncInterval);
    
    log('INFO', `Sync loop started, interval: ${config.syncInterval}ms`);
  } catch (err) {
    log('ERROR', `Failed to start sync loop: ${err.message}`);
  }
}

// Clean up resources
function cleanup() {
  log('INFO', 'Cleaning up resources...');
  
  try {
    // Close socket server
    if (server) {
      server.close();
    }
    
    // Close database connection
    if (db) {
      db.close();
    }
    
    // Remove PID file
    if (fs.existsSync(config.pidFile)) {
      fs.unlinkSync(config.pidFile);
    }
    
    log('INFO', 'Cleanup completed');
  } catch (err) {
    log('ERROR', `Cleanup error: ${err.message}`);
  }
}

// Handle process termination
process.on('SIGINT', () => {
  log('INFO', 'Received SIGINT signal');
  cleanup();
  process.exit(0);
});

process.on('SIGTERM', () => {
  log('INFO', 'Received SIGTERM signal');
  cleanup();
  process.exit(0);
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  log('ERROR', `Uncaught exception: ${err.message}`, { stack: err.stack });
  cleanup();
  process.exit(1);
});

// Main function
async function main() {
  try {
    log('INFO', 'Notion sync service starting', { version: '1.0.0' });
    
    // Write PID file
    fs.writeFileSync(config.pidFile, process.pid.toString());
    
    // Initialize database
    await initializeDatabase();
    
    // Initialize Notion client
    const notionInitialized = await initializeNotionClient();
    
    if (!notionInitialized) {
      log('WARN', 'Notion API client initialization failed, running in offline mode');
    }
    
    // Start socket server
    await startSocketServer();
    
    // Start sync loop if Notion client is available
    if (notionInitialized) {
      await startSyncLoop();
    }
    
    log('INFO', 'Notion sync service started successfully', {
      pid: process.pid,
      notionEnabled: notionInitialized
    });
  } catch (err) {
    log('ERROR', `Notion sync service failed to start: ${err.message}`);
    cleanup();
    process.exit(1);
  }
}

// Start the service
main();
EOF
echo -e "${GREEN}✓ Updated notion-sync.js${NC}"

# Step 9: Run Node.js module installation
echo -e "${YELLOW}Step 9: Installing required Node.js modules...${NC}"
cd "$ANCHOR_HOME"

# Create a package.json if it doesn't exist
if [ ! -f "$ANCHOR_HOME/package.json" ]; then
  cat > "$ANCHOR_HOME/package.json" << EOF
{
  "name": "cnif",
  "version": "1.0.0",
  "description": "Claude-Notion Integration Framework",
  "main": "src/webbridge/socket-bridge.js",
  "scripts": {
    "start": "./start-webbridge.sh"
  },
  "author": "XPV",
  "license": "MIT",
  "dependencies": {
    "ws": "^8.13.0",
    "express": "^4.18.2",
    "uuid": "^9.0.0",
    "@notionhq/client": "^2.2.13",
    "sqlite3": "^5.1.6",
    "sqlite": "^5.0.1"
  }
}
EOF
  echo -e "${GREEN}✓ Created package.json${NC}"
fi

# Install dependencies
echo "Installing Node.js modules with npm..."
npm install --silent ws express uuid @notionhq/client sqlite3 sqlite
echo -e "${GREEN}✓ Installed required Node.js modules${NC}"

# Step 10: Create missing dashboard files
echo -e "${YELLOW}Step 10: Creating dashboard directory structure...${NC}"
mkdir -p "$SRC_DIR/dashboard"

cat > "$SRC_DIR/dashboard/config.json" << EOF
{
  "webSocketUrl": "ws://localhost:8765/ws",
  "apiBaseUrl": "http://localhost:8765/api",
  "socketDir": "$SOCKET_DIR",
  "logDir": "$LOG_DIR",
  "port": 8765,
  "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%S.000Z)"
}
EOF

cat > "$SRC_DIR/dashboard/config.js" << EOF
// Dashboard Configuration
window.dashboardConfig = {
  "webSocketUrl": "ws://localhost:8765/ws",
  "apiBaseUrl": "http://localhost:8765/api",
  "socketDir": "$SOCKET_DIR",
  "logDir": "$LOG_DIR",
  "port": 8765,
  "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%S.000Z)"
};
EOF
echo -e "${GREEN}✓ Created dashboard configuration files${NC}"

# Step 11: Start services
echo -e "${YELLOW}Step 11: Starting CNIF services...${NC}"
cd "$ANCHOR_HOME"
export NOTION_API_TOKEN="$NOTION_TOKEN"
chmod +x "$ANCHOR_HOME/start-webbridge.sh"
chmod +x "$ANCHOR_HOME/verify-cnif.sh"
"$ANCHOR_HOME/start-webbridge.sh"
echo -e "${GREEN}✓ CNIF services started${NC}"

echo -e "${BLUE}======================================================${NC}"
echo -e "${GREEN}✓ CNIF Setup Complete!${NC}"
echo -e "${BLUE}✓ Troubleshooting:${NC}"
echo -e "   - If services aren't running, check logs in $LOG_DIR"
echo -e "   - Run verify-cnif.sh to check component status"
echo -e "   - Dashboard URL: http://localhost:8765"
echo -e "${BLUE}======================================================${NC}"
