#!/bin/bash
# simple-launcher.sh - Simple launcher for CNIF without memory pools
# © 2025 XPV - MIT

# Define colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color
BLUE='\033[0;34m'

# Base paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
MCP_DIR="$ANCHOR_HOME/mcp-servers"
LOG_DIR="$HOME/Library/Logs/Claude"
SOCKET_DIR="$ANCHOR_HOME/sockets"

echo -e "${BLUE}CNIF Simple Launcher - Starting services...${NC}"

# Create required directories
mkdir -p "$LOG_DIR"
mkdir -p "$SOCKET_DIR"
mkdir -p "$ANCHOR_HOME/coherence_lock"

# Kill any existing processes
echo -e "${BLUE}Stopping any existing processes...${NC}"
pkill -f "socket-server-implementation.cjs" 2>/dev/null || true
pkill -f "schema-registry.cjs" 2>/dev/null || true
pkill -f "streaming-schema-transformer.cjs" 2>/dev/null || true
pkill -f "notion-connection-manager.cjs" 2>/dev/null || true
pkill -f "mcp-orchestrator.cjs" 2>/dev/null || true

# Wait a moment for processes to stop
sleep 2

# Clean up any existing socket files
rm -f "$SOCKET_DIR"/*.sock 2>/dev/null || true

# Define server configurations using simple arrays (not associative arrays)
SERVER_NAMES=("socket-server" "schema-registry" "streaming-transformer" "notion" "mcp-orchestrator")
SERVER_SCRIPTS=("$MCP_DIR/socket-server-implementation.cjs" "$MCP_DIR/schema-registry.cjs" "$MCP_DIR/streaming-schema-transformer.cjs" "$MCP_DIR/notion-connection-manager.cjs" "$MCP_DIR/mcp-orchestrator.cjs")

# Start each server
for i in "${!SERVER_NAMES[@]}"; do
  name="${SERVER_NAMES[$i]}"
  script="${SERVER_SCRIPTS[$i]}"
  
  # Check if script exists
  if [ ! -f "$script" ]; then
    echo -e "${RED}Error: Script not found for $name: $script${NC}"
    continue
  fi
  
  echo -e "${BLUE}Starting $name...${NC}"
  
  # Set environment variables
  export MCP_SERVER_NAME="$name"
  export ANCHOR_HOME="$ANCHOR_HOME"
  export SOCKET_DIR="$SOCKET_DIR"
  export LOG_DIR="$LOG_DIR"
  
  # Start the service
  node "$script" > "$LOG_DIR/$name.log" 2>&1 &
  pid=$!
  
  # Save PID
  echo "$pid" > "$MCP_DIR/$name.pid"
  
  echo -e "${GREEN}Started $name (PID: $pid)${NC}"
  
  # Short pause between services
  sleep 1
done

echo -e "${GREEN}All services started.${NC}"
echo -e "${BLUE}Use 'ps aux | grep node' to check if services are running.${NC}"
echo -e "${BLUE}Use 'tail -f $LOG_DIR/*.log' to view logs.${NC}"
