const net = require('net');
const socketPath = process.argv[2];

if (!socketPath) {
  console.error('Socket path must be provided as argument');
  process.exit(1);
}

console.error(`Connecting to socket: ${socketPath}`);

const socket = net.createConnection({ path: socketPath });

// Handle connection errors
socket.on('error', (err) => {
  console.error(`Socket connection error: ${err.message}`);
  process.exit(1);
});

// Handle connection events
socket.on('connect', () => {
  console.error(`Connected to socket: ${socketPath}`);
});

socket.on('close', () => {
  console.error(`Connection to socket closed: ${socketPath}`);
  process.exit(0);
});

// Directly pipe stdin/stdout to the socket
process.stdin.pipe(socket).pipe(process.stdout);

// Make sure we properly handle signals
process.on('SIGINT', () => {
  socket.destroy();
  process.exit(0);
});

process.on('SIGTERM', () => {
  socket.destroy();
  process.exit(0);
});
