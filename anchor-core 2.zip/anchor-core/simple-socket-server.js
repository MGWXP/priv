/**
 * simple-socket-server.js - Simplified socket server for testing
 * © 2025 XPV - MIT
 * 
 * This is a minimal implementation to test basic socket functionality
 */

const fs = require('fs');
const net = require('net');
const path = require('path');

// Configuration
const SOCKET_DIR = process.env.SOCKET_DIR || '/Users/XPV/Desktop/anchor-core/sockets';
const SERVER_NAME = 'test-socket';
const SOCKET_PATH = path.join(SOCKET_DIR, `${SERVER_NAME}.sock`);

// Ensure socket directory exists
if (!fs.existsSync(SOCKET_DIR)) {
  fs.mkdirSync(SOCKET_DIR, { recursive: true });
  console.log(`Created socket directory: ${SOCKET_DIR}`);
}

// Remove existing socket file
if (fs.existsSync(SOCKET_PATH)) {
  fs.unlinkSync(SOCKET_PATH);
  console.log(`Removed existing socket file: ${SOCKET_PATH}`);
}

// Create server
const server = net.createServer((socket) => {
  console.log('Client connected');
  
  socket.on('data', (data) => {
    console.log(`Received data: ${data.toString()}`);
    
    // Echo back
    socket.write(`Echo: ${data.toString()}`);
  });
  
  socket.on('end', () => {
    console.log('Client disconnected');
  });
  
  socket.on('error', (err) => {
    console.error(`Socket error: ${err.message}`);
  });
});

// Start listening
server.listen(SOCKET_PATH, () => {
  console.log(`Server listening on ${SOCKET_PATH}`);
  
  // Set permissions
  try {
    fs.chmodSync(SOCKET_PATH, 0o666);
    console.log(`Set permissions on socket file: 0666`);
    
    // Double-check permissions
    const stats = fs.statSync(SOCKET_PATH);
    const perms = stats.mode & 0o777;
    console.log(`Actual permissions: ${perms.toString(8)}`);
  } catch (err) {
    console.error(`Failed to set permissions: ${err.message}`);
  }
});

// Handle server errors
server.on('error', (err) => {
  console.error(`Server error: ${err.message}`);
});

// Handle process exit
process.on('SIGINT', () => {
  console.log('Received SIGINT, shutting down');
  server.close(() => {
    if (fs.existsSync(SOCKET_PATH)) {
      fs.unlinkSync(SOCKET_PATH);
      console.log(`Removed socket file on exit: ${SOCKET_PATH}`);
    }
    process.exit(0);
  });
});

process.on('SIGTERM', () => {
  console.log('Received SIGTERM, shutting down');
  server.close(() => {
    if (fs.existsSync(SOCKET_PATH)) {
      fs.unlinkSync(SOCKET_PATH);
      console.log(`Removed socket file on exit: ${SOCKET_PATH}`);
    }
    process.exit(0);
  });
});

console.log(`Started simple socket server (PID: ${process.pid})`);
console.log('Press Ctrl+C to stop');
