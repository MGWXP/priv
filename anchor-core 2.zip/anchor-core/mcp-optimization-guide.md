
# MCP Server Optimization Guide for M3 Max Hardware

## ✅ System Configuration

The MCP servers have been optimized for your M3 Max hardware with 48GB unified memory:

| Parameter             | Previous Value | Optimized Value |
|-----------------------|----------------|-----------------|
| NODE_OPTIONS          | 4096 MB        | 8192 MB         |
| UV_THREADPOOL_SIZE    | 8 threads      | 12 threads      |

## 🔧 Instructions for Finalizing Setup

1. Make the verification script executable:
   ```bash
   chmod +x /Users/XPV/Desktop/anchor-core/mcp-server-verification.sh
   ```

2. Run the verification script to ensure all MCP servers are installed:
   ```bash
   /Users/XPV/Desktop/anchor-core/mcp-server-verification.sh
   ```

3. Restart Claude Desktop application to apply changes

## 📊 Troubleshooting

If issues persist after restart:

1. Check for any terminal errors when running the script
2. Verify API keys are correctly set in environment variables for Notion and Slack servers
3. Run the script again with sudo if permission issues occur

## 🔄 Backup Information

Your original configuration has been backed up to:
`/Users/XPV/Library/Application Support/Claude/claude_desktop_config.json.bak.20250518`

To restore the original configuration if needed:
```bash
cp "/Users/XPV/Library/Application Support/Claude/claude_desktop_config.json.bak.20250518" "/Users/XPV/Library/Application Support/Claude/claude_desktop_config.json"
```
