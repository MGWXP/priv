#!/bin/bash
chmod +x /Users/XPV/Desktop/anchor-core/fix-cnif.sh
echo "✅ Fix script is now executable"
echo "To fix all CNIF issues and configure Notion integration, run:"
echo "  /Users/XPV/Desktop/anchor-core/fix-cnif.sh"
