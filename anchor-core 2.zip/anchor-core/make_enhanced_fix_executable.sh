chmod +x /Users/XPV/Desktop/anchor-core/enhanced-quick-fix.sh
