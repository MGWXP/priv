# MCP Server System Documentation

## ✅ Current MCP Server Configuration

Your Claude Desktop environment is successfully configured with the following official MCP servers:

| Server     | Package                              | Status | Tools |
|------------|--------------------------------------|--------|-------|
| Filesystem | @modelcontextprotocol/server-filesystem | ✅ Active | 11 Tools |
| Notion     | @notionhq/notion-mcp-server          | ✅ Active | 19 Tools |
| Slack      | @modelcontextprotocol/server-slack   | ✅ Active | 8 Tools |

## 🔧 System Optimization

Your system has been optimized for the M3 Max hardware with:
- Memory allocation: 8192MB (NODE_OPTIONS)
- Thread pool size: 12 threads (UV_THREADPOOL_SIZE)

## 📋 Environment Maintenance

To ensure your MCP servers remain functional:

1. Run the environment verification script regularly:
   ```bash
   chmod +x /Users/XPV/Desktop/anchor-core/mcp-environment-verifier.sh
   /Users/XPV/Desktop/anchor-core/mcp-environment-verifier.sh
   ```

2. Ensure your API keys are properly set:
   ```bash
   export NOTION_API_KEY="your_notion_api_key"
   export SLACK_BOT_TOKEN="your_slack_bot_token" 
   export SLACK_TEAM_ID="your_slack_team_id"
   ```

3. To make these environment variables persistent, add them to your shell profile:
   ```bash
   echo 'export NOTION_API_KEY="your_notion_api_key"' >> ~/.zshrc
   echo 'export SLACK_BOT_TOKEN="your_slack_bot_token"' >> ~/.zshrc
   echo 'export SLACK_TEAM_ID="your_slack_team_id"' >> ~/.zshrc
   source ~/.zshrc
   ```

## 🔄 Troubleshooting Common Issues

### Server Connection Problems
- Restart Claude Desktop if connections drop
- Verify API tokens are correctly set and valid
- Run the environment verification script

### Performance Issues
- Ensure no conflicting Node.js processes are running
- Check system resources using Activity Monitor
- Consider restarting your system if performance degrades

### API Token Expiration
- Notion and Slack tokens may expire - regenerate them from their respective admin panels
- Update your environment variables with the new tokens

## 📊 Using MCP Tools Effectively

### Notion Tools
- Query databases with `notion_query_database`
- Retrieve page content with `notion_retrieve_page`
- Create and update pages with `notion_create_page` and `notion_update_page`

### Slack Tools
- Post messages with `slack_post_message`
- Get channel history with `slack_get_channel_history`
- Add reactions with `slack_add_reaction`

### Filesystem Tools
- Read files with `read_file`
- Write files with `write_file`
- Search for files with `search_files`
