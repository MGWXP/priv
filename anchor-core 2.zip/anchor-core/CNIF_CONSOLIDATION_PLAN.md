# CNIF System Consolidation and Streamlining Plan

## 1. Identified Issues

Based on deep analysis of the Claude-Notion Integration Framework (CNIF), several areas for consolidation and integration have been identified:

### 1.1. Optimizer Proliferation
- Multiple M3 optimizer implementations with overlapping functionality (`m3-optimizer.js`, `m3_optimizer.js`, `m3_optimizer.cjs`, `m3-mcp-optimizer.js`)
- Inconsistent NODE_OPTIONS flags that could lead to runtime errors
- Divergent memory allocation strategies between different optimizer implementations

### 1.2. Script Proliferation
- Multiple launch scripts that perform similar functions (`launch-optimized.sh`, `launch-mcp-servers.sh`, etc.)
- Numerous executable permission scripts that could be consolidated
- Redundant server verification and monitoring scripts

### 1.3. Entry Point Confusion
- Inconsistent entry point pattern implementation across services
- Mix of direct `.cjs` execution and wrapper entry points

### 1.4. Directory Structure Inconsistencies
- Scattered configuration files across multiple directories
- Unclear separation between core components and utility scripts

## 2. Consolidation Strategy

### 2.1. MCP Server Components
- **Unified Module Format**: Standardize on .cjs for all server implementation files
- **Entry Point Pattern**: Create consistent entry points for all services
- **Core Component Directory**: Centralize core components in a dedicated directory

### 2.2. Optimizer Consolidation
- **Single Optimizer Implementation**: Create a unified M3 optimizer with consistent memory strategies
- **Safe NODE_OPTIONS**: Ensure only allowed flags are used in NODE_OPTIONS
- **Memory Pool Management**: Standardize memory pooling approach

### 2.3. Script Consolidation
- **Admin CLI**: Create a unified admin CLI script for all operations
- **Self-documenting Scripts**: Implement help functionality in scripts
- **Script Categories**: Organize scripts by function (setup, launch, monitor, optimize)

### 2.4. Directory Structure Optimization
- **Config Directory**: Centralize all configuration in a single location
- **Scripts Directory**: Organize scripts into subdirectories by function
- **Archive Legacy**: Move all legacy files to a structured archive

## 3. Implementation Plan

### 3.1. Phase 1: Core Component Standardization
1. Create unified directory structure
2. Standardize module format and entry points
3. Implement consistent error handling and logging

### 3.2. Phase 2: Optimizer Integration
1. Create unified M3 optimizer with safe flags
2. Implement adaptive memory allocation based on hardware
3. Create standard memory pooling solution

### 3.3. Phase 3: Script Consolidation
1. Create unified admin CLI
2. Implement script categories
3. Add self-documentation to all scripts

### 3.4. Phase 4: Documentation and Testing
1. Create comprehensive documentation
2. Implement automated testing
3. Create system integrity verification tools

## 4. Immediate Actions

1. **Create Unified Directory Structure**
   - `core/`: Core server components (.cjs files)
   - `entry-points/`: Entry point files (main.js files)
   - `admin/`: Administrative scripts (CLI, monitoring)
   - `config/`: Configuration files (.json, .env)
   - `tools/`: Utility tools and scripts

2. **Consolidate M3 Optimizer**
   - Create unified M3Optimizer class
   - Implement safe NODE_OPTIONS handling
   - Create dynamic memory allocation

3. **Create Admin CLI**
   - Implement command patterns (start, stop, status, optimize)
   - Add self-documentation
   - Create error handling and recovery

4. **Archive Legacy Files**
   - Move all duplicate/obsolete files to archive
   - Document archived files for reference
   - Create migration guide

## 5. Long-term Improvements

1. **Automated Testing**
   - Implement unit tests for core components
   - Create integration tests for system coherence
   - Add performance benchmarks

2. **Documentation**
   - Create developer guide
   - Implement auto-generated API documentation
   - Create system architecture diagrams

3. **Monitoring Tools**
   - Create real-time performance dashboard
   - Implement log analysis tools
   - Add system health monitoring
