#!/bin/bash
# CNIF Verification Script
# Checks if all CNIF components are properly installed and running

echo "======================================================"
echo "  CNIF - System Verification"
echo "  Checking components and configurations..."
echo "======================================================"

ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
SOCKET_DIR="$ANCHOR_HOME/sockets"
LOG_DIR="/Users/XPV/Library/Logs/Claude"
SRC_DIR="$ANCHOR_HOME/src"

# Check directories
echo -n "Checking directories... "
for dir in "$ANCHOR_HOME" "$SOCKET_DIR" "$LOG_DIR" "$SRC_DIR" "$SRC_DIR/webbridge" "$SRC_DIR/dashboard"; do
  if [ ! -d "$dir" ]; then
    echo "❌"
    echo "Missing directory: $dir"
    mkdir -p "$dir"
    echo "Created directory: $dir"
  fi
done
echo "✅"

# Check required files
echo -n "Checking required files... "
required_files=(
  "$SRC_DIR/webbridge/socket-bridge.js"
  "$SRC_DIR/webbridge/notion-sync.js"
  "$SRC_DIR/dashboard/index.html"
  "$SRC_DIR/dashboard/styles.css"
  "$SRC_DIR/dashboard/config.js"
  "$SRC_DIR/dashboard/config.json"
)

missing_files=false
for file in "${required_files[@]}"; do
  if [ ! -f "$file" ]; then
    echo "❌"
    echo "Missing file: $file"
    missing_files=true
  fi
done

if [ "$missing_files" = "false" ]; then
  echo "✅"
fi

# Check if start-webbridge.sh is executable
echo -n "Checking script permissions... "
if [ ! -x "$ANCHOR_HOME/start-webbridge.sh" ]; then
  echo "❌"
  echo "Making start-webbridge.sh executable..."
  chmod +x "$ANCHOR_HOME/start-webbridge.sh"
else
  echo "✅"
fi

# Check running processes
echo "Checking running processes..."

# Check WebSocket Bridge
if [ -f "$ANCHOR_HOME/webbridge.pid" ]; then
  WS_PID=$(cat "$ANCHOR_HOME/webbridge.pid")
  if ps -p "$WS_PID" > /dev/null; then
    echo "✅ WebSocket Bridge is running (PID: $WS_PID)"
  else
    echo "❌ WebSocket Bridge is not running (PID file exists but process is dead)"
  fi
else
  echo "❌ WebSocket Bridge is not running (PID file not found)"
fi

# Check Notion Sync
if [ -f "$ANCHOR_HOME/notion-sync.pid" ]; then
  NOTION_PID=$(cat "$ANCHOR_HOME/notion-sync.pid")
  if ps -p "$NOTION_PID" > /dev/null; then
    echo "✅ Notion Sync is running (PID: $NOTION_PID)"
  else
    echo "❌ Notion Sync is not running (PID file exists but process is dead)"
  fi
else
  echo "❌ Notion Sync is not running (PID file not found)"
fi

# Check Dashboard
if [ -f "$ANCHOR_HOME/dashboard.pid" ]; then
  DASHBOARD_PID=$(cat "$ANCHOR_HOME/dashboard.pid")
  if ps -p "$DASHBOARD_PID" > /dev/null; then
    echo "✅ Dashboard is running (PID: $DASHBOARD_PID)"
  else
    echo "❌ Dashboard is not running (PID file exists but process is dead)"
  fi
else
  echo "❌ Dashboard is not running (PID file not found)"
fi

# Check socket files
echo "Checking socket directory..."
if [ -d "$SOCKET_DIR" ]; then
  SOCKET_COUNT=$(find "$SOCKET_DIR" -name "*.sock" | wc -l)
  if [ "$SOCKET_COUNT" -gt 0 ]; then
    echo "✅ Socket directory exists: $SOCKET_DIR"
    echo "   Available sockets:"
    for sock in "$SOCKET_DIR"/*.sock; do
      echo "   - $(basename "$sock")"
    done
  else
    echo "✅ Socket directory exists: $SOCKET_DIR"
    echo "   (No active socket files found)"
  fi
else
  echo "❌ Socket directory not found: $SOCKET_DIR"
fi

# Check log files
echo "Checking log files..."
if [ -d "$LOG_DIR" ]; then
  echo "✅ Log directory exists: $LOG_DIR"
  echo "   Recent log entries:"
  
  # Check WebSocket Bridge log
  WS_LOG=$(find "$LOG_DIR" -name "webbridge-*.log" -type f -mtime -1 | sort -r | head -1)
  if [ -n "$WS_LOG" ]; then
    echo "   Socket Bridge Log:"
    tail -n 3 "$WS_LOG" | while read -r line; do
      echo "    $line"
    done
  else
    echo "   ❌ No recent WebSocket Bridge log found"
  fi
  
  # Check Notion Sync log
  NOTION_LOG=$(find "$LOG_DIR" -name "notion-sync-*.log" -type f -mtime -1 | sort -r | head -1)
  if [ -n "$NOTION_LOG" ]; then
    echo "   Notion Sync Log:"
    tail -n 3 "$NOTION_LOG" | while read -r line; do
      echo "    $line"
    done
  else
    echo "   ❌ No recent Notion sync log found"
  fi
else
  echo "❌ Log directory not found: $LOG_DIR"
fi

# Check Notion token
echo -n "Checking Notion API token... "
NOTION_TOKEN_PATH="$HOME/.notion/token"
if [ -f "$NOTION_TOKEN_PATH" ]; then
  echo "✅"
else
  echo "❌"
  echo "Notion API token not found. Create a file at $NOTION_TOKEN_PATH with your token."
fi

# Summary
echo "======================================================"
echo "Verification Summary"
if [ ! -x "$ANCHOR_HOME/start-webbridge.sh" ] || [ "$missing_files" = "true" ]; then
  echo "❌ System verification failed. Please fix the issues above."
  
  # Provide fix instructions
  echo ""
  echo "To fix issues, run the following commands:"
  
  if [ ! -x "$ANCHOR_HOME/start-webbridge.sh" ]; then
    echo "  chmod +x $ANCHOR_HOME/start-webbridge.sh"
  fi
  
  if [ "$missing_files" = "true" ]; then
    echo "  # Ensure all required files are present in the correct locations"
  fi
else
  # Check if all components are running
  if [ -f "$ANCHOR_HOME/webbridge.pid" ] && ps -p "$(cat "$ANCHOR_HOME/webbridge.pid")" > /dev/null && \
     [ -f "$ANCHOR_HOME/notion-sync.pid" ] && ps -p "$(cat "$ANCHOR_HOME/notion-sync.pid")" > /dev/null && \
     [ -f "$ANCHOR_HOME/dashboard.pid" ] && ps -p "$(cat "$ANCHOR_HOME/dashboard.pid")" > /dev/null; then
    echo "✅ All components are running correctly."
    echo ""
    echo "To access the dashboard, open:"
    echo "  http://localhost:8765"
    echo ""
    echo "For troubleshooting, see:"
    echo "  $ANCHOR_HOME/WEBBRIDGE_TROUBLESHOOTING.md"
  else
    echo "⚠️ Some components are not running. To start all components:"
    echo "  $ANCHOR_HOME/start-webbridge.sh"
    echo ""
    echo "For more detailed troubleshooting, see:"
    echo "  $ANCHOR_HOME/WEBBRIDGE_TROUBLESHOOTING.md"
  fi
fi
echo "======================================================"
