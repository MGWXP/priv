#!/bin/bash
# mcp-restart-all.sh - Complete MCP system restart with optimizations for M3 Max
# Part of Anchor System MCP optimization (2025-05-18)

echo "=== Anchor System MCP Server Restart ==="
echo "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

# Environment variables
export NODE_OPTIONS="--max-old-space-size=8192 --expose-gc"
export UV_THREADPOOL_SIZE="12"
export MCP_WORKER_THREADS="11"
export MCP_MAX_PARALLEL="7"
export MCP_USE_NEURAL_ENGINE="1"

# Critical paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
MCP_DIR="$ANCHOR_HOME/mcp-servers"
SOCKET_DIR="$ANCHOR_HOME/sockets"
LOG_DIR="$HOME/Library/Logs/Claude"
COHERENCE_DIR="$ANCHOR_HOME/coherence_lock"
CONFIG_DIR="$HOME/Library/Application Support/Claude"
CONFIG_FILE="$CONFIG_DIR/claude_desktop_config.json"

# Create required directories
mkdir -p "$SOCKET_DIR"
mkdir -p "$LOG_DIR"
mkdir -p "$COHERENCE_DIR"
mkdir -p "$CONFIG_DIR"

# Ensure proper permissions
chmod 770 "$SOCKET_DIR"

# Server files
FILESYSTEM_SERVER="$MCP_DIR/enhanced-socket-server.js"
GIT_LOCAL_SERVER="$MCP_DIR/git-local-optimized.js"
NOTION_SERVER="$MCP_DIR/notion-v5-wrapper.js"
ANCHOR_MANAGER_SERVER="$MCP_DIR/anchor-manager-optimized.js"

# PID files
FILESYSTEM_PID="$MCP_DIR/filesystem.pid"
GIT_LOCAL_PID="$MCP_DIR/git-local.pid"
NOTION_PID="$MCP_DIR/notion.pid"
ANCHOR_MANAGER_PID="$MCP_DIR/anchor-manager.pid"

# Log files
FILESYSTEM_LOG="$LOG_DIR/mcp-server-filesystem.log"
GIT_LOCAL_LOG="$LOG_DIR/mcp-server-git-local.log"
NOTION_LOG="$LOG_DIR/mcp-server-notion.log"
ANCHOR_MANAGER_LOG="$LOG_DIR/mcp-server-anchor-manager.log"

# Socket files
FILESYSTEM_SOCKET="$SOCKET_DIR/filesystem.sock"
GIT_LOCAL_SOCKET="$SOCKET_DIR/git-local.sock"
NOTION_SOCKET="$SOCKET_DIR/notion.sock"
ANCHOR_MANAGER_SOCKET="$SOCKET_DIR/anchor-manager.sock"

# Function to stop a server by name
stop_server() {
  local server_name="$1"
  local pid_file="$MCP_DIR/$server_name.pid"
  
  echo "Stopping $server_name server..."
  
  if [ -f "$pid_file" ]; then
    local pid=$(cat "$pid_file")
    if ps -p "$pid" > /dev/null; then
      echo "Killing process $pid"
      kill "$pid" 2>/dev/null || true
      sleep 1
      kill -9 "$pid" 2>/dev/null || true
    else
      echo "Process not running (PID: $pid)"
    fi
  else
    echo "PID file not found, searching for process..."
    local process_pid=$(pgrep -f "$server_name" || echo "")
    if [ -n "$process_pid" ]; then
      echo "Found process $process_pid"
      kill "$process_pid" 2>/dev/null || true
      sleep 1
      kill -9 "$process_pid" 2>/dev/null || true
    else
      echo "No process found"
    fi
  fi
  
  # Clean up socket file
  local socket_file="$SOCKET_DIR/$server_name.sock"
  if [ -S "$socket_file" ]; then
    echo "Removing socket file $socket_file"
    rm -f "$socket_file"
  fi
  
  # Clean up PID file
  if [ -f "$pid_file" ]; then
    echo "Removing PID file $pid_file"
    rm -f "$pid_file"
  fi
}

# Function to start a server
start_server() {
  local server_name="$1"
  local server_file="$2"
  local log_file="$3"
  
  echo "Starting $server_name server..."
  
  if [ ! -f "$server_file" ]; then
    echo "❌ Server file not found: $server_file"
    return 1
  fi
  
  # Make sure the file is executable
  chmod +x "$server_file"
  
  # Set environment variables
  export MCP_SERVER_NAME="$server_name"
  export ANCHOR_HOME="$ANCHOR_HOME"
  export SOCKET_DIR="$SOCKET_DIR"
  
  # Start the server
  node "$server_file" > "$log_file" 2>&1 &
  
  # Wait for server to start
  sleep 2
  
  # Check if server started
  local socket_file="$SOCKET_DIR/$server_name.sock"
  if [ -S "$socket_file" ]; then
    echo "✅ $server_name server started successfully"
    return 0
  else
    echo "❌ $server_name server failed to start"
    return 1
  fi
}

# Function to update Claude Desktop configuration
update_config() {
  echo "Updating Claude Desktop configuration..."
  
  # Backup existing config
  if [ -f "$CONFIG_FILE" ]; then
    cp "$CONFIG_FILE" "$CONFIG_FILE.bak.$(date '+%Y%m%d_%H%M%S')"
  fi
  
  # Copy new config
  cp "$ANCHOR_HOME/new_claude_config.json" "$CONFIG_FILE"
  
  echo "✅ Configuration updated"
}

# Function to create coherence lock
create_coherence_lock() {
  echo "Creating coherence lock..."
  
  local timestamp=$(date -u +"%Y-%m-%dT%H:%M:%S.%3NZ")
  local formatted_timestamp=$(date -u +"%Y%m%d_%H%M%S")
  local coherence_file="$COHERENCE_DIR/coherence_lock_$formatted_timestamp.json"
  
  # Check which servers are running
  local filesystem_status="disconnected"
  local git_local_status="disconnected"
  local notion_status="disconnected"
  local anchor_manager_status="disconnected"
  
  [ -S "$FILESYSTEM_SOCKET" ] && filesystem_status="connected"
  [ -S "$GIT_LOCAL_SOCKET" ] && git_local_status="connected"
  [ -S "$NOTION_SOCKET" ] && notion_status="connected"
  [ -S "$ANCHOR_MANAGER_SOCKET" ] && anchor_manager_status="connected"
  
  # Create coherence lock file
  cat > "$coherence_file" << EOL
{
  "timestamp": "$timestamp",
  "system": "anchor-system-v6",
  "components": {
    "git-local": {
      "version": "6.0.0",
      "socket": "$GIT_LOCAL_SOCKET",
      "checksum": "sha256:$(shasum -a 256 "$GIT_LOCAL_SERVER" | cut -d' ' -f1 | cut -c1-40)",
      "status": "$git_local_status"
    },
    "notion": {
      "version": "6.0.0",
      "socket": "$NOTION_SOCKET",
      "checksum": "sha256:$(shasum -a 256 "$NOTION_SERVER" | cut -d' ' -f1 | cut -c1-40)",
      "status": "$notion_status"
    },
    "filesystem": {
      "version": "6.0.0",
      "socket": "$FILESYSTEM_SOCKET",
      "checksum": "sha256:$(shasum -a 256 "$FILESYSTEM_SERVER" | cut -d' ' -f1 | cut -c1-40)",
      "status": "$filesystem_status"
    },
    "anchor-manager": {
      "version": "6.0.0",
      "socket": "$ANCHOR_MANAGER_SOCKET",
      "checksum": "sha256:$(shasum -a 256 "$ANCHOR_MANAGER_SERVER" | cut -d' ' -f1 | cut -c1-40)",
      "status": "$anchor_manager_status"
    }
  },
  "system_info": {
    "hardware": "M3 Max (48GB unified memory)",
    "os": "macOS Sequoia 15.4.1",
    "node_version": "$(node -v)",
    "mcp_version": "V4.2.1",
    "claude_version": "Claude 3.7 Sonnet"
  },
  "optimization": {
    "thread_pool_size": 12,
    "memory_limit": "8192MB",
    "cache_strategy": "aggressive",
    "cache_ttl": 600,
    "cache_size": "2GB"
  },
  "verification": {
    "method": "sha256-hmac",
    "signature": "$(shasum -a 256 "$0" | cut -d' ' -f1 | cut -c1-40)",
    "verified_by": "mcp-restart-all.sh ($(date -u +"%Y-%m-%d"))"
  }
}
EOL
  
  echo "✅ Coherence lock created: $coherence_file"
}

# Main function to restart all servers
restart_all() {
  echo "Restarting all MCP servers..."
  
  # Stop all servers
  stop_server "filesystem"
  stop_server "git-local"
  stop_server "notion"
  stop_server "anchor-manager"
  
  # Give some time for processes to terminate
  sleep 2
  
  # Start servers
  start_server "filesystem" "$FILESYSTEM_SERVER" "$FILESYSTEM_LOG"
  start_server "git-local" "$GIT_LOCAL_SERVER" "$GIT_LOCAL_LOG"
  start_server "notion" "$NOTION_SERVER" "$NOTION_LOG"
  start_server "anchor-manager" "$ANCHOR_MANAGER_SERVER" "$ANCHOR_MANAGER_LOG"
  
  # Create coherence lock
  create_coherence_lock
  
  # Update configuration
  update_config
  
  echo ""
  echo "Server restart complete!"
  echo "Check server status with 'ps aux | grep mcp-server'"
}

# Execute the main function
restart_all

echo ""
echo "Run 'chmod +x mcp-restart-all.sh' to make this script executable"
echo "Then run './mcp-restart-all.sh' to restart all servers"
