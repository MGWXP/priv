#!/bin/bash
# mcp-alias-setup.sh - Creates helpful aliases for MCP management

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

echo -e "${BLUE}=== Setting up MCP Management Aliases ===${NC}"

# Determine shell type and profile file
if [ -n "$ZSH_VERSION" ]; then
    PROFILE_FILE="$HOME/.zshrc"
elif [ -n "$BASH_VERSION" ]; then
    PROFILE_FILE="$HOME/.bashrc"
else
    PROFILE_FILE="$HOME/.profile"
fi

# Create aliases
echo -e "${YELLOW}Adding aliases to $PROFILE_FILE${NC}"

cat << 'EOF' >> "$PROFILE_FILE"

# MCP Management Aliases
alias mcp-verify="/Users/XPV/Desktop/anchor-core/mcp-environment-verifier.sh"
alias mcp-status="ps aux | grep -E 'notion-mcp-server|server-slack|server-filesystem' | grep -v grep"
alias mcp-docs="open /Users/XPV/Desktop/anchor-core/mcp-system-documentation.md"
alias mcp-restart="pkill -f 'notion-mcp-server|server-slack|server-filesystem' && open -a 'Claude'"

# MCP Environment Variables Helper
mcp-env-setup() {
    echo "Enter your Notion API Key:"
    read -s NOTION_KEY
    echo "Enter your Slack Bot Token:"
    read -s SLACK_TOKEN
    echo "Enter your Slack Team ID:"
    read -s SLACK_ID
    
    export NOTION_API_KEY="$NOTION_KEY"
    export SLACK_BOT_TOKEN="$SLACK_TOKEN"
    export SLACK_TEAM_ID="$SLACK_ID"
    
    echo "Environment variables set for current session"
    echo "To make them permanent, run: mcp-env-save"
}

# Save MCP Environment Variables
mcp-env-save() {
    if [ -n "$NOTION_API_KEY" ] && [ -n "$SLACK_BOT_TOKEN" ] && [ -n "$SLACK_TEAM_ID" ]; then
        echo "export NOTION_API_KEY=\"$NOTION_API_KEY\"" >> "$PROFILE_FILE"
        echo "export SLACK_BOT_TOKEN=\"$SLACK_BOT_TOKEN\"" >> "$PROFILE_FILE"
        echo "export SLACK_TEAM_ID=\"$SLACK_TEAM_ID\"" >> "$PROFILE_FILE"
        echo "Environment variables saved to $PROFILE_FILE"
        echo "Run 'source $PROFILE_FILE' to apply changes"
    else
        echo "Error: One or more environment variables not set"
        echo "Run mcp-env-setup first"
    fi
}
EOF

echo -e "${GREEN}✓ Aliases created successfully${NC}"
echo -e "${YELLOW}Run 'source $PROFILE_FILE' to apply changes${NC}"
echo -e "\nAvailable commands:"
echo -e "  ${BLUE}mcp-verify${NC} - Run environment verification script"
echo -e "  ${BLUE}mcp-status${NC} - Check if MCP servers are running"
echo -e "  ${BLUE}mcp-docs${NC} - Open the MCP system documentation"
echo -e "  ${BLUE}mcp-restart${NC} - Restart all MCP servers and Claude"
echo -e "  ${BLUE}mcp-env-setup${NC} - Set up environment variables"
echo -e "  ${BLUE}mcp-env-save${NC} - Save environment variables permanently"
