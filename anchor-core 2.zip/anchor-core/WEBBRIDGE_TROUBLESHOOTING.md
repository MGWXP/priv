# Troubleshooting Guide for CNIF

This document provides solutions for common issues encountered with the Claude-Notion Integration Framework (CNIF).

## Connection Issues

### WebSocket Bridge Not Starting

**Symptoms:**
- Error message: "WebSocket bridge is not running"
- Cannot connect to the dashboard
- Error in logs about port already in use

**Solutions:**

1. **Check if the port is already in use**
   ```bash
   lsof -i :8765
   ```
   If the port is in use, either terminate that process or change the port in your configuration.

2. **Check for stale PID files**
   ```bash
   rm -f /Users/XPV/Desktop/anchor-core/webbridge.pid
   ```

3. **Review WebSocket bridge logs**
   ```bash
   cat /Users/XPV/Library/Logs/Claude/webbridge-$(date +%Y%m%d).log
   ```

4. **Verify required directories exist**
   ```bash
   mkdir -p /Users/XPV/Desktop/anchor-core/sockets
   mkdir -p /Users/XPV/Desktop/anchor-core/src/webbridge
   mkdir -p /Users/XPV/Desktop/anchor-core/src/dashboard
   ```

5. **Restart WebSocket bridge with verbose logging**
   ```bash
   LOG_LEVEL=DEBUG ./start-webbridge.sh
   ```

### Notion Sync Not Running

**Symptoms:**
- Dashboard shows "Notion Sync: Disconnected"
- Cannot query Notion databases

**Solutions:**

1. **Check Notion API token**
   Ensure you have a valid Notion API token stored in `~/.notion/token`.
   ```bash
   cat ~/.notion/token
   # Token should be present and valid
   ```

2. **Check Notion sync logs**
   ```bash
   cat /Users/XPV/Library/Logs/Claude/notion-sync-$(date +%Y%m%d).log
   ```

3. **Test Notion API connection**
   Use a simple cURL command to test your API token:
   ```bash
   curl -X POST https://api.notion.com/v1/users/me \
   -H 'Authorization: Bearer YOUR_API_TOKEN' \
   -H 'Notion-Version: 2022-06-28'
   ```

4. **Restart Notion sync independently**
   ```bash
   node /Users/XPV/Desktop/anchor-core/src/webbridge/notion-sync.js
   ```

### Dashboard Not Appearing

**Symptoms:**
- Cannot access dashboard at http://localhost:8765
- Dashboard loads but shows no data

**Solutions:**

1. **Check if WebSocket bridge is running**
   ```bash
   ps aux | grep socket-bridge
   ```

2. **Verify dashboard files**
   Ensure all dashboard files are present:
   ```bash
   ls -la /Users/XPV/Desktop/anchor-core/src/dashboard
   ```

3. **Check browser console for errors**
   Open browser developer tools and look for errors in the console.

4. **Try different browser**
   Some browsers handle WebSockets differently. Try Chrome or Firefox.

## Performance Issues

### High CPU Usage

**Symptoms:**
- System becomes unresponsive
- High CPU usage by Node.js processes
- Dashboard reports slow message throughput

**Solutions:**

1. **Check memory settings**
   ```bash
   # In start-webbridge.sh
   NODE_OPTIONS="--max-old-space-size=8192"
   ```

2. **Adjust thread pool size**
   Try reducing the thread pool size:
   ```bash
   # In start-webbridge.sh
   UV_THREADPOOL_SIZE=8  # Reduce from 16
   ```

3. **Disable worker threads**
   Edit socket-bridge.js and set:
   ```javascript
   config.threadPoolSize = 1;  // Disable worker threads
   ```

4. **Check for memory leaks**
   Review logs for increasing memory usage over time.

### Slow Response Time

**Symptoms:**
- Dashboard updates are delayed
- Messages take a long time to process
- Notion sync takes too long

**Solutions:**

1. **Optimize caching settings**
   ```javascript
   // In notion-sync.js
   config.enableCache = true;
   config.cacheExpiryTime = 60 * 60 * 1000; // 1 hour
   ```

2. **Reduce sync interval**
   ```javascript
   // In notion-sync.js or via environment variable
   NOTION_SYNC_INTERVAL=30000; // 30 seconds instead of 10
   ```

3. **Optimize database operations**
   Ensure SQlite optimizations are enabled:
   ```javascript
   await db.exec('PRAGMA journal_mode = WAL;');
   await db.exec('PRAGMA synchronous = NORMAL;');
   await db.exec('PRAGMA temp_store = MEMORY;');
   await db.exec('PRAGMA mmap_size = 268435456;'); // 256MB memory mapping
   ```

## Common Error Messages

### "Circuit breaker is open, API calls suspended"

This is a protective mechanism to prevent overloading the Notion API when errors occur.

**Solution:**
1. Check Notion API status
2. Verify your token is valid
3. Wait for the circuit breaker to reset (usually 60 seconds)
4. Restart the Notion sync service

### "EADDRINUSE: Address already in use"

Port 8765 is already being used by another process.

**Solution:**
1. Find and terminate the process using that port
   ```bash
   lsof -i :8765
   kill -9 <PID>
   ```
2. Or change the port in your configuration
   ```bash
   # In start-webbridge.sh
   WS_PORT=8766  # Use a different port
   ```

### "No Notion API token provided, sync will be disabled"

The system cannot find your Notion API token.

**Solution:**
1. Set the token in your environment
   ```bash
   export NOTION_API_TOKEN=your_token_here
   ```
2. Or create a token file
   ```bash
   mkdir -p ~/.notion
   echo "your_token_here" > ~/.notion/token
   chmod 600 ~/.notion/token
   ```

## Reset and Restart

If all else fails, try a complete reset and restart:

```bash
# Stop all processes
kill $(cat /Users/XPV/Desktop/anchor-core/webbridge.pid /Users/XPV/Desktop/anchor-core/notion-sync.pid /Users/XPV/Desktop/anchor-core/dashboard.pid 2>/dev/null)

# Remove PID files
rm -f /Users/XPV/Desktop/anchor-core/webbridge.pid /Users/XPV/Desktop/anchor-core/notion-sync.pid /Users/XPV/Desktop/anchor-core/dashboard.pid

# Remove socket files
rm -f /Users/XPV/Desktop/anchor-core/sockets/*.sock

# Clear cache
rm -rf /Users/XPV/Desktop/anchor-core/data/notion-cache/*

# Restart
./start-webbridge.sh
```

## M3 Max Specific Troubleshooting

### Performance Not Optimized for M3 Max

**Symptoms:**
- High energy impact in Activity Monitor
- Performance seems suboptimal
- E-cores are not being utilized

**Solutions:**

1. **Check core utilization**
   ```bash
   sudo powermetrics --samplers cpu_power -i 1000 -n 5
   ```
   Look for balanced utilization across P and E cores.

2. **Adjust thread pool size to match hardware**
   ```bash
   # For M3 Max with 12P/4E cores
   UV_THREADPOOL_SIZE=16
   ```

3. **Enable Metal acceleration if available**
   ```javascript
   config.useMetalComputing = true;
   ```

4. **Verify Node.js is using ARM native binaries**
   ```bash
   node -p "process.arch"  # Should output 'arm64'
   ```

## Getting Additional Help

If you continue to experience issues after trying these solutions, please:

1. Collect full logs from all components
   ```bash
   zip -r cnif-logs.zip /Users/XPV/Library/Logs/Claude/
   ```

2. Note your exact environment:
   - macOS version
   - Node.js version
   - Exact M3 Max configuration

3. File an issue in the repository with the complete information.

---

*For additional support, please refer to the [CNIF documentation](README.md).*
