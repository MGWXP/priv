#!/bin/bash
# mcp-credentials-manager.sh
# Wrapper script for the MCP Credentials Manager
# © 2025 XPV - MIT License

# Set directory paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
LOG_DIR="${ANCHOR_HOME}/logs"
MANAGER_PATH="${ANCHOR_HOME}/utils/mcp-credentials-manager.js"

# Create log directory if it doesn't exist
mkdir -p "${LOG_DIR}"

# Log function
log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "${LOG_DIR}/mcp-credentials-manager.log"
}

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
  log "ERROR: Node.js is not installed or not in PATH"
  echo "❌ Error: Node.js is required but not found."
  echo "Please install Node.js and try again."
  exit 1
fi

# Check if the manager script exists
if [ ! -f "${MANAGER_PATH}" ]; then
  log "ERROR: MCP Credentials Manager script not found at ${MANAGER_PATH}"
  echo "❌ Error: MCP Credentials Manager script not found."
  exit 1
fi

# Ensure the script is executable
chmod +x "${MANAGER_PATH}"

# Run the credentials manager
log "Starting MCP Credentials Manager"
node "${MANAGER_PATH}" "$@"
status=$?

# Check the exit status
if [ $status -ne 0 ]; then
  log "ERROR: MCP Credentials Manager exited with status ${status}"
  echo "❌ Error: MCP Credentials Manager encountered an error."
  exit $status
else
  log "MCP Credentials Manager completed successfully"
fi

# Ask if Claude Desktop should be restarted
read -p "Would you like to restart Claude Desktop to apply changes? (y/n): " restart_claude

if [[ "${restart_claude}" =~ ^[Yy]$ ]]; then
  log "Restarting Claude Desktop"
  echo "Restarting Claude Desktop..."
  
  # Attempt to close Claude Desktop gracefully
  pkill -x "Claude"
  
  # Wait a moment for the app to close
  sleep 2
  
  # Launch Claude Desktop
  open -a "Claude"
  
  log "Claude Desktop restarted"
  echo "✅ Claude Desktop has been restarted."
else
  echo "Please remember to restart Claude Desktop manually to apply the changes."
fi

exit 0
