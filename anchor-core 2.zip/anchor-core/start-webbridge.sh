#!/bin/bash
# WebSocket Bridge Startup Script - Optimized for M3 Max hardware
# Updated: 2025-05-19

# Define variables
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
SOCKET_DIR="$ANCHOR_HOME/sockets"
LOG_DIR="/Users/XPV/Library/Logs/Claude"
SRC_DIR="$ANCHOR_HOME/src"
WS_PORT=8765
NOTION_SYNC_INTERVAL=10000
ENABLE_DASHBOARD=true
ENABLE_NOTION_SYNC=true
ENABLE_HTTP2=true

# M3 Max optimizations
NODE_OPTIONS="--max-old-space-size=8192"
UV_THREADPOOL_SIZE=16
NODE_PERFORMANCE_MODE="high"

# Export environment variables
export ANCHOR_HOME SOCKET_DIR LOG_DIR WS_PORT NOTION_SYNC_INTERVAL ENABLE_HTTP2
export NODE_OPTIONS UV_THREADPOOL_SIZE NODE_PERFORMANCE_MODE

# Print banner
echo "======================================================"
echo "  CNIF - Claude-Notion Integration Framework"
echo "  Optimized for M3 Max hardware"
echo "  Starting services..."
echo "======================================================"

# Create necessary directories
mkdir -p "$SOCKET_DIR" "$LOG_DIR" "$SRC_DIR/webbridge" "$SRC_DIR/dashboard"

# Kill any existing instances
if [ -f "$ANCHOR_HOME/webbridge.pid" ]; then
  OLD_PID=$(cat "$ANCHOR_HOME/webbridge.pid")
  if [ -n "$OLD_PID" ]; then
    echo "Stopping existing WebSocket bridge (PID: $OLD_PID)"
    kill $OLD_PID 2>/dev/null || true
  fi
  rm -f "$ANCHOR_HOME/webbridge.pid"
fi

if [ -f "$ANCHOR_HOME/notion-sync.pid" ]; then
  OLD_PID=$(cat "$ANCHOR_HOME/notion-sync.pid")
  if [ -n "$OLD_PID" ]; then
    echo "Stopping existing Notion sync (PID: $OLD_PID)"
    kill $OLD_PID 2>/dev/null || true
  fi
  rm -f "$ANCHOR_HOME/notion-sync.pid"
fi

if [ -f "$ANCHOR_HOME/dashboard.pid" ]; then
  OLD_PID=$(cat "$ANCHOR_HOME/dashboard.pid")
  if [ -n "$OLD_PID" ]; then
    echo "Stopping existing dashboard server (PID: $OLD_PID)"
    kill $OLD_PID 2>/dev/null || true
  fi
  rm -f "$ANCHOR_HOME/dashboard.pid"
fi

# Check if required node modules are installed
if [ ! -d "$ANCHOR_HOME/node_modules/ws" ] || [ ! -d "$ANCHOR_HOME/node_modules/express" ]; then
  echo "Installing required Node.js modules..."
  cd "$ANCHOR_HOME"
  npm install ws express uuid http2-express-bridge @notionhq/client limiter sqlite3 sqlite
fi

# Setup Notion API token directory
NOTION_DIR="$HOME/.notion"
if [ ! -d "$NOTION_DIR" ]; then
  mkdir -p "$NOTION_DIR"
  chmod 700 "$NOTION_DIR"
  if [ -n "$NOTION_API_TOKEN" ]; then
    echo "$NOTION_API_TOKEN" > "$NOTION_DIR/token"
    chmod 600 "$NOTION_DIR/token"
    echo "✅ Saved Notion API token to $NOTION_DIR/token"
  else
    echo "⚠️ Notion API token not provided. Set NOTION_API_TOKEN environment variable or create ~/.notion/token file."
  fi
fi

# Start WebSocket bridge
echo "Starting WebSocket bridge..."
node "$SRC_DIR/webbridge/socket-bridge.js" > "$LOG_DIR/webbridge-$(date +%Y%m%d).log" 2>&1 &
SOCKET_BRIDGE_PID=$!
echo $SOCKET_BRIDGE_PID > "$ANCHOR_HOME/webbridge.pid"
echo "✅ Started WebSocket bridge with PID $SOCKET_BRIDGE_PID"

# Wait for WebSocket bridge to initialize
echo "Waiting for WebSocket bridge to initialize..."
sleep 3

# Verify WebSocket bridge is running
if ! ps -p $SOCKET_BRIDGE_PID > /dev/null; then
  echo "❌ WebSocket bridge failed to start. Check logs at $LOG_DIR/webbridge-$(date +%Y%m%d).log"
  exit 1
fi

# Start Notion sync if enabled
if [ "$ENABLE_NOTION_SYNC" = "true" ]; then
  echo "Starting Notion sync..."
  node "$SRC_DIR/webbridge/notion-sync.js" > "$LOG_DIR/notion-sync-$(date +%Y%m%d).log" 2>&1 &
  NOTION_SYNC_PID=$!
  echo $NOTION_SYNC_PID > "$ANCHOR_HOME/notion-sync.pid"
  echo "✅ Started Notion sync with PID $NOTION_SYNC_PID"
  
  # Verify Notion sync is running
  sleep 1
  if ! ps -p $NOTION_SYNC_PID > /dev/null; then
    echo "❌ Notion sync failed to start. Check logs at $LOG_DIR/notion-sync-$(date +%Y%m%d).log"
  fi
fi

# Start dashboard if enabled
if [ "$ENABLE_DASHBOARD" = "true" ]; then
  # Create package.json for dashboard if it doesn't exist
  if [ ! -f "$ANCHOR_HOME/dashboard/package.json" ]; then
    mkdir -p "$ANCHOR_HOME/dashboard"
    cat > "$ANCHOR_HOME/dashboard/package.json" << EOF
{
  "name": "cnif-dashboard",
  "version": "1.0.0",
  "description": "Dashboard for Claude-Notion Integration Framework",
  "main": "index.js",
  "scripts": {
    "start": "echo 'Dashboard is available at http://localhost:$WS_PORT' && sleep infinity"
  },
  "author": "XPV",
  "license": "MIT"
}
EOF
    echo "Created dashboard package.json"
  fi
  
  # Start dashboard server
  echo "Starting dashboard server..."
  cd "$ANCHOR_HOME/dashboard"
  npm start > "$LOG_DIR/dashboard-$(date +%Y%m%d).log" 2>&1 &
  DASHBOARD_PID=$!
  echo $DASHBOARD_PID > "$ANCHOR_HOME/dashboard.pid"
  echo "✅ Started dashboard server with PID $DASHBOARD_PID"
  echo "Dashboard is available at http://localhost:$WS_PORT"
fi

echo "======================================================"
echo "✅ WebSocket bridge initialization complete"
echo "✅ Socket directory: $SOCKET_DIR"
echo "✅ Log directory: $LOG_DIR"
echo "To stop all services: bash -c 'kill \$(cat $ANCHOR_HOME/webbridge.pid $ANCHOR_HOME/notion-sync.pid $ANCHOR_HOME/dashboard.pid 2>/dev/null)'"
echo "======================================================"
