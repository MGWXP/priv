#!/usr/bin/env node

const net = require('net');
const socketPath = process.argv[2];

if (!socketPath) {
  console.error('Error: Socket path must be provided as first argument');
  process.exit(1);
}

// Connect to the Unix socket
const socket = net.createConnection({ path: socketPath });

let stdInBuffer = '';
let socketBuffer = '';

// Handle connection
socket.on('connect', () => {
  console.error(`Successfully connected to ${socketPath}`);
});

// Handle socket data - forward to stdout
socket.on('data', (data) => {
  process.stdout.write(data);
});

// Handle stdin data - forward to socket
process.stdin.on('data', (data) => {
  socket.write(data);
});

// Handle errors
socket.on('error', (err) => {
  console.error(`Socket error: ${err.message}`);
  process.exit(1);
});

// Handle close
socket.on('close', () => {
  console.error('Socket connection closed');
  process.exit(0);
});

// Handle process termination
process.on('SIGINT', () => {
  socket.destroy();
  process.exit(0);
});

process.on('SIGTERM', () => {
  socket.destroy();
  process.exit(0);
});
