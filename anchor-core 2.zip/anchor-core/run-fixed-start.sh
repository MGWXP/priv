#!/bin/bash
# Run this to execute the fixed CNIF starter
chmod +x /Users/XPV/Desktop/anchor-core/cnif-start.sh
/Users/XPV/Desktop/anchor-core/cnif-start.sh
