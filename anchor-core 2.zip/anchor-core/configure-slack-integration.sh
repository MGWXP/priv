#!/bin/bash
# configure-slack-integration.sh - Sets up Slack Integration for Anchor Workspace
# For M3 Max (48GB unified memory) hardware

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

echo -e "${BLUE}=== Configuring Slack Integration ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e ""

# Check if SLACK_API_TOKEN is set
if [ -z "${SLACK_API_TOKEN}" ]; then
    echo -e "${YELLOW}SLACK_API_TOKEN environment variable is not set${NC}"
    echo -e "Would you like to set it now? (y/n)"
    read -r response
    if [[ "$response" =~ ^([yY][eE][sS]|[yY])$ ]]; then
        echo -e "Enter your Slack API Token:"
        read -s SLACK_TOKEN
        export SLACK_API_TOKEN="$SLACK_TOKEN"
        echo -e "${GREEN}✓ SLACK_API_TOKEN set${NC}"
    else
        echo -e "${RED}Cannot proceed without Slack API Token${NC}"
        exit 1
    fi
fi

# Check if NOTION_API_KEY is set (needed for updating Notion)
if [ -z "${NOTION_API_KEY}" ]; then
    echo -e "${YELLOW}NOTION_API_KEY environment variable is not set${NC}"
    echo -e "This is needed for updating the Notion tasks. Would you like to set it now? (y/n)"
    read -r response
    if [[ "$response" =~ ^([yY][eE][sS]|[yY])$ ]]; then
        echo -e "Enter your Notion API Key:"
        read -s NOTION_KEY
        export NOTION_API_KEY="$NOTION_KEY"
        echo -e "${GREEN}✓ NOTION_API_KEY set${NC}"
    else
        echo -e "${YELLOW}Will proceed without updating Notion tasks${NC}"
        SKIP_NOTION_UPDATE=true
    fi
fi

# Setup Slack config
echo -e "Setting up Slack configuration..."
mkdir -p /Users/XPV/Desktop/anchor-core/config
cat > /Users/XPV/Desktop/anchor-core/config/slack-config.json << EOF
{
    "token": "${SLACK_API_TOKEN}",
    "appId": "A05M82T3X7N",
    "channels": {
        "alerts": "C05M4LRNW7F",
        "logs": "C05M4LRQB6D",
        "notifications": "C05M4LS1S9P"
    },
    "defaultChannel": "notifications",
    "botName": "Anchor Bot",
    "botIcon": ":anchor:",
    "retryAttempts": 3,
    "retryDelay": 2000,
    "maxThreadDepth": 5,
    "allowThreadReplies": true,
    "webhook": {
        "enabled": true,
        "url": "https://hooks.slack.com/services/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",
        "channel": "alerts"
    },
    "systemMetricsEnabled": true,
    "notificationThreshold": "INFO"
}
EOF

echo -e "${GREEN}✓ Slack configuration file created${NC}"

# Setup Slack MCP server
echo -e "Setting up Slack MCP server..."
cat > /Users/XPV/Desktop/anchor-core/mcp-servers/slack-integration.js << EOF
#!/usr/bin/env node
/**
 * slack-integration.js - Slack Integration MCP Server
 * For M3 Max (48GB unified memory) with UV_THREADPOOL_SIZE=12
 */

const { createServer } = require('@modelcontextprotocol/sdk/server/stdio');
const fs = require('fs');
const path = require('path');
const { WebClient } = require('@slack/web-api');
const { IncomingWebhook } = require('@slack/webhook');

// Set environment variables for optimization
process.env.UV_THREADPOOL_SIZE = '12';
process.env.NODE_OPTIONS = '--max-old-space-size=8192';

// Load configuration
const configPath = path.join(__dirname, '..', 'config', 'slack-config.json');
const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));

// Initialize Slack WebClient
const slack = new WebClient(config.token);

// Initialize webhook if enabled
let webhook = null;
if (config.webhook && config.webhook.enabled && config.webhook.url) {
    webhook = new IncomingWebhook(config.webhook.url);
}

// Function implementations
const functions = {
    // List channels
    slack_list_channels: async ({ cursor, limit = 100 }) => {
        try {
            const result = await slack.conversations.list({
                cursor,
                limit: Math.min(limit, 200),
                types: 'public_channel,private_channel'
            });
            return result;
        } catch (error) {
            console.error('Error listing channels:', error);
            throw new Error(\`Failed to list channels: \${error.message}\`);
        }
    },
    
    // Post message to channel
    slack_post_message: async ({ channel_id, text }) => {
        try {
            const result = await slack.chat.postMessage({
                channel: channel_id,
                text,
                username: config.botName,
                icon_emoji: config.botIcon
            });
            return result;
        } catch (error) {
            console.error('Error posting message:', error);
            throw new Error(\`Failed to post message: \${error.message}\`);
        }
    },
    
    // Reply to thread
    slack_reply_to_thread: async ({ channel_id, thread_ts, text }) => {
        try {
            const result = await slack.chat.postMessage({
                channel: channel_id,
                thread_ts,
                text,
                username: config.botName,
                icon_emoji: config.botIcon
            });
            return result;
        } catch (error) {
            console.error('Error replying to thread:', error);
            throw new Error(\`Failed to reply to thread: \${error.message}\`);
        }
    },
    
    // Add reaction
    slack_add_reaction: async ({ channel_id, timestamp, reaction }) => {
        try {
            const result = await slack.reactions.add({
                channel: channel_id,
                timestamp,
                name: reaction
            });
            return result;
        } catch (error) {
            console.error('Error adding reaction:', error);
            throw new Error(\`Failed to add reaction: \${error.message}\`);
        }
    },
    
    // Get channel history
    slack_get_channel_history: async ({ channel_id, limit = 10 }) => {
        try {
            const result = await slack.conversations.history({
                channel: channel_id,
                limit
            });
            return result;
        } catch (error) {
            console.error('Error getting channel history:', error);
            throw new Error(\`Failed to get channel history: \${error.message}\`);
        }
    },
    
    // Get thread replies
    slack_get_thread_replies: async ({ channel_id, thread_ts }) => {
        try {
            const result = await slack.conversations.replies({
                channel: channel_id,
                ts: thread_ts
            });
            return result;
        } catch (error) {
            console.error('Error getting thread replies:', error);
            throw new Error(\`Failed to get thread replies: \${error.message}\`);
        }
    },
    
    // Get users list
    slack_get_users: async ({ cursor, limit = 100 }) => {
        try {
            const result = await slack.users.list({
                cursor,
                limit: Math.min(limit, 200)
            });
            return result;
        } catch (error) {
            console.error('Error getting users:', error);
            throw new Error(\`Failed to get users: \${error.message}\`);
        }
    },
    
    // Get user profile
    slack_get_user_profile: async ({ user_id }) => {
        try {
            const result = await slack.users.info({
                user: user_id
            });
            return result;
        } catch (error) {
            console.error('Error getting user profile:', error);
            throw new Error(\`Failed to get user profile: \${error.message}\`);
        }
    }
};

// Create and start MCP server
const server = createServer({
    name: 'slack',
    description: 'Slack Integration MCP Server for Anchor',
    functions,
    onStart: () => {
        console.log(\`[MCP] Slack Integration server started with API Token: \${config.token.slice(0, 5)}...\${config.token.slice(-5)}\`);
        
        // Send startup notification to default channel
        const startupMessage = \`🚀 *Slack Integration MCP Server* has started at \${new Date().toISOString()}\n_Running on Node.js \${process.version} with \${process.env.UV_THREADPOOL_SIZE} threads_\`;
        
        slack.chat.postMessage({
            channel: config.channels.notifications,
            text: startupMessage,
            username: config.botName,
            icon_emoji: config.botIcon
        }).catch(error => {
            console.error('Error sending startup notification:', error);
        });
        
        // Create PID file
        const pidFile = path.join(__dirname, 'slack.pid');
        fs.writeFileSync(pidFile, process.pid.toString());
        console.log(\`[MCP] PID \${process.pid} written to \${pidFile}\`);
    },
    onStop: () => {
        console.log('[MCP] Slack Integration server stopping');
        
        // Remove PID file
        const pidFile = path.join(__dirname, 'slack.pid');
        if (fs.existsSync(pidFile)) {
            fs.unlinkSync(pidFile);
            console.log(\`[MCP] Removed PID file \${pidFile}\`);
        }
    }
});

// Handle errors
process.on('uncaughtException', (error) => {
    console.error('Uncaught exception:', error);
    const errorMessage = \`⚠️ *Slack Integration MCP Server Error*: \${error.message}\`;
    
    if (webhook) {
        webhook.send({
            text: errorMessage,
            channel: config.webhook.channel
        }).catch(console.error);
    }
});

// Handle signals
process.on('SIGINT', () => {
    console.log('[MCP] Received SIGINT signal');
    server.stop();
    process.exit(0);
});

process.on('SIGTERM', () => {
    console.log('[MCP] Received SIGTERM signal');
    server.stop();
    process.exit(0);
});
EOF

# Make the script executable
chmod +x /Users/XPV/Desktop/anchor-core/mcp-servers/slack-integration.js
echo -e "${GREEN}✓ Slack MCP server script created and made executable${NC}"

# Create startup script
cat > /Users/XPV/Desktop/anchor-core/start-slack-integration.sh << EOF
#!/bin/bash
# Start the Slack Integration MCP Server

# Check if server is already running
if [ -f "/Users/XPV/Desktop/anchor-core/mcp-servers/slack.pid" ]; then
    PID=\$(cat /Users/XPV/Desktop/anchor-core/mcp-servers/slack.pid)
    if ps -p \$PID > /dev/null; then
        echo "Slack Integration server is already running with PID \$PID"
        exit 0
    else
        echo "Removing stale PID file"
        rm -f /Users/XPV/Desktop/anchor-core/mcp-servers/slack.pid
    fi
fi

# Export environment variables
export UV_THREADPOOL_SIZE=12
export NODE_OPTIONS="--max-old-space-size=8192"

# Start the server
echo "Starting Slack Integration MCP Server..."
cd /Users/XPV/Desktop/anchor-core
node ./mcp-servers/slack-integration.js > ./logs/slack.out 2>&1 &

echo "Slack Integration MCP Server started. Check logs in ./logs/slack.out"
EOF

# Make the script executable
chmod +x /Users/XPV/Desktop/anchor-core/start-slack-integration.sh
echo -e "${GREEN}✓ Slack startup script created and made executable${NC}"

# Create LaunchAgent for automatic startup
mkdir -p /Users/XPV/Desktop/anchor-core/launch_agents
cat > /Users/XPV/Desktop/anchor-core/launch_agents/com.anchor.slack.plist << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.anchor.slack</string>
    <key>ProgramArguments</key>
    <array>
        <string>/Users/XPV/Desktop/anchor-core/start-slack-integration.sh</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>/Users/XPV/Desktop/anchor-core/logs/slack.out</string>
    <key>StandardErrorPath</key>
    <string>/Users/XPV/Desktop/anchor-core/logs/slack.err</string>
    <key>EnvironmentVariables</key>
    <dict>
        <key>UV_THREADPOOL_SIZE</key>
        <string>12</string>
        <key>NODE_OPTIONS</key>
        <string>--max-old-space-size=8192</string>
        <key>SLACK_API_TOKEN</key>
        <string>${SLACK_API_TOKEN}</string>
    </dict>
    <key>WorkingDirectory</key>
    <string>/Users/XPV/Desktop/anchor-core</string>
</dict>
</plist>
EOF

echo -e "${GREEN}✓ LaunchAgent configuration created${NC}"

# Register the LaunchAgent (commented out for safety)
echo -e "${YELLOW}To register the LaunchAgent, run:${NC}"
echo -e "cp /Users/XPV/Desktop/anchor-core/launch_agents/com.anchor.slack.plist ~/Library/LaunchAgents/"
echo -e "launchctl load ~/Library/LaunchAgents/com.anchor.slack.plist"

# Create test script for the Slack integration
cat > /Users/XPV/Desktop/anchor-core/test-slack-integration.sh << EOF
#!/bin/bash
# Test the Slack Integration

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

echo -e "${YELLOW}Testing Slack Integration...${NC}"

# Test if the server is running
if [ -f "/Users/XPV/Desktop/anchor-core/mcp-servers/slack.pid" ]; then
    PID=\$(cat /Users/XPV/Desktop/anchor-core/mcp-servers/slack.pid)
    if ps -p \$PID > /dev/null; then
        echo -e "${GREEN}✓ Slack Integration server is running with PID \$PID${NC}"
    else
        echo -e "${RED}× Slack Integration server PID file exists but process is not running${NC}"
        exit 1
    fi
else
    echo -e "${RED}× Slack Integration server is not running${NC}"
    exit 1
fi

# Check if API token is set
if [ -z "${SLACK_API_TOKEN}" ]; then
    echo -e "${RED}× SLACK_API_TOKEN environment variable is not set${NC}"
    exit 1
fi

# Test Slack API with curl
echo -e "Testing Slack API connection..."
RESPONSE=\$(curl -s -X POST "https://slack.com/api/auth.test" \
  -H "Authorization: Bearer ${SLACK_API_TOKEN}" \
  -H "Content-Type: application/json")

if echo \$RESPONSE | grep -q '"ok":true'; then
    echo -e "${GREEN}✓ Successfully connected to Slack API${NC}"
    TEAM=\$(echo \$RESPONSE | grep -o '"team":"[^"]*' | cut -d'"' -f4)
    USER=\$(echo \$RESPONSE | grep -o '"user":"[^"]*' | cut -d'"' -f4)
    echo -e "   Connected as: \$USER"
    echo -e "   Team: \$TEAM"
else
    echo -e "${RED}× Failed to connect to Slack API${NC}"
    echo \$RESPONSE
    exit 1
fi

echo -e "\n${GREEN}✓ Slack Integration is properly configured!${NC}"
EOF

# Make the script executable
chmod +x /Users/XPV/Desktop/anchor-core/test-slack-integration.sh
echo -e "${GREEN}✓ Slack test script created and made executable${NC}"

# Update the Notion task to mark Slack integration as completed
if [ -z "$SKIP_NOTION_UPDATE" ]; then
    echo -e "Updating Notion task to mark Slack integration as completed..."
    curl -s -X PATCH "https://api.notion.com/v1/blocks/1f8e48c2-efff-450c-b4ea-f73d6b9e5b4f" \
      -H "Authorization: Bearer ${NOTION_API_KEY}" \
      -H "Content-Type: application/json" \
      -H "Notion-Version: 2022-06-28" \
      --data '{
        "to_do": {
            "checked": true
        }
      }'
    echo -e "${GREEN}✓ Notion task updated${NC}"
fi

echo -e "\n${GREEN}✓ Slack Integration setup complete!${NC}"
echo -e "${YELLOW}To start the Slack Integration, run:${NC}"
echo -e "/Users/XPV/Desktop/anchor-core/start-slack-integration.sh"
echo -e "\n${YELLOW}To test the Slack Integration, run:${NC}"
echo -e "/Users/XPV/Desktop/anchor-core/test-slack-integration.sh"
