#!/bin/bash
# clean-coherence-markers.sh - Clean up coherence markers
# © 2025 XPV - MIT

set -e

# Define colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color
BLUE='\033[0;34m'

# Base paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
COHERENCE_LOCK_DIR="$ANCHOR_HOME/coherence_lock"

echo -e "${BLUE}Cleaning Up Coherence Markers${NC}"
echo -e "${BLUE}=========================${NC}"

# Check if coherence directory exists
if [ ! -d "$COHERENCE_LOCK_DIR" ]; then
  echo -e "${YELLOW}Creating coherence lock directory: $COHERENCE_LOCK_DIR${NC}"
  mkdir -p "$COHERENCE_LOCK_DIR"
  echo -e "${GREEN}✅ Coherence lock directory created${NC}"
  exit 0
fi

# Count existing markers
marker_count=$(find "$COHERENCE_LOCK_DIR" -name "*.marker" 2>/dev/null | wc -l)
if [ "$marker_count" -eq 0 ]; then
  echo -e "${GREEN}✅ No coherence markers found to clean${NC}"
  exit 0
fi

echo -e "${YELLOW}Found $marker_count coherence markers to clean${NC}"

# Remove all marker files
find "$COHERENCE_LOCK_DIR" -name "*.marker" -delete
echo -e "${GREEN}✅ All coherence markers removed${NC}"

echo -e "${BLUE}Coherence lock directory is now clean${NC}"
