#!/bin/bash
# launch-enhanced-servers.sh - Launch enhanced socket servers for Anchor System V6
# © 2025 XPV - MIT

set -e

ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
MCP_DIR="${ANCHOR_HOME}/mcp-servers"
LOG_DIR="${HOME}/Library/Logs/Claude"
SOCKET_DIR="${ANCHOR_HOME}/sockets"

# Load environment variables
if [ -f "${ANCHOR_HOME}/.env" ]; then
  source "${ANCHOR_HOME}/.env"
fi

# Make sure directories exist
mkdir -p "${SOCKET_DIR}"
mkdir -p "${LOG_DIR}"

# Stop any running servers
echo "🛑 Stopping existing servers..."
pkill -f "git-local-optimized.js" 2>/dev/null || true
pkill -f "notion-v5-wrapper.js" 2>/dev/null || true
pkill -f "anchor-manager-optimized.js" 2>/dev/null || true
pkill -f "socket-server-implementation.js" 2>/dev/null || true
pkill -f "enhanced-socket-server.js" 2>/dev/null || true
sleep 1

# Clean up PID files and stale sockets
rm -f "${MCP_DIR}"/*.pid 2>/dev/null || true
rm -f "${SOCKET_DIR}"/*.sock 2>/dev/null || true

# Start enhanced socket servers
echo "🚀 Starting enhanced socket servers..."

# Launch Git Local server
echo "🚀 Launching Git Local socket server..."
MCP_SERVER_NAME="git-local" \
  node --expose-gc "${ANCHOR_HOME}/enhanced-socket-server.js" > "${LOG_DIR}/mcp-server-git-local.log" 2>&1 &
echo $! > "${MCP_DIR}/git-local.pid"

# Launch Notion server
echo "🚀 Launching Notion socket server..."
MCP_SERVER_NAME="notion" \
  node --expose-gc "${ANCHOR_HOME}/enhanced-socket-server.js" > "${LOG_DIR}/mcp-server-notion.log" 2>&1 &
echo $! > "${MCP_DIR}/notion.pid"

# Launch Anchor Manager server
echo "🚀 Launching Anchor Manager socket server..."
MCP_SERVER_NAME="anchor-manager" \
  node --expose-gc "${ANCHOR_HOME}/enhanced-socket-server.js" > "${LOG_DIR}/mcp-server-anchor-manager.log" 2>&1 &
echo $! > "${MCP_DIR}/anchor-manager.pid"

echo "✅ All enhanced socket servers launched!"
echo "📂 Socket files located in: ${SOCKET_DIR}"
echo "📊 To verify, run: ${ANCHOR_HOME}/verify-enhanced-servers.sh"
