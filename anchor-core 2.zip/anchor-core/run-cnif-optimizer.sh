#!/bin/bash
# run-cnif-optimizer.sh - Run CNIF optimizer for M3 Max hardware
# © 2025 XPV - MIT

ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
LOG_DIR="${HOME}/Library/Logs/Claude"
TIMESTAMP=$(date +"%Y%m%d%H%M%S")
LOG_FILE="${LOG_DIR}/m3-optimizer-${TIMESTAMP}.log"

# Ensure log directory exists
mkdir -p "${LOG_DIR}"

# Log function
log() {
  echo "$(date +"%Y-%m-%d %H:%M:%S") $1" | tee -a "${LOG_FILE}"
}

log "🚀 Running CNIF M3 Max optimizer..."

# Check if optimizer exists
if [ ! -f "${ANCHOR_HOME}/m3-optimizer/m3-cnif-optimizer.js" ]; then
  log "❌ Optimizer script not found at ${ANCHOR_HOME}/m3-optimizer/m3-cnif-optimizer.js"
  exit 1
fi

# Run the optimizer
log "📋 Executing optimizer..."
node "${ANCHOR_HOME}/m3-optimizer/m3-cnif-optimizer.js" | tee -a "${LOG_FILE}"

log "📋 Checking for optimized launcher..."

# Check if the launcher was created
if [ -f "${ANCHOR_HOME}/m3-optimized-launcher.sh" ]; then
  # Make the optimized launcher executable
  chmod +x "${ANCHOR_HOME}/m3-optimized-launcher.sh"
  log "✅ Made optimized launcher executable"
  log "✅ M3 Max optimization complete"
  log "🔧 Use ${ANCHOR_HOME}/m3-optimized-launcher.sh to start CNIF with optimized settings"
else
  log "❌ Failed to create optimized launcher"
  log "📋 Creating fallback launcher..."
  
  # Create a basic fallback launcher
  cat > "${ANCHOR_HOME}/m3-optimized-launcher.sh" << EOF
#!/bin/bash
# m3-optimized-launcher.sh - M3 Max optimized launcher for CNIF (FALLBACK VERSION)
# © 2025 XPV - MIT
# Generated: $(date)

# Default optimizations
export NODE_OPTIONS="--max-old-space-size=8192"
export UV_THREADPOOL_SIZE="12"
export CNIF_BUFFER_SIZE="65536"
export CNIF_SCHEMA_CACHE_SIZE="256"
export CNIF_SOCKET_BACKLOG="128"
export CNIF_POOL_SIZE="8"
export CNIF_XML_CHUNK_SIZE="16384"
export CNIF_JSON_CHUNK_SIZE="16384"
export CNIF_USE_ASYNC_HOOKS="true"
export CNIF_LOG_LEVEL="info"
export CNIF_COHERENCE_ENABLED="true"
export CNIF_CIRCUIT_BREAKER_ENABLED="true"
export ANCHOR_HOME="${ANCHOR_HOME}"

# Print optimization info
echo "✅ M3 Max optimizations applied (fallback)"
echo "🧠 Memory allocation: \${NODE_OPTIONS}"
echo "⚙️ Thread pool size: \${UV_THREADPOOL_SIZE}"
echo "📊 Buffer size: \${CNIF_BUFFER_SIZE}"

# Launch the sequenced launcher with optimizations
"\${ANCHOR_HOME}/sequenced-launcher.sh" "\$@"
EOF
  
  # Make it executable
  chmod +x "${ANCHOR_HOME}/m3-optimized-launcher.sh"
  log "✅ Created fallback launcher at ${ANCHOR_HOME}/m3-optimized-launcher.sh"
fi

log "📋 Optimization process complete. Log saved to ${LOG_FILE}"
