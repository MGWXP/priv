#!/bin/bash
# setup-dashboard-views.sh - Creates Dashboard Views for Anchor Workspace
# For M3 Max (48GB unified memory) hardware

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

NOTION_PAGE_ID="1f7e48c2-bbbd-80df-86ed-d35832916f80"

echo -e "${BLUE}=== Setting Up Dashboard Views ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e ""

# Check if NOTION_API_KEY is set
if [ -z "${NOTION_API_KEY}" ]; then
    echo -e "${YELLOW}NOTION_API_KEY environment variable is not set${NC}"
    echo -e "Would you like to set it now? (y/n)"
    read -r response
    if [[ "$response" =~ ^([yY][eE][sS]|[yY])$ ]]; then
        echo -e "Enter your Notion API Key:"
        read -s NOTION_KEY
        export NOTION_API_KEY="$NOTION_KEY"
        echo -e "${GREEN}✓ NOTION_API_KEY set${NC}"
    else
        echo -e "${RED}Cannot proceed without Notion API Key${NC}"
        exit 1
    fi
fi

# Load database IDs
AGENT_REGISTRY_ID=$(cat /Users/XPV/Desktop/anchor-core/notion-db-ids/agent-registry-id.txt | head -1)
COMPONENT_LIBRARY_ID=$(cat /Users/XPV/Desktop/anchor-core/notion-db-ids/component-library-id.txt | head -1)
PROJECT_TRACKER_ID=$(cat /Users/XPV/Desktop/anchor-core/notion-db-ids/project-tracker-id.txt | head -1)

# Check if system metrics database ID exists
if [ -f "/Users/XPV/Desktop/anchor-core/notion-db-ids/system-metrics-id.txt" ]; then
    SYSTEM_METRICS_ID=$(cat /Users/XPV/Desktop/anchor-core/notion-db-ids/system-metrics-id.txt | head -1)
else
    echo -e "${YELLOW}System Metrics database ID not found. Will skip related views.${NC}"
    SYSTEM_METRICS_ID=""
fi

# Create a Dashboard page
echo -e "Creating Main Dashboard page..."
DASHBOARD_RESPONSE=$(curl -s -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "parent": {
        "page_id": "'"${NOTION_PAGE_ID}"'"
    },
    "properties": {
        "title": [
            {
                "text": {
                    "content": "Anchor Dashboard"
                }
            }
        ]
    },
    "children": [
        {
            "object": "block",
            "type": "heading_1",
            "heading_1": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Anchor System Dashboard"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "paragraph",
            "paragraph": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Main operational dashboard for the Anchor workspace. Last updated: '"$(date '+%Y-%m-%d %H:%M:%S')"'"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Active Components"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "linked_database",
            "linked_database": {
                "database_id": "'"${COMPONENT_LIBRARY_ID}"'"
            }
        },
        {
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Active Agents"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "linked_database",
            "linked_database": {
                "database_id": "'"${AGENT_REGISTRY_ID}"'"
            }
        },
        {
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Project Status"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "linked_database",
            "linked_database": {
                "database_id": "'"${PROJECT_TRACKER_ID}"'"
            }
        }
    ]
}')

# Extract dashboard page ID from response
DASHBOARD_ID=$(echo $DASHBOARD_RESPONSE | grep -o '"id":"[^"]*' | cut -d'"' -f4 | head -1)

if [ -z "$DASHBOARD_ID" ]; then
    echo -e "${RED}Failed to create Dashboard page${NC}"
    echo $DASHBOARD_RESPONSE
    exit 1
fi

echo -e "${GREEN}✓ Main Dashboard page created successfully!${NC}"
echo -e "Dashboard ID: ${DASHBOARD_ID}"

# Add System Metrics view if available
if [ ! -z "$SYSTEM_METRICS_ID" ]; then
    echo -e "Adding System Metrics view to Dashboard..."
    
    METRICS_VIEW_RESPONSE=$(curl -s -X PATCH "https://api.notion.com/v1/blocks/${DASHBOARD_ID}/children" \
      -H "Authorization: Bearer ${NOTION_API_KEY}" \
      -H "Content-Type: application/json" \
      -H "Notion-Version: 2022-06-28" \
      --data '{
        "children": [
            {
                "object": "block",
                "type": "heading_2",
                "heading_2": {
                    "rich_text": [
                        {
                            "type": "text",
                            "text": {
                                "content": "System Metrics"
                            }
                        }
                    ]
                }
            },
            {
                "object": "block",
                "type": "linked_database",
                "linked_database": {
                    "database_id": "'"${SYSTEM_METRICS_ID}"'"
                }
            }
        ]
    }')
    
    if echo $METRICS_VIEW_RESPONSE | grep -q "error"; then
        echo -e "${YELLOW}System Metrics view added with warnings${NC}"
    else
        echo -e "${GREEN}✓ System Metrics view added successfully!${NC}"
    fi
fi

# Create a Project Dashboard page
echo -e "Creating Project Dashboard page..."
PROJECT_DASHBOARD_RESPONSE=$(curl -s -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "parent": {
        "page_id": "'"${NOTION_PAGE_ID}"'"
    },
    "properties": {
        "title": [
            {
                "text": {
                    "content": "Project Dashboard"
                }
            }
        ]
    },
    "children": [
        {
            "object": "block",
            "type": "heading_1",
            "heading_1": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Project Status Dashboard"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "paragraph",
            "paragraph": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Project tracking and status dashboard. Last updated: '"$(date '+%Y-%m-%d %H:%M:%S')"'"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Project Status Overview"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "linked_database",
            "linked_database": {
                "database_id": "'"${PROJECT_TRACKER_ID}"'"
            }
        },
        {
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Components by Status"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "linked_database",
            "linked_database": {
                "database_id": "'"${COMPONENT_LIBRARY_ID}"'"
            }
        }
    ]
}')

# Extract project dashboard page ID from response
PROJECT_DASHBOARD_ID=$(echo $PROJECT_DASHBOARD_RESPONSE | grep -o '"id":"[^"]*' | cut -d'"' -f4 | head -1)

if [ -z "$PROJECT_DASHBOARD_ID" ]; then
    echo -e "${RED}Failed to create Project Dashboard page${NC}"
    echo $PROJECT_DASHBOARD_RESPONSE
    exit 1
fi

echo -e "${GREEN}✓ Project Dashboard page created successfully!${NC}"
echo -e "Project Dashboard ID: ${PROJECT_DASHBOARD_ID}"

# Save dashboard IDs for future reference
mkdir -p /Users/XPV/Desktop/anchor-core/notion-dashboard-ids
echo "${DASHBOARD_ID}" > /Users/XPV/Desktop/anchor-core/notion-dashboard-ids/main-dashboard-id.txt
echo "${PROJECT_DASHBOARD_ID}" > /Users/XPV/Desktop/anchor-core/notion-dashboard-ids/project-dashboard-id.txt

echo -e "\n${GREEN}✓ Dashboard Views setup complete!${NC}"
echo -e "${YELLOW}View your Main Dashboard at: https://www.notion.so/${DASHBOARD_ID}${NC}"
echo -e "${YELLOW}View your Project Dashboard at: https://www.notion.so/${PROJECT_DASHBOARD_ID}${NC}"

# Mark the Dashboard Views task as completed
curl -X PATCH "https://api.notion.com/v1/blocks/1f8e48c2-deef-440b-a3e9-f82a5b8d4a3e" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "to_do": {
        "checked": true
    }
  }'
