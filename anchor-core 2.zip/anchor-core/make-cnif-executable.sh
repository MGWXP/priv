chmod +x /Users/XPV/Desktop/anchor-core/cnif.sh
echo "✅ CNIF master script is now executable"
echo "🚀 Usage: ./cnif.sh [start|stop|status|fix|logs|help]"
