#!/usr/bin/env node
/**
 * enhanced-socket-server.js - Unix socket server for MCP
 * Using enhanced Socket Manager for lifecycle management
 * © 2025 XPV - MIT
 */

const fs = require('fs').promises;
const fsSync = require('fs');
const path = require('path');
const net = require('net');
const os = require('os');

// Load environment variables
require('dotenv').config({ path: path.join(__dirname, '.env') });

// Configuration with proper defaults
const SERVER_NAME = process.env.MCP_SERVER_NAME || 'unknown';
const SOCKET_DIR = process.env.SOCKET_DIR || path.join(__dirname, 'sockets');
const SOCKET_PATH = path.join(SOCKET_DIR, `${SERVER_NAME}.sock`);
const LOG_DIR = process.env.LOG_DIR || path.join(process.env.HOME || os.homedir(), 'Library/Logs/Claude');
const LOG_FILE = path.join(LOG_DIR, `mcp-server-${SERVER_NAME}.log`);

// Set up logger
const logger = {
  info: (message, extra = {}) => log('INFO', message, extra),
  error: (message, extra = {}) => log('ERROR', message, extra),
  debug: (message, extra = {}) => log('DEBUG', message, extra),
  warn: (message, extra = {}) => log('WARN', message, extra)
};

// Logger implementation
function log(level, message, extra = {}) {
  const timestamp = new Date().toISOString();
  const logEntry = `${timestamp} [${SERVER_NAME}] [${level.toLowerCase()}] ${message} ${JSON.stringify(extra)}`;
  
  console.log(logEntry);
  
  try {
    fsSync.appendFileSync(LOG_FILE, logEntry + '\n');
  } catch (err) {
    console.error(`Failed to write to log file: ${err.message}`);
  }
}

// Socket Manager class for proper socket lifecycle management
class SocketManager {
  constructor(socketPath, options = {}) {
    this.socketPath = socketPath;
    this.options = {
      mode: 0o666,            // rw-rw-rw- permissions
      dirMode: 0o755,         // rwxr-xr-x for directory
      backlog: 511,           // Connection backlog
      keepAlive: true,        // Enable keepalive
      keepAliveInterval: 1000, // 1 second interval
      ...options
    };
    this.server = null;
    this.isListening = false;
  }

  async initialize() {
    try {
      // Check if socket directory exists, create if not
      const socketDir = path.dirname(this.socketPath);
      await this._ensureDirectory(socketDir, this.options.dirMode);
      
      // Check if socket file already exists, handle accordingly
      if (await this._exists(this.socketPath)) {
        try {
          fsSync.unlinkSync(this.socketPath);
          logger.info(`Removed existing socket at ${this.socketPath}`);
        } catch (err) {
          logger.error(`Failed to remove existing socket: ${err.message}`);
        }
      }
      
      return this;
    } catch (err) {
      logger.error(`Initialization error: ${err.message}`);
      throw err;
    }
  }

  createServer(connectionHandler) {
    this.server = net.createServer(connectionHandler);
    
    // Handle server errors
    this.server.on('error', (err) => {
      logger.error(`Server error: ${err.message}`);
      
      // Attempt recovery for specific errors
      if (err.code === 'EADDRINUSE') {
        logger.info(`Attempting to recover from EADDRINUSE error`);
        this._recoverFromAddressInUse();
      }
    });
    
    return this.server;
  }

  async listen() {
    if (!this.server) {
      throw new Error('Server not created. Call createServer() first');
    }

    return new Promise((resolve, reject) => {
      this.server.listen(this.socketPath, () => {
        try {
          // Set explicit permissions on socket file
          fsSync.chmodSync(this.socketPath, this.options.mode);
          this.isListening = true;
          logger.info(`Server listening on socket: ${this.socketPath}`);
          logger.info(`Socket permissions set to: 0${this.options.mode.toString(8)}`);
          resolve(this.server);
        } catch (err) {
          logger.error(`Failed to set socket permissions: ${err.message}`);
          reject(err);
        }
      });
    });
  }

  _recoverFromAddressInUse() {
    try {
      // Remove the socket file
      fsSync.unlinkSync(this.socketPath);
      logger.info(`Removed socket file for recovery: ${this.socketPath}`);
      
      // Try to listen again
      setTimeout(() => {
        logger.info(`Attempting to listen again after recovery`);
        this.server.listen(this.socketPath);
      }, 1000);
    } catch (err) {
      logger.error(`Recovery failed: ${err.message}`);
    }
  }

  async _exists(filePath) {
    try {
      await fs.access(filePath);
      return true;
    } catch (err) {
      return false;
    }
  }

  async _ensureDirectory(dirPath, mode) {
    try {
      await fs.mkdir(dirPath, { recursive: true, mode });
      logger.info(`Created directory: ${dirPath}`);
    } catch (err) {
      // Ignore if directory already exists
      if (err.code !== 'EEXIST') {
        throw err;
      }
    }
  }
}

// Ensure directories exist
async function ensureDirectories() {
  try {
    await fs.mkdir(SOCKET_DIR, { recursive: true });
    await fs.mkdir(LOG_DIR, { recursive: true });
    logger.info('Ensured directories exist', { socket_dir: SOCKET_DIR, log_dir: LOG_DIR });
  } catch (err) {
    logger.error(`Failed to create directories: ${err.message}`);
    process.exit(1);
  }
}

// Create PID file
async function createPidFile() {
  const pidDir = path.join(__dirname, 'mcp-servers');
  const pidPath = path.join(pidDir, `${SERVER_NAME}.pid`);
  
  try {
    // Ensure PID directory exists
    await fs.mkdir(pidDir, { recursive: true });
    
    // Write PID file
    await fs.writeFile(pidPath, String(process.pid));
    logger.info(`Created PID file: ${pidPath}`);
    
    // Clean up PID file on exit
    process.on('exit', () => {
      try {
        fsSync.unlinkSync(pidPath);
      } catch (err) {
        // Ignore errors during exit
      }
    });
  } catch (err) {
    logger.error(`Failed to create PID file: ${err.message}`);
  }
}

// Message handler
function handleMessage(socket, data) {
  try {
    // Parse the received data as JSON
    const message = JSON.parse(data.toString());
    logger.debug('Received message', { type: message.type });
    
    // Process the message based on type
    let response;
    if (message.type === 'handshake') {
      response = { 
        type: 'handshake_response', 
        status: 'success',
        server: SERVER_NAME,
        version: '1.0.0'
      };
    } else if (message.type === 'invoke_tool') {
      response = {
        type: 'tool_response',
        id: message.id || 'unknown',
        status: 'success',
        result: `Mock response from ${SERVER_NAME} tool: ${message.tool || 'unknown'}`
      };
    } else {
      response = {
        type: 'error_response',
        status: 'error',
        error: `Unknown message type: ${message.type}`
      };
    }
    
    // Send response
    socket.write(JSON.stringify(response) + '\n');
    logger.debug('Sent response', { type: response.type });
  } catch (err) {
    logger.error(`Failed to process message: ${err.message}`);
    
    // Send error response
    const errorResponse = {
      type: 'error_response',
      status: 'error',
      error: `Failed to process message: ${err.message}`
    };
    socket.write(JSON.stringify(errorResponse) + '\n');
  }
}

// Main function
async function main() {
  try {
    logger.info(`Starting ${SERVER_NAME} MCP socket server (PID: ${process.pid})`);
    
    // Ensure directories exist
    await ensureDirectories();
    
    // Create PID file
    await createPidFile();
    
    // Initialize socket manager
    const socketManager = new SocketManager(SOCKET_PATH);
    await socketManager.initialize();
    
    // Create server with socket manager
    const server = socketManager.createServer((socket) => {
      logger.info('Client connected');
      
      socket.on('data', (data) => {
        handleMessage(socket, data);
      });
      
      socket.on('end', () => {
        logger.info('Client disconnected');
      });
      
      socket.on('error', (err) => {
        logger.error(`Socket error: ${err.message}`);
      });
    });
    
    // Start listening
    await socketManager.listen();
    
    // Set up heartbeat for health monitoring
    setInterval(() => {
      logger.debug('Heartbeat: Server running with 0 pending requests', {});
    }, 5000);
    
    // Handle signals for graceful shutdown
    process.on('SIGINT', () => {
      logger.info('Received SIGINT, shutting down');
      process.exit(0);
    });
    
    process.on('SIGTERM', () => {
      logger.info('Received SIGTERM, shutting down');
      process.exit(0);
    });
    
    // Handle uncaught exceptions
    process.on('uncaughtException', (err) => {
      logger.error(`Uncaught exception: ${err.message}`);
      process.exit(1);
    });
    
  } catch (err) {
    logger.error(`Server initialization error: ${err.message}`);
    process.exit(1);
  }
}

// Start the server
main().catch(err => {
  console.error(`Failed to start server: ${err.message}`);
  process.exit(1);
});
