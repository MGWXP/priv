# MCP Socket Troubleshooting Guide

Based on the error messages shown in Claude's interface, we've identified that while our MCP servers are running correctly, they're not properly creating Unix socket files that Claude can connect to.

## The Issue

The previous implementation used mock classes but didn't actually create Unix domain socket files that Claude needs to establish a connection. This is why you're seeing:

1. "MCP git-local: Server disconnected" message
2. Warning triangles next to the server names in Developer settings

## How To Fix It

I've created a complete solution that implements actual Unix domain socket servers. Follow these steps:

1. Make the fix script executable:
   ```bash
   chmod +x /Users/XPV/Desktop/anchor-core/one-step-mcp-fix.sh
   ```

2. Run the all-in-one fix script:
   ```bash
   /Users/XPV/Desktop/anchor-core/one-step-mcp-fix.sh
   ```

3. Restart Claude application
   - This is necessary for Claude to reconnect to the new socket files

4. Check Developer settings again
   - The warning triangles should be gone
   - The servers should show as connected

## What The Fix Does

The new implementation:

1. Creates proper Unix domain socket files in the expected locations
2. Implements a basic protocol for Claude to communicate with the servers
3. Ensures file permissions are set correctly for socket access
4. Updates Claude's configuration to point to the correct socket files

## Technical Details

The socket server implementation:
- Uses Node.js `net` module to create Unix domain socket servers
- Handles client connections and message parsing
- Provides mock responses to tool invocations
- Manages socket file lifecycle (creation, permissions, cleanup)

## Verifying the Fix

After running the fix, verify that:
1. Socket files exist in `/Users/XPV/Desktop/anchor-core/sockets`
2. Socket server processes are running
3. Claude no longer shows warning triangles in Developer settings
4. MCP tools can be used without disconnection errors

## Maintaining the Setup

To restart the socket servers if needed:
```bash
/Users/XPV/Desktop/anchor-core/socket-server-launcher.sh
```

To verify socket server status:
```bash
/Users/XPV/Desktop/anchor-core/verify-socket-servers.sh
```
