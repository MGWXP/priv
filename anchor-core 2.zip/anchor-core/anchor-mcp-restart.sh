#!/bin/bash
# anchor-mcp-restart.sh - Restarts MCP server processes
# For M3 Max (48GB unified memory) hardware

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

echo -e "${BLUE}=== Anchor MCP Server Restart ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e "Hardware Target: M3 Max (48GB unified memory)"

# Kill existing MCP server processes if running
echo -e "${BLUE}Stopping existing MCP server processes...${NC}"

if [ -f "/Users/XPV/Desktop/anchor-core/mcp-servers/git-local.pid" ]; then
    pid=$(cat /Users/XPV/Desktop/anchor-core/mcp-servers/git-local.pid)
    if ps -p $pid > /dev/null; then
        kill $pid
        echo -e "${GREEN}✓ Stopped git server process (PID: $pid)${NC}"
    else
        echo -e "${YELLOW}Git server process not running${NC}"
    fi
fi

if [ -f "/Users/XPV/Desktop/anchor-core/mcp-servers/slack.pid" ]; then
    pid=$(cat /Users/XPV/Desktop/anchor-core/mcp-servers/slack.pid)
    if ps -p $pid > /dev/null; then
        kill $pid
        echo -e "${GREEN}✓ Stopped slack server process (PID: $pid)${NC}"
    else
        echo -e "${YELLOW}Slack server process not running${NC}"
    fi
fi

if [ -f "/Users/XPV/Desktop/anchor-core/mcp-servers/notion.pid" ]; then
    pid=$(cat /Users/XPV/Desktop/anchor-core/mcp-servers/notion.pid)
    if ps -p $pid > /dev/null; then
        kill $pid
        echo -e "${GREEN}✓ Stopped notion server process (PID: $pid)${NC}"
    else
        echo -e "${YELLOW}Notion server process not running${NC}"
    fi
fi

# Start MCP server processes
echo -e "${BLUE}Starting MCP server processes...${NC}"

# Start Git server
NODE_OPTIONS="--max-old-space-size=8192" UV_THREADPOOL_SIZE=12 node /Users/XPV/Desktop/anchor-core/mcp-servers/git-local-optimized.js > /dev/null 2>&1 &
echo $! > /Users/XPV/Desktop/anchor-core/mcp-servers/git-local.pid
echo -e "${GREEN}✓ Started git server process (PID: $!)${NC}"

# Start Slack server
NODE_OPTIONS="--max-old-space-size=8192" UV_THREADPOOL_SIZE=12 node /Users/XPV/Desktop/anchor-core/mcp-servers/slack-wrapper.js > /dev/null 2>&1 &
echo $! > /Users/XPV/Desktop/anchor-core/mcp-servers/slack.pid
echo -e "${GREEN}✓ Started slack server process (PID: $!)${NC}"

# Start Notion server
NODE_OPTIONS="--max-old-space-size=8192" UV_THREADPOOL_SIZE=12 node /Users/XPV/Desktop/anchor-core/mcp-servers/notion-v5-wrapper.js > /dev/null 2>&1 &
echo $! > /Users/XPV/Desktop/anchor-core/mcp-servers/notion.pid
echo -e "${GREEN}✓ Started notion server process (PID: $!)${NC}"

echo -e "\n${GREEN}✓ All MCP servers started!${NC}"
echo -e "${YELLOW}Please restart Claude Desktop to apply the changes.${NC}"
