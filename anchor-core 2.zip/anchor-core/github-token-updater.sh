#!/bin/bash
# Quick GitHub Token Updater
# © 2025 XPV - MIT License

# Set directory paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
LOG_DIR="${ANCHOR_HOME}/logs"
CLAUDE_CONFIG_DIR="${HOME}/Library/Application Support/Claude"
CLAUDE_CONFIG_FILE="${CLAUDE_CONFIG_DIR}/claude_desktop_config.json"

# Create log directory if it doesn't exist
mkdir -p "${LOG_DIR}"

# Log function
log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "${LOG_DIR}/github-token-updater.log"
}

# Title
echo "╔═══════════════════════════════════════╗"
echo "║       GITHUB TOKEN QUICK UPDATER      ║"
echo "╚═══════════════════════════════════════╝"
echo

# Check if Claude config file exists
if [ ! -f "${CLAUDE_CONFIG_FILE}" ]; then
  log "Claude config file not found: ${CLAUDE_CONFIG_FILE}"
  echo "❌ Claude Desktop config file not found."
  echo "Please run Claude Desktop at least once to create the config file."
  exit 1
fi

# Backup current config
BACKUP_FILE="${CLAUDE_CONFIG_FILE}.bak.$(date '+%Y%m%d%H%M%S')"
log "Backing up Claude config to ${BACKUP_FILE}"
cp "${CLAUDE_CONFIG_FILE}" "${BACKUP_FILE}"

# Read current config
log "Reading current Claude config"
CURRENT_CONFIG=$(cat "${CLAUDE_CONFIG_FILE}")

# Prompt for GitHub token
echo "Enter your GitHub Personal Access Token"
echo "This token should have the following scopes: repo, workflow, read:org"
echo "It will be stored directly in the Claude Desktop config file."
echo
read -p "GitHub Token: " GITHUB_TOKEN

if [ -z "${GITHUB_TOKEN}" ]; then
  log "No token provided. Exiting."
  echo "No token provided. Operation cancelled."
  exit 0
fi

# Check if GitHub MCP server already exists in config
if [[ "${CURRENT_CONFIG}" == *"\"github\""* ]]; then
  log "Updating existing GitHub MCP server config"
  
  # Use jq if available for proper JSON manipulation
  if command -v jq &> /dev/null; then
    # Update token in existing config
    UPDATED_CONFIG=$(echo "${CURRENT_CONFIG}" | jq --arg token "${GITHUB_TOKEN}" '
      if .mcpServers.github.env.GITHUB_PERSONAL_ACCESS_TOKEN then
        .mcpServers.github.env.GITHUB_PERSONAL_ACCESS_TOKEN = $token
      else
        .mcpServers.github.env += {"GITHUB_PERSONAL_ACCESS_TOKEN": $token}
      end
    ')
    
    # Check if "env" key exists in github server, create if not
    if [[ "${CURRENT_CONFIG}" != *"\"github\""*"\"env\""* ]]; then
      UPDATED_CONFIG=$(echo "${CURRENT_CONFIG}" | jq --arg token "${GITHUB_TOKEN}" '
        .mcpServers.github.env = {
          "NODE_OPTIONS": "--max-old-space-size=8192",
          "UV_THREADPOOL_SIZE": "12",
          "GITHUB_PERSONAL_ACCESS_TOKEN": $token,
          "GITHUB_TOOLSETS": "repos,issues,pull_requests,code_security,experiments,enterprise"
        }
      ')
    fi
  else
    # Fallback to basic sed replacement (less reliable)
    log "jq not found. Using basic replacement."
    UPDATED_CONFIG=$(echo "${CURRENT_CONFIG}" | sed "s/\"GITHUB_PERSONAL_ACCESS_TOKEN\": \"[^\"]*\"/\"GITHUB_PERSONAL_ACCESS_TOKEN\": \"${GITHUB_TOKEN}\"/g")
  fi
else
  log "Adding new GitHub MCP server config"
  
  # Use jq if available for proper JSON manipulation
  if command -v jq &> /dev/null; then
    # Add completely new github server config
    UPDATED_CONFIG=$(echo "${CURRENT_CONFIG}" | jq --arg token "${GITHUB_TOKEN}" '
      .mcpServers.github = {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-github"],
        "env": {
          "NODE_OPTIONS": "--max-old-space-size=8192",
          "UV_THREADPOOL_SIZE": "12",
          "GITHUB_PERSONAL_ACCESS_TOKEN": $token,
          "GITHUB_TOOLSETS": "repos,issues,pull_requests,code_security,experiments,enterprise"
        }
      }
    ')
  else
    # Fallback to template-based solution (less reliable)
    log "jq not found. Using template solution."
    
    # Format the new server config
    GITHUB_SERVER_CONFIG=$(cat << EOF
  "github": {
    "command": "npx",
    "args": [
      "-y",
      "@modelcontextprotocol/server-github"
    ],
    "env": {
      "NODE_OPTIONS": "--max-old-space-size=8192",
      "UV_THREADPOOL_SIZE": "12",
      "GITHUB_PERSONAL_ACCESS_TOKEN": "${GITHUB_TOKEN}",
      "GITHUB_TOOLSETS": "repos,issues,pull_requests,code_security,experiments,enterprise"
    }
  }
EOF
    )
    
    # Insert before the last "}" in the mcpServers object
    LAST_BRACE_POSITION=$(echo "${CURRENT_CONFIG}" | grep -n -m 2 "}" | tail -n 1 | cut -d: -f1)
    
    if [ -n "${LAST_BRACE_POSITION}" ]; then
      FIRST_PART=$(echo "${CURRENT_CONFIG}" | head -n "$((LAST_BRACE_POSITION - 1))")
      LAST_PART=$(echo "${CURRENT_CONFIG}" | tail -n "+${LAST_BRACE_POSITION}")
      
      # Check if we need to add a comma before the new server
      if [[ "${FIRST_PART}" == *"}"* ]]; then
        FIRST_PART="${FIRST_PART},"
      fi
      
      UPDATED_CONFIG="${FIRST_PART}${GITHUB_SERVER_CONFIG}${LAST_PART}"
    else
      log "Error finding insertion point in config file"
      echo "❌ Error updating config file. Structure not recognized."
      exit 1
    fi
  fi
fi

# Save the updated config
log "Saving updated config"
echo "${UPDATED_CONFIG}" > "${CLAUDE_CONFIG_FILE}"

log "GitHub token update completed"
echo "✅ GitHub token updated successfully!"
echo

# Ask if Claude Desktop should be restarted
read -p "Would you like to restart Claude Desktop now? (y/n): " restart_claude

if [[ "${restart_claude}" =~ ^[Yy]$ ]]; then
  log "Restarting Claude Desktop"
  echo "Restarting Claude Desktop..."
  
  # Attempt to close Claude Desktop gracefully
  pkill -x "Claude"
  
  # Wait a moment for the app to close
  sleep 2
  
  # Launch Claude Desktop
  open -a "Claude"
  
  log "Claude Desktop restarted"
  echo "✅ Claude Desktop has been restarted."
else
  echo "Remember to restart Claude Desktop manually to apply the changes."
fi

exit 0
