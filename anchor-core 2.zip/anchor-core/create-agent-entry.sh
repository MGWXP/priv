#!/bin/bash
# create-agent-entry.sh - Creates a sample agent entry in the Agent Registry
# For M3 Max (48GB unified memory) hardware

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

# The actual database ID from the creation response
DATABASE_ID="1f8e48c2-bbbd-8149-aa90-ced3c874efb6"

echo -e "${BLUE}=== Creating Sample Agent Entry in Agent Registry ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e "Target database: ${DATABASE_ID}"
echo -e ""

# Check if NOTION_API_KEY is set
if [ -z "${NOTION_API_KEY}" ]; then
    echo -e "${RED}Error: NOTION_API_KEY environment variable is not set${NC}"
    echo -e "Please set your Notion API key first with:"
    echo -e "export NOTION_API_KEY=\"your_notion_api_key\""
    exit 1
fi

# Create a sample agent entry
echo -e "${BLUE}Creating sample agent entry for filesystem MCP server...${NC}"

curl -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "parent": {
        "database_id": "'"${DATABASE_ID}"'"
    },
    "properties": {
        "Agent ID": {
            "title": [
                {
                    "text": {
                        "content": "AGT-0001"
                    }
                }
            ]
        },
        "Kind": {
            "multi_select": [
                { "name": "Core" }
            ]
        },
        "Status": {
            "select": {
                "name": "Active"
            }
        },
        "Skills": {
            "multi_select": [
                { "name": "Git" },
                { "name": "Notion API" }
            ]
        },
        "Perf Score": {
            "number": 0.95
        },
        "Last Active": {
            "date": {
                "start": "'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'"
            }
        },
        "Load %": {
            "number": 0.25
        }
    }
}'

echo -e "\n${GREEN}✓ Sample agent entry created successfully!${NC}"

# Create another agent entry for the git-local MCP server
echo -e "${BLUE}Creating sample agent entry for git-local MCP server...${NC}"

curl -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "parent": {
        "database_id": "'"${DATABASE_ID}"'"
    },
    "properties": {
        "Agent ID": {
            "title": [
                {
                    "text": {
                        "content": "AGT-0002"
                    }
                }
            ]
        },
        "Kind": {
            "multi_select": [
                { "name": "Core" },
                { "name": "Utility" }
            ]
        },
        "Status": {
            "select": {
                "name": "Active"
            }
        },
        "Skills": {
            "multi_select": [
                { "name": "Git" }
            ]
        },
        "Perf Score": {
            "number": 0.87
        },
        "Last Active": {
            "date": {
                "start": "'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'"
            }
        },
        "Load %": {
            "number": 0.15
        }
    }
}'

echo -e "\n${GREEN}✓ Second agent entry created successfully!${NC}"
