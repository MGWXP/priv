#!/bin/bash
# make-cnif-system-executable.sh - Make all CNIF system scripts executable
# © 2025 XPV - MIT

# Set execution permissions on CNIF scripts
chmod +x /Users/XPV/Desktop/anchor-core/sequenced-launcher.sh
chmod +x /Users/XPV/Desktop/anchor-core/cnif-system-check.sh
chmod +x /Users/XPV/Desktop/anchor-core/fix-socket-permissions.sh
chmod +x /Users/XPV/Desktop/anchor-core/cnif-integration-test.sh
chmod +x /Users/XPV/Desktop/anchor-core/simple-launcher.sh

# If an optimized launcher was generated, make it executable
if [ -f /Users/XPV/Desktop/anchor-core/m3-optimized-launcher.sh ]; then
  chmod +x /Users/XPV/Desktop/anchor-core/m3-optimized-launcher.sh
fi

echo "✅ Made all CNIF system scripts executable"
