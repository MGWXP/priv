#!/bin/bash
# create-project-tracker.sh - Creates the Project Tracker database
# For M3 Max (48GB unified memory) hardware

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

NOTION_PAGE_ID="1f7e48c2-bbbd-80df-86ed-d35832916f80"

echo -e "${BLUE}=== Creating Project Tracker Database in Notion ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e ""

# Check if NOTION_API_KEY is set
if [ -z "${NOTION_API_KEY}" ]; then
    echo -e "${RED}Error: NOTION_API_KEY environment variable is not set${NC}"
    echo -e "Please set your Notion API key first with:"
    echo -e "export NOTION_API_KEY=\"your_notion_api_key\""
    exit 1
fi

# Create the Project Tracker database
echo -e "${BLUE}Creating Project Tracker database...${NC}"

RESPONSE=$(curl -s -X POST "https://api.notion.com/v1/databases" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "parent": {
        "type": "page_id",
        "page_id": "'${NOTION_PAGE_ID}'"
    },
    "title": [
        {
            "type": "text",
            "text": {
                "content": "Project Tracker"
            }
        }
    ],
    "properties": {
        "Proj ID": {
            "title": {}
        },
        "Stage": {
            "select": {
                "options": [
                    { "name": "Planning", "color": "blue" },
                    { "name": "Build", "color": "yellow" },
                    { "name": "Review", "color": "orange" },
                    { "name": "Done", "color": "green" }
                ]
            }
        },
        "Progress %": {
            "number": {
                "format": "percent"
            }
        },
        "Risk": {
            "select": {
                "options": [
                    { "name": "Low", "color": "green" },
                    { "name": "Med", "color": "yellow" },
                    { "name": "High", "color": "red" }
                ]
            }
        },
        "Budget (h)": {
            "number": {
                "format": "number"
            }
        },
        "Due": {
            "date": {}
        },
        "Description": {
            "rich_text": {}
        }
    }
}')

echo $RESPONSE

# Extract the database ID from the response
DATABASE_ID=$(echo $RESPONSE | grep -o '"id":"[^"]*"' | sed 's/"id":"//g' | sed 's/"//g')

echo -e "\n${GREEN}✓ Project Tracker database created successfully!${NC}"
echo -e "${YELLOW}Database ID: ${DATABASE_ID}${NC}"

# Create a sample project entry
echo -e "${BLUE}Creating sample project entry for MCP Integration...${NC}"

curl -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "parent": {
        "database_id": "'"${DATABASE_ID}"'"
    },
    "properties": {
        "Proj ID": {
            "title": [
                {
                    "text": {
                        "content": "PRJ-2025-001"
                    }
                }
            ]
        },
        "Stage": {
            "select": {
                "name": "Build"
            }
        },
        "Progress %": {
            "number": 0.65
        },
        "Risk": {
            "select": {
                "name": "Low"
            }
        },
        "Budget (h)": {
            "number": 40
        },
        "Due": {
            "date": {
                "start": "2025-05-25"
            }
        },
        "Description": {
            "rich_text": [
                {
                    "text": {
                        "content": "Integrate MCP servers with Notion workspace for comprehensive system monitoring and management."
                    }
                }
            ]
        }
    }
}'

echo -e "\n${GREEN}✓ Sample project entry created successfully!${NC}"

# Create another project entry
echo -e "${BLUE}Creating sample project entry for Slack Integration...${NC}"

curl -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "parent": {
        "database_id": "'"${DATABASE_ID}"'"
    },
    "properties": {
        "Proj ID": {
            "title": [
                {
                    "text": {
                        "content": "PRJ-2025-002"
                    }
                }
            ]
        },
        "Stage": {
            "select": {
                "name": "Planning"
            }
        },
        "Progress %": {
            "number": 0.15
        },
        "Risk": {
            "select": {
                "name": "Med"
            }
        },
        "Budget (h)": {
            "number": 25
        },
        "Due": {
            "date": {
                "start": "2025-06-10"
            }
        },
        "Description": {
            "rich_text": [
                {
                    "text": {
                        "content": "Set up Slack MCP server integration for team communications and automated notifications."
                    }
                }
            ]
        }
    }
}'

echo -e "\n${GREEN}✓ Second project entry created successfully!${NC}"

# Save the database ID to a local file for future reference
echo -e "${BLUE}Saving database ID for future reference...${NC}"
echo "${DATABASE_ID}" > /Users/XPV/Desktop/anchor-core/project-tracker-db-id.txt

echo -e "\n${GREEN}✓ Project Tracker setup complete!${NC}"
echo -e "${YELLOW}View your database at: https://www.notion.so/${DATABASE_ID}${NC}"
