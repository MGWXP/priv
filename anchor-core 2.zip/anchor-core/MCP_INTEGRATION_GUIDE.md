# MCP Server Integration Documentation
# Version: 1.0.0 (2025-05-18)

## Overview

This documentation explains the MCP (Model Context Protocol) server integration setup for Claude Desktop, optimized for M3 Max hardware. The integration includes the following MCP servers:

- Filesystem
- Git
- SQLite
- Notion
- Slack
- Anchor Manager

## Setup Instructions

1. Run the integration setup script:
   ```bash
   chmod +x /Users/XPV/Desktop/anchor-core/run-mcp-integration.sh
   /Users/XPV/Desktop/anchor-core/run-mcp-integration.sh
   ```

2. This script will:
   - Fix permission issues with scripts
   - Configure the MCP servers
   - Create necessary directories
   - Create optimized launch scripts
   - Launch all MCP servers

3. Restart Claude Desktop to apply the changes

## Server Details

### Filesystem Server
- Official MCP server from modelcontextprotocol
- Provides file system access to specified directories

### Git Server
- Custom implementation based on modelcontextprotocol/servers/git
- Provides Git repository operations
- Configured paths: /Users/XPV/Documents/Git, /Users/XPV/Desktop/Projects

### SQLite Server
- Custom implementation based on better-sqlite3
- Provides database operations for SQLite databases
- Data directory: /Users/XPV/Desktop/anchor-core/data/sqlite

### Notion Server
- Custom implementation using @notionhq/client
- Provides Notion API integration with caching in SQLite
- Fixed initialization issues and optimized for M3 Max

### Slack Server
- Custom implementation using @slack/web-api
- Provides Slack API integration with caching
- Requires Slack tokens to be configured in .env file

### Anchor Manager Server
- Custom implementation for system management
- Handles coordination between MCP servers

## Configuration

The MCP server configuration is stored in:
- `/Users/XPV/Library/Application Support/Claude/claude_desktop_config.json`

Environment variables are set in:
- `/Users/XPV/Desktop/anchor-core/.env`

## Optimization for M3 Max

- Node.js memory allocation: 16GB (--max-old-space-size=16384)
- Thread pool size: 12 threads (UV_THREADPOOL_SIZE=12)
- SQLite optimizations: WAL journal mode, memory mapping
- Connection pooling and caching mechanisms

## Troubleshooting

If you encounter issues:

1. Check the server status:
   ```bash
   /Users/XPV/Desktop/anchor-core/verify-mcp-servers.sh
   ```

2. Check the logs in:
   ```
   /Users/XPV/Library/Logs/Claude/
   ```

3. Restart the servers:
   ```bash
   /Users/XPV/Desktop/anchor-core/launch-mcp-servers.sh
   ```

4. Ensure permissions are set correctly:
   ```bash
   /Users/XPV/Desktop/anchor-core/make-scripts-executable.sh
   ```

## Additional n8n Integration

For n8n integration:
1. Download n8n-mcp-server from https://github.com/leonardsellem/n8n-mcp-server
2. Install dependencies with 'npm install'
3. Add the server to your Claude configuration file
