#!/bin/bash
# update-anchor-setup.sh - Updates the complete-anchor-setup.sh script to include new options
# For M3 Max (48GB unified memory) hardware

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

echo -e "${BLUE}=== Updating Anchor Setup Script ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e ""

# Backup the original script
cp /Users/XPV/Desktop/anchor-core/complete-anchor-setup.sh /Users/XPV/Desktop/anchor-core/complete-anchor-setup.sh.bak
echo -e "${GREEN}✓ Original script backed up to complete-anchor-setup.sh.bak${NC}"

# Update the script with new options
cat > /Users/XPV/Desktop/anchor-core/complete-anchor-setup.sh << 'EOF'
#!/bin/bash
# complete-anchor-setup.sh - Creates all databases for the Anchor workspace
# For M3 Max (48GB unified memory) hardware

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

AGENT_REGISTRY_ID="1f8e48c2-bbbd-8149-aa90-ced3c874efb6"
NOTION_PAGE_ID="1f7e48c2-bbbd-80df-86ed-d35832916f80"

echo -e "${BLUE}=== Complete Anchor Workspace Setup ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e ""

# Make all scripts executable
chmod +x /Users/XPV/Desktop/anchor-core/create-agent-entry.sh
chmod +x /Users/XPV/Desktop/anchor-core/create-component-library.sh
chmod +x /Users/XPV/Desktop/anchor-core/create-project-tracker.sh
chmod +x /Users/XPV/Desktop/anchor-core/create-system-metrics-db.sh
chmod +x /Users/XPV/Desktop/anchor-core/create-documentation-db.sh
chmod +x /Users/XPV/Desktop/anchor-core/create-meeting-notes-db.sh
chmod +x /Users/XPV/Desktop/anchor-core/setup-dashboard-views.sh
chmod +x /Users/XPV/Desktop/anchor-core/configure-slack-integration.sh
chmod +x /Users/XPV/Desktop/anchor-core/create-remaining-databases.sh

# Check if NOTION_API_KEY is set
if [ -z "${NOTION_API_KEY}" ]; then
    echo -e "${YELLOW}NOTION_API_KEY environment variable is not set${NC}"
    echo -e "Would you like to set it now? (y/n)"
    read -r response
    if [[ "$response" =~ ^([yY][eE][sS]|[yY])$ ]]; then
        echo -e "Enter your Notion API Key:"
        read -s NOTION_KEY
        export NOTION_API_KEY="$NOTION_KEY"
        echo -e "${GREEN}✓ NOTION_API_KEY set${NC}"
    else
        echo -e "${RED}Cannot proceed without Notion API Key${NC}"
        exit 1
    fi
fi

# Create a directory to store database IDs
mkdir -p /Users/XPV/Desktop/anchor-core/notion-db-ids

# Save the Agent Registry ID
echo "${AGENT_REGISTRY_ID}" > /Users/XPV/Desktop/anchor-core/notion-db-ids/agent-registry-id.txt

# Create a status tracking file
echo "Agent Registry: Created (ID: ${AGENT_REGISTRY_ID})" > /Users/XPV/Desktop/anchor-core/notion-db-status.txt

# Display menu
echo -e "${BLUE}Please select an action:${NC}"
echo -e "1. Complete setup (all databases and integrations)"
echo -e "2. Complete setup (only core databases)"
echo -e "3. Complete setup (all remaining databases)"
echo -e "4. Create Agent entries"
echo -e "5. Create Component Library database"
echo -e "6. Create Project Tracker database"
echo -e "7. Create System Metrics database"
echo -e "8. Create Documentation database"
echo -e "9. Create Meeting Notes database"
echo -e "10. Setup Dashboard Views"
echo -e "11. Configure Slack Integration"
echo -e "12. View database IDs"
echo -e "13. Exit"
read -p "Enter your choice (1-13): " choice

case $choice in
    1)
        echo -e "\n${YELLOW}Running complete setup (all databases and integrations)...${NC}"
        
        # Add agent entries
        /Users/XPV/Desktop/anchor-core/create-agent-entry.sh
        echo "Agent entries: Created" >> /Users/XPV/Desktop/anchor-core/notion-db-status.txt
        
        # Create Component Library
        /Users/XPV/Desktop/anchor-core/create-component-library.sh
        COMP_DB_ID=$(cat /Users/XPV/Desktop/anchor-core/component-library-db-id.txt)
        echo "${COMP_DB_ID}" > /Users/XPV/Desktop/anchor-core/notion-db-ids/component-library-id.txt
        echo "Component Library: Created (ID: ${COMP_DB_ID})" >> /Users/XPV/Desktop/anchor-core/notion-db-status.txt
        
        # Create Project Tracker
        /Users/XPV/Desktop/anchor-core/create-project-tracker.sh
        PROJ_DB_ID=$(cat /Users/XPV/Desktop/anchor-core/project-tracker-db-id.txt)
        echo "${PROJ_DB_ID}" > /Users/XPV/Desktop/anchor-core/notion-db-ids/project-tracker-id.txt
        echo "Project Tracker: Created (ID: ${PROJ_DB_ID})" >> /Users/XPV/Desktop/anchor-core/notion-db-status.txt
        
        # Create all remaining databases
        /Users/XPV/Desktop/anchor-core/create-remaining-databases.sh
        ;;
    2)
        echo -e "\n${YELLOW}Running complete setup (only core databases)...${NC}"
        
        # Add agent entries
        /Users/XPV/Desktop/anchor-core/create-agent-entry.sh
        echo "Agent entries: Created" >> /Users/XPV/Desktop/anchor-core/notion-db-status.txt
        
        # Create Component Library
        /Users/XPV/Desktop/anchor-core/create-component-library.sh
        COMP_DB_ID=$(cat /Users/XPV/Desktop/anchor-core/component-library-db-id.txt)
        echo "${COMP_DB_ID}" > /Users/XPV/Desktop/anchor-core/notion-db-ids/component-library-id.txt
        echo "Component Library: Created (ID: ${COMP_DB_ID})" >> /Users/XPV/Desktop/anchor-core/notion-db-status.txt
        
        # Create Project Tracker
        /Users/XPV/Desktop/anchor-core/create-project-tracker.sh
        PROJ_DB_ID=$(cat /Users/XPV/Desktop/anchor-core/project-tracker-db-id.txt)
        echo "${PROJ_DB_ID}" > /Users/XPV/Desktop/anchor-core/notion-db-ids/project-tracker-id.txt
        echo "Project Tracker: Created (ID: ${PROJ_DB_ID})" >> /Users/XPV/Desktop/anchor-core/notion-db-status.txt
        
        # Update the Next Steps to-do list on the main page to mark items as completed
        echo -e "${BLUE}Updating Next Steps to mark completed items...${NC}"
        
        # Mark Agent Registry as completed
        curl -X PATCH "https://api.notion.com/v1/blocks/1f8e48c2-bbbd-8138-a456-fa678599690a" \
          -H "Authorization: Bearer ${NOTION_API_KEY}" \
          -H "Content-Type: application/json" \
          -H "Notion-Version: 2022-06-28" \
          --data '{
            "to_do": {
                "checked": true
            }
          }'
        
        # Mark Component Library as completed
        curl -X PATCH "https://api.notion.com/v1/blocks/1f8e48c2-bbbd-81d0-a193-c3e670faaba5" \
          -H "Authorization: Bearer ${NOTION_API_KEY}" \
          -H "Content-Type: application/json" \
          -H "Notion-Version: 2022-06-28" \
          --data '{
            "to_do": {
                "checked": true
            }
          }'
        
        # Mark Project Tracker as completed
        curl -X PATCH "https://api.notion.com/v1/blocks/1f8e48c2-bbbd-816a-95d0-da3111b5eebb" \
          -H "Authorization: Bearer ${NOTION_API_KEY}" \
          -H "Content-Type: application/json" \
          -H "Notion-Version: 2022-06-28" \
          --data '{
            "to_do": {
                "checked": true
            }
          }'
        
        # Add a note to the main page about completed setup
        curl -X PATCH "https://api.notion.com/v1/blocks/${NOTION_PAGE_ID}/children" \
          -H "Authorization: Bearer ${NOTION_API_KEY}" \
          -H "Content-Type: application/json" \
          -H "Notion-Version: 2022-06-28" \
          --data '{
            "children": [
              {
                "object": "block",
                "type": "callout",
                "callout": {
                  "rich_text": [
                    {
                      "type": "text",
                      "text": {
                        "content": "Core databases created and populated:\n• Agent Registry\n• Component Library\n• Project Tracker\n\nAll database IDs have been saved to /Users/XPV/Desktop/anchor-core/notion-db-ids/"
                      }
                    }
                  ],
                  "icon": {
                    "emoji": "✅"
                  },
                  "color": "green_background"
                }
              }
            ]
          }'
        ;;
    3)
        echo -e "\n${YELLOW}Running setup for all remaining databases...${NC}"
        /Users/XPV/Desktop/anchor-core/create-remaining-databases.sh
        ;;
    4)
        echo -e "\n${YELLOW}Creating Agent entries...${NC}"
        /Users/XPV/Desktop/anchor-core/create-agent-entry.sh
        echo "Agent entries: Created" >> /Users/XPV/Desktop/anchor-core/notion-db-status.txt
        ;;
    5)
        echo -e "\n${YELLOW}Creating Component Library database...${NC}"
        /Users/XPV/Desktop/anchor-core/create-component-library.sh
        COMP_DB_ID=$(cat /Users/XPV/Desktop/anchor-core/component-library-db-id.txt)
        echo "${COMP_DB_ID}" > /Users/XPV/Desktop/anchor-core/notion-db-ids/component-library-id.txt
        echo "Component Library: Created (ID: ${COMP_DB_ID})" >> /Users/XPV/Desktop/anchor-core/notion-db-status.txt
        ;;
    6)
        echo -e "\n${YELLOW}Creating Project Tracker database...${NC}"
        /Users/XPV/Desktop/anchor-core/create-project-tracker.sh
        PROJ_DB_ID=$(cat /Users/XPV/Desktop/anchor-core/project-tracker-db-id.txt)
        echo "${PROJ_DB_ID}" > /Users/XPV/Desktop/anchor-core/notion-db-ids/project-tracker-id.txt
        echo "Project Tracker: Created (ID: ${PROJ_DB_ID})" >> /Users/XPV/Desktop/anchor-core/notion-db-status.txt
        ;;
    7)
        echo -e "\n${YELLOW}Creating System Metrics database...${NC}"
        /Users/XPV/Desktop/anchor-core/create-system-metrics-db.sh
        ;;
    8)
        echo -e "\n${YELLOW}Creating Documentation database...${NC}"
        /Users/XPV/Desktop/anchor-core/create-documentation-db.sh
        ;;
    9)
        echo -e "\n${YELLOW}Creating Meeting Notes database...${NC}"
        /Users/XPV/Desktop/anchor-core/create-meeting-notes-db.sh
        ;;
    10)
        echo -e "\n${YELLOW}Setting up Dashboard Views...${NC}"
        /Users/XPV/Desktop/anchor-core/setup-dashboard-views.sh
        ;;
    11)
        echo -e "\n${YELLOW}Configuring Slack Integration...${NC}"
        /Users/XPV/Desktop/anchor-core/configure-slack-integration.sh
        ;;
    12)
        echo -e "\n${YELLOW}Database IDs:${NC}"
        echo -e "Agent Registry: ${AGENT_REGISTRY_ID}"
        
        if [ -f "/Users/XPV/Desktop/anchor-core/notion-db-ids/component-library-id.txt" ]; then
            COMP_ID=$(head -1 /Users/XPV/Desktop/anchor-core/notion-db-ids/component-library-id.txt)
            echo -e "Component Library: ${COMP_ID}"
        else
            echo -e "Component Library: Not created yet"
        fi
        
        if [ -f "/Users/XPV/Desktop/anchor-core/notion-db-ids/project-tracker-id.txt" ]; then
            PROJ_ID=$(head -1 /Users/XPV/Desktop/anchor-core/notion-db-ids/project-tracker-id.txt)
            echo -e "Project Tracker: ${PROJ_ID}"
        else
            echo -e "Project Tracker: Not created yet"
        fi
        
        if [ -f "/Users/XPV/Desktop/anchor-core/notion-db-ids/system-metrics-id.txt" ]; then
            METRICS_ID=$(head -1 /Users/XPV/Desktop/anchor-core/notion-db-ids/system-metrics-id.txt)
            echo -e "System Metrics: ${METRICS_ID}"
        else
            echo -e "System Metrics: Not created yet"
        fi
        
        if [ -f "/Users/XPV/Desktop/anchor-core/notion-db-ids/documentation-id.txt" ]; then
            DOCS_ID=$(head -1 /Users/XPV/Desktop/anchor-core/notion-db-ids/documentation-id.txt)
            echo -e "Documentation: ${DOCS_ID}"
        else
            echo -e "Documentation: Not created yet"
        fi
        
        if [ -f "/Users/XPV/Desktop/anchor-core/notion-db-ids/meeting-notes-id.txt" ]; then
            MEETING_ID=$(head -1 /Users/XPV/Desktop/anchor-core/notion-db-ids/meeting-notes-id.txt)
            echo -e "Meeting Notes: ${MEETING_ID}"
        else
            echo -e "Meeting Notes: Not created yet"
        fi
        ;;
    13)
        echo -e "\n${YELLOW}Exiting. No changes made.${NC}"
        exit 0
        ;;
    *)
        echo -e "\n${RED}Invalid choice. Please select 1-13.${NC}"
        exit 1
        ;;
esac

echo -e "\n${GREEN}✓ Anchor database setup operation complete!${NC}"
echo -e "${YELLOW}View your workspace at: https://www.notion.so/Anchor-${NOTION_PAGE_ID}${NC}"
echo -e "${YELLOW}Database status has been saved to: /Users/XPV/Desktop/anchor-core/notion-db-status.txt${NC}"
EOF

# Make the updated script executable
chmod +x /Users/XPV/Desktop/anchor-core/complete-anchor-setup.sh

echo -e "${GREEN}✓ Anchor Setup script has been updated with new options${NC}"
echo -e "${YELLOW}The script now includes options for:${NC}"
echo -e "  - Creating System Metrics database"
echo -e "  - Creating Documentation database"
echo -e "  - Creating Meeting Notes database"
echo -e "  - Setting up Dashboard Views"
echo -e "  - Configuring Slack Integration"
echo -e "  - Creating all remaining databases at once"
echo -e "\n${BLUE}Run the updated script with:${NC}"
echo -e "./complete-anchor-setup.sh"
