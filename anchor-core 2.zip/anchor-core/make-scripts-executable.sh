#!/bin/bash
# make-scripts-executable.sh - Make all shell scripts executable
# © 2025 XPV - MIT

echo "Making scripts executable..."

# Make verify-after-archival.sh executable
chmod +x /Users/XPV/Desktop/anchor-core/verify-after-archival.sh
echo "✓ Made verify-after-archival.sh executable"

# Make all .sh files in the root directory executable
find /Users/XPV/Desktop/anchor-core -type f -name "*.sh" -maxdepth 1 -exec chmod +x {} \;
echo "✓ Made all .sh files in root directory executable"

# Make all .sh files in the mcp-servers directory executable
find /Users/XPV/Desktop/anchor-core/mcp-servers -type f -name "*.sh" -exec chmod +x {} \;
echo "✓ Made all .sh files in mcp-servers directory executable"

echo "All scripts are now executable!"
