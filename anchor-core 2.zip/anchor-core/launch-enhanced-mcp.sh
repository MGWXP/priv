#!/bin/bash
# Enhanced MCP Server Launcher for M3 Max
# Optimized for M3 Max with 48GB unified memory
# © 2025 XPV - MIT License

set -e  # Exit on error

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
RED='\033[0;31m'
BOLD='\033[1m'
NC='\033[0m'  # No Color

# Core paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
SOCKET_DIR="${ANCHOR_HOME}/sockets"
MCP_DIR="${ANCHOR_HOME}/mcp-servers"
LOG_DIR="${HOME}/Library/Logs/Claude"
DATA_DIR="${ANCHOR_HOME}/data"
CONFIG_DIR="${HOME}/Library/Application Support/Claude"
CLAUDE_CONFIG="${CONFIG_DIR}/claude_desktop_config.json"
ENHANCED_CONFIG="${ANCHOR_HOME}/enhanced-config.json"

echo -e "${BLUE}${BOLD}┌───────────────────────────────────────────────────────┐${NC}"
echo -e "${BLUE}${BOLD}│        Enhanced MCP Server Launcher (v6.1.0)          │${NC}"
echo -e "${BLUE}${BOLD}│         Optimized for Apple M3 Max (48GB)             │${NC}"
echo -e "${BLUE}${BOLD}└───────────────────────────────────────────────────────┘${NC}"
echo -e "Launching at: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e "System: $(sw_vers -productName) $(sw_vers -productVersion)"

# Apply M3 Max optimizations
# Set optimal environment variables for the M3 Max architecture
export NODE_OPTIONS="--max-old-space-size=16384 --max-semi-space-size=128"
export UV_THREADPOOL_SIZE="16"  # Match M3 Max core count
export APPLE_PTHREAD_HIGH_PERFORMANCE_DEFAULT="1"  # Prioritize performance cores

# Enhanced directory creation with error handling
create_directory() {
    local dir="$1"
    local perms="$2"
    
    if [ ! -d "$dir" ]; then
        echo -e "${YELLOW}Creating directory: $dir${NC}"
        mkdir -p "$dir" || { echo -e "${RED}Failed to create $dir${NC}"; exit 1; }
    fi
    
    if [ ! -z "$perms" ]; then
        chmod "$perms" "$dir" || echo -e "${YELLOW}Warning: Could not set permissions on $dir${NC}"
    fi
    
    echo -e "${GREEN}✓ Directory ready: $dir${NC}"
}

# Create required directories with proper permissions
create_directory "${SOCKET_DIR}" "775"
create_directory "${LOG_DIR}" "755"
create_directory "${DATA_DIR}" "755"
create_directory "${DATA_DIR}/sqlite" "755" 
create_directory "${DATA_DIR}/notion-cache" "755"
create_directory "${DATA_DIR}/slack-cache" "755"
create_directory "${CONFIG_DIR}" "755"

# Update Claude config with enhanced settings
echo -e "\n${BLUE}${BOLD}Updating Claude configuration with enhanced settings...${NC}"
if [ -f "$ENHANCED_CONFIG" ]; then
    # Create backup of current config
    if [ -f "$CLAUDE_CONFIG" ]; then
        cp "$CLAUDE_CONFIG" "${CLAUDE_CONFIG}.bak.$(date +%Y%m%d_%H%M%S)" || echo -e "${YELLOW}Warning: Could not create backup${NC}"
    fi
    
    # Copy enhanced config to Claude config location
    cp "$ENHANCED_CONFIG" "$CLAUDE_CONFIG" || { echo -e "${RED}Failed to update Claude configuration${NC}"; exit 1; }
    echo -e "${GREEN}✓ Claude configuration updated with enhanced settings${NC}"
else
    echo -e "${RED}× Enhanced configuration file not found: $ENHANCED_CONFIG${NC}"
    echo -e "${YELLOW}Using existing Claude configuration${NC}"
fi

# Stop any running servers with graceful shutdown
echo -e "\n${BLUE}${BOLD}Stopping any running MCP servers...${NC}"
# Function to stop a process more gracefully
stop_process() {
    local pattern="$1"
    local name="$2"
    
    # Find PIDs matching the pattern
    local pids=$(pgrep -f "$pattern" 2>/dev/null || echo "")
    
    if [ -n "$pids" ]; then
        echo -e "${YELLOW}Stopping $name server(s)...${NC}"
        
        # Try SIGTERM first for graceful shutdown
        kill -TERM $pids 2>/dev/null || true
        
        # Wait briefly for graceful shutdown
        sleep 1
        
        # Check if still running
        local remaining=$(pgrep -f "$pattern" 2>/dev/null || echo "")
        if [ -n "$remaining" ]; then
            # Force kill if still running
            echo -e "${YELLOW}Forcing termination of $name server(s)...${NC}"
            kill -9 $remaining 2>/dev/null || true
        fi
        
        echo -e "${GREEN}✓ Stopped $name server(s)${NC}"
    else
        echo -e "${GREEN}✓ No running $name servers found${NC}"
    fi
}

# Stop all MCP servers
stop_process "git-local-optimized.js" "Git Local"
stop_process "notion.*wrapper.js" "Notion"
stop_process "anchor-manager-optimized.js" "Anchor Manager"
stop_process "sqlite-wrapper.js" "SQLite"
stop_process "slack-wrapper.js" "Slack"

# Clean up any leftover socket files
echo -e "\n${BLUE}${BOLD}Cleaning up socket files...${NC}"
find "${SOCKET_DIR}" -name "*.sock" -exec rm -f {} \; 2>/dev/null || true
echo -e "${GREEN}✓ Socket files cleaned up${NC}"

# Clean up PID files
echo -e "\n${BLUE}${BOLD}Cleaning up PID files...${NC}"
find "${MCP_DIR}" -name "*.pid" -exec rm -f {} \; 2>/dev/null || true
echo -e "${GREEN}✓ PID files cleaned up${NC}"

# Enhanced server launcher with error handling and memory optimization
launch_server() {
    local name="$1"
    local script="$2"
    local memory_size="$3"
    local thread_pool="$4"
    local log_file="${LOG_DIR}/mcp-server-${name}.log"
    local pid_file="${MCP_DIR}/${name}.pid"
    
    echo -e "\n${BLUE}Starting ${name} server...${NC}"
    
    # Clear previous log file but keep backup
    if [ -f "$log_file" ]; then
        mv "$log_file" "${log_file}.$(date +%Y%m%d%H%M%S).bak" 2>/dev/null || true
    fi
    
    # Set server-specific environment variables
    local server_env="SOCKET_DIR=\"${SOCKET_DIR}\" MCP_SERVER_NAME=\"${name}\" \
    NODE_OPTIONS=\"--max-old-space-size=${memory_size} --max-semi-space-size=$((memory_size / 128))\" \
    UV_THREADPOOL_SIZE=\"${thread_pool}\" \
    ANCHOR_HOME=\"${ANCHOR_HOME}\" \
    LOG_DIR=\"${LOG_DIR}\" \
    MCP_SOCKET_BUFFER_SIZE=\"1048576\" \
    LOG_LEVEL=\"INFO\""
    
    # Launch the server with environment variables
    eval "$server_env node \"$script\" > \"$log_file\" 2>&1 &"
    
    local pid=$!
    echo $pid > "$pid_file"
    
    # Give the server a moment to start
    sleep 0.5
    
    # Check if process is still running
    if ps -p $pid > /dev/null; then
        echo -e "${GREEN}✓ Started ${name} server (PID: $pid)${NC}"
        # Touch the PID file to update timestamp (helps heartbeat scripts)
        touch "$pid_file"
    else
        echo -e "${RED}× Failed to start ${name} server${NC}"
        echo -e "${YELLOW}Last 10 lines of log:${NC}"
        tail -10 "$log_file" | sed 's/^/    /'
    fi
}

# Launch servers with optimized memory and thread allocation for M3 Max
echo -e "\n${BLUE}${BOLD}Launching MCP servers with M3 Max optimizations...${NC}"

# Git Local - Performance intensive
launch_server "git-local" "${MCP_DIR}/git-local-optimized.js" 8192 13

# Notion - Balanced workload
launch_server "notion" "${MCP_DIR}/notion-v5-wrapper.js" 8192 12

# SQLite - Data intensive
launch_server "sqlite" "${MCP_DIR}/sqlite-wrapper.js" 6144 8

# Slack - Networking intensive
launch_server "slack" "${MCP_DIR}/slack-wrapper.js" 4096 6

# Anchor Manager - System monitoring (lowest resources as mostly idle)
launch_server "anchor-manager" "${MCP_DIR}/anchor-manager-optimized.js" 8192 8

# Verify socket files and fix permissions if needed
echo -e "\n${BLUE}${BOLD}Verifying socket files...${NC}"
for server in git-local notion sqlite slack anchor-manager; do
    socket_file="${SOCKET_DIR}/${server}.sock"
    if [ -S "$socket_file" ]; then
        perms=$(stat -f "%Lp" "$socket_file")
        echo -e "${GREEN}✓ ${server}.sock: Found with permissions ${perms}${NC}"
        
        # Fix permissions if needed
        if [ "$perms" != "666" ]; then
            chmod 666 "$socket_file" || echo -e "${YELLOW}Warning: Could not set permissions on ${server}.sock${NC}"
            echo -e "${YELLOW}⚠️ Fixed permissions on ${server}.sock${NC}"
        fi
    else
        echo -e "${RED}× ${server}.sock: Not found or not a socket${NC}"
        
        # Check process to see if it's still starting up
        pid_file="${MCP_DIR}/${server}.pid"
        if [ -f "$pid_file" ]; then
            pid=$(cat "$pid_file")
            if ps -p $pid > /dev/null; then
                echo -e "${YELLOW}  Server process is running (PID: $pid), socket may still be initializing...${NC}"
            fi
        fi
    fi
done

# Memory usage report
echo -e "\n${BLUE}${BOLD}Memory Allocation Report:${NC}"
total_allocated=0
show_memory() {
    local server="$1"
    local size="$2"
    local size_mb=$((size / 1024))
    local size_gb=$(echo "scale=1; $size_mb/1024" | bc)
    total_allocated=$((total_allocated + size))
    printf "${CYAN}%-15s${NC} : ${GREEN}%4d MB${NC} / ${GREEN}%.1f GB${NC}\n" "$server" "$size_mb" "$size_gb"
}

show_memory "Git Local" 8192
show_memory "Notion" 8192
show_memory "SQLite" 6144
show_memory "Slack" 4096
show_memory "Anchor Manager" 8192

# Calculate total and percentage
total_mb=$((total_allocated / 1024))
total_gb=$(echo "scale=1; $total_mb/1024" | bc)
percent=$(echo "scale=0; ($total_allocated * 100) / (48 * 1024)" | bc)
echo -e "${YELLOW}───────────────────────────────────────────${NC}"
printf "${YELLOW}%-15s${NC} : ${GREEN}%4d MB${NC} / ${GREEN}%.1f GB${NC} (${CYAN}%d%%${NC} of 48GB)\n" "TOTAL" "$total_mb" "$total_gb" "$percent"

# Check for Claude Desktop running
if pgrep "Claude" > /dev/null; then
    echo -e "\n${YELLOW}${BOLD}⚠️ Claude Desktop is currently running${NC}"
    echo -e "${YELLOW}For the new MCP server configuration to take effect, restart Claude Desktop${NC}"
else 
    echo -e "\n${GREEN}${BOLD}Ready to launch Claude Desktop with enhanced MCP servers${NC}"
fi

echo -e "\n${GREEN}${BOLD}All MCP servers started with M3 Max optimizations!${NC}"
echo -e "${BLUE}To verify MCP server status:${NC} ${ANCHOR_HOME}/mcp-servers/verify-servers.sh"
echo -e "${BLUE}To monitor MCP server logs:${NC} tail -f ${LOG_DIR}/mcp-server-*.log"
echo -e "${BLUE}Complete at:${NC} $(date '+%Y-%m-%d %H:%M:%S')"
