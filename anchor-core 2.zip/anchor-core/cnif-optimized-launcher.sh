#!/bin/bash
# cnif-optimized-launcher.sh - Integrated CNIF optimization launcher
# © 2025 XPV - MIT

# Set terminal colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Print banner
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}   ▄████▄   ███▄    █  ██▓  █████▒   ▒█████    ██▓███  ▄▄▄█████▓ ██▓ ███▄ ▄███▓   ${NC}"
echo -e "${BLUE}  ▒██▀ ▀█   ██ ▀█   █ ▓██▒▓██   ▒   ▒██▒  ██▒ ▓██░  ██▒▓  ██▒ ▓▒ ▓██▒▓██▒▀█▀ ██▒   ${NC}"
echo -e "${BLUE}  ▒▓█    ▄ ▓██  ▀█ ██▒▒██▒▒████ ░   ▒██░  ██▒ ▓██░ ██▓▒▒ ▓██░ ▒░ ▒██▒▓██    ▓██░   ${NC}"
echo -e "${BLUE}  ▒▓▓▄ ▄██▒▓██▒  ▐▌██▒░██░░▓█▒  ░   ▒██   ██░ ▒██▄█▓▒ ▒░ ▓██▓ ░  ░██░▒██    ▒██    ${NC}"
echo -e "${BLUE}  ▒ ▓███▀ ░▒██░   ▓██░░██░░▒█░      ░ ████▓▒░ ▒██▒ ░  ░  ▒██▒ ░  ░██░▒██▒   ░██▒   ${NC}"
echo -e "${BLUE}  ░ ░▒ ▒  ░░ ▒░   ▒ ▒ ░▓   ▒ ░      ░ ▒░▒░▒░  ▒▓▒░ ░  ░  ▒ ░░    ░▓  ░ ▒░   ░  ░   ${NC}"
echo -e "${BLUE}    ░  ▒   ░ ░░   ░ ▒░ ▒ ░ ░          ░ ▒ ▒░  ░▒ ░         ░      ▒ ░░  ░      ░   ${NC}"
echo -e "${BLUE}  ░          ░   ░ ░  ▒ ░ ░ ░      ░ ░ ░ ▒   ░░         ░        ▒ ░░      ░      ${NC}"
echo -e "${BLUE}  ░ ░              ░  ░                ░ ░                       ░         ░      ${NC}"
echo -e "${BLUE}  ░                                                                              ${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}           Claude-Notion Integration Framework - M3 Max Optimized              ${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

# Set base directories
ANCHOR_HOME="${ANCHOR_HOME:-/Users/XPV/Desktop/anchor-core}"
MCP_DIR="${MCP_DIR:-$ANCHOR_HOME/mcp-servers}"
SOCKET_DIR="${SOCKET_DIR:-$ANCHOR_HOME/sockets}"
LOG_DIR="${LOG_DIR:-$HOME/Library/Logs/Claude}"
OPTIMIZER_DIR="${OPTIMIZER_DIR:-$ANCHOR_HOME/m3-optimizer}"

# Ensure required directories exist
mkdir -p "$SOCKET_DIR" "$LOG_DIR"

# Check for hardware detector and run optimization
if [[ -f "$OPTIMIZER_DIR/m3-hardware-detector.js" ]]; then
    echo -e "${YELLOW}Running M3 hardware detection and optimization...${NC}"
    NODE_OPTIONS="" node "$OPTIMIZER_DIR/m3-hardware-detector.js" > "$LOG_DIR/hardware-detection.json"
    
    # Extract and apply optimizations
    export UV_THREADPOOL_SIZE=$(grep -o '"threadPoolSize":[^,}]*' "$LOG_DIR/hardware-detection.json" | cut -d':' -f2)
    export NODE_OPTIONS="--max-old-space-size=$(grep -o '"maxMemory":[^,}]*' "$LOG_DIR/hardware-detection.json" | cut -d':' -f2)"
    export SOCKET_BUFFER_SIZE=$(grep -o '"socketBufferSize":[^,}]*' "$LOG_DIR/hardware-detection.json" | cut -d':' -f2)
    
    # Check if M3 Max was detected
    IS_M3_MAX=$(grep -o '"isM3Max":[^,}]*' "$LOG_DIR/hardware-detection.json" | cut -d':' -f2)
    if [[ "$IS_M3_MAX" == *"true"* ]]; then
        echo -e "${GREEN}✓ M3 Max detected! Applied optimal configuration for 48GB unified memory.${NC}"
    else
        echo -e "${YELLOW}⚠ Not running on M3 Max. Applied generic optimizations.${NC}"
    fi
else
    echo -e "${YELLOW}Hardware detector not found, using default configurations...${NC}"
    # Default optimization settings
    export UV_THREADPOOL_SIZE=12
    export NODE_OPTIONS="--max-old-space-size=8192"
    export SOCKET_BUFFER_SIZE=65536
fi

# Additional environment variables
export ANCHOR_HOME="$ANCHOR_HOME"
export MCP_DIR="$MCP_DIR"
export SOCKET_DIR="$SOCKET_DIR" 
export LOG_DIR="$LOG_DIR"
export NODE_PERFORMANCE_MODE="high"

# Stop existing servers
echo -e "${YELLOW}Stopping any existing MCP servers...${NC}"

function stop_server() {
    local name=$1
    local pid_file="$MCP_DIR/$name.pid"
    
    if [[ -f "$pid_file" ]]; then
        local pid=$(cat "$pid_file")
        if kill -0 "$pid" 2>/dev/null; then
            echo -e "${YELLOW}Stopping $name server (PID: $pid)...${NC}"
            kill "$pid" 2>/dev/null || true
            sleep 1
            if kill -0 "$pid" 2>/dev/null; then
                echo -e "${RED}Force stopping $name server...${NC}"
                kill -9 "$pid" 2>/dev/null || true
            fi
            echo -e "${GREEN}✓ Stopped $name server${NC}"
        fi
        rm -f "$pid_file"
    fi
}

# Stop servers
stop_server "git-local"
stop_server "notion"
stop_server "anchor-manager"

# Clean up socket files
echo -e "${YELLOW}Cleaning up socket files...${NC}"
rm -f "$SOCKET_DIR"/*.sock

# Create coherence directory if it doesn't exist
mkdir -p "$ANCHOR_HOME/coherence_lock"

# Create coherence lock file
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
COHERENCE_FILE="$ANCHOR_HOME/coherence_lock/coherence_lock_$TIMESTAMP.json"
cat > "$COHERENCE_FILE" << EOF
{
  "timestamp": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
  "action": "system_launch",
  "status": "starting",
  "components": ["git-local", "notion", "anchor-manager"],
  "configuration": {
    "threadPoolSize": $UV_THREADPOOL_SIZE,
    "maxMemory": ${NODE_OPTIONS#*=},
    "socketBufferSize": $SOCKET_BUFFER_SIZE
  }
}
EOF
echo -e "${GREEN}✓ Created coherence lock file: $COHERENCE_FILE${NC}"

# Start M3-optimized servers
echo -e "${YELLOW}Starting M3-optimized MCP servers...${NC}"

# Function to start server
function start_server() {
    local name=$1
    local script=$2
    local log_file="$LOG_DIR/mcp-server-$name.log"
    
    echo -e "${YELLOW}Starting $name server...${NC}"
    
    # Set server-specific environment variables
    export MCP_SERVER_NAME="$name"
    
    # Start server and write PID file
    NODE_OPTIONS="$NODE_OPTIONS" \
    UV_THREADPOOL_SIZE="$UV_THREADPOOL_SIZE" \
    SOCKET_BUFFER_SIZE="$SOCKET_BUFFER_SIZE" \
    SOCKET_DIR="$SOCKET_DIR" \
    ANCHOR_HOME="$ANCHOR_HOME" \
    node "$script" > "$log_file" 2>&1 &
    
    local pid=$!
    echo "$pid" > "$MCP_DIR/$name.pid"
    
    # Verify server started
    sleep 1
    if kill -0 "$pid" 2>/dev/null; then
        echo -e "${GREEN}✓ Started $name server (PID: $pid)${NC}"
        return 0
    else
        echo -e "${RED}✗ Failed to start $name server${NC}"
        return 1
    fi
}

# Start servers
start_server "git-local" "$MCP_DIR/git-local-optimized.js"
start_server "notion" "$MCP_DIR/notion-v5-wrapper.js"
start_server "anchor-manager" "$MCP_DIR/anchor-manager-optimized.js"

# Wait a moment for servers to initialize
sleep 2

# Verify server health using anchor-manager
echo -e "${YELLOW}Verifying server health...${NC}"

# Check for socket files
function check_socket() {
    local name=$1
    local socket_file="$SOCKET_DIR/$name.sock"
    
    if [[ -S "$socket_file" ]]; then
        echo -e "${GREEN}✓ $name socket file exists${NC}"
        # Verify socket permissions
        local perms=$(ls -la "$socket_file" | awk '{print $1}')
        if [[ "$perms" == *"rw-rw"* ]]; then
            echo -e "${GREEN}✓ $name socket has correct permissions${NC}"
        else
            echo -e "${YELLOW}⚠ $name socket has incorrect permissions: $perms${NC}"
            echo -e "${YELLOW}  Fixing permissions...${NC}"
            chmod 666 "$socket_file"
        fi
        return 0
    else
        echo -e "${RED}✗ $name socket file missing${NC}"
        return 1
    fi
}

# Check socket files
check_socket "git-local"
check_socket "notion"
check_socket "anchor-manager"

# Update coherence lock with status
cat > "$COHERENCE_FILE" << EOF
{
  "timestamp": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
  "action": "system_launch",
  "status": "running",
  "components": ["git-local", "notion", "anchor-manager"],
  "configuration": {
    "threadPoolSize": $UV_THREADPOOL_SIZE,
    "maxMemory": ${NODE_OPTIONS#*=},
    "socketBufferSize": $SOCKET_BUFFER_SIZE
  },
  "sockets": {
    "git-local": "$(ls -la "$SOCKET_DIR/git-local.sock" 2>/dev/null || echo "missing")",
    "notion": "$(ls -la "$SOCKET_DIR/notion.sock" 2>/dev/null || echo "missing")",
    "anchor-manager": "$(ls -la "$SOCKET_DIR/anchor-manager.sock" 2>/dev/null || echo "missing")"
  },
  "pids": {
    "git-local": "$(cat "$MCP_DIR/git-local.pid" 2>/dev/null || echo "missing")",
    "notion": "$(cat "$MCP_DIR/notion.pid" 2>/dev/null || echo "missing")",
    "anchor-manager": "$(cat "$MCP_DIR/anchor-manager.pid" 2>/dev/null || echo "missing")"
  }
}
EOF

# Start dashboard
echo -e "${YELLOW}Starting dashboard...${NC}"
if [[ -d "$ANCHOR_HOME/dashboard" ]]; then
    (cd "$ANCHOR_HOME/dashboard" && npm start > "$LOG_DIR/dashboard.log" 2>&1) &
    echo "$!" > "$ANCHOR_HOME/dashboard.pid"
    echo -e "${GREEN}✓ Started dashboard${NC}"
    echo -e "${BLUE}Dashboard available at: http://localhost:8765${NC}"
else
    echo -e "${YELLOW}⚠ Dashboard directory not found${NC}"
fi

# Display summary
echo ""
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}                                 CNIF Status                                    ${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "  ${BLUE}Thread Pool Size:${NC} $UV_THREADPOOL_SIZE"
echo -e "  ${BLUE}Node.js Heap:${NC} ${NODE_OPTIONS#*=}"
echo -e "  ${BLUE}Socket Buffer:${NC} $SOCKET_BUFFER_SIZE bytes"
echo -e "  ${BLUE}Socket Directory:${NC} $SOCKET_DIR"
echo -e "  ${BLUE}Log Directory:${NC} $LOG_DIR"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "${GREEN}✓ CNIF Started - Connect Claude to MCP servers${NC}"
echo ""
echo -e "To stop the system: $ANCHOR_HOME/cnif-stop.sh"
echo -e "To monitor logs: tail -f $LOG_DIR/mcp-server-*.log"
echo ""

# Create a stop script for convenience
cat > "$ANCHOR_HOME/cnif-stop.sh" << 'EOF'
#!/bin/bash
# cnif-stop.sh - Stop CNIF servers

ANCHOR_HOME="${ANCHOR_HOME:-/Users/XPV/Desktop/anchor-core}"
MCP_DIR="${MCP_DIR:-$ANCHOR_HOME/mcp-servers}"

# Stop MCP servers
for server in git-local notion anchor-manager; do
  if [ -f "$MCP_DIR/$server.pid" ]; then
    pid=$(cat "$MCP_DIR/$server.pid")
    echo "Stopping $server (PID: $pid)..."
    kill $pid 2>/dev/null || true
    rm -f "$MCP_DIR/$server.pid"
  fi
done

# Stop dashboard
if [ -f "$ANCHOR_HOME/dashboard.pid" ]; then
  pid=$(cat "$ANCHOR_HOME/dashboard.pid")
  echo "Stopping dashboard (PID: $pid)..."
  kill $pid 2>/dev/null || true
  rm -f "$ANCHOR_HOME/dashboard.pid"
fi

echo "All CNIF servers stopped"
EOF

chmod +x "$ANCHOR_HOME/cnif-stop.sh"

# Create an optimization marker
touch "$ANCHOR_HOME/MCP_OPTIMIZATION_COMPLETE_$(date +%Y%m%d_%H%M%S).marker"

# Setup exit handler to record exit in coherence lock
function on_exit {
    if [[ -f "$COHERENCE_FILE" ]]; then
        cat > "$COHERENCE_FILE" << EOF
{
  "timestamp": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
  "action": "system_launch",
  "status": "exit",
  "exit_code": $?,
  "components": ["git-local", "notion", "anchor-manager"],
  "configuration": {
    "threadPoolSize": $UV_THREADPOOL_SIZE,
    "maxMemory": ${NODE_OPTIONS#*=},
    "socketBufferSize": $SOCKET_BUFFER_SIZE
  }
}
EOF
    fi
}

trap on_exit EXIT
