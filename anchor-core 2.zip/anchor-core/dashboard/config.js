/**
 * Dashboard Configuration
 * Provides configuration for CNIF dashboard
 */

const config = {
    // WebSocket configuration
    websocket: {
        port: 8765,                 // WebSocket port
        reconnectAttempts: 10,      // Maximum reconnection attempts
        initialReconnectDelay: 1000, // Initial reconnect delay (ms)
        maxReconnectDelay: 30000    // Maximum reconnect delay (ms)
    },
    
    // Dashboard refresh rates
    refresh: {
        statusInterval: 5000,       // Status refresh interval (ms)
        metricsInterval: 10000      // Metrics refresh interval (ms)
    },
    
    // Chart configuration
    charts: {
        historyPoints: 10,          // Number of history points to display
        colors: {
            primary: '#4a90e2',     // Primary chart color
            secondary: '#50e3c2',   // Secondary chart color
            success: '#5cb85c',     // Success color
            warning: '#f0ad4e',     // Warning color
            danger: '#d9534f'       // Danger color
        }
    },
    
    // Circuit breaker configuration
    circuitBreaker: {
        states: {
            CLOSED: {
                color: '#5cb85c',   // Green
                description: 'Normal operation'
            },
            HALF_OPEN: {
                color: '#f0ad4e',   // Yellow
                description: 'Testing if system has recovered'
            },
            OPEN: {
                color: '#d9534f',   // Red
                description: 'Failing, not accepting requests'
            },
            PARTIAL: {
                color: '#5bc0de',   // Blue
                description: 'Degraded operation'
            }
        }
    },
    
    // M3 Max hardware configuration
    m3Max: {
        totalMemory: 48 * 1024 * 1024 * 1024, // 48GB in bytes
        coreCount: 16,              // Total cores
        pCores: 12,                 // Performance cores
        eCores: 4                   // Efficiency cores
    }
};
