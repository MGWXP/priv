/**
 * server.js - Dashboard server for CNIF
 * © 2025 XPV - MIT
 * 
 * Implements a WebSocket server for real-time dashboard updates
 * and serves static dashboard files for CNIF monitoring.
 */

const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { exec } = require('child_process');

// Configuration
const PORT = process.env.PORT || 8765;
const DATA_UPDATE_INTERVAL = 5000; // 5 seconds
const SOCKET_DIR = process.env.SOCKET_DIR || '/Users/XPV/Desktop/anchor-core/sockets';
const LOG_DIR = process.env.LOG_DIR || path.join(os.homedir(), 'Library/Logs/Claude');
const MCP_DIR = process.env.MCP_DIR || '/Users/XPV/Desktop/anchor-core/mcp-servers';

// Create Express app
const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server, path: '/dashboard' });

// Serve static files from the current directory
app.use(express.static(__dirname));

// Serve logs directory
app.use('/logs', express.static(LOG_DIR));

// Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/api/status', async (req, res) => {
    try {
        const status = await getSystemStatus();
        res.json(status);
    } catch (err) {
        res.status(500).json({
            error: err.message
        });
    }
});

// Start server
server.listen(PORT, () => {
    console.log(`Dashboard server running on port ${PORT}`);
    console.log(`Visit http://localhost:${PORT} to view the dashboard`);
});

// WebSocket connections
wss.on('connection', (ws) => {
    console.log('Client connected to dashboard');
    
    // Send initial status
    getSystemStatus().then(status => {
        ws.send(JSON.stringify({
            type: 'status',
            data: status
        }));
    }).catch(err => {
        console.error('Error getting system status:', err);
    });
    
    // Set up regular status updates
    const statusInterval = setInterval(async () => {
        try {
            const status = await getSystemStatus();
            
            ws.send(JSON.stringify({
                type: 'status',
                data: status
            }));
        } catch (err) {
            console.error('Error sending status update:', err);
        }
    }, DATA_UPDATE_INTERVAL);
    
    // Send metrics
    getMetrics().then(metrics => {
        ws.send(JSON.stringify({
            type: 'metrics',
            data: metrics
        }));
    }).catch(err => {
        console.error('Error getting metrics:', err);
    });
    
    // Set up regular metrics updates
    const metricsInterval = setInterval(async () => {
        try {
            const metrics = await getMetrics();
            
            ws.send(JSON.stringify({
                type: 'metrics',
                data: metrics
            }));
        } catch (err) {
            console.error('Error sending metrics update:', err);
        }
    }, DATA_UPDATE_INTERVAL * 2);
    
    // Handle client messages
    ws.on('message', async (message) => {
        try {
            const data = JSON.parse(message);
            
            if (data.action === 'getStatus') {
                const status = await getSystemStatus();
                
                ws.send(JSON.stringify({
                    type: 'status',
                    data: status
                }));
            } else if (data.action === 'resetCircuitBreaker') {
                // Reset circuit breakers
                resetCircuitBreakers();
                
                ws.send(JSON.stringify({
                    type: 'notification',
                    data: {
                        type: 'success',
                        message: 'Circuit breakers reset successfully'
                    }
                }));
            } else if (data.action === 'clearCache') {
                // Clear cache
                clearCache();
                
                ws.send(JSON.stringify({
                    type: 'notification',
                    data: {
                        type: 'success',
                        message: 'Cache cleared successfully'
                    }
                }));
            } else if (data.action === 'disconnectClient') {
                // Disconnect client
                const clientId = data.clientId;
                
                ws.send(JSON.stringify({
                    type: 'notification',
                    data: {
                        type: 'info',
                        message: `Disconnecting client ${clientId}...`
                    }
                }));
            } else if (data.action === 'getSchema') {
                // Get schema
                const schemaId = data.schemaId;
                const schemaType = data.schemaType;
                
                ws.send(JSON.stringify({
                    type: 'notification',
                    data: {
                        type: 'info',
                        message: `Getting schema ${schemaId} (${schemaType})...`
                    }
                }));
            }
        } catch (err) {
            console.error('Error handling message:', err);
        }
    });
    
    // Handle client disconnection
    ws.on('close', () => {
        console.log('Client disconnected from dashboard');
        
        // Clear intervals
        clearInterval(statusInterval);
        clearInterval(metricsInterval);
    });
});

// Helper functions

// Get system status
async function getSystemStatus() {
    const startTime = Date.now();
    
    // Check MCP socket files
    const socketStatus = await checkMcpSockets();
    
    // Check MCP server processes
    const processStatus = await checkMcpProcesses();
    
    // Get system info
    const systemInfo = getSystemInfo();
    
    // Circuit breaker status (mocked for this example)
    const circuitBreakers = {
        socket: {
            state: 'CLOSED',
            failures: 0,
            successRate: 100
        },
        notion: {
            state: 'CLOSED',
            failures: 0,
            successRate: 100
        },
        transformer: {
            state: 'CLOSED',
            failures: 0,
            successRate: 100
        }
    };
    
    // Mock data for demonstration - in a real implementation, would get actual data
    const socketConnected = socketStatus.some(s => s.exists && s.name === 'socket');
    const notionConnected = socketStatus.some(s => s.exists && s.name === 'notion');
    
    // Create status object
    const status = {
        timestamp: new Date().toISOString(),
        socket: {
            connected: socketConnected,
            clients: Math.floor(Math.random() * 5),
            messagesPerMinute: Math.floor(Math.random() * 100),
            avgLatency: 15 + Math.random() * 10,
            avgMessageSize: 1024 + Math.random() * 1024
        },
        notion: {
            connected: notionConnected,
            requestsPerMinute: Math.floor(Math.random() * 30),
            totalRequests: 1234,
            rateLimitRemaining: 3,
            cacheHitRate: 0.8,
            errorRate: 0.02
        },
        transformer: {
            transformsPerMinute: Math.floor(Math.random() * 50),
            totalTransforms: 5678,
            avgSize: 2048 + Math.random() * 2048,
            avgTime: 25 + Math.random() * 15,
            errorRate: 0.01
        },
        system: {
            uptime: process.uptime(),
            healthy: true,
            memory: {
                total: os.totalmem(),
                free: os.freemem(),
                used: os.totalmem() - os.freemem()
            },
            cpu: systemInfo.cpuUsage
        },
        circuitBreakers
    };
    
    const endTime = Date.now();
    console.log(`Status generated in ${endTime - startTime}ms`);
    
    return status;
}

// Check MCP socket files
async function checkMcpSockets() {
    try {
        const socketFiles = [
            { name: 'git-local', path: path.join(SOCKET_DIR, 'git-local.sock') },
            { name: 'notion', path: path.join(SOCKET_DIR, 'notion.sock') },
            { name: 'socket', path: path.join(SOCKET_DIR, 'socket.sock') },
            { name: 'anchor-manager', path: path.join(SOCKET_DIR, 'anchor-manager.sock') }
        ];
        
        const results = [];
        
        for (const socket of socketFiles) {
            try {
                const stats = await fs.promises.stat(socket.path);
                
                results.push({
                    name: socket.name,
                    path: socket.path,
                    exists: true,
                    isSocket: stats.isSocket(),
                    mode: stats.mode
                });
            } catch (err) {
                results.push({
                    name: socket.name,
                    path: socket.path,
                    exists: false,
                    error: err.code
                });
            }
        }
        
        return results;
    } catch (err) {
        console.error('Error checking MCP sockets:', err);
        return [];
    }
}

// Check MCP server processes
async function checkMcpProcesses() {
    return new Promise((resolve, reject) => {
        const cmd = process.platform === 'win32'
            ? 'tasklist'
            : 'ps -eo pid,command | grep -E "node.*mcp-servers"';
        
        exec(cmd, (error, stdout, stderr) => {
            if (error) {
                console.error(`Error checking processes: ${error.message}`);
                resolve([]);
                return;
            }
            
            if (stderr) {
                console.error(`Process check stderr: ${stderr}`);
            }
            
            // Parse process list
            const processes = [];
            const lines = stdout.split('\n');
            
            for (const line of lines) {
                if (line.includes('mcp-servers')) {
                    const parts = line.trim().split(/\s+/);
                    const pid = parseInt(parts[0], 10);
                    
                    // Determine server type
                    let serverType = 'unknown';
                    if (line.includes('git-local')) serverType = 'git-local';
                    else if (line.includes('notion')) serverType = 'notion';
                    else if (line.includes('socket')) serverType = 'socket';
                    else if (line.includes('anchor-manager')) serverType = 'anchor-manager';
                    
                    processes.push({
                        pid,
                        serverType,
                        command: line.trim()
                    });
                }
            }
            
            resolve(processes);
        });
    });
}

// Get system info
function getSystemInfo() {
    const cpus = os.cpus();
    
    // Calculate CPU usage
    let totalIdle = 0;
    let totalTick = 0;
    
    for (const cpu of cpus) {
        for (const type in cpu.times) {
            totalTick += cpu.times[type];
        }
        totalIdle += cpu.times.idle;
    }
    
    const idle = totalIdle / cpus.length;
    const total = totalTick / cpus.length;
    const usage = 100 - (idle / total * 100);
    
    return {
        platform: os.platform(),
        arch: os.arch(),
        cpuModel: cpus[0].model,
        cpuCount: cpus.length,
        cpuUsage: usage,
        totalMemory: os.totalmem(),
        freeMemory: os.freemem(),
        usedMemory: os.totalmem() - os.freemem()
    };
}

// Generate metrics
async function getMetrics() {
    // Generate random metrics for demonstration
    // In a real implementation, would collect actual metrics
    
    function generateRandomArray(length, min, max, trend = 0) {
        const result = [];
        let value = min + Math.random() * (max - min);
        
        for (let i = 0; i < length; i++) {
            // Add some randomness with a trend
            value += trend + (Math.random() - 0.5) * (max - min) * 0.2;
            
            // Keep within bounds
            value = Math.max(min, Math.min(max, value));
            
            result.push(Math.round(value * 10) / 10);
        }
        
        return result;
    }
    
    const metrics = {
        requests: generateRandomArray(10, 20, 80, 2),
        memory: generateRandomArray(10, 500, 1500, 10),
        socketMessages: generateRandomArray(10, 10, 100, 1),
        socketLatency: generateRandomArray(10, 10, 30, -0.2),
        notionRequests: generateRandomArray(10, 5, 40, 0.5),
        notionCache: generateRandomArray(10, 60, 90, 0.3),
        transforms: generateRandomArray(10, 15, 60, 1),
        transformTime: generateRandomArray(10, 20, 40, -0.1)
    };
    
    return metrics;
}

// Reset circuit breakers
function resetCircuitBreakers() {
    console.log('Resetting circuit breakers');
    
    // In a real implementation, would send commands to reset circuit breakers
}

// Clear cache
function clearCache() {
    console.log('Clearing cache');
    
    // In a real implementation, would send commands to clear cache
}

// Error handler
function handleError(err) {
    console.error('Error:', err);
}

// Process error handlers
process.on('uncaughtException', (err) => {
    console.error('Uncaught exception:', err);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled rejection at:', promise, 'reason:', reason);
});
