/**
 * m3-performance-dashboard.js - Performance monitoring for CNIF on M3 Max
 * © 2025 XPV - MIT
 * 
 * Provides real-time performance metrics visualization for
 * M3 Max optimized memory, CPU, and I/O operations.
 */

const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const os = require('os');
const fs = require('fs');
const path = require('path');

// Configuration
const PORT = process.env.DASHBOARD_PORT || 8766;
const UPDATE_INTERVAL = 1000; // Metrics update interval in ms
const METRICS_HISTORY_LENGTH = 60; // Keep 1 minute of history

// Create Express app
const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// Metrics storage
const metrics = {
    history: [],
    current: {},
    cpuUsage: {
        p_cores: Array(12).fill(0),
        e_cores: Array(4).fill(0)
    },
    memory: {
        total: 0,
        free: 0,
        used: 0
    },
    processes: []
};

// Serve static files from the dashboard directory
app.use(express.static(path.join(__dirname, 'dashboard')));

// API routes
app.get('/api/metrics', (req, res) => {
    res.json(metrics);
});

app.get('/api/hardware', async (req, res) => {
    try {
        const hardwareInfo = await getHardwareInfo();
        res.json(hardwareInfo);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/processes', async (req, res) => {
    try {
        const processes = await getProcessInfo();
        res.json(processes);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// WebSocket connections
wss.on('connection', (ws) => {
    console.log('Client connected to performance dashboard');
    
    // Send initial metrics
    ws.send(JSON.stringify({
        type: 'metrics',
        data: metrics
    }));
    
    // Handle client messages
    ws.on('message', (message) => {
        try {
            const data = JSON.parse(message);
            
            if (data.action === 'getMetrics') {
                ws.send(JSON.stringify({
                    type: 'metrics',
                    data: metrics
                }));
            } else if (data.action === 'getHardwareInfo') {
                getHardwareInfo().then(hardwareInfo => {
                    ws.send(JSON.stringify({
                        type: 'hardwareInfo',
                        data: hardwareInfo
                    }));
                });
            }
        } catch (err) {
            console.error('Error handling message:', err);
        }
    });
    
    // Handle disconnection
    ws.on('close', () => {
        console.log('Client disconnected from performance dashboard');
    });
});

// Start server
server.listen(PORT, () => {
    console.log(`M3 Performance Dashboard running on port ${PORT}`);
});

// Update metrics regularly
setInterval(updateMetrics, UPDATE_INTERVAL);

// Helper functions
async function updateMetrics() {
    try {
        // Update system metrics
        const cpuLoad = await getCpuUsage();
        const memoryInfo = getMemoryInfo();
        const processInfo = await getProcessInfo();
        
        // Update metrics
        metrics.current = {
            timestamp: Date.now(),
            cpu: {
                total: cpuLoad.total,
                p_cores: cpuLoad.p_cores,
                e_cores: cpuLoad.e_cores
            },
            memory: memoryInfo,
            processes: processInfo.slice(0, 10) // Top 10 processes
        };
        
        // Add to history
        metrics.history.push(metrics.current);
        
        // Limit history length
        if (metrics.history.length > METRICS_HISTORY_LENGTH) {
            metrics.history.shift();
        }
        
        // Broadcast metrics to all clients
        broadcastMetrics();
    } catch (err) {
        console.error('Error updating metrics:', err);
    }
}

function broadcastMetrics() {
    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify({
                type: 'metrics',
                data: {
                    current: metrics.current,
                    // Only send recent history to keep message size reasonable
                    history: metrics.history.slice(-20)
                }
            }));
        }
    });
}

async function getCpuUsage() {
    // Get CPU usage
    // Note: This is a simplified approach, would need a more complex implementation
    // to accurately track per-core usage, especially P-core vs E-core on M3 Max
    
    // Mock CPU load for demonstration
    // In a real implementation, would use OS-specific methods to get per-core load
    const cpus = os.cpus();
    const total = cpus.reduce((acc, cpu) => {
        const total = cpu.times.user + cpu.times.nice + cpu.times.sys + cpu.times.idle + cpu.times.irq;
        const idle = cpu.times.idle;
        const used = 100 - (idle / total * 100);
        return acc + used;
    }, 0) / cpus.length;
    
    // Mock P-core and E-core distinction
    // In a real implementation, would use system-specific methods to identify cores
    const p_cores = [];
    const e_cores = [];
    
    for (let i = 0; i < cpus.length; i++) {
        const cpu = cpus[i];
        const total = cpu.times.user + cpu.times.nice + cpu.times.sys + cpu.times.idle + cpu.times.irq;
        const idle = cpu.times.idle;
        const used = 100 - (idle / total * 100);
        
        if (i < 12) {
            // First 12 cores are P-cores
            p_cores.push(used);
        } else {
            // Remaining cores are E-cores
            e_cores.push(used);
        }
    }
    
    return {
        total,
        p_cores,
        e_cores
    };
}

function getMemoryInfo() {
    const totalMemory = os.totalmem();
    const freeMemory = os.freemem();
    const usedMemory = totalMemory - freeMemory;
    
    return {
        total: totalMemory,
        free: freeMemory,
        used: usedMemory,
        percentUsed: (usedMemory / totalMemory) * 100
    };
}

async function getProcessInfo() {
    // Note: This is a simplified approach to get process info
    // In a real implementation, would use more system-specific methods
    
    try {
        // Get list of top processes
        // Using ps command on macOS/Linux
        const { execSync } = require('child_process');
        
        const command = process.platform === 'darwin'
            ? 'ps -eo pid,comm,%cpu,%mem -r'
            : 'ps -eo pid,comm,pcpu,pmem --sort=-pcpu';
        
        const output = execSync(command).toString();
        
        // Parse output
        const lines = output.split('\n').slice(1); // Skip header
        
        return lines
            .filter(line => line.trim())
            .map(line => {
                const parts = line.trim().split(/\s+/);
                
                return {
                    pid: parseInt(parts[0], 10),
                    name: parts[1],
                    cpu: parseFloat(parts[2]),
                    memory: parseFloat(parts[3])
                };
            })
            .filter(process => !isNaN(process.pid));
    } catch (err) {
        console.error('Error getting process info:', err);
        return [];
    }
}

async function getHardwareInfo() {
    // Get detailed hardware info
    // Note: This is a simplified approach, would need a more complex implementation
    // to get accurate hardware info, especially for Apple Silicon
    
    try {
        const cpus = os.cpus();
        const cpuModel = cpus[0].model;
        const cpuCount = cpus.length;
        
        // Check if this is Apple Silicon
        const isAppleSilicon = cpuModel.includes('Apple') || process.platform === 'darwin';
        
        // Determine if M3 Max
        const totalMemoryGB = Math.round(os.totalmem() / (1024 * 1024 * 1024));
        const isM3Max = isAppleSilicon && cpuCount === 16 && totalMemoryGB >= 45 && totalMemoryGB <= 50;
        
        return {
            platform: process.platform,
            hostname: os.hostname(),
            cpuModel,
            cpuCount,
            totalMemoryGB,
            isAppleSilicon,
            isM3Max,
            architecture: os.arch(),
            osVersion: os.version(),
            p_cores: isM3Max ? 12 : Math.ceil(cpuCount * 0.75),
            e_cores: isM3Max ? 4 : Math.floor(cpuCount * 0.25)
        };
    } catch (err) {
        console.error('Error getting hardware info:', err);
        return {
            error: err.message
        };
    }
}
