#!/bin/bash
# anchor-v6-archival-hub.sh - Central launcher for Anchor V6 Archival System
# Provides a simple menu to access all archival system functions

# Make this script executable
chmod +x $0

# ANSI color codes for output formatting
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

# Clear screen and display banner
clear
echo -e "${BLUE}╔══════════════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║                        ${WHITE}ANCHOR V6 ARCHIVAL HUB${BLUE}                          ║${NC}"
echo -e "${BLUE}╠══════════════════════════════════════════════════════════════════════════╣${NC}"
echo -e "${BLUE}║                                                                          ║${NC}"
echo -e "${BLUE}║  ${WHITE}A comprehensive toolkit for managing Anchor V6 component lifecycle${BLUE}     ║${NC}"
echo -e "${BLUE}║  ${CYAN}Optimized for M3 Max hardware with systematic archiving protocol${BLUE}        ║${NC}"
echo -e "${BLUE}║                                                                          ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════════════════════════════════════╝${NC}"

# Base directory
BASE_DIR="/Users/XPV/Desktop/anchor-core"

# Function to display the main menu
show_main_menu() {
    echo ""
    echo -e "${WHITE}                         MAIN MENU${NC}"
    echo -e "${CYAN}═════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo -e "${YELLOW}System Management:${NC}"
    echo -e "  ${WHITE}1${NC}) Initialize Archival System      (${CYAN}First-time setup${NC})"
    echo -e "  ${WHITE}2${NC}) Run System Health Check         (${CYAN}Verify & fix issues${NC})"
    echo -e "  ${WHITE}3${NC}) Launch Protocol Controller      (${CYAN}Full management UI${NC})"
    echo ""
    echo -e "${YELLOW}Quick Operations:${NC}"
    echo -e "  ${WHITE}4${NC}) Quick Archive Component         (${CYAN}Interactive archiving${NC})"
    echo -e "  ${WHITE}5${NC}) View Archive Dashboard          (${CYAN}System statistics${NC})"
    echo -e "  ${WHITE}6${NC}) Create Replacement Component    (${CYAN}New implementation${NC})"
    echo ""
    echo -e "${YELLOW}Documentation:${NC}"
    echo -e "  ${WHITE}7${NC}) View User Guide                 (${CYAN}Usage instructions${NC})"
    echo -e "  ${WHITE}8${NC}) View Implementation Plan        (${CYAN}System architecture${NC})"
    echo -e "  ${WHITE}9${NC}) View Archive Report             (${CYAN}Archived components${NC})"
    echo ""
    echo -e "  ${WHITE}0${NC}) Exit"
    echo ""
    echo -e "${CYAN}═════════════════════════════════════════════════════════════${NC}"
    echo -e "${WHITE}Enter your choice [0-9]:${NC} "
}

# Function to check if a file exists and is executable
check_executable() {
    if [ ! -f "$1" ]; then
        echo -e "${RED}Error: File not found: $1${NC}"
        return 1
    fi
    
    if [ ! -x "$1" ]; then
        chmod +x "$1"
    fi
    
    return 0
}

# Function to view a document
view_document() {
    if [ ! -f "$1" ]; then
        echo -e "${RED}Error: Document not found: $1${NC}"
        echo ""
        read -p "Press Enter to continue..."
        return 1
    fi
    
    clear
    echo -e "${CYAN}═════════════════════════════════════════════════════════════${NC}"
    echo -e "${WHITE}Viewing: ${MAGENTA}$(basename "$1")${NC}"
    echo -e "${CYAN}═════════════════════════════════════════════════════════════${NC}"
    echo ""
    # Display the file with pagination
    less "$1"
    
    clear
    return 0
}

# Main menu loop
while true; do
    show_main_menu
    read choice
    
    case $choice in
        0)
            clear
            echo -e "${GREEN}Thank you for using the Anchor V6 Archival Hub!${NC}"
            echo -e "${CYAN}Exiting...${NC}"
            exit 0
            ;;
        1)
            # Initialize Archival System
            INIT_SCRIPT="$BASE_DIR/initialize-archival-system.sh"
            if check_executable "$INIT_SCRIPT"; then
                clear
                "$INIT_SCRIPT"
                echo ""
                read -p "Press Enter to continue..."
                clear
            fi
            ;;
        2)
            # Run System Health Check
            HEALTH_CHECK_SCRIPT="$BASE_DIR/archival-system-health-check.sh"
            if check_executable "$HEALTH_CHECK_SCRIPT"; then
                clear
                "$HEALTH_CHECK_SCRIPT"
                echo ""
                read -p "Press Enter to continue..."
                clear
            fi
            ;;
        3)
            # Launch Protocol Controller
            CONTROLLER_SCRIPT="$BASE_DIR/archival-protocol-controller.sh"
            if check_executable "$CONTROLLER_SCRIPT"; then
                clear
                "$CONTROLLER_SCRIPT"
                clear
            fi
            ;;
        4)
            # Quick Archive Component
            QUICK_ARCHIVE_SCRIPT="$BASE_DIR/quick-archive-component.sh"
            if check_executable "$QUICK_ARCHIVE_SCRIPT"; then
                clear
                "$QUICK_ARCHIVE_SCRIPT"
                echo ""
                read -p "Press Enter to continue..."
                clear
            fi
            ;;
        5)
            # View Archive Dashboard
            DASHBOARD_SCRIPT="$BASE_DIR/meta-protocols/archive-dashboard.sh"
            if check_executable "$DASHBOARD_SCRIPT"; then
                clear
                "$DASHBOARD_SCRIPT"
                echo ""
                read -p "Press Enter to continue..."
                clear
            fi
            ;;
        6)
            # Create Replacement Component
            REPLACEMENT_SCRIPT="$BASE_DIR/meta-protocols/create-replacement-component.sh"
            
            if ! check_executable "$REPLACEMENT_SCRIPT"; then
                echo ""
                read -p "Press Enter to continue..."
                clear
                continue
            fi
            
            clear
            echo -e "${BLUE}╔══════════════════════════════════════════════════════════════════════════╗${NC}"
            echo -e "${BLUE}║                      ${WHITE}CREATE REPLACEMENT COMPONENT${BLUE}                      ║${NC}"
            echo -e "${BLUE}╚══════════════════════════════════════════════════════════════════════════╝${NC}"
            echo ""
            
            # Component to replace
            echo -e "${YELLOW}Step 1: Enter the archived component path:${NC}"
            read -p "Path: " archived_path
            
            if [ ! -f "$archived_path" ]; then
                echo -e "${RED}Error: File not found: $archived_path${NC}"
                echo ""
                read -p "Press Enter to continue..."
                clear
                continue
            fi
            
            # New component path
            echo -e "\n${YELLOW}Step 2: Enter the new replacement component path:${NC}"
            read -p "Path: " replacement_path
            
            if [ -z "$replacement_path" ]; then
                echo -e "${RED}Error: Replacement path cannot be empty${NC}"
                echo ""
                read -p "Press Enter to continue..."
                clear
                continue
            fi
            
            # Component type
            echo -e "\n${YELLOW}Step 3: Select component type:${NC}"
            echo "  1) server        (Socket server implementation)"
            echo "  2) schema        (Schema registry component)"
            echo "  3) transformer   (Data transformer component)"
            echo "  4) connection    (Connection manager component)"
            echo "  5) orchestrator  (MCP orchestrator component)"
            echo "  6) circuit       (Circuit breaker component)"
            echo "  7) generic       (Generic component with basic structure)"
            read -p "Enter type [1-7]: " type_num
            
            case $type_num in
                1) component_type="server" ;;
                2) component_type="schema" ;;
                3) component_type="transformer" ;;
                4) component_type="connection" ;;
                5) component_type="orchestrator" ;;
                6) component_type="circuit" ;;
                7) component_type="generic" ;;
                *)
                    echo -e "${RED}Invalid component type${NC}"
                    echo ""
                    read -p "Press Enter to continue..."
                    clear
                    continue
                    ;;
            esac
            
            # Execute component creation
            "$REPLACEMENT_SCRIPT" "$archived_path" "$replacement_path" "$component_type"
            
            echo ""
            read -p "Press Enter to continue..."
            clear
            ;;
        7)
            # View User Guide
            USER_GUIDE="$BASE_DIR/ARCHIVING_PROTOCOL_USER_GUIDE.md"
            view_document "$USER_GUIDE"
            ;;
        8)
            # View Implementation Plan
            IMPL_PLAN="$BASE_DIR/meta-protocols/ARCHIVAL_IMPLEMENTATION_PLAN.md"
            view_document "$IMPL_PLAN"
            ;;
        9)
            # View Archive Report
            ARCHIVE_REPORT="$BASE_DIR/ARCHIVE_REPORT.md"
            view_document "$ARCHIVE_REPORT"
            ;;
        *)
            echo -e "${RED}Invalid option. Please try again.${NC}"
            sleep 1
            clear
            ;;
    esac
done
