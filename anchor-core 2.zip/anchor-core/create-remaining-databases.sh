#!/bin/bash
# create-remaining-databases.sh - Creates all remaining databases for Anchor
# For M3 Max (48GB unified memory) hardware

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

echo -e "${BLUE}=== Creating Remaining Anchor Databases ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e ""

# Make scripts executable
chmod +x /Users/XPV/Desktop/anchor-core/create-system-metrics-db.sh
chmod +x /Users/XPV/Desktop/anchor-core/create-documentation-db.sh
chmod +x /Users/XPV/Desktop/anchor-core/create-meeting-notes-db.sh
chmod +x /Users/XPV/Desktop/anchor-core/setup-dashboard-views.sh
chmod +x /Users/XPV/Desktop/anchor-core/configure-slack-integration.sh

# Create System Metrics database
echo -e "${YELLOW}Running System Metrics Database setup...${NC}"
/Users/XPV/Desktop/anchor-core/create-system-metrics-db.sh

# Create Documentation database
echo -e "\n${YELLOW}Running Documentation Database setup...${NC}"
/Users/XPV/Desktop/anchor-core/create-documentation-db.sh

# Create Meeting Notes database
echo -e "\n${YELLOW}Running Meeting Notes Database setup...${NC}"
/Users/XPV/Desktop/anchor-core/create-meeting-notes-db.sh

# Setup Dashboard Views
echo -e "\n${YELLOW}Setting up Dashboard Views...${NC}"
/Users/XPV/Desktop/anchor-core/setup-dashboard-views.sh

# Configure Slack Integration
echo -e "\n${YELLOW}Configuring Slack Integration...${NC}"
/Users/XPV/Desktop/anchor-core/configure-slack-integration.sh

echo -e "\n${GREEN}✓ All Anchor databases and configurations have been completed!${NC}"
echo -e "${YELLOW}View your workspace at: https://www.notion.so/Anchor-1f7e48c2-bbbd-80df-86ed-d35832916f80${NC}"

# Update notion-db-status.txt
echo -e "\nUpdating database status file..."
cat > /Users/XPV/Desktop/anchor-core/notion-db-status.txt << EOF
# Anchor Workspace Database Status
# Updated: $(date '+%Y-%m-%d %H:%M:%S')

## Core Databases
- Agent Registry: Created (ID: $(cat /Users/XPV/Desktop/anchor-core/notion-db-ids/agent-registry-id.txt))
- Component Library: Created (ID: $(cat /Users/XPV/Desktop/anchor-core/notion-db-ids/component-library-id.txt))
- Project Tracker: Created (ID: $(cat /Users/XPV/Desktop/anchor-core/notion-db-ids/project-tracker-id.txt))

## Extended Databases
- System Metrics: Created (ID: $(cat /Users/XPV/Desktop/anchor-core/notion-db-ids/system-metrics-id.txt))
- Documentation: Created (ID: $(cat /Users/XPV/Desktop/anchor-core/notion-db-ids/documentation-id.txt))
- Meeting Notes: Created (ID: $(cat /Users/XPV/Desktop/anchor-core/notion-db-ids/meeting-notes-id.txt))

## Views
- Main Dashboard: Created (ID: $(cat /Users/XPV/Desktop/anchor-core/notion-dashboard-ids/main-dashboard-id.txt))
- Project Dashboard: Created (ID: $(cat /Users/XPV/Desktop/anchor-core/notion-dashboard-ids/project-dashboard-id.txt))

## Integrations
- Slack Integration: Configured

## Status
All database creation and configuration tasks completed successfully.
EOF

echo -e "${GREEN}✓ Status file updated at: /Users/XPV/Desktop/anchor-core/notion-db-status.txt${NC}"
