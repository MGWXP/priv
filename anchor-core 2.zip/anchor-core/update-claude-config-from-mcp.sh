#!/bin/bash
# update-claude-config-from-mcp.sh
# Updates Claude Desktop config with MCP credentials
# © 2025 XPV - MIT License

# Set directory paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
LOG_DIR="${ANCHOR_HOME}/logs"
SECURE_CREDS_DIR="${ANCHOR_HOME}/data/secure-credentials"
CLAUDE_CONFIG_DIR="${HOME}/Library/Application Support/Claude"
CLAUDE_CONFIG_FILE="${CLAUDE_CONFIG_DIR}/claude_desktop_config.json"

# Create log directory if it doesn't exist
mkdir -p "${LOG_DIR}"

# Log function
log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "${LOG_DIR}/update-claude-config.log"
}

# Check if Claude config directory exists, create if not
if [ ! -d "${CLAUDE_CONFIG_DIR}" ]; then
  log "Creating Claude config directory: ${CLAUDE_CONFIG_DIR}"
  mkdir -p "${CLAUDE_CONFIG_DIR}"
fi

# Check if Claude config file exists
if [ ! -f "${CLAUDE_CONFIG_FILE}" ]; then
  log "Claude config file not found. Creating a new one with default MCP servers."
  
  # Create basic config with filesystem MCP server
  cat > "${CLAUDE_CONFIG_FILE}" << 'EOF'
{
  "mcpServers": {
    "filesystem": {
      "command": "npx",
      "args": [
        "-y",
        "@modelcontextprotocol/server-filesystem",
        "/Users/XPV/Desktop",
        "/Users/XPV/Library",
        "/Users/XPV/Documents"
      ],
      "env": {
        "NODE_OPTIONS": "--max-old-space-size=8192",
        "UV_THREADPOOL_SIZE": "12"
      }
    }
  }
}
EOF
  
  log "Created default Claude config file"
fi

# Function to prompt for credentials
prompt_for_credentials() {
  local service=$1
  local token_name=$2
  local token_var=$3
  
  read -p "${service} ${token_name} [leave empty to skip]: " token_value
  
  if [ -n "${token_value}" ]; then
    eval "${token_var}=\"${token_value}\""
    return 0
  else
    return 1
  fi
}

# Backup current config
BACKUP_FILE="${CLAUDE_CONFIG_FILE}.bak.$(date '+%Y%m%d%H%M%S')"
log "Backing up current Claude config to ${BACKUP_FILE}"
cp "${CLAUDE_CONFIG_FILE}" "${BACKUP_FILE}"

# Read current config
log "Reading current Claude config"
CURRENT_CONFIG=$(cat "${CLAUDE_CONFIG_FILE}")

# Prompt for credentials
log "Prompting for GitHub credentials"
GITHUB_TOKEN=""
GITHUB_ENTERPRISE_URL=""

prompt_for_credentials "GitHub" "Personal Access Token" "GITHUB_TOKEN"
GITHUB_SET=$?

if [ ${GITHUB_SET} -eq 0 ]; then
  prompt_for_credentials "GitHub" "Enterprise URL (optional)" "GITHUB_ENTERPRISE_URL"
  
  # Ensure GitHub MCP server config exists
  if [[ ! "${CURRENT_CONFIG}" == *"\"github\""* ]]; then
    log "Adding GitHub MCP server to Claude config"
    
    # Use jq if available to manipulate the JSON
    if command -v jq &> /dev/null; then
      CURRENT_CONFIG=$(echo "${CURRENT_CONFIG}" | jq '.mcpServers.github = {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-github"],
        "env": {
          "NODE_OPTIONS": "--max-old-space-size=8192",
          "UV_THREADPOOL_SIZE": "12",
          "GITHUB_PERSONAL_ACCESS_TOKEN": "'"${GITHUB_TOKEN}"'",
          "GITHUB_TOOLSETS": "repos,issues,pull_requests,code_security,experiments,enterprise"
        }
      }')
      
      if [ -n "${GITHUB_ENTERPRISE_URL}" ]; then
        CURRENT_CONFIG=$(echo "${CURRENT_CONFIG}" | jq '.mcpServers.github.env.GITHUB_ENTERPRISE_URL = "'"${GITHUB_ENTERPRISE_URL}"'"')
      fi
    else
      # Fallback to basic sed replacement if jq is not available
      log "jq not found. Using basic text replacement. This may not work reliably."
      
      # Create a temporary file with the updated config
      TMP_CONFIG=$(mktemp)
      
      # Extract the mcpServers object
      MCPSERVERS_START=$(echo "${CURRENT_CONFIG}" | grep -n "\"mcpServers\"" | cut -d: -f1)
      MCPSERVERS_END=$(echo "${CURRENT_CONFIG}" | grep -n "}" | tail -n 2 | head -n 1 | cut -d: -f1)
      
      # Write the updated config to the temporary file
      head -n ${MCPSERVERS_START} "${CLAUDE_CONFIG_FILE}" > "${TMP_CONFIG}"
      
      # Add the GitHub server config
      cat >> "${TMP_CONFIG}" << EOF
    "github": {
      "command": "npx",
      "args": [
        "-y",
        "@modelcontextprotocol/server-github"
      ],
      "env": {
        "NODE_OPTIONS": "--max-old-space-size=8192",
        "UV_THREADPOOL_SIZE": "12",
        "GITHUB_PERSONAL_ACCESS_TOKEN": "${GITHUB_TOKEN}",
        "GITHUB_TOOLSETS": "repos,issues,pull_requests,code_security,experiments,enterprise"
EOF
      
      if [ -n "${GITHUB_ENTERPRISE_URL}" ]; then
        cat >> "${TMP_CONFIG}" << EOF
        "GITHUB_ENTERPRISE_URL": "${GITHUB_ENTERPRISE_URL}"
EOF
      fi
      
      cat >> "${TMP_CONFIG}" << EOF
      }
    },
EOF
      
      # Add the rest of the config
      tail -n +$((${MCPSERVERS_START} + 1)) "${CLAUDE_CONFIG_FILE}" >> "${TMP_CONFIG}"
      
      # Use the temporary config
      CURRENT_CONFIG=$(cat "${TMP_CONFIG}")
      rm "${TMP_CONFIG}"
    fi
  else
    # GitHub MCP server already exists, update the token
    log "Updating GitHub credentials in Claude config"
    
    # Use jq if available
    if command -v jq &> /dev/null; then
      CURRENT_CONFIG=$(echo "${CURRENT_CONFIG}" | jq '.mcpServers.github.env.GITHUB_PERSONAL_ACCESS_TOKEN = "'"${GITHUB_TOKEN}"'"')
      
      if [ -n "${GITHUB_ENTERPRISE_URL}" ]; then
        CURRENT_CONFIG=$(echo "${CURRENT_CONFIG}" | jq '.mcpServers.github.env.GITHUB_ENTERPRISE_URL = "'"${GITHUB_ENTERPRISE_URL}"'"')
      else
        # Remove GITHUB_ENTERPRISE_URL if it exists and new value is empty
        CURRENT_CONFIG=$(echo "${CURRENT_CONFIG}" | jq 'del(.mcpServers.github.env.GITHUB_ENTERPRISE_URL)')
      fi
    else
      # Fallback to basic sed replacement if jq is not available
      log "jq not found. Using basic text replacement. This may not work reliably."
      
      # Replace the GitHub token
      CURRENT_CONFIG=$(echo "${CURRENT_CONFIG}" | sed "s/\"GITHUB_PERSONAL_ACCESS_TOKEN\": \"[^\"]*\"/\"GITHUB_PERSONAL_ACCESS_TOKEN\": \"${GITHUB_TOKEN}\"/g")
      
      if [ -n "${GITHUB_ENTERPRISE_URL}" ]; then
        # Replace or add the GitHub Enterprise URL
        if [[ "${CURRENT_CONFIG}" == *"GITHUB_ENTERPRISE_URL"* ]]; then
          CURRENT_CONFIG=$(echo "${CURRENT_CONFIG}" | sed "s/\"GITHUB_ENTERPRISE_URL\": \"[^\"]*\"/\"GITHUB_ENTERPRISE_URL\": \"${GITHUB_ENTERPRISE_URL}\"/g")
        else
          # Add it after GITHUB_PERSONAL_ACCESS_TOKEN
          CURRENT_CONFIG=$(echo "${CURRENT_CONFIG}" | sed "s/\"GITHUB_PERSONAL_ACCESS_TOKEN\": \"[^\"]*\"/\"GITHUB_PERSONAL_ACCESS_TOKEN\": \"${GITHUB_TOKEN}\",\n        \"GITHUB_ENTERPRISE_URL\": \"${GITHUB_ENTERPRISE_URL}\"/g")
        fi
      fi
    fi
  fi
fi

# Save the updated config
log "Saving updated Claude config"
echo "${CURRENT_CONFIG}" > "${CLAUDE_CONFIG_FILE}"

log "Claude config update complete"
echo "✅ Claude Desktop config has been updated."
echo "Restart Claude Desktop to apply the changes."

# Ask if Claude Desktop should be restarted
read -p "Would you like to restart Claude Desktop now? (y/n): " restart_claude

if [[ "${restart_claude}" =~ ^[Yy]$ ]]; then
  log "Restarting Claude Desktop"
  echo "Restarting Claude Desktop..."
  
  # Attempt to close Claude Desktop gracefully
  pkill -x "Claude"
  
  # Wait a moment for the app to close
  sleep 2
  
  # Launch Claude Desktop
  open -a "Claude"
  
  log "Claude Desktop restarted"
  echo "✅ Claude Desktop has been restarted."
else
  echo "Remember to restart Claude Desktop manually to apply the changes."
fi

exit 0
