#!/bin/bash
# Make initiate-archiving-protocol.sh executable
chmod +x /Users/XPV/Desktop/anchor-core/initiate-archiving-protocol.sh
echo "✅ Made initiate-archiving-protocol.sh executable"

# Create coherence marker
touch /Users/XPV/Desktop/anchor-core/coherence_lock/PROTOCOL_SCRIPT_EXECUTABLE_$(date +"%Y-%m-%dT%H%M%S%3N%z").marker
