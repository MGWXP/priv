#!/bin/bash
# run-module-fix.sh - Execute the CNIF module fixer
# © 2025 XPV - MIT

# Make the fix script executable
chmod +x /Users/XPV/Desktop/anchor-core/fix-cnif-modules.sh

# Run the fix script
/Users/XPV/Desktop/anchor-core/fix-cnif-modules.sh
