#!/bin/bash
chmod +x /Users/XPV/Desktop/anchor-core/socket-server-launcher.sh
chmod +x /Users/XPV/Desktop/anchor-core/verify-socket-servers.sh
chmod +x /Users/XPV/Desktop/anchor-core/mcp-servers/socket-server-implementation.js

echo "✅ Made socket server scripts executable"
echo "Now run: ./socket-server-launcher.sh"
