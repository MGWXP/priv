#!/bin/bash
# test-commonjs.sh - Test Node.js CommonJS functionality
# © 2025 XPV - MIT

set -e

# Define colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color
BLUE='\033[0;34m'

echo -e "${BLUE}===============================================${NC}"
echo -e "${BLUE}Testing Node.js CommonJS Support${NC}"
echo -e "${BLUE}===============================================${NC}"

# Create a simple CommonJS test file
cat > /tmp/test-commonjs.js << 'EOF'
// Basic CommonJS test
const fs = require('fs');
const path = require('path');
const os = require('os');

console.log("=== CommonJS Test ===");
console.log(`Node.js version: ${process.version}`);
console.log(`Platform: ${process.platform}`);
console.log(`Architecture: ${process.arch}`);
console.log(`Process ID: ${process.pid}`);

// Test requiring built-in modules
if (fs && path && os) {
  console.log("✅ Successfully required built-in modules");
} else {
  console.error("❌ Failed to require built-in modules");
  process.exit(1);
}

// Write a test file
const testFile = path.join(os.tmpdir(), 'commonjs-test.txt');
try {
  fs.writeFileSync(testFile, `Test file created at ${new Date().toISOString()}`);
  console.log(`✅ Successfully wrote file: ${testFile}`);
} catch (err) {
  console.error(`❌ Failed to write file: ${err.message}`);
  process.exit(1);
}

console.log("=== CommonJS Test Passed ===");
EOF

# Run the test
echo -e "${BLUE}Running CommonJS test...${NC}"
node /tmp/test-commonjs.js

echo -e "\n${GREEN}✅ CommonJS support verified!${NC}"
