#!/bin/bash
# make-deploy-executable.sh - Make deployment script executable
# © 2025 XPV - MIT

chmod +x /Users/XPV/Desktop/anchor-core/cnif-deploy.sh
echo "✅ CNIF deployment script is now executable"
echo "Run it with: /Users/XPV/Desktop/anchor-core/cnif-deploy.sh"
