#!/bin/bash
# make-optimizer-executable.sh - Make optimization scripts executable
chmod +x /Users/XPV/Desktop/anchor-core/one-step-mcp-optimizer.sh
chmod +x /Users/XPV/Desktop/anchor-core/launch-enhanced-mcp.sh
chmod +x /Users/XPV/Desktop/anchor-core/m3-optimizer/m3-mcp-optimizer.js
echo "Made optimization scripts executable"
