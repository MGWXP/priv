#!/bin/bash
# Run this to fix permissions for all scripts
chmod +x /Users/XPV/Desktop/anchor-core/fix-permissions.sh
