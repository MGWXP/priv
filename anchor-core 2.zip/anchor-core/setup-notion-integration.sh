#!/bin/bash
# setup-notion-integration.sh
# Sets up the enhanced Notion integration with SQLite metadata

set -e

ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
ENV_FILE="$ANCHOR_HOME/.env"

# Colors for better output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Create data directory
mkdir -p "$ANCHOR_HOME/data"
echo -e "${GREEN}✅ Created data directory at $ANCHOR_HOME/data${NC}"

# Check if .env file exists
if [ -f "$ENV_FILE" ]; then
    echo -e "${BLUE}Existing .env file found${NC}"
else
    echo -e "${YELLOW}Creating new .env file${NC}"
    cat > "$ENV_FILE" << EOF
# Anchor System V6.1 Environment Configuration
# Optimized for M3 Max hardware

# Node.js configuration
NODE_OPTIONS="--max-old-space-size=16220"
UV_THREADPOOL_SIZE=17

# Directory configuration
ANCHOR_HOME="$ANCHOR_HOME"
SOCKET_DIR="$ANCHOR_HOME/sockets"
LOG_DIR="$HOME/Library/Logs/Claude"
SQLITE_DIR="$ANCHOR_HOME/data"

# Security settings
SOCKET_MODE=0666

# Process management
HEALTH_CHECK_INTERVAL=5000
MAX_RESTART_ATTEMPTS=5
RESTART_DELAY=2000

# Server names
SERVER_NAMES=("git-local" "notion" "anchor-manager")

# Notion specific
NOTION_API_TOKEN=""
NOTION_CACHE_DURATION=3600
EOF
    echo -e "${GREEN}✅ Created new .env file${NC}"
fi

# Prompt for Notion API token if not already set
CURRENT_TOKEN=$(grep "NOTION_API_TOKEN" "$ENV_FILE" | cut -d '"' -f 2)
if [ -z "$CURRENT_TOKEN" ]; then
    echo -e "${YELLOW}Notion API token is not set.${NC}"
    read -p "Enter your Notion API token (leave blank to skip): " NOTION_TOKEN
    
    if [ ! -z "$NOTION_TOKEN" ]; then
        # Update token in .env file
        sed -i '' "s/NOTION_API_TOKEN=\"\"/NOTION_API_TOKEN=\"$NOTION_TOKEN\"/" "$ENV_FILE"
        echo -e "${GREEN}✅ Notion API token set in .env file${NC}"
    else
        echo -e "${YELLOW}Skipping Notion API token configuration${NC}"
    fi
else
    echo -e "${GREEN}✅ Notion API token already configured${NC}"
fi

# Install dependencies if not already installed
if [ ! -d "$ANCHOR_HOME/node_modules/@notionhq" ]; then
    echo -e "${BLUE}Installing required dependencies...${NC}"
    cd "$ANCHOR_HOME"
    npm install
    echo -e "${GREEN}✅ Dependencies installed${NC}"
else
    echo -e "${GREEN}✅ Dependencies already installed${NC}"
fi

# Make all scripts executable
echo -e "${BLUE}Making scripts executable...${NC}"
find "$ANCHOR_HOME" -name "*.sh" -exec chmod +x {} \;
chmod +x "$ANCHOR_HOME/mcp-servers/notion-integration.js"
echo -e "${GREEN}✅ Scripts made executable${NC}"

# Update Claude Desktop config
CONFIG_DIR="$HOME/Library/Application Support/Claude"
CONFIG_FILE="$CONFIG_DIR/claude_desktop_config.json"

if [ -f "$CONFIG_FILE" ]; then
    echo -e "${BLUE}Updating Claude Desktop configuration...${NC}"
    # Backup current config
    cp "$CONFIG_FILE" "$CONFIG_FILE.bak.$(date +%Y%m%d_%H%M%S)"
    
    # Update the config with the notion socket path if needed
    if grep -q "notion" "$CONFIG_FILE"; then
        echo -e "${GREEN}✅ Notion already configured in Claude Desktop${NC}"
    else
        # Add notion to the config
        TMP_FILE=$(mktemp)
        jq '.mcpServers.notion = {"command": "notion", "socketPath": "'"$ANCHOR_HOME"'/sockets/notion.sock"}' "$CONFIG_FILE" > "$TMP_FILE"
        mv "$TMP_FILE" "$CONFIG_FILE"
        echo -e "${GREEN}✅ Added Notion to Claude Desktop configuration${NC}"
    fi
else
    echo -e "${YELLOW}Claude Desktop configuration not found.${NC}"
    echo -e "${YELLOW}Please run Claude Desktop at least once to generate the config file.${NC}"
fi

echo -e "\n${GREEN}=== Notion Integration Setup Complete ===${NC}"
echo -e "${BLUE}To start the Notion integration:${NC}"
echo -e "  1. Run: ${YELLOW}cd $ANCHOR_HOME && npm run start${NC}"
echo -e "  2. Or run: ${YELLOW}cd $ANCHOR_HOME && npm run notion${NC} (for Notion only)"

echo -e "\n${BLUE}To verify the Notion integration:${NC}"
echo -e "  1. Launch Claude Desktop"
echo -e "  2. Ask Claude to perform a notion search"
echo -e "\n${YELLOW}NOTE: If you want to use a different Notion API token, edit $ENV_FILE${NC}"
