#!/bin/bash
# Documentation for CNIF WebSocket Bridge Integration
# ===================================================

# Overview
# --------
# This document provides instructions for integrating the WebSocket Bridge
# with the Claude-Notion Integration Framework (CNIF). The WebSocket Bridge
# enables real-time dashboard applications to communicate with MCP servers
# through Unix sockets.

# Key Components
# --------------
# 1. Socket Bridge: Connects Unix sockets to WebSockets
# 2. Notion Sync: Provides bidirectional synchronization with Notion databases
# 3. Dashboard: React-based real-time dashboard

# Installation
# ------------
# Run the setup script to install and initialize the WebSocket bridge:
#
#   chmod +x /Users/XPV/Desktop/anchor-core/setup-webbridge.sh
#   /Users/XPV/Desktop/anchor-core/setup-webbridge.sh
#
# This will:
# - Install required dependencies
# - Create necessary directories
# - Initialize the WebSocket bridge
# - Start the services

# Configuration
# -------------
# The WebSocket bridge can be configured in several ways:
#
# 1. Environment variables:
#    - SOCKET_DIR: Directory for Unix socket files
#    - LOG_DIR: Directory for log files
#    - WS_PORT: WebSocket server port
#    - NOTION_API_TOKEN: Notion API token
#    - NOTION_SYNC_INTERVAL: Interval for Notion synchronization
#    - ENABLE_DASHBOARD: Enable/disable dashboard server
#    - ENABLE_NOTION_SYNC: Enable/disable Notion synchronization
#
# 2. Command line options (webbridge-init.js):
#    - --port: WebSocket server port
#    - --socket-dir: Socket directory
#    - --log-dir: Log directory
#    - --dashboard/--no-dashboard: Enable/disable dashboard
#    - --notion-sync/--no-notion-sync: Enable/disable Notion sync

# Usage
# -----
# 1. Connect to the WebSocket server:
#    - WebSocket URL: ws://localhost:8765
#    - Available endpoints:
#      - /: Main WebSocket endpoint
#
# 2. Dashboard:
#    - URL: http://localhost:3000
#    - Configuration: /Users/XPV/Desktop/anchor-core/dashboard/config.json
#
# 3. Notion synchronization:
#    - Register a database: Send a message with type 'register_database'
#    - Get sync status: Send a message with type 'get_sync_status'
#    - Force sync: Send a message with type 'sync_database'

# Development
# -----------
# The source code is located in /Users/XPV/Desktop/anchor-core/src/webbridge.
# Key files:
#
# - socket-bridge.js: WebSocket bridge implementation
# - notion-sync.js: Notion synchronization
# - dashboard-optimizations.js: React optimizations for dashboard
# - webbridge-init.js: Initialization script

# Troubleshooting
# ---------------
# 1. Check logs:
#    - WebSocket bridge: ~/Library/Logs/Claude/socket-bridge.log
#    - Notion sync: ~/Library/Logs/Claude/notion-sync.log
#
# 2. Check if processes are running:
#    - WebSocket bridge: cat /Users/XPV/Desktop/anchor-core/webbridge.pid
#    - Notion sync: cat /Users/XPV/Desktop/anchor-core/notion-sync.pid
#
# 3. Restart services:
#    - /Users/XPV/Desktop/anchor-core/start-webbridge.sh

# Integration with MCP
# --------------------
# The WebSocket bridge seamlessly integrates with MCP servers using Unix sockets.
# To connect to an MCP server, send a message with type 'connect' and socketName.
#
# Example:
# {
#   "type": "connect",
#   "socketName": "notion"
# }
#
# To send a message to an MCP server, send a message with type 'message':
# {
#   "type": "message",
#   "socketName": "notion",
#   "message": {
#     "id": "12345",
#     "type": "get_database",
#     "database_id": "67890"
#   }
# }
