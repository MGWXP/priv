#!/bin/bash
# make-mcp-credential-scripts-executable.sh
# Makes all MCP credential management scripts executable
# © 2025 XPV - MIT License

# Set directory paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
LOG_DIR="${ANCHOR_HOME}/logs"

# Create log directory if it doesn't exist
mkdir -p "${LOG_DIR}"

# Log function
log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "${LOG_DIR}/make-executable.log"
}

# Make scripts executable
log "Making MCP credential management scripts executable"

chmod +x "${ANCHOR_HOME}/mcp-credentials-manager.sh"
chmod +x "${ANCHOR_HOME}/launch-mcp-credentials-ui.sh"
chmod +x "${ANCHOR_HOME}/update-claude-config-from-mcp.sh"
chmod +x "${ANCHOR_HOME}/mcp-credential-management.sh"
chmod +x "${ANCHOR_HOME}/utils/mcp-credentials-manager.js"
chmod +x "${ANCHOR_HOME}/utils/mcp-credentials-ui-launcher.js"
chmod +x "${ANCHOR_HOME}/github-token-updater.sh"
chmod +x "${ANCHOR_HOME}/test-mcp-connections.sh"

# Create executable indicator file
touch "${ANCHOR_HOME}/.mcp-credential-scripts-executable"

log "All MCP credential management scripts are now executable"
echo "✅ All MCP credential management scripts are now executable."

exit 0
