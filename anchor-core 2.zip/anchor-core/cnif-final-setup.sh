#!/bin/bash
# cnif-final-setup.sh - Final setup and verification for CNIF
# © 2025 XPV - MIT
#
# This script performs a comprehensive final setup and verification
# of the CNIF implementation to ensure all components are properly
# configured and operational.

ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
LOG_DIR="${HOME}/Library/Logs/Claude"
TIMESTAMP=$(date +"%Y%m%d%H%M%S")
LOG_FILE="${LOG_DIR}/cnif-final-setup-${TIMESTAMP}.log"

# Ensure log directory exists
mkdir -p "${LOG_DIR}"

# ANSI color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Log function
log() {
  local level="$1"
  local message="$2"
  local color="${NC}"
  
  case "${level}" in
    "INFO") color="${GREEN}" ;;
    "WARN") color="${YELLOW}" ;;
    "ERROR") color="${RED}" ;;
    "DEBUG") color="${BLUE}" ;;
    "STEP") color="${CYAN}" ;;
    *) color="${NC}" ;;
  esac
  
  echo -e "${color}$(date +"%Y-%m-%d %H:%M:%S") [${level}] ${message}${NC}" | tee -a "${LOG_FILE}"
}

# Print header
print_header() {
  local title="$1"
  echo -e "\n${CYAN}======================================================================${NC}"
  echo -e "${CYAN}= ${title}${NC}"
  echo -e "${CYAN}======================================================================${NC}"
}

# Fix script permissions
fix_permissions() {
  print_header "Fixing Permissions"
  
  log "STEP" "Making all scripts executable..."
  
  # Make this script executable first
  chmod +x "$0"
  
  # Make fix-permissions.sh executable
  if [ -f "${ANCHOR_HOME}/fix-permissions.sh" ]; then
    chmod +x "${ANCHOR_HOME}/fix-permissions.sh"
    log "INFO" "Made fix-permissions.sh executable"
    
    # Run the full permission fix script
    log "STEP" "Running comprehensive permission fix..."
    "${ANCHOR_HOME}/fix-permissions.sh"
  else
    log "WARN" "fix-permissions.sh not found, doing basic permission fixes"
    
    # Basic permission fixes
    for script in $(find "${ANCHOR_HOME}" -name "*.sh"); do
      chmod +x "$script"
    done
    
    log "INFO" "Made all .sh scripts executable"
    
    # Fix permissions for key directories
    mkdir -p "${ANCHOR_HOME}/schemas/claude"
    mkdir -p "${ANCHOR_HOME}/schemas/notion"
    mkdir -p "${ANCHOR_HOME}/config"
    mkdir -p "${ANCHOR_HOME}/sockets"
    mkdir -p "${ANCHOR_HOME}/coherence_lock"
    
    chmod 755 "${ANCHOR_HOME}/schemas"
    chmod 755 "${ANCHOR_HOME}/schemas/claude"
    chmod 755 "${ANCHOR_HOME}/schemas/notion"
    chmod 755 "${ANCHOR_HOME}/config"
    chmod 755 "${ANCHOR_HOME}/sockets"
    chmod 755 "${ANCHOR_HOME}/coherence_lock"
    chmod 755 "${ANCHOR_HOME}/m3-optimizer"
    chmod 755 "${LOG_DIR}"
    
    log "INFO" "Set directory permissions"
  fi
  
  log "INFO" "✅ Permission fixes complete"
}

# Verify schema registry
verify_schema_registry() {
  print_header "Verifying Schema Registry"
  
  log "STEP" "Checking schema directories..."
  
  # Check schema directories
  if [ ! -d "${ANCHOR_HOME}/schemas/claude" ]; then
    log "ERROR" "Claude schema directory missing"
    mkdir -p "${ANCHOR_HOME}/schemas/claude"
    log "INFO" "Created Claude schema directory"
  fi
  
  if [ ! -d "${ANCHOR_HOME}/schemas/notion" ]; then
    log "ERROR" "Notion schema directory missing"
    mkdir -p "${ANCHOR_HOME}/schemas/notion"
    log "INFO" "Created Notion schema directory"
  fi
  
  # Check for schema files
  local claude_schemas=$(ls -1 "${ANCHOR_HOME}/schemas/claude/"*.json 2>/dev/null | wc -l)
  local notion_schemas=$(ls -1 "${ANCHOR_HOME}/schemas/notion/"*.json 2>/dev/null | wc -l)
  
  log "INFO" "Found ${claude_schemas} Claude schemas and ${notion_schemas} Notion schemas"
  
  if [ "$claude_schemas" -eq 0 ]; then
    log "WARN" "No Claude schemas found, creating test schema"
    
    # Create basic test schema
    cat > "${ANCHOR_HOME}/schemas/claude/test-schema-1-0-0.json" << EOF
{
  "id": "test-schema",
  "version": "1-0-0",
  "description": "Basic test schema for Claude",
  "schema": {
    "type": "object",
    "required": ["message", "timestamp"],
    "properties": {
      "message": {
        "type": "string",
        "description": "The message content"
      },
      "timestamp": {
        "type": "string",
        "description": "ISO timestamp"
      },
      "metadata": {
        "type": "object",
        "properties": {
          "source": {
            "type": "string"
          },
          "priority": {
            "type": "string"
          }
        }
      }
    }
  }
}
EOF
    log "INFO" "Created test Claude schema"
  fi
  
  if [ "$notion_schemas" -eq 0 ]; then
    log "WARN" "No Notion schemas found, creating test schema"
    
    # Create basic Notion schema
    cat > "${ANCHOR_HOME}/schemas/notion/notion-database-schema-1-0-0.json" << EOF
{
  "id": "notion-database-schema",
  "version": "1-0-0",
  "description": "Basic schema for Notion database",
  "schema": {
    "type": "object",
    "required": ["results"],
    "properties": {
      "object": {
        "type": "string"
      },
      "results": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "object": {
              "type": "string"
            },
            "id": {
              "type": "string"
            },
            "properties": {
              "type": "object"
            }
          }
        }
      },
      "next_cursor": {
        "type": ["string", "null"]
      },
      "has_more": {
        "type": "boolean"
      }
    }
  }
}
EOF
    log "INFO" "Created test Notion schema"
  fi
  
  log "INFO" "✅ Schema verification complete"
}

# Verify configuration
verify_configuration() {
  print_header "Verifying Configuration"
  
  log "STEP" "Checking configuration directory..."
  
  # Check config directory
  if [ ! -d "${ANCHOR_HOME}/config" ]; then
    log "ERROR" "Config directory missing"
    mkdir -p "${ANCHOR_HOME}/config"
    log "INFO" "Created config directory"
  fi
  
  # Check for Notion config
  if [ ! -f "${ANCHOR_HOME}/config/notion-config.json" ]; then
    log "WARN" "Notion config missing, creating template"
    
    # Create template Notion config
    cat > "${ANCHOR_HOME}/config/notion-config.json" << EOF
{
  "apiToken": "",
  "apiVersion": "2022-06-28",
  "baseUrl": "https://api.notion.com/v1",
  "rateLimit": {
    "maxRequests": 3,
    "periodMs": 1000,
    "maxRetries": 5
  },
  "cacheDir": "${ANCHOR_HOME}/data/notion-cache",
  "timeout": 30000,
  "databases": {
    "documentation": "",
    "meetingNotes": ""
  },
  "connectionSettings": {
    "exponentialBackoff": {
      "baseDelay": 1000,
      "maxDelay": 32000,
      "factor": 2,
      "jitter": 0.25
    },
    "circuitBreaker": {
      "failureThreshold": 5,
      "resetTimeout": 60000,
      "halfOpenMaxRequests": 1
    },
    "poolSize": 3,
    "keepAliveTimeout": 60000
  }
}
EOF
    log "INFO" "Created template Notion config"
    log "WARN" "You will need to add your Notion API token to ${ANCHOR_HOME}/config/notion-config.json"
  fi
  
  # Create data directory
  if [ ! -d "${ANCHOR_HOME}/data/notion-cache" ]; then
    mkdir -p "${ANCHOR_HOME}/data/notion-cache"
    log "INFO" "Created notion-cache directory"
  fi
  
  log "INFO" "✅ Configuration verification complete"
}

# Verify launcher scripts
verify_launchers() {
  print_header "Verifying Launcher Scripts"
  
  log "STEP" "Checking launcher scripts..."
  
  # Check for simple launcher
  if [ ! -x "${ANCHOR_HOME}/simple-launcher.sh" ]; then
    log "WARN" "simple-launcher.sh is not executable"
    chmod +x "${ANCHOR_HOME}/simple-launcher.sh"
    log "INFO" "Made simple-launcher.sh executable"
  fi
  
  # Check for sequenced launcher
  if [ ! -x "${ANCHOR_HOME}/sequenced-launcher.sh" ]; then
    log "WARN" "sequenced-launcher.sh is not executable"
    chmod +x "${ANCHOR_HOME}/sequenced-launcher.sh"
    log "INFO" "Made sequenced-launcher.sh executable"
  fi
  
  # Check for CNIF launcher
  if [ ! -x "${ANCHOR_HOME}/cnif-launcher.sh" ]; then
    log "WARN" "cnif-launcher.sh is not executable"
    chmod +x "${ANCHOR_HOME}/cnif-launcher.sh"
    log "INFO" "Made cnif-launcher.sh executable"
  fi
  
  # Run optimizer if needed
  if [ ! -f "${ANCHOR_HOME}/m3-optimized-launcher.sh" ]; then
    log "INFO" "Optimized launcher not found, running optimizer..."
    
    if [ -x "${ANCHOR_HOME}/run-cnif-optimizer.sh" ]; then
      "${ANCHOR_HOME}/run-cnif-optimizer.sh"
    else
      chmod +x "${ANCHOR_HOME}/run-cnif-optimizer.sh"
      "${ANCHOR_HOME}/run-cnif-optimizer.sh"
    fi
  fi
  
  log "INFO" "✅ Launcher verification complete"
}

# Setup coherence tracking
setup_coherence() {
  print_header "Setting Up Coherence Tracking"
  
  log "STEP" "Checking coherence directories..."
  
  # Check coherence directory
  if [ ! -d "${ANCHOR_HOME}/coherence_lock" ]; then
    log "INFO" "Creating coherence lock directory"
    mkdir -p "${ANCHOR_HOME}/coherence_lock"
  fi
  
  # Create coherence marker for this setup
  local marker_path="${ANCHOR_HOME}/coherence_lock/SETUP_COMPLETE_${TIMESTAMP}.marker"
  
  cat > "${marker_path}" << EOF
{
  "timestamp": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
  "status": "SETUP_COMPLETE",
  "component": "CNIF_SYSTEM",
  "version": "1.0.0"
}
EOF
  
  log "INFO" "Created coherence marker: ${marker_path}"
  log "INFO" "✅ Coherence setup complete"
}

# Create final system report
create_system_report() {
  print_header "Creating System Report"
  
  local report_path="${ANCHOR_HOME}/CNIF_SYSTEM_READY.md"
  
  log "STEP" "Generating system report..."
  
  cat > "${report_path}" << EOF
# CNIF System Ready Report

**Generated:** $(date)

## System Status

The Claude-Notion Integration Framework (CNIF) has been verified and is ready for use.

## Available Commands

1. **Start System (Basic):**
   \`\`\`
   /Users/XPV/Desktop/anchor-core/simple-launcher.sh
   \`\`\`

2. **Start System (Advanced):**
   \`\`\`
   /Users/XPV/Desktop/anchor-core/sequenced-launcher.sh
   \`\`\`

3. **Start System (Optimized for M3 Max):**
   \`\`\`
   /Users/XPV/Desktop/anchor-core/m3-optimized-launcher.sh
   \`\`\`

4. **All-in-One Launcher:**
   \`\`\`
   /Users/XPV/Desktop/anchor-core/cnif-launcher.sh
   \`\`\`

## System Components

- **Schema Registry:** Manages versioned schemas for Claude and Notion data
- **Socket Server:** Handles MCP communication with Claude using Unix sockets
- **Streaming Transformer:** Converts between Claude's XML and Notion's JSON formats
- **Notion Connection Manager:** Handles API communication with Notion
- **MCP Orchestrator:** Coordinates service communication and workflow

## Setup Verification

The following components have been verified:

- ✅ Script permissions fixed
- ✅ Schema directories and files created
- ✅ Configuration files verified
- ✅ Launcher scripts ready
- ✅ Coherence tracking initialized

## Next Steps

1. Configure your Notion API token in \`/Users/XPV/Desktop/anchor-core/config/notion-config.json\`
2. Start the system using one of the launcher scripts
3. Verify operation with the system check script:
   \`\`\`
   /Users/XPV/Desktop/anchor-core/cnif-system-check.sh
   \`\`\`

## Documentation

For detailed information about the system, please refer to:

- \`/Users/XPV/Desktop/anchor-core/CNIF_SYSTEM_DOCUMENTATION.md\`
- \`/Users/XPV/Desktop/anchor-core/CNIF_IMPLEMENTATION_FINAL_REPORT.md\`

---

CNIF System Setup Complete at $(date)
EOF
  
  log "INFO" "Generated system report: ${report_path}"
  log "INFO" "✅ System report creation complete"
}

# Main function
main() {
  print_header "CNIF Final Setup"
  log "INFO" "🚀 Starting CNIF final setup..."
  
  # Run verification steps
  fix_permissions
  verify_schema_registry
  verify_configuration
  verify_launchers
  setup_coherence
  create_system_report
  
  # Final status
  print_header "Setup Complete"
  log "INFO" "✅ CNIF system setup and verification complete"
  log "INFO" "📝 Log file: ${LOG_FILE}"
  log "INFO" "📋 System report: ${ANCHOR_HOME}/CNIF_SYSTEM_READY.md"
  
  echo -e "\n${GREEN}✅ CNIF system is now ready for use.${NC}"
  echo -e "${GREEN}💡 Run ${CYAN}/Users/XPV/Desktop/anchor-core/cnif-launcher.sh${GREEN} to get started.${NC}"
}

# Run main function
main
