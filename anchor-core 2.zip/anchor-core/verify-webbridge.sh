#!/bin/bash
# WebSocket Bridge Verification Script
# Updated: 2025-05-19

# Define variables
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
SOCKET_DIR="/Users/XPV/Desktop/anchor-core/sockets"
LOG_DIR="$HOME/Library/Logs/Claude"
WS_PORT=$(cat "$ANCHOR_HOME/dashboard/config.json" | grep -o '"port":[^,}]*' | cut -d ":" -f2 | tr -d ' ' || echo 8765)

echo "==== CNIF WebSocket Bridge Verification ===="
echo "Date: $(date)"
echo

# Check if WebSocket bridge is running
echo "Checking WebSocket bridge..."
if [ -f "$ANCHOR_HOME/webbridge.pid" ]; then
  PID=$(cat "$ANCHOR_HOME/webbridge.pid")
  if [ -n "$PID" ] && ps -p $PID > /dev/null; then
    echo "✅ WebSocket bridge is running (PID: $PID)"
    
    # Try to fetch status from API
    echo -n "  Testing API connection... "
    if curl -s "http://localhost:$WS_PORT/api/status" > /dev/null; then
      echo "Connected"
    else
      echo "Failed (API not responding)"
    fi
  else
    echo "❌ WebSocket bridge PID file exists but process is not running"
  fi
else
  echo "❌ WebSocket bridge is not running (PID file not found)"
fi

# Check if Notion sync is running
echo
echo "Checking Notion sync..."
if [ -f "$ANCHOR_HOME/notion-sync.pid" ]; then
  PID=$(cat "$ANCHOR_HOME/notion-sync.pid")
  if [ -n "$PID" ] && ps -p $PID > /dev/null; then
    echo "✅ Notion sync is running (PID: $PID)"
  else
    echo "❌ Notion sync PID file exists but process is not running"
  fi
else
  echo "❌ Notion sync is not running (PID file not found)"
fi

# Check if dashboard server is running
echo
echo "Checking dashboard server..."
if [ -f "$ANCHOR_HOME/dashboard.pid" ]; then
  PID=$(cat "$ANCHOR_HOME/dashboard.pid")
  if [ -n "$PID" ] && ps -p $PID > /dev/null; then
    echo "✅ Dashboard server is running (PID: $PID)"
  else
    echo "❌ Dashboard server PID file exists but process is not running"
  fi
else
  echo "❌ Dashboard server is not running (PID file not found)"
fi

# Check socket directory
echo
echo "Checking socket directory..."
if [ -d "$SOCKET_DIR" ]; then
  echo "✅ Socket directory exists: $SOCKET_DIR"
  echo "  Available sockets:"
  SOCK_COUNT=0
  for SOCK in "$SOCKET_DIR"/*.sock; do
    if [ -S "$SOCK" ]; then
      echo "  - $(basename "$SOCK" .sock)"
      SOCK_COUNT=$((SOCK_COUNT+1))
    fi
  done
  
  if [ $SOCK_COUNT -eq 0 ]; then
    echo "  (No active socket files found)"
  fi
else
  echo "❌ Socket directory does not exist: $SOCKET_DIR"
fi

# Check log files
echo
echo "Checking log files..."
if [ -d "$LOG_DIR" ]; then
  echo "✅ Log directory exists: $LOG_DIR"
  echo "  Recent log entries:"
  
  if [ -f "$LOG_DIR/socket-bridge.log" ]; then
    echo "  Socket Bridge Log:"
    tail -n 3 "$LOG_DIR/socket-bridge.log" | sed 's/^/    /'
  else
    echo "  ❌ Socket bridge log not found"
  fi
  
  if [ -f "$LOG_DIR/notion-sync.log" ]; then
    echo "  Notion Sync Log:"
    tail -n 3 "$LOG_DIR/notion-sync.log" | sed 's/^/    /'
  else
    echo "  ❌ Notion sync log not found"
  fi
else
  echo "❌ Log directory does not exist: $LOG_DIR"
fi

# Provide next steps
echo
echo "==== Verification Summary ===="
if [ -f "$ANCHOR_HOME/webbridge.pid" ] && ps -p $(cat "$ANCHOR_HOME/webbridge.pid") > /dev/null; then
  echo "WebSocket bridge is operational"
  echo "Dashboard is available at: http://localhost:$WS_PORT"
else
  echo "WebSocket bridge is not running"
  echo "To start the WebSocket bridge:"
  echo "  $ANCHOR_HOME/start-webbridge.sh"
fi

if [ -f "$ANCHOR_HOME/notion-sync.pid" ] && ps -p $(cat "$ANCHOR_HOME/notion-sync.pid") > /dev/null; then
  echo "Notion sync is operational"
else
  echo "Notion sync is not running"
fi

echo
echo "For more detailed troubleshooting, see:"
echo "  $ANCHOR_HOME/WEBBRIDGE_TROUBLESHOOTING.md"
echo
