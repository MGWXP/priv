# CNIF Quick Setup Guide

This guide will help you quickly set up the Claude-Notion Integration Framework (CNIF) on your system.

## 🚀 One-Step Setup

The fix-cnif.sh script will:
1. Configure your Notion API token
2. Set up all required directories
3. Start all necessary services
4. Verify everything is working correctly

To use it:

```bash
# Make the script executable
chmod +x /Users/XPV/Desktop/anchor-core/fix-cnif.sh

# Run the script
/Users/XPV/Desktop/anchor-core/fix-cnif.sh
```

## 🔍 Verification

After running the fix script, you can verify that everything is working correctly by running:

```bash
/Users/XPV/Desktop/anchor-core/verify-cnif.sh
```

## 🌐 Accessing the Dashboard

Once the system is running, you can access the dashboard at:

http://localhost:8765

## 📝 Troubleshooting

If you encounter any issues, check the log files in:

```
/Users/XPV/Library/Logs/Claude/
```

For more detailed troubleshooting, see the WEBBRIDGE_TROUBLESHOOTING.md file.

## 🛑 Stopping the Services

To stop all running services:

```bash
bash -c 'kill $(cat /Users/XPV/Desktop/anchor-core/webbridge.pid /Users/XPV/Desktop/anchor-core/notion-sync.pid /Users/XPV/Desktop/anchor-core/dashboard.pid 2>/dev/null)'
```

---

For more details about the CNIF architecture and implementation, see the main README.md file.
