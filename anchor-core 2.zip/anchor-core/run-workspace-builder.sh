#!/bin/bash
# Build the Anchor workspace in Notion

# Make the builder script executable
chmod +x /Users/XPV/Desktop/anchor-core/notion-anchor-workspace-builder.sh

# Run the builder script
/Users/XPV/Desktop/anchor-core/notion-anchor-workspace-builder.sh

# Open the Notion page in the default browser
open "https://www.notion.so/Anchor-1f7e48c2bbbd80df86edd35832916f80"

echo "Anchor V6 MCP Project workspace setup complete!"
