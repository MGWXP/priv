#!/bin/bash
# run-basic-test.sh - Run basic Node.js tests to validate environment
# © 2025 XPV - MIT

set -e

# Define colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color
BLUE='\033[0;34m'

# Base paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
TEST_PATH="$ANCHOR_HOME/test-basic.js"

echo -e "${BLUE}=========================================${NC}"
echo -e "${BLUE}Running Basic Node.js Test${NC}"
echo -e "${BLUE}=========================================${NC}"

# Check if test file exists
if [ ! -f "$TEST_PATH" ]; then
  echo -e "${RED}Error: Test file not found: $TEST_PATH${NC}"
  exit 1
fi

# Export only safe NODE_OPTIONS
export NODE_OPTIONS="--max-old-space-size=8192"

echo -e "${BLUE}Starting basic test...${NC}"
# Run the test
node "$TEST_PATH"

echo -e "\n${GREEN}Basic test complete!${NC}"
