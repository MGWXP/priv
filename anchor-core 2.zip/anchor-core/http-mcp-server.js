const http = require('http');
const url = require('url');

// Server configuration
const PORT = 3000;
const servers = {
  'git-local': {
    name: 'git-local',
    version: '1.0.0',
    tools: {
      'git': {
        description: 'Git local operations',
        schema: {
          type: 'object',
          properties: {
            command: {
              type: 'string',
              description: 'Git command to execute'
            }
          },
          required: ['command']
        }
      }
    }
  },
  'notion': {
    name: 'notion',
    version: '1.0.0',
    tools: {
      'notion': {
        description: 'Notion operations',
        schema: {
          type: 'object',
          properties: {
            operation: {
              type: 'string',
              description: 'Notion operation to execute'
            }
          },
          required: ['operation']
        }
      }
    }
  },
  'anchor-manager': {
    name: 'anchor-manager',
    version: '1.0.0',
    tools: {
      'anchor': {
        description: 'Anchor system management',
        schema: {
          type: 'object',
          properties: {
            action: {
              type: 'string',
              description: 'Anchor management action'
            }
          },
          required: ['action']
        }
      }
    }
  }
};

// Create HTTP server
const server = http.createServer((req, res) => {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  
  // Handle preflight requests
  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }
  
  // Only allow POST requests
  if (req.method !== 'POST') {
    res.writeHead(405);
    res.end('Method Not Allowed');
    return;
  }
  
  // Get server name from URL path
  const pathname = url.parse(req.url).pathname;
  const serverName = pathname.split('/')[1]; // e.g., /git-local/... -> git-local
  
  if (!serverName || !servers[serverName]) {
    res.writeHead(404);
    res.end('Server not found');
    return;
  }
  
  // Process request body
  let body = '';
  req.on('data', chunk => {
    body += chunk.toString();
  });
  
  req.on('end', () => {
    try {
      const requestData = JSON.parse(body);
      console.log(`[${serverName}] Received request:`, JSON.stringify(requestData, null, 2));
      
      // Handle request
      if (requestData.method === 'initialize') {
        // Send server information
        const response = {
          jsonrpc: '2.0',
          id: requestData.id,
          result: {
            protocolVersion: requestData.params?.protocolVersion || '2024-11-05',
            name: servers[serverName].name,
            version: servers[serverName].version,
            capabilities: {
              tools: servers[serverName].tools
            }
          }
        };
        
        res.writeHead(200, {'Content-Type': 'application/json'});
        res.end(JSON.stringify(response));
        console.log(`[${serverName}] Sent initialize response`);
      } 
      else if (requestData.method === 'execute') {
        // Execute tool
        const toolName = requestData.params?.tool;
        const params = requestData.params?.params || {};
        
        const response = {
          jsonrpc: '2.0',
          id: requestData.id,
          result: {
            output: `Executed ${toolName} with params: ${JSON.stringify(params)}`
          }
        };
        
        res.writeHead(200, {'Content-Type': 'application/json'});
        res.end(JSON.stringify(response));
        console.log(`[${serverName}] Executed ${toolName} with params:`, params);
      }
      else {
        // Unknown method
        const response = {
          jsonrpc: '2.0',
          id: requestData.id,
          error: {
            code: -32601,
            message: `Method not found: ${requestData.method}`
          }
        };
        
        res.writeHead(200, {'Content-Type': 'application/json'});
        res.end(JSON.stringify(response));
      }
    } catch (err) {
      console.error(`[${serverName}] Error:`, err);
      
      const response = {
        jsonrpc: '2.0',
        id: null,
        error: {
          code: -32700,
          message: `Parse error: ${err.message}`
        }
      };
      
      res.writeHead(200, {'Content-Type': 'application/json'});
      res.end(JSON.stringify(response));
    }
  });
});

// Start server
server.listen(PORT, () => {
  console.log(`MCP HTTP server running at http://localhost:${PORT}`);
  console.log('Available servers:');
  Object.keys(servers).forEach(name => {
    console.log(`- http://localhost:${PORT}/${name}`);
  });
});

// Handle process termination
process.on('SIGINT', () => {
  console.log('Shutting down server...');
  server.close(() => {
    process.exit(0);
  });
});
