#!/bin/bash
# test-socket-server.sh - Run a simple socket server test
# © 2025 XPV - MIT

set -e

# Define colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color
BLUE='\033[0;34m'

# Base paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
SOCKET_DIR="$ANCHOR_HOME/sockets"

echo -e "${BLUE}=========================================${NC}"
echo -e "${BLUE}Running Simple Socket Server Test${NC}"
echo -e "${BLUE}=========================================${NC}"

# Ensure socket directory exists
mkdir -p "$SOCKET_DIR"

# Export only safe NODE_OPTIONS
export NODE_OPTIONS="--max-old-space-size=8192"
export SOCKET_DIR="$SOCKET_DIR"

# Remove any existing test socket
if [ -e "$SOCKET_DIR/test-socket.sock" ]; then
  rm -f "$SOCKET_DIR/test-socket.sock"
  echo -e "${YELLOW}Removed existing test socket${NC}"
fi

echo -e "${BLUE}Starting simple socket server...${NC}"
node "$ANCHOR_HOME/simple-socket-server.js" &
SERVER_PID=$!

# Wait for server to start
sleep 2

# Check if socket file was created
if [ -e "$SOCKET_DIR/test-socket.sock" ]; then
  # Check permissions
  PERMS=$(stat -f "%p" "$SOCKET_DIR/test-socket.sock" | cut -c 3-5)
  echo -e "${GREEN}✅ Socket file created: $SOCKET_DIR/test-socket.sock${NC}"
  echo -e "${GREEN}✅ Socket permissions: $PERMS${NC}"
  
  # Test connection to socket
  echo -e "${BLUE}Testing connection to socket...${NC}"
  echo "Hello, socket!" | nc -U "$SOCKET_DIR/test-socket.sock"
  
  # Check if server is still running
  if ps -p $SERVER_PID > /dev/null; then
    echo -e "${GREEN}✅ Server is running (PID: $SERVER_PID)${NC}"
    
    # Stop the server
    echo -e "${BLUE}Stopping server...${NC}"
    kill -SIGINT $SERVER_PID
    sleep 1
    
    # Check if socket file was removed
    if [ ! -e "$SOCKET_DIR/test-socket.sock" ]; then
      echo -e "${GREEN}✅ Socket file was properly removed on exit${NC}"
    else
      echo -e "${RED}❌ Socket file was not removed on exit${NC}"
      rm -f "$SOCKET_DIR/test-socket.sock"
    fi
  else
    echo -e "${RED}❌ Server process died unexpectedly${NC}"
  fi
else
  echo -e "${RED}❌ Socket file was not created!${NC}"
  # Kill the server if it's still running
  if ps -p $SERVER_PID > /dev/null; then
    kill $SERVER_PID
  fi
fi

echo -e "\n${GREEN}Simple socket server test complete${NC}"
