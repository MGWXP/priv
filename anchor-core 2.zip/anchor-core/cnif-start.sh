#!/bin/bash
# cnif-start.sh - Fixed CNIF starter
# © 2025 XPV - MIT

ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
LOG_DIR="${HOME}/Library/Logs/Claude"

# Create necessary directories
mkdir -p "${LOG_DIR}"
mkdir -p "${ANCHOR_HOME}/sockets"
mkdir -p "${ANCHOR_HOME}/coherence_lock"

# Make optimizations
export NODE_OPTIONS="--max-old-space-size=8192"
export UV_THREADPOOL_SIZE="12"
export CNIF_BUFFER_SIZE="65536"
export CNIF_SCHEMA_CACHE_SIZE="256"
export CNIF_SOCKET_BACKLOG="128"
export CNIF_POOL_SIZE="8"
export CNIF_XML_CHUNK_SIZE="16384"
export CNIF_JSON_CHUNK_SIZE="16384"
export CNIF_LOG_LEVEL="info"
export CNIF_COHERENCE_ENABLED="true"
export CNIF_CIRCUIT_BREAKER_ENABLED="true"
export ANCHOR_HOME="${ANCHOR_HOME}"

# Stop any existing processes
echo "Stopping any existing processes..."
pkill -f "node ${ANCHOR_HOME}/mcp-servers" || true
sleep 1

# Remove any existing socket files
rm -f "${ANCHOR_HOME}/sockets/"*.sock

# Print optimization info
echo "✅ M3 Max optimizations applied"
echo "🧠 Memory allocation: ${NODE_OPTIONS}"
echo "⚙️ Thread pool size: ${UV_THREADPOOL_SIZE}"
echo "📊 Buffer size: ${CNIF_BUFFER_SIZE}"

# Start services directly
echo "Starting schema-registry..."
MCP_SERVER_NAME="schema-registry" node "${ANCHOR_HOME}/mcp-servers/schema-registry-index.js" > "${LOG_DIR}/schema-registry.out" 2>&1 &
echo "Started schema-registry (PID: $!)"
sleep 3

echo "Starting socket-server..."
MCP_SERVER_NAME="socket-server" node "${ANCHOR_HOME}/mcp-servers/socket-server-implementation.cjs" > "${LOG_DIR}/socket-server.out" 2>&1 &
echo "Started socket-server (PID: $!)"
sleep 1

echo "Starting streaming-transformer..."
MCP_SERVER_NAME="streaming-transformer" node "${ANCHOR_HOME}/mcp-servers/streaming-schema-transformer.cjs" > "${LOG_DIR}/streaming-transformer.out" 2>&1 &
echo "Started streaming-transformer (PID: $!)"
sleep 1

echo "Starting notion..."
MCP_SERVER_NAME="notion" node "${ANCHOR_HOME}/mcp-servers/notion-connection-manager.cjs" > "${LOG_DIR}/notion.out" 2>&1 &
echo "Started notion (PID: $!)"
sleep 1

echo "Starting mcp-orchestrator..."
MCP_SERVER_NAME="mcp-orchestrator" node "${ANCHOR_HOME}/mcp-servers/mcp-orchestrator.cjs" > "${LOG_DIR}/mcp-orchestrator.out" 2>&1 &
echo "Started mcp-orchestrator (PID: $!)"

# Fix socket permissions
echo "Fixing socket permissions..."
sleep 2
chmod 666 "${ANCHOR_HOME}/sockets/"*.sock 2>/dev/null || true

echo "✅ All services started"
echo "Use 'ps aux | grep node' to check if services are running"
echo "Use 'tail -f ${LOG_DIR}/*.log' to view logs"

# Create success marker
echo "CNIF started successfully at $(date)" > "${ANCHOR_HOME}/coherence_lock/CNIF_START_SUCCESS_$(date +%Y%m%d%H%M%S).marker"
