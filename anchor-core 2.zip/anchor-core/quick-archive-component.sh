#!/bin/bash
# quick-archive-component.sh - Simple interactive archiving tool for Anchor V6
# This script provides a user-friendly way to archive a single component

# Set strict error handling
set -e

# ANSI color codes for output formatting
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Make this script executable
chmod +x $0

# Print banner
echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║                ANCHOR V6 QUICK COMPONENT ARCHIVER               ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"

# Check if meta-protocols directory exists
META_DIR="/Users/XPV/Desktop/anchor-core/meta-protocols"
if [ ! -d "$META_DIR" ]; then
    echo -e "${RED}Error: Meta-protocols directory not found at:${NC}"
    echo -e "${MAGENTA}$META_DIR${NC}"
    echo -e "${YELLOW}Please run initialize-archival-system.sh first.${NC}"
    exit 1
fi

# Check if archive-component.sh exists
ARCHIVE_SCRIPT="$META_DIR/archive-component.sh"
if [ ! -f "$ARCHIVE_SCRIPT" ]; then
    echo -e "${RED}Error: Archive component script not found at:${NC}"
    echo -e "${MAGENTA}$ARCHIVE_SCRIPT${NC}"
    echo -e "${YELLOW}Please run initialize-archival-system.sh first.${NC}"
    exit 1
fi

# Make archive script executable
chmod +x "$ARCHIVE_SCRIPT"

# Interactive component selection
echo -e "\n${CYAN}Welcome to the Quick Component Archiver${NC}"
echo -e "This tool will help you quickly archive a problematic component."
echo -e "Let's get started..."

# Step 1: Find the component to archive
echo -e "\n${YELLOW}Step 1: Find the component to archive${NC}"
echo -e "You can specify a component path, or search for a component by name."
echo -e "What would you like to do?"
echo -e "  1) Specify full component path"
echo -e "  2) Search for component by name"
read -p "Enter your choice [1-2]: " find_choice

COMPONENT_PATH=""

case $find_choice in
    1)
        read -p "Enter full component path: " COMPONENT_PATH
        ;;
    2)
        read -p "Enter component name or partial name to search: " search_term
        echo -e "\n${CYAN}Searching for components matching: ${MAGENTA}$search_term${NC}"
        
        # Search for JS files matching the name
        SEARCH_RESULTS=$(find "/Users/XPV/Desktop/anchor-core" -type f \( -name "*$search_term*.js" -o -name "*$search_term*.cjs" -o -name "*$search_term*.mjs" \) -not -path "*/node_modules/*" -not -path "*/archive/*" 2>/dev/null)
        
        if [ -z "$SEARCH_RESULTS" ]; then
            echo -e "${RED}No components found matching: $search_term${NC}"
            exit 1
        fi
        
        # Display search results with numbers
        echo -e "\n${CYAN}Found the following components:${NC}"
        count=1
        declare -a result_array
        while read -r file; do
            echo -e "  $count) $file"
            result_array[$count]="$file"
            count=$((count + 1))
        done <<< "$SEARCH_RESULTS"
        
        # Let user select from search results
        read -p "Enter component number: " component_num
        
        if [[ "$component_num" =~ ^[0-9]+$ ]] && [ "$component_num" -gt 0 ] && [ "$component_num" -lt "$count" ]; then
            COMPONENT_PATH="${result_array[$component_num]}"
            echo -e "${GREEN}Selected component: ${MAGENTA}$COMPONENT_PATH${NC}"
        else
            echo -e "${RED}Invalid selection${NC}"
            exit 1
        fi
        ;;
    *)
        echo -e "${RED}Invalid choice${NC}"
        exit 1
        ;;
esac

# Verify component path exists
if [ ! -f "$COMPONENT_PATH" ]; then
    echo -e "${RED}Error: Component does not exist at:${NC}"
    echo -e "${MAGENTA}$COMPONENT_PATH${NC}"
    exit 1
fi

# Step 2: Select archiving category
echo -e "\n${YELLOW}Step 2: Select archiving category${NC}"
echo -e "Choose the appropriate category for this component:"
echo -e "  1) module-system-conflicts    - ESM/CommonJS incompatibilities"
echo -e "  2) socket-connectivity-issues - Connection handling problems"
echo -e "  3) schema-validation-errors   - Schema validation issues"
echo -e "  4) process-management-issues  - Process lifecycle problems"
echo -e "  5) performance-bottlenecks    - Resource constraint issues"
echo -e "  6) deprecated-implementations - Superseded implementations"
echo -e "  7) obsolete-configurations    - Outdated configurations"
read -p "Enter category number [1-7]: " category_num

# Map selection to category name
case $category_num in
    1) CATEGORY="module-system-conflicts" ;;
    2) CATEGORY="socket-connectivity-issues" ;;
    3) CATEGORY="schema-validation-errors" ;;
    4) CATEGORY="process-management-issues" ;;
    5) CATEGORY="performance-bottlenecks" ;;
    6) CATEGORY="deprecated-implementations" ;;
    7) CATEGORY="obsolete-configurations" ;;
    *)
        echo -e "${RED}Invalid category number${NC}"
        exit 1
        ;;
esac

# Step 3: Enter reason for archiving
echo -e "\n${YELLOW}Step 3: Enter reason for archiving${NC}"
read -p "Enter reason for archiving this component: " REASON

if [ -z "$REASON" ]; then
    echo -e "${RED}Error: Reason cannot be empty${NC}"
    exit 1
fi

# Step 4: Specify replacement (optional)
echo -e "\n${YELLOW}Step 4: Specify replacement component (optional)${NC}"
echo -e "Would you like to specify a replacement component?"
echo -e "  1) Yes, specify replacement path"
echo -e "  2) No replacement yet"
read -p "Enter your choice [1-2]: " replacement_choice

REPLACEMENT_PATH="None"

if [ "$replacement_choice" -eq 1 ]; then
    read -p "Enter replacement component path: " REPLACEMENT_PATH
    
    # Check if replacement exists
    if [ ! -f "$REPLACEMENT_PATH" ]; then
        echo -e "${YELLOW}Warning: Replacement component does not exist:${NC}"
        echo -e "${MAGENTA}$REPLACEMENT_PATH${NC}"
        
        echo -e "Would you like to:"
        echo -e "  1) Continue anyway with this replacement path"
        echo -e "  2) Create a placeholder component at this path"
        echo -e "  3) Cancel archiving"
        read -p "Enter your choice [1-3]: " nonexistent_choice
        
        case $nonexistent_choice in
            1)
                echo -e "${YELLOW}Continuing with non-existent replacement path${NC}"
                ;;
            2)
                echo -e "${CYAN}Creating placeholder component...${NC}"
                mkdir -p "$(dirname "$REPLACEMENT_PATH")"
                
                cat > "$REPLACEMENT_PATH" <<EOF
/**
 * Placeholder Replacement Component
 * Created by quick-archive-component.sh on $(date)
 * 
 * This is a placeholder for a replacement component that will replace:
 * ${COMPONENT_PATH}
 * 
 * Reason for replacement: ${REASON}
 */

// TODO: Implement replacement component

// For reference, this component is intended to replace a component that was archived
// due to: ${REASON}

module.exports = {
    // Placeholder implementation
    placeholder: true,
    timestamp: '$(date)',
    replacedComponent: '${COMPONENT_PATH}'
};
EOF
                
                echo -e "${GREEN}Created placeholder component at:${NC}"
                echo -e "${MAGENTA}$REPLACEMENT_PATH${NC}"
                ;;
            3)
                echo -e "${RED}Archiving cancelled${NC}"
                exit 0
                ;;
            *)
                echo -e "${RED}Invalid choice, archiving cancelled${NC}"
                exit 1
                ;;
        esac
    fi
fi

# Step 5: Confirm and archive
echo -e "\n${YELLOW}Step 5: Confirm and archive${NC}"
echo -e "Please verify the following information:"
echo -e "  Component: ${MAGENTA}$COMPONENT_PATH${NC}"
echo -e "  Category:  ${MAGENTA}$CATEGORY${NC}"
echo -e "  Reason:    ${MAGENTA}$REASON${NC}"
echo -e "  Replacement: ${MAGENTA}$REPLACEMENT_PATH${NC}"
echo -e ""
read -p "Is this information correct? [y/N]: " confirm

if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
    echo -e "${RED}Archiving cancelled${NC}"
    exit 0
fi

# Execute the archive operation
echo -e "\n${CYAN}Executing archive operation...${NC}"
"$ARCHIVE_SCRIPT" "$COMPONENT_PATH" "$CATEGORY" "$REASON" "$REPLACEMENT_PATH"

# Final success message
echo -e "\n${GREEN}Component has been successfully archived!${NC}"
echo -e "${CYAN}You can view archived components and their metadata in:${NC}"
echo -e "${MAGENTA}/Users/XPV/Desktop/anchor-core/archive/$CATEGORY/${NC}"
echo -e ""
echo -e "${CYAN}For more advanced archiving operations, use the Archival Protocol Controller:${NC}"
echo -e "${MAGENTA}/Users/XPV/Desktop/anchor-core/archival-protocol-controller.sh${NC}"

exit 0
