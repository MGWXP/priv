#!/bin/bash
# make-quick-fix-executable.sh - Make quick fix script executable
# © 2025 XPV - MIT

chmod +x /Users/XPV/Desktop/anchor-core/fix-cnif-quick.sh
echo "✅ CNIF quick fix script is now executable"
echo "Run it with: /Users/XPV/Desktop/anchor-core/fix-cnif-quick.sh"
