#!/bin/bash
# make-launcher-executable.sh - Make the CNIF launcher executable
# © 2025 XPV - MIT

chmod +x /Users/XPV/Desktop/anchor-core/cnif-launcher.sh
echo "CNIF launcher is now executable"
