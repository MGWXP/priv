#!/bin/bash
# verify-socket-servers.sh - Verify socket server status
# © 2025 XPV - MIT

set -e

# Define colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color
BLUE='\033[0;34m'

# Base paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
SOCKET_DIR="$ANCHOR_HOME/sockets"
COHERENCE_LOCK_DIR="$ANCHOR_HOME/coherence_lock"
MCP_DIR="$ANCHOR_HOME/mcp-servers"
PID_DIR="$MCP_DIR"

echo -e "${BLUE}Checking Socket Server Status${NC}"
echo -e "${BLUE}================================${NC}"

# Check if socket directory exists
if [ -d "$SOCKET_DIR" ]; then
  echo -e "${GREEN}✅ Socket directory exists: $SOCKET_DIR${NC}"
else
  echo -e "${RED}❌ Socket directory not found: $SOCKET_DIR${NC}"
  exit 1
fi

# Check socket files
socket_files=$(find "$SOCKET_DIR" -name "*.sock" 2>/dev/null)
socket_count=$(echo "$socket_files" | grep -v "^$" | wc -l)

if [ "$socket_count" -gt 0 ]; then
  echo -e "${GREEN}✅ Found $socket_count socket files:${NC}"
  for socket in $socket_files; do
    socket_name=$(basename "$socket")
    socket_perms=$(stat -f "%p" "$socket" | cut -c 3-5)
    if [ "$socket_perms" = "666" ]; then
      echo -e "${GREEN}  - $socket_name (permissions: $socket_perms)${NC}"
    else
      echo -e "${YELLOW}  - $socket_name (permissions: $socket_perms - should be 666)${NC}"
    fi
  done
else
  echo -e "${RED}❌ No socket files found in $SOCKET_DIR${NC}"
fi

# Check coherence markers
marker_files=$(find "$COHERENCE_LOCK_DIR" -name "*.marker" 2>/dev/null)
marker_count=$(echo "$marker_files" | grep -v "^$" | wc -l)

if [ "$marker_count" -gt 0 ]; then
  echo -e "${GREEN}✅ Found $marker_count coherence markers:${NC}"
  for marker in $marker_files; do
    marker_name=$(basename "$marker")
    server_name=$(echo "$marker_name" | cut -d '_' -f 1)
    pid=$(cat "$marker")
    if ps -p "$pid" > /dev/null; then
      echo -e "${GREEN}  - $server_name (PID: $pid) - Running${NC}"
    else
      echo -e "${RED}  - $server_name (PID: $pid) - Not running${NC}"
    fi
  done
else
  echo -e "${RED}❌ No coherence markers found in $COHERENCE_LOCK_DIR${NC}"
fi

# Check server processes
echo -e "\n${BLUE}Checking Server Processes${NC}"
echo -e "${BLUE}=======================${NC}"

# Define server list
servers=("socket-server" "notion" "schema-registry" "streaming-transformer" "mcp-orchestrator")

for server in "${servers[@]}"; do
  pid_file="$PID_DIR/$server.pid"
  if [ -f "$pid_file" ]; then
    pid=$(cat "$pid_file")
    if ps -p "$pid" > /dev/null; then
      cpu=$(ps -o %cpu -p "$pid" | tail -1 | tr -d ' ')
      mem=$(ps -o %mem -p "$pid" | tail -1 | tr -d ' ')
      runtime=$(ps -o etime -p "$pid" | tail -1 | tr -d ' ')
      echo -e "${GREEN}✅ $server (PID: $pid)${NC}"
      echo -e "   CPU: $cpu%, Memory: $mem%, Runtime: $runtime"
    else
      echo -e "${RED}❌ $server (PID: $pid) - Not running${NC}"
    fi
  else
    echo -e "${RED}❌ $server - No PID file found${NC}"
  fi
done

# Test socket connection if netcat is available
if command -v nc > /dev/null; then
  echo -e "\n${BLUE}Testing Socket Connections${NC}"
  echo -e "${BLUE}========================${NC}"
  
  for socket in $socket_files; do
    socket_name=$(basename "$socket")
    server_name=$(echo "$socket_name" | cut -d '.' -f 1)
    
    echo -e "${BLUE}Testing connection to $server_name...${NC}"
    
    # Simple connection test using netcat
    if echo '{"type":"handshake"}' | nc -U "$socket" -w 1 > /dev/null; then
      echo -e "${GREEN}✅ Successfully connected to $server_name${NC}"
    else
      echo -e "${RED}❌ Failed to connect to $server_name${NC}"
    fi
  done
fi

# Check load average
echo -e "\n${BLUE}System Load${NC}"
echo -e "${BLUE}===========${NC}"

load_avg=$(sysctl -n vm.loadavg | cut -d ' ' -f 2-4)
echo -e "Load average: $load_avg"

# Memory usage
mem_used=$(vm_stat | grep "Pages active" | awk '{print $3}' | sed 's/\.//')
page_size=$(sysctl -n hw.pagesize)
mem_used_gb=$(echo "scale=2; $mem_used * $page_size / 1024 / 1024 / 1024" | bc)
mem_total_gb=$(sysctl -n hw.memsize | awk '{print $1 / 1024 / 1024 / 1024}')
mem_percent=$(echo "scale=2; $mem_used_gb / $mem_total_gb * 100" | bc)

echo -e "Memory usage: ${mem_used_gb}GB / ${mem_total_gb}GB (${mem_percent}%)"

# CPU usage
cpu_usage=$(ps -A -o %cpu | awk '{s+=$1} END {print s}')
cpu_count=$(sysctl -n hw.ncpu)
cpu_percent=$(echo "scale=2; $cpu_usage / $cpu_count" | bc)

echo -e "CPU usage: ${cpu_percent}%"

# Final status message
if [ "$socket_count" -gt 0 ] && [ "$marker_count" -gt 0 ]; then
  echo -e "\n${GREEN}✅ Socket servers appear to be running correctly${NC}"
else
  echo -e "\n${RED}❌ Socket server configuration issues detected${NC}"
  echo -e "${YELLOW}Try restarting with: $ANCHOR_HOME/launch-optimized.sh${NC}"
fi
