#!/bin/bash
# Run with: chmod +x /Users/XPV/Desktop/anchor-core/make-simple-launcher-executable.sh && /Users/XPV/Desktop/anchor-core/make-simple-launcher-executable.sh
# make-simple-launcher-executable.sh - Make the simple launcher executable
# © 2025 XPV - MIT

chmod +x /Users/XPV/Desktop/anchor-core/simple-launcher.sh
chmod +x /Users/XPV/Desktop/anchor-core/admin/cnif-cli.sh
chmod +x /Users/XPV/Desktop/anchor-core/admin/unified-launcher.sh

echo "✅ Made scripts executable"
echo "Try running the simple launcher for best results:"
echo "  /Users/XPV/Desktop/anchor-core/simple-launcher.sh"
