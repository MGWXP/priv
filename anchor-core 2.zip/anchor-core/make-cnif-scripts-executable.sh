#!/bin/bash
# make-cnif-scripts-executable.sh - Make CNIF scripts executable
# © 2025 XPV - MIT

# Set execution permissions on CNIF scripts
chmod +x /Users/XPV/Desktop/anchor-core/fix-socket-permissions.sh
chmod +x /Users/XPV/Desktop/anchor-core/cnif-system-check.sh
chmod +x /Users/XPV/Desktop/anchor-core/simple-launcher.sh
chmod +x /Users/XPV/Desktop/anchor-core/mcp-servers/verify-servers.sh

echo "✅ Made CNIF scripts executable"
