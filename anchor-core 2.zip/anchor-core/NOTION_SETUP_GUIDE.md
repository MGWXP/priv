# Setting Up Notion Integration with Claude

This guide walks you through setting up a Notion integration to work with Claude Desktop.

## Step 1: Create a Notion integration

1. Go to [https://www.notion.so/my-integrations](https://www.notion.so/my-integrations)
2. Click "Create new integration"
3. Name it something like "Claude Assistant"
4. Under "Associated workspace", select the workspace you want to connect
5. Under "Capabilities", select:
   - Read content
   - Update content
   - Insert content
6. Click "Submit"
7. Copy the "Internal Integration Token" (it starts with `secret_`)

## Step 2: Configure Claude Desktop

1. Run the fix script we created:
   ```bash
   chmod +x /Users/XPV/Desktop/anchor-core/fix-notion-config.sh
   /Users/XPV/Desktop/anchor-core/fix-notion-config.sh
   ```
2. When prompted, paste your Notion integration token
3. Restart Claude Desktop

## Step 3: Share Notion pages with your integration

For each page or database you want Claude to access:

1. Open the page in Notion
2. Click the "..." menu at the top right
3. Select "Add connections"
4. Find your integration (e.g., "Claude Assistant") and select it
5. Click "Confirm"

## Step 4: Testing the integration

1. Open Claude Desktop
2. Ask Claude something like: "Search my Notion workspace for pages about [topic]"
3. If everything is set up correctly, Claude should be able to access your Notion pages

## Troubleshooting

If you encounter issues:

1. **Configuration Issues**
   - Make sure your Notion API token is correctly set in the Claude configuration
   - Verify that the npx path is correct in the configuration

2. **Permission Issues**
   - Double-check that you've shared the pages with your integration
   - Verify that your integration has the correct capabilities (Read/Update/Insert)

3. **Connection Issues**
   - Restart Claude Desktop
   - Check if the Notion MCP server is installed globally: `npm list -g @notionhq/notion-mcp-server`
   - Install it manually if needed: `npm install -g @notionhq/notion-mcp-server`

4. **Logs**
   - Check Claude logs: `/Users/XPV/Library/Logs/Claude/`
