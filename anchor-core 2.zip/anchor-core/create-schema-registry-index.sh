#!/bin/bash
# create-schema-registry-index.sh - Create an entry point for schema-registry
# © 2025 XPV - MIT

# Create the index.js file that instantiates and exports a SchemaRegistry instance
cat > /Users/XPV/Desktop/anchor-core/mcp-servers/schema-registry-index.js << 'EOF'
/**
 * schema-registry-index.js - Entry point for Schema Registry
 * © 2025 XPV - MIT
 */

const SchemaRegistry = require('./schema-registry.cjs');

// Create and export a singleton instance
const schemaRegistry = new SchemaRegistry({
  schemaDirClaude: process.env.ANCHOR_HOME ? `${process.env.ANCHOR_HOME}/schemas/claude` : './schemas/claude',
  schemaDirNotion: process.env.ANCHOR_HOME ? `${process.env.ANCHOR_HOME}/schemas/notion` : './schemas/notion',
  validateOnLoad: true
});

// Initialize the registry
(async () => {
  try {
    console.log('Initializing schema registry...');
    await schemaRegistry.initialize();
    console.log('Schema registry initialized successfully');
  } catch (err) {
    console.error(`Failed to initialize schema registry: ${err.message}`);
    process.exit(1);
  }
})();

// Export the singleton
module.exports = schemaRegistry;
EOF

echo "✅ Created schema-registry-index.js"

# Create a test for the schema registry
cat > /Users/XPV/Desktop/anchor-core/mcp-servers/test-schema-registry.js << 'EOF'
/**
 * test-schema-registry.js - Test schema registry functionality
 * © 2025 XPV - MIT
 */

const SchemaRegistry = require('./schema-registry.cjs');

// Create a registry instance
const registry = new SchemaRegistry({
  schemaDirClaude: process.env.ANCHOR_HOME ? `${process.env.ANCHOR_HOME}/schemas/claude` : './schemas/claude',
  schemaDirNotion: process.env.ANCHOR_HOME ? `${process.env.ANCHOR_HOME}/schemas/notion` : './schemas/notion'
});

// Register event listeners
registry.on('initialized', () => {
  console.log('Schema registry initialized');
});

registry.on('schema-loaded', (event) => {
  console.log(`Loaded schema: ${event.type}/${event.id}@${event.version}`);
});

registry.on('error', (err) => {
  console.error(`Error in schema registry: ${err.message}`);
});

// Initialize and test
async function runTest() {
  try {
    // Initialize registry
    console.log('Initializing schema registry...');
    await registry.initialize();
    
    // Create a test schema
    console.log('\nCreating test schema...');
    const testSchema = {
      id: 'test-schema',
      version: '1-0-0',
      description: 'Test schema for CNIF',
      schema: {
        type: 'object',
        properties: {
          name: { type: 'string' },
          age: { type: 'number' }
        },
        required: ['name']
      }
    };
    
    // Register schema
    console.log('\nRegistering test schema...');
    await registry.registerSchema('claude', testSchema);
    
    // Get schema metrics
    console.log('\nSchema metrics:');
    console.log(registry.getMetrics());
    
    // Test complete
    console.log('\n✅ Schema registry test completed successfully');
  } catch (err) {
    console.error(`\n❌ Test failed: ${err.message}`);
    process.exit(1);
  }
}

// Run the test
runTest();
EOF

echo "✅ Created test-schema-registry.js"

# Create a simple sample schema
mkdir -p /Users/XPV/Desktop/anchor-core/schemas/claude
cat > /Users/XPV/Desktop/anchor-core/schemas/claude/sample-1-0-0.json << 'EOF'
{
  "id": "sample",
  "version": "1-0-0",
  "description": "Sample schema for testing",
  "schema": {
    "type": "object",
    "properties": {
      "name": { "type": "string" },
      "description": { "type": "string" },
      "tags": { 
        "type": "array",
        "items": { "type": "string" }
      }
    },
    "required": ["name"]
  }
}
EOF

echo "✅ Created sample schema"

echo "Run the test with:"
echo "node /Users/XPV/Desktop/anchor-core/mcp-servers/test-schema-registry.js"
