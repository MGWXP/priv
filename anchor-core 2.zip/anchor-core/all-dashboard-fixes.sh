#!/bin/bash
# all-dashboard-fixes.sh - Apply all dashboard fixes in one script
# For M3 Max (48GB unified memory) hardware

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

echo -e "${BLUE}=== Applying Dashboard Fixes ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e ""

# 1. Make scripts executable
echo -e "${YELLOW}Making all dashboard scripts executable...${NC}"
chmod +x /Users/XPV/Desktop/anchor-core/setup-dashboard-views-fixed.sh
chmod +x /Users/XPV/Desktop/anchor-core/create-dashboard-entry.sh
chmod +x /Users/XPV/Desktop/anchor-core/make-dashboard-views-executable.sh

echo -e "${GREEN}✓ All dashboard scripts are now executable${NC}"

# 2. Run fixed dashboard views script
echo -e "\n${YELLOW}Creating dashboard views with fixed script...${NC}"
/Users/XPV/Desktop/anchor-core/setup-dashboard-views-fixed.sh

# 3. Add detailed status entry to dashboard
echo -e "\n${YELLOW}Adding detailed status to dashboard...${NC}"
/Users/XPV/Desktop/anchor-core/create-dashboard-entry.sh

# Create a README for dashboard fixes
echo -e "\n${YELLOW}Creating README for dashboard fixes...${NC}"
cat > /Users/XPV/Desktop/anchor-core/DASHBOARD_README.md << 'EOF'
# Anchor Dashboard Views

## Overview
This directory contains scripts to create and manage Notion dashboard views for the Anchor system. The current implementation uses hyperlinks to databases rather than embedded views due to API limitations.

## Dashboard Scripts
- `setup-dashboard-views-fixed.sh` - Creates the main dashboard with links to databases
- `create-dashboard-entry.sh` - Adds system status and action items to the dashboard
- `make-dashboard-views-executable.sh` - Makes the dashboard scripts executable

## Technical Note
The Notion API version 2022-06-28 does not support directly embedding linked databases when creating pages. See `DASHBOARD_ERROR_REPORT.md` for detailed error analysis and the implemented solution.

## Usage
To update the dashboard with current system status:
```bash
./create-dashboard-entry.sh
```

This will add the latest system metrics, service status, and action items to the dashboard.

## Dashboard Structure
1. Main Dashboard - Provides overview of system status and links to all databases
2. Project Dashboard - Focused on project tracking and status

## Troubleshooting
If you encounter issues with the dashboard views, check:
1. Notion API token - Ensure it has proper permissions
2. Database IDs - Verify they exist in /Users/XPV/Desktop/anchor-core/notion-db-ids/
3. API version - The scripts use version 2022-06-28

Refer to `DASHBOARD_ERROR_REPORT.md` for more detailed technical information.
EOF

echo -e "${GREEN}✓ Dashboard README created${NC}"

# Update notion-db-status.txt
echo -e "\n${YELLOW}Updating database status file...${NC}"
cat >> /Users/XPV/Desktop/anchor-core/notion-db-status.txt << EOF

## Dashboard Views
- Main Dashboard: Created (ID: $(cat /Users/XPV/Desktop/anchor-core/notion-dashboard-ids/main-dashboard-id.txt))
- Project Dashboard: Created (ID: $(cat /Users/XPV/Desktop/anchor-core/notion-dashboard-ids/project-dashboard-id.txt))
- Note: Direct database embedding not supported in current API version

## Status
Dashboard views have been created with hyperlinks to databases.
Technical details available in DASHBOARD_ERROR_REPORT.md
EOF

echo -e "${GREEN}✓ Status file updated${NC}"

echo -e "\n${GREEN}✅ All dashboard fixes have been applied!${NC}"
echo -e "${YELLOW}View your dashboard at: https://www.notion.so/$(cat /Users/XPV/Desktop/anchor-core/notion-dashboard-ids/main-dashboard-id.txt)${NC}"
echo -e "${YELLOW}Technical details available in: /Users/XPV/Desktop/anchor-core/DASHBOARD_ERROR_REPORT.md${NC}"
