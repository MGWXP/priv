const MCPServer = require('../mcp-server-base');

const SOCKET_DIR = process.env.SOCKET_DIR || '/Users/XPV/Desktop/anchor-core/sockets';

// Create and start the git-local server
new MCPServer('git-local', SOCKET_DIR)
  .addTool('git', 'Git local operations', {
    type: 'object',
    properties: {
      command: {
        type: 'string',
        description: 'Git command to execute'
      }
    },
    required: ['command']
  })
  .start();
