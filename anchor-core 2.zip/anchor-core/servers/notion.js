const MCPServer = require('../mcp-server-base');

const SOCKET_DIR = process.env.SOCKET_DIR || '/Users/XPV/Desktop/anchor-core/sockets';

// Create and start the notion server
new MCPServer('notion', SOCKET_DIR)
  .addTool('notion', 'Notion operations', {
    type: 'object',
    properties: {
      operation: {
        type: 'string',
        description: 'Notion operation to execute'
      }
    },
    required: ['operation']
  })
  .start();
