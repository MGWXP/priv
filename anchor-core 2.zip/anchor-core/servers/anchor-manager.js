const MCPServer = require('../mcp-server-base');

const SOCKET_DIR = process.env.SOCKET_DIR || '/Users/XPV/Desktop/anchor-core/sockets';

// Create and start the anchor-manager server
new MCPServer('anchor-manager', SOCKET_DIR)
  .addTool('anchor', 'Anchor system management', {
    type: 'object',
    properties: {
      action: {
        type: 'string',
        description: 'Anchor management action'
      }
    },
    required: ['action']
  })
  .start();
