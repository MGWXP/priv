#!/usr/bin/env python3.12
import hmac, hashlib, json, os, time, asyncio, subprocess
from aiohttp import web
from prometheus_client import Counter, Histogram, generate_latest

# ── CONFIG ─────────────────────────────────────────────────────────────
HMAC_KEY = os.environ.get("MCP_HMAC_KEY", "changeme").encode()
INJECT_TIMEOUT = 5

# ── METRICS ────────────────────────────────────────────────────────────
REQS = Counter("mcp_requests_total", "Total MCP requests", ["status"])
LAT  = Histogram("mcp_latency_ms", "Latency (ms)", buckets=(25,50,100,250,500,1000))

# ── UTIL ───────────────────────────────────────────────────────────────
def verify_sig(body: bytes, sig_header: str|None) -> bool:
    if not sig_header:
        return False
    digest = hmac.new(HMAC_KEY, body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(digest, sig_header)

def inject_to_chatgpt(payload: dict):
    encoded = json.dumps(payload, separators=(',', ':'))
    esc = encoded.replace('\\', '\\\\').replace('"', '\\"')
    script = f'''
        tell application "ChatGPT" to activate
        delay 0.2
        tell application "System Events"
            keystroke "{esc}"
            key code 36
        end tell
    '''
    subprocess.run(["osascript", "-e", script], timeout=INJECT_TIMEOUT, check=True)

# ── ROUTES ─────────────────────────────────────────────────────────────
async def ingest(request):
    ts0 = time.time()
    body = await request.read()
    sig_ok = verify_sig(body, request.headers.get("X-MCP-Sig"))
    try:
        REQS.labels("received").inc()
        if not sig_ok:
            raise ValueError("Signature mismatch")
        payload = json.loads(body)
        assert payload.get("mcp_version") == 1
        context_id = hashlib.sha1(body).hexdigest()[:12]
        inject_to_chatgpt(payload)
        REQS.labels("ok").inc()
        return web.json_response({"context_id": context_id}, status=202)
    except Exception as e:
        REQS.labels("error").inc()
        return web.json_response({"error": str(e)}, status=400)
    finally:
        LAT.observe((time.time()-ts0)*1000)

async def metrics(_):
    return web.Response(body=generate_latest(), content_type='text/plain')

def main():
    app = web.Application()
    app.add_routes([web.post('/mcp', ingest),
                    web.get('/metrics', metrics)])
    web.run_app(app, host='127.0.0.1', port=3213, ssl_context=None)

if __name__ == "__main__":
    main()
