#!/usr/bin/env node
// create-marker.js

import fs from 'fs/promises';
import path from 'path';
import { execSync } from 'child_process';

const COHERENCE_LOCK_DIR = '/Users/XPV/Desktop/anchor-core/coherence_lock';

/**
 * Creates a standardized marker file in the coherence_lock directory
 * 
 * @param {string} component - The component name
 * @param {string} status - The status code (e.g., 'INITIALIZED', 'RUNNING', 'COMPLETE')
 * @param {Object} metadata - Additional component-specific metadata
 * @returns {Promise<string>} - The path to the created marker file
 */
async function createMarker(component, status, metadata = {}) {
  try {
    // Create directory if it doesn't exist
    await fs.mkdir(COHERENCE_LOCK_DIR, { recursive: true });
    
    // Generate ISO timestamp with Z suffix
    const timestamp = new Date().toISOString();
    
    // Get system information
    const hostname = execSync('hostname').toString().trim();
    const platform = process.platform;
    const nodeVersion = process.version;
    const pid = process.pid;
    
    // Create marker content
    const markerContent = {
      component,
      status,
      timestamp,
      version: '1.0.0',
      pid,
      system_info: {
        hostname,
        platform,
        node_version: nodeVersion,
        hardware: 'M3 Max'
      },
      metadata
    };
    
    // Create filename with timestamp
    const timeFragment = timestamp.replace(/:/g, '').replace(/\./g, '').replace(/[TZ]/g, '');
    const filename = `${component}_${status}_${timeFragment}.marker`;
    const filePath = path.join(COHERENCE_LOCK_DIR, filename);
    
    // Write marker file
    await fs.writeFile(filePath, JSON.stringify(markerContent, null, 2));
    
    console.log(`✅ Created marker: ${filename}`);
    return filePath;
  } catch (err) {
    console.error(`❌ Error creating marker: ${err.message}`);
    throw err;
  }
}

// If script is run directly, parse command line arguments
if (require.main === module) {
  const args = process.argv.slice(2);
  if (args.length < 2) {
    console.error('Usage: create-marker.js component status [metadata-json]');
    process.exit(1);
  }
  
  const component = args[0];
  const status = args[1];
  let metadata = {};
  
  if (args[2]) {
    try {
      metadata = JSON.parse(args[2]);
    } catch (err) {
      console.error(`❌ Invalid JSON metadata: ${err.message}`);
      process.exit(1);
    }
  }
  
  createMarker(component, status, metadata)
    .catch(err => {
      console.error(`❌ Fatal error: ${err.message}`);
      process.exit(1);
    });
}

export default createMarker;
