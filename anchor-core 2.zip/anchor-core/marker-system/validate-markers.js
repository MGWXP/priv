#!/usr/bin/env node
// validate-markers.js

import fs from 'fs/promises';
import path from 'path';

const COHERENCE_LOCK_DIR = '/Users/XPV/Desktop/anchor-core/coherence_lock';

// Marker schema definition
const markerSchema = {
  required: ['component', 'status', 'timestamp', 'version'],
  properties: {
    component: { type: 'string' },
    status: { type: 'string', enum: ['INITIALIZED', 'RUNNING', 'COMPLETE', 'ERROR', 'WARNING'] },
    timestamp: { type: 'string', format: 'date-time' },
    version: { type: 'string', pattern: '^\\d+\\.\\d+\\.\\d+$' },
    pid: { type: 'number' },
    system_info: {
      type: 'object',
      properties: {
        hostname: { type: 'string' },
        platform: { type: 'string' },
        node_version: { type: 'string' },
        hardware: { type: 'string' }
      }
    },
    metadata: { type: 'object' }
  }
};

/**
 * Validates a value against a schema type
 * 
 * @param {any} value - The value to validate
 * @param {string} type - The expected type
 * @param {Object} options - Additional validation options
 * @returns {boolean} - True if valid, false otherwise
 */
function validateType(value, type, options = {}) {
  switch (type) {
    case 'string':
      if (typeof value !== 'string') return false;
      if (options.pattern && !new RegExp(options.pattern).test(value)) return false;
      if (options.enum && !options.enum.includes(value)) return false;
      if (options.format === 'date-time') {
        try {
          const date = new Date(value);
          return !isNaN(date.getTime());
        } catch (e) {
          return false;
        }
      }
      return true;
    case 'number':
      return typeof value === 'number';
    case 'object':
      return typeof value === 'object' && value !== null;
    default:
      return true;
  }
}

/**
 * Validates a marker object against the schema
 * 
 * @param {Object} marker - The marker object to validate
 * @returns {Object} - Validation result with errors
 */
function validateMarker(marker) {
  const errors = [];
  
  // Check required fields
  for (const field of markerSchema.required) {
    if (marker[field] === undefined) {
      errors.push(`Missing required field: ${field}`);
    }
  }
  
  // Check property types
  for (const [key, value] of Object.entries(marker)) {
    const schemaProperty = markerSchema.properties[key];
    if (!schemaProperty) continue;
    
    if (!validateType(value, schemaProperty.type, schemaProperty)) {
      errors.push(`Invalid type for ${key}: expected ${schemaProperty.type}`);
    }
    
    // Check nested properties
    if (schemaProperty.type === 'object' && schemaProperty.properties) {
      for (const [nestedKey, nestedValue] of Object.entries(value || {})) {
        const nestedSchema = schemaProperty.properties[nestedKey];
        if (!nestedSchema) continue;
        
        if (!validateType(nestedValue, nestedSchema.type, nestedSchema)) {
          errors.push(`Invalid type for ${key}.${nestedKey}: expected ${nestedSchema.type}`);
        }
      }
    }
  }
  
  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Validates all marker files in the coherence_lock directory
 * 
 * @param {boolean} [fixInvalid=false] - Whether to attempt fixing invalid markers
 * @returns {Promise<Object>} - Validation results
 */
async function validateMarkers(fixInvalid = false) {
  try {
    const files = await fs.readdir(COHERENCE_LOCK_DIR);
    const markerFiles = files.filter(file => file.endsWith('.marker'));
    
    const results = {
      total: markerFiles.length,
      valid: 0,
      invalid: 0,
      nonJson: 0,
      fixed: 0,
      details: []
    };
    
    for (const file of markerFiles) {
      const filePath = path.join(COHERENCE_LOCK_DIR, file);
      const fileResult = {
        file,
        path: filePath,
        isJson: true,
        valid: false,
        errors: []
      };
      
      try {
        const content = await fs.readFile(filePath, 'utf8');
        
        // Try to parse as JSON
        try {
          const marker = JSON.parse(content);
          fileResult.marker = marker;
          
          // Validate against schema
          const validation = validateMarker(marker);
          fileResult.valid = validation.valid;
          fileResult.errors = validation.errors;
          
          if (validation.valid) {
            results.valid++;
          } else {
            results.invalid++;
            
            // Try to fix if requested
            if (fixInvalid) {
              const fixed = { ...marker };
              let wasFixed = false;
              
              // Add missing required fields
              for (const field of markerSchema.required) {
                if (fixed[field] === undefined) {
                  switch (field) {
                    case 'component':
                      // Try to extract from filename
                      const match = file.match(/^([^_]+)/);
                      fixed.component = match ? match[1] : 'unknown';
                      wasFixed = true;
                      break;
                    case 'status':
                      fixed.status = 'UNKNOWN';
                      wasFixed = true;
                      break;
                    case 'timestamp':
                      fixed.timestamp = new Date().toISOString();
                      wasFixed = true;
                      break;
                    case 'version':
                      fixed.version = '1.0.0';
                      wasFixed = true;
                      break;
                  }
                }
              }
              
              // If fixes were applied, write back to file
              if (wasFixed) {
                await fs.writeFile(filePath, JSON.stringify(fixed, null, 2));
                fileResult.fixed = true;
                fileResult.fixedMarker = fixed;
                results.fixed++;
              }
            }
          }
        } catch (parseErr) {
          // Not valid JSON
          fileResult.isJson = false;
          fileResult.errors.push('Not a valid JSON file');
          results.nonJson++;
        }
      } catch (readErr) {
        fileResult.errors.push(`Failed to read file: ${readErr.message}`);
        results.invalid++;
      }
      
      results.details.push(fileResult);
    }
    
    return results;
  } catch (err) {
    console.error(`❌ Error validating markers: ${err.message}`);
    throw err;
  }
}

// If script is run directly, run validation and print results
if (require.main === module) {
  const args = process.argv.slice(2);
  const fixInvalid = args.includes('--fix');
  const jsonOutput = args.includes('--json');
  
  validateMarkers(fixInvalid)
    .then(results => {
      if (jsonOutput) {
        console.log(JSON.stringify(results, null, 2));
      } else {
        console.log(`\n📁 Marker Validation Results:\n`);
        console.log(`✅ Total markers: ${results.total}`);
        console.log(`✅ Valid markers: ${results.valid}`);
        if (results.invalid > 0) {
          console.log(`❌ Invalid markers: ${results.invalid}`);
        }
        if (results.nonJson > 0) {
          console.log(`⚠️ Non-JSON markers: ${results.nonJson}`);
        }
        if (fixInvalid) {
          console.log(`🔧 Fixed markers: ${results.fixed}`);
        }
        
        console.log('\nDetailed Results:');
        results.details.forEach(result => {
          if (result.valid) {
            console.log(`✅ ${result.file}`);
          } else if (!result.isJson) {
            console.log(`⚠️ ${result.file} (Not JSON)`);
          } else {
            console.log(`❌ ${result.file}`);
            result.errors.forEach(error => {
              console.log(`   - ${error}`);
            });
            if (result.fixed) {
              console.log(`   - Fixed automatically`);
            }
          }
        });
      }
    })
    .catch(err => {
      console.error(`❌ Fatal error: ${err.message}`);
      process.exit(1);
    });
}

export default validateMarkers;
