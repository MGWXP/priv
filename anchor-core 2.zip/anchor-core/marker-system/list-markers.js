#!/usr/bin/env node
// list-markers.js

import fs from 'fs/promises';
import path from 'path';

const COHERENCE_LOCK_DIR = '/Users/XPV/Desktop/anchor-core/coherence_lock';

/**
 * Lists marker files with filtering options
 * 
 * @param {Object} options - Filter options
 * @param {string} [options.component] - Filter by component name
 * @param {string} [options.status] - Filter by status
 * @param {string} [options.since] - Filter by timestamp (ISO format)
 * @param {boolean} [options.json=false] - Output as JSON
 * @returns {Promise<Array>} - Array of marker objects
 */
async function listMarkers(options = {}) {
  try {
    const files = await fs.readdir(COHERENCE_LOCK_DIR);
    const markerFiles = files.filter(file => file.endsWith('.marker'));
    
    // Read and parse all marker files
    const markers = [];
    for (const file of markerFiles) {
      const filePath = path.join(COHERENCE_LOCK_DIR, file);
      try {
        const content = await fs.readFile(filePath, 'utf8');
        let marker;
        
        // Try to parse as JSON
        try {
          marker = JSON.parse(content);
          marker._filename = file;
        } catch (parseErr) {
          // If not JSON, create a simple object with the content
          marker = {
            _filename: file,
            _content: content.trim(),
            _format: 'plain-text'
          };
        }
        
        // Apply filters
        if (options.component && (!marker.component || marker.component !== options.component)) {
          continue;
        }
        if (options.status && (!marker.status || marker.status !== options.status)) {
          continue;
        }
        if (options.since && marker.timestamp && new Date(marker.timestamp) < new Date(options.since)) {
          continue;
        }
        
        markers.push(marker);
      } catch (readErr) {
        console.error(`❌ Error reading ${file}: ${readErr.message}`);
      }
    }
    
    // Sort by timestamp if available
    markers.sort((a, b) => {
      if (a.timestamp && b.timestamp) {
        return new Date(b.timestamp) - new Date(a.timestamp);
      }
      return a._filename.localeCompare(b._filename);
    });
    
    return markers;
  } catch (err) {
    console.error(`❌ Error listing markers: ${err.message}`);
    throw err;
  }
}

// If script is run directly, parse command line arguments and print results
if (require.main === module) {
  const args = process.argv.slice(2);
  const options = {
    json: args.includes('--json'),
    component: null,
    status: null,
    since: null
  };
  
  // Parse filter options
  for (const arg of args) {
    if (arg.startsWith('--component=')) {
      options.component = arg.split('=')[1];
    } else if (arg.startsWith('--status=')) {
      options.status = arg.split('=')[1];
    } else if (arg.startsWith('--since=')) {
      options.since = arg.split('=')[1];
    }
  }
  
  listMarkers(options)
    .then(markers => {
      if (options.json) {
        console.log(JSON.stringify(markers, null, 2));
      } else {
        console.log(`\n📁 Marker Files (${markers.length} found):\n`);
        markers.forEach(marker => {
          if (marker.component && marker.status) {
            console.log(`✅ ${marker._filename}`);
            console.log(`   Component: ${marker.component}`);
            console.log(`   Status: ${marker.status}`);
            console.log(`   Timestamp: ${marker.timestamp || 'N/A'}`);
            console.log(`   Version: ${marker.version || 'N/A'}`);
            console.log('');
          } else {
            console.log(`⚠️ ${marker._filename} (Non-standard format)`);
            if (marker._content) {
              const preview = marker._content.length > 100 
                ? marker._content.substring(0, 100) + '...' 
                : marker._content;
              console.log(`   Content: ${preview}`);
            }
            console.log('');
          }
        });
      }
    })
    .catch(err => {
      console.error(`❌ Fatal error: ${err.message}`);
      process.exit(1);
    });
}

export default listMarkers;
