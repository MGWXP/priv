const net = require('net');
const fs = require('fs');
const path = require('path');

class MCPServer {
  constructor(name, socketDir) {
    this.name = name;
    this.socketPath = path.join(socketDir, `${name}.sock`);
    this.server = null;
    this.tools = {};
  }

  addTool(toolName, toolDescription, schema) {
    this.tools[toolName] = {
      description: toolDescription,
      schema: schema
    };
    return this;
  }

  start() {
    // Clean up existing socket
    this._cleanupSocket();

    // Create server
    this.server = net.createServer((socket) => {
      console.log(`Client connected to ${this.name} server`);
      
      let buffer = '';
      
      socket.on('data', (data) => {
        buffer += data.toString();
        
        try {
          // Try to process as complete JSON
          const message = JSON.parse(buffer);
          buffer = ''; // Reset buffer on successful parse
          
          this._handleMessage(socket, message);
        } catch (err) {
          // If it's not valid JSON, it might be an incomplete message
          // Keep in buffer until we get more data
          if (buffer.length > 10000) {
            // If buffer gets too big, something is wrong - reset it
            console.error('Buffer overflow, resetting');
            buffer = '';
          }
        }
      });
      
      socket.on('error', (err) => {
        console.error(`Socket error: ${err}`);
      });
      
      socket.on('close', () => {
        console.log('Client disconnected');
      });
    });

    // Handle server errors
    this.server.on('error', (err) => {
      console.error(`Server error: ${err}`);
    });

    // Start listening
    this.server.listen(this.socketPath, () => {
      console.log(`Server listening on ${this.socketPath}`);
      
      // Set permissions after socket is created
      fs.chmod(this.socketPath, 0o666, (err) => {
        if (err) {
          console.error(`Failed to set socket permissions: ${err}`);
        } else {
          console.log(`Set permissions on ${this.socketPath} to 0666`);
        }
      });
    });

    // Handle process termination
    process.on('SIGINT', () => {
      this._shutdown();
    });

    process.on('SIGTERM', () => {
      this._shutdown();
    });

    return this;
  }

  _cleanupSocket() {
    try {
      if (fs.existsSync(this.socketPath)) {
        fs.unlinkSync(this.socketPath);
        console.log(`Removed existing socket at ${this.socketPath}`);
      }
    } catch (err) {
      console.error(`Error removing socket: ${err}`);
    }
  }

  _shutdown() {
    console.log('Shutting down server...');
    if (this.server) {
      this.server.close(() => {
        this._cleanupSocket();
        process.exit(0);
      });
    } else {
      this._cleanupSocket();
      process.exit(0);
    }
  }

  _handleMessage(socket, message) {
    console.log('Received message:', JSON.stringify(message, null, 2));
    
    try {
      if (message.method === 'initialize') {
        // Use client's protocol version
        const clientProtocolVersion = message.params?.protocolVersion || '2024-11-05';
        
        const response = {
          jsonrpc: '2.0',
          id: message.id,
          result: {
            protocolVersion: clientProtocolVersion,
            name: this.name,
            version: '1.0.0',
            capabilities: {
              tools: this.tools
            }
          }
        };
        
        console.log('Sending initialize response:', JSON.stringify(response, null, 2));
        socket.write(JSON.stringify(response) + '\n');
      } 
      else if (message.method === 'execute') {
        // Handle execute requests
        const toolName = message.params?.tool;
        const params = message.params?.params || {};
        
        console.log(`Executing tool: ${toolName} with params:`, params);
        
        // Simple echo response
        const response = {
          jsonrpc: '2.0',
          id: message.id,
          result: {
            output: `Executed ${toolName} with params: ${JSON.stringify(params)}`
          }
        };
        
        console.log('Sending execute response:', JSON.stringify(response, null, 2));
        socket.write(JSON.stringify(response) + '\n');
      }
      else {
        // Handle unknown methods
        const errorResponse = {
          jsonrpc: '2.0',
          id: message.id,
          error: {
            code: -32601,
            message: `Method not found: ${message.method}`
          }
        };
        
        console.log('Sending error response:', JSON.stringify(errorResponse, null, 2));
        socket.write(JSON.stringify(errorResponse) + '\n');
      }
    } catch (err) {
      console.error(`Error handling message: ${err}`);
      
      // Send error response
      try {
        const errorResponse = {
          jsonrpc: '2.0',
          id: message.id,
          error: {
            code: -32603,
            message: `Internal error: ${err.message}`
          }
        };
        socket.write(JSON.stringify(errorResponse) + '\n');
      } catch (e) {
        console.error(`Failed to send error response: ${e}`);
      }
    }
  }
}

module.exports = MCPServer;
