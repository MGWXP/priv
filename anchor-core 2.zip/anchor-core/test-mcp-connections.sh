#!/bin/bash
# MCP Server Connection Test
# © 2025 XPV - MIT License

# This script checks the connection status of all configured MCP servers
# and provides detailed troubleshooting information for any failures.

# Set directory paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
LOG_DIR="${ANCHOR_HOME}/logs"
CLAUDE_CONFIG_DIR="${HOME}/Library/Application Support/Claude"
CLAUDE_CONFIG_FILE="${CLAUDE_CONFIG_DIR}/claude_desktop_config.json"
CLAUDE_LOG_DIR="${HOME}/Library/Logs/Claude"

# Create log directory if it doesn't exist
mkdir -p "${LOG_DIR}"

# Log function
log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "${LOG_DIR}/mcp-connection-test.log"
}

# Title banner
echo "╔═══════════════════════════════════════════╗"
echo "║          MCP SERVER CONNECTION TEST       ║"
echo "╚═══════════════════════════════════════════╝"

# Check if Claude config file exists
if [ ! -f "${CLAUDE_CONFIG_FILE}" ]; then
  log "Claude config file not found: ${CLAUDE_CONFIG_FILE}"
  echo "❌ Claude Desktop config file not found."
  echo "Please run Claude Desktop at least once to create the config file."
  exit 1
fi

# Read current config
log "Reading Claude config"
CURRENT_CONFIG=$(cat "${CLAUDE_CONFIG_FILE}")

# Function to check if a log file contains connection errors
check_log_for_errors() {
  local server_name=$1
  local log_files=($(ls -t "${CLAUDE_LOG_DIR}/mcp-${server_name}"* 2>/dev/null))
  
  if [ ${#log_files[@]} -eq 0 ]; then
    echo "No log files found for ${server_name} server"
    return 1
  fi
  
  # Check the most recent log file
  local recent_log="${log_files[0]}"
  local errors=$(grep -i "error\|exception\|fail" "${recent_log}" | tail -n 5)
  
  if [ -n "${errors}" ]; then
    echo "Recent errors in ${server_name} log:"
    echo "${errors}"
    return 1
  else
    echo "No recent errors found in ${server_name} log"
    return 0
  fi
}

# Function to provide troubleshooting tips
provide_troubleshooting_tips() {
  local server_name=$1
  
  echo
  echo "🔍 Troubleshooting tips for ${server_name}:"
  
  case "${server_name}" in
    github)
      echo "1. Check that your GitHub token is valid and has the necessary scopes (repo, workflow, read:org)"
      echo "2. Verify that '@modelcontextprotocol/server-github' is installed (run 'npm list -g @modelcontextprotocol/server-github')"
      echo "3. Try running the GitHub token updater: '${ANCHOR_HOME}/github-token-updater.sh'"
      ;;
    notion)
      echo "1. Verify your Notion API token is valid and has database access permissions"
      echo "2. Ensure 'OPENAPI_MCP_HEADERS' includes valid 'Authorization' and 'Notion-Version' values"
      echo "3. Check that '@notionhq/notion-mcp-server' is installed"
      ;;
    slack)
      echo "1. Verify your Slack Bot Token and Team ID are correct"
      echo "2. Ensure the Slack app has the necessary scopes (channels:read, chat:write, etc.)"
      echo "3. Check that '@modelcontextprotocol/server-slack' is installed"
      ;;
    filesystem)
      echo "1. Check that the specified directories exist and are accessible"
      echo "2. Verify that '@modelcontextprotocol/server-filesystem' is installed"
      echo "3. Try restarting Claude Desktop"
      ;;
    *)
      echo "1. Check that the server package is installed correctly"
      echo "2. Verify all required environment variables are set"
      echo "3. Look for specific error messages in the logs"
      ;;
  esac
  
  echo "4. View detailed logs at: ${CLAUDE_LOG_DIR}/mcp-${server_name}*.log"
  echo "5. Try using the MCP Credentials Manager to update your credentials:"
  echo "   ${ANCHOR_HOME}/mcp-credential-management.sh"
}

# Extract server names from config
server_names=$(echo "${CURRENT_CONFIG}" | grep -o '"[^"]*": {' | grep -v '"env"' | grep -v '"args"' | tr -d '": {')

echo "Found MCP servers:"
echo "${server_names}"
echo

# Check each server
for server in ${server_names}; do
  if [[ "${server}" == "mcpServers" ]]; then
    continue
  fi
  
  echo "Testing ${server} server connection..."
  
  # Check if server logs exist and contain errors
  if check_log_for_errors "${server}"; then
    echo "✅ ${server} server appears to be properly connected"
  else
    echo "❌ ${server} server has connection issues"
    provide_troubleshooting_tips "${server}"
  fi
  
  echo "--------------------------------------"
done

echo
echo "Test completed. For more detailed diagnostics, run Claude Desktop with the Developer Tools open."
echo "Remember to restart Claude Desktop after making any configuration changes."

exit 0
