chmod +x /Users/XPV/Desktop/anchor-core/quick-fix.sh
