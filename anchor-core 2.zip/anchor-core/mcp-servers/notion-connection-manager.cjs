/**
 * notion-connection-manager.cjs - Notion API connection manager for CNIF
 * © 2025 XPV - MIT
 * 
 * This module provides connection management for the Notion API.
 */

const fs = require('fs');
const net = require('net');
const path = require('path');
const EventEmitter = require('events');

// Configuration
const SOCKET_DIR = process.env.SOCKET_DIR || '/Users/XPV/Desktop/anchor-core/sockets';
const SERVER_NAME = process.env.MCP_SERVER_NAME || 'notion';
const SOCKET_PATH = path.join(SOCKET_DIR, `${SERVER_NAME}.sock`);
const LOG_DIR = process.env.LOG_DIR || path.join(process.env.HOME, 'Library/Logs/Claude');
const LOG_FILE = path.join(LOG_DIR, `${SERVER_NAME}.log`);
const ANCHOR_HOME = process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core';
const CONFIG_FILE = path.join(ANCHOR_HOME, 'config', 'notion-config.json');

// Logger
function log(level, message, extra = {}) {
  const logEntry = JSON.stringify({
    ts: new Date().toISOString(),
    level,
    component: SERVER_NAME,
    pid: process.pid,
    message,
    extra: extra || {}
  });
  
  console.log(logEntry);
  
  try {
    fs.appendFileSync(LOG_FILE, logEntry + '\n');
  } catch (err) {
    console.error(`Failed to write to log file: ${err.message}`);
  }
}

// Ensure directories exist
try {
  fs.mkdirSync(SOCKET_DIR, { recursive: true });
  fs.mkdirSync(LOG_DIR, { recursive: true });
} catch (err) {
  log('ERROR', `Failed to create directories: ${err.message}`);
}

// Load configuration
let config;
try {
  if (fs.existsSync(CONFIG_FILE)) {
    const configData = fs.readFileSync(CONFIG_FILE, 'utf8');
    config = JSON.parse(configData);
    log('INFO', 'Loaded configuration', {
      apiVersion: config.apiVersion,
      baseUrl: config.baseUrl,
      hasToken: Boolean(config.apiToken)
    });
  } else {
    // Create default config
    config = {
      apiToken: "",
      apiVersion: "2022-06-28",
      baseUrl: "https://api.notion.com/v1",
      rateLimit: {
        maxRequests: 3,
        periodMs: 1000,
        maxRetries: 5
      },
      cacheDir: path.join(ANCHOR_HOME, 'data', 'notion-cache'),
      timeout: 30000
    };
    
    // Create config directory if it doesn't exist
    const configDir = path.dirname(CONFIG_FILE);
    if (!fs.existsSync(configDir)) {
      fs.mkdirSync(configDir, { recursive: true });
    }
    
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
    log('INFO', 'Created default configuration', { path: CONFIG_FILE });
  }
} catch (err) {
  log('ERROR', `Failed to load configuration: ${err.message}`);
  config = {
    apiToken: "",
    apiVersion: "2022-06-28",
    baseUrl: "https://api.notion.com/v1",
    rateLimit: {
      maxRequests: 3,
      periodMs: 1000,
      maxRetries: 5
    },
    timeout: 30000
  };
}

// Notion connection class
class NotionConnection extends EventEmitter {
  constructor(options = {}) {
    super();
    
    this.options = {
      apiToken: options.apiToken || "",
      apiVersion: options.apiVersion || "2022-06-28",
      baseUrl: options.baseUrl || "https://api.notion.com/v1",
      timeout: options.timeout || 30000,
      ...options
    };
    
    this.initialized = false;
    this.apiRequests = 0;
  }
  
  async initialize() {
    log('INFO', 'Initializing Notion connection...');
    
    // Check if API token is configured
    if (!this.options.apiToken) {
      log('WARN', 'No API token configured, some functionality may be limited');
    }
    
    this.initialized = true;
    this.emit('initialized');
    log('INFO', 'Notion connection initialized');
    
    return true;
  }
  
  async searchByTitle(query) {
    if (!this.initialized) {
      throw new Error('Notion connection not initialized');
    }
    
    this.apiRequests++;
    log('INFO', 'Searching by title', { query, requestCount: this.apiRequests });
    
    // Simulate API response
    const response = {
      object: 'list',
      results: [
        {
          object: 'page',
          id: 'mock-page-id-1',
          created_time: new Date().toISOString(),
          last_edited_time: new Date().toISOString(),
          properties: {
            title: {
              title: [
                {
                  text: {
                    content: `Sample page matching "${query}"`
                  }
                }
              ]
            }
          }
        }
      ],
      next_cursor: null,
      has_more: false
    };
    
    return response;
  }
  
  async checkHealth() {
    return {
      status: 'ok',
      initialized: this.initialized,
      apiRequests: this.apiRequests,
      timestamp: new Date().toISOString()
    };
  }
}

// Create an instance
const notionConnection = new NotionConnection({
  apiToken: config.apiToken,
  apiVersion: config.apiVersion,
  baseUrl: config.baseUrl,
  timeout: config.timeout
});

// Remove socket file if it exists
try {
  if (fs.existsSync(SOCKET_PATH)) {
    fs.unlinkSync(SOCKET_PATH);
    log('INFO', `Removed existing socket file: ${SOCKET_PATH}`);
  }
} catch (err) {
  log('ERROR', `Failed to remove existing socket file: ${err.message}`);
  process.exit(1);
}

// Create coherence marker
try {
  const coherenceDir = path.join(ANCHOR_HOME, 'coherence_lock');
  fs.mkdirSync(coherenceDir, { recursive: true });
  
  const markerPath = path.join(coherenceDir, `${SERVER_NAME}_${new Date().toISOString().replace(/[:.]/g, '')}.marker`);
  fs.writeFileSync(markerPath, String(process.pid));
  
  log('INFO', `Created coherence marker: ${markerPath}`);
} catch (err) {
  log('ERROR', `Failed to create coherence marker: ${err.message}`);
}

// Message buffer for handling partial messages
class MessageBuffer {
  constructor() {
    this.buffer = '';
  }
  
  append(data) {
    this.buffer += data.toString();
  }
  
  getMessages() {
    if (!this.buffer.includes('\n')) {
      return [];
    }
    
    const messages = this.buffer.split('\n');
    this.buffer = messages.pop(); // Keep incomplete message in buffer
    
    return messages.filter(message => message.trim());
  }
}

// Start socket server
async function startSocketServer() {
  return new Promise((resolve, reject) => {
    const server = net.createServer((socket) => {
      const clientId = Date.now().toString(36) + Math.random().toString(36).substr(2);
      log('INFO', 'Client connected', { clientId });
      
      // Initialize message buffer for this client
      const messageBuffer = new MessageBuffer();
      
      // Setup heartbeat
      const heartbeatInterval = setInterval(() => {
        try {
          if (socket.writable) {
            socket.write(JSON.stringify({
              type: 'heartbeat',
              timestamp: new Date().toISOString(),
              server: SERVER_NAME
            }) + '\n');
          }
        } catch (err) {
          log('ERROR', `Failed to send heartbeat to client ${clientId}`, { error: err.message });
        }
      }, 30000);
      
      socket.on('data', (data) => {
        log('DEBUG', `Received data: ${data.length} bytes`, { clientId });
        
        // Append data to buffer
        messageBuffer.append(data);
        
        // Process complete messages
        const messages = messageBuffer.getMessages();
        
        for (const messageText of messages) {
          try {
            // Parse the received data as JSON
            const message = JSON.parse(messageText);
            log('DEBUG', 'Parsed message', { type: message.type, clientId });
            
            // Process the message based on type
            let response;
            if (message.type === 'invoke_tool') {
              // Handle different tools
              if (message.tool === 'searchByTitle') {
                notionConnection.searchByTitle(message.params?.query || '')
                  .then(result => {
                    const response = {
                      type: 'tool_response',
                      id: message.id || 'unknown',
                      status: 'success',
                      result
                    };
                    socket.write(JSON.stringify(response) + '\n');
                  })
                  .catch(err => {
                    const errorResponse = {
                      type: 'error_response',
                      id: message.id || 'unknown',
                      status: 'error',
                      error: err.message
                    };
                    socket.write(JSON.stringify(errorResponse) + '\n');
                  });
                
                // Don't send immediate response for async operations
                continue;
              } else {
                response = {
                  type: 'tool_response',
                  id: message.id || 'unknown',
                  status: 'success',
                  result: `Mock response for tool: ${message.tool || 'unknown'}`
                };
              }
            } else if (message.type === 'handshake') {
              response = { 
                type: 'handshake_response', 
                status: 'success',
                server: SERVER_NAME,
                version: '1.0.0'
              };
            } else {
              response = {
                type: 'error_response',
                status: 'error',
                error: `Unknown message type: ${message.type}`
              };
            }
            
            // Send response if it exists
            if (response) {
              socket.write(JSON.stringify(response) + '\n');
              log('DEBUG', 'Sent response', { type: response.type, clientId });
            }
            
          } catch (err) {
            log('ERROR', `Failed to process message: ${err.message}`, { clientId });
            
            // Send error response
            const errorResponse = {
              type: 'error_response',
              status: 'error',
              error: `Failed to process message: ${err.message}`
            };
            socket.write(JSON.stringify(errorResponse) + '\n');
          }
        }
      });
      
      socket.on('end', () => {
        clearInterval(heartbeatInterval);
        log('INFO', 'Client disconnected', { clientId });
      });
      
      socket.on('error', (err) => {
        log('ERROR', `Socket error: ${err.message}`, { clientId });
      });
    });
    
    // Start listening
    server.listen(SOCKET_PATH, () => {
      log('INFO', `Server listening on ${SOCKET_PATH}`);
      
      // Set permissions on socket file (666 = rw-rw-rw-)
      try {
        fs.chmodSync(SOCKET_PATH, 0o666);
        log('INFO', `Set permissions on socket file: 0666`);
        resolve(true);
      } catch (err) {
        log('ERROR', `Failed to set permissions on socket file: ${err.message}`);
        reject(err);
      }
    });
    
    // Handle errors
    server.on('error', (err) => {
      log('ERROR', `Server error: ${err.message}`);
      
      if (err.code === 'EADDRINUSE') {
        log('ERROR', `Socket file is already in use: ${SOCKET_PATH}`);
      }
      
      reject(err);
    });
    
    // Handle process exit
    process.on('exit', () => {
      try {
        if (fs.existsSync(SOCKET_PATH)) {
          fs.unlinkSync(SOCKET_PATH);
          log('INFO', `Removed socket file on exit: ${SOCKET_PATH}`);
        }
      } catch (err) {
        log('ERROR', `Failed to remove socket file on exit: ${err.message}`);
      }
    });
    
    process.on('SIGINT', () => {
      log('INFO', 'Received SIGINT, shutting down');
      server.close(() => {
        process.exit(0);
      });
    });
    
    process.on('SIGTERM', () => {
      log('INFO', 'Received SIGTERM, shutting down');
      server.close(() => {
        process.exit(0);
      });
    });
  });
}

// Initialize and start
async function initialize() {
  try {
    await notionConnection.initialize();
    await startSocketServer();
    log('INFO', `${SERVER_NAME} server started and ready (PID: ${process.pid})`);
  } catch (err) {
    log('ERROR', `Failed to initialize ${SERVER_NAME} server: ${err.message}`);
    process.exit(1);
  }
}

// Start the server
initialize();

// Export the Notion connection class and instance
module.exports = {
  NotionConnection,
  notionConnection
};
