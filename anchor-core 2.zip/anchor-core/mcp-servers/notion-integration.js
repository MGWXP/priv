#!/usr/bin/env node
/**
 * notion-integration.js - Enhanced Notion MCP Server with SQLite Metadata
 * Version: 6.1.0
 * 
 * This server provides comprehensive Notion API integration with:
 * - SQLite metadata caching
 * - M3 Max hardware optimization
 * - Comprehensive search and database operations
 * - Better error handling and logging
 */

// Core optimizations for M3 Max hardware
process.env.NODE_OPTIONS ||= '--max-old-space-size=16384';
process.env.UV_THREADPOOL_SIZE ||= '12';
process.env.MCP_SERVER_NAME = 'notion';

// Import required modules
const fs = require('fs').promises;
const path = require('path');
const os = require('os');

// Critical paths
const ANCHOR_HOME = process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core';
const PID_PATH = `${ANCHOR_HOME}/mcp-servers/notion.pid`;
const SOCKET_DIR = process.env.SOCKET_DIR || `${ANCHOR_HOME}/sockets`;
const LOG_DIR = process.env.LOG_DIR || `${os.homedir()}/Library/Logs/Claude`;
const SQLITE_DIR = process.env.SQLITE_DIR || `${ANCHOR_HOME}/data`;
const SQLITE_PATH = `${SQLITE_DIR}/notion-metadata.db`;
const CACHE_DURATION = parseInt(process.env.NOTION_CACHE_DURATION || '3600', 10); // Default: 1 hour

// Import additional modules
const sqlite3 = require('sqlite3').verbose();
const { open } = require('sqlite');
const { Client } = require('@notionhq/client');

// Mock implementation for testing without the actual SDK
class MockServer {
  constructor(info, options) {
    this.info = info;
    this.options = options;
    this.tools = [];
  }
  
  registerTools(tools) {
    this.tools.push(...tools);
    console.error(`Registered ${tools.length} tools`);
  }
  
  connect(transport) {
    console.error(`Server ${this.info.name} v${this.info.version} connected to transport`);
  }
}

class MockTransport {
  constructor() {
    console.error('Transport initialized');
  }
}

// Determine whether to use mocks or actual SDK based on environment
const Server = global.Server || MockServer;
const StdioServerTransport = global.StdioServerTransport || MockTransport;

// Advanced logging with structured output
const LV = {DEBUG:0,INFO:1,WARN:2,ERROR:3};
const CUR = LV[(process.env.LOG_LEVEL||'INFO').toUpperCase()]||LV.INFO;
function log(l,msg,extra={}){ if(LV[l]>=CUR)console.error(JSON.stringify({ts:new Date().toISOString(),lvl:l,svr:'notion',msg,extra,pid:process.pid}));}

// Initialize Notion client with safety checks
let notionClient = null;
try {
  const token = process.env.NOTION_API_TOKEN;
  if (token) {
    notionClient = new Client({ auth: token });
    log('INFO', 'Notion client initialized successfully');
  } else {
    log('WARN', 'NOTION_API_TOKEN not provided, using mock responses');
  }
} catch (error) {
  log('ERROR', `Failed to initialize Notion client: ${error.message}`);
}

// Initialize SQLite for metadata caching
let db = null;

async function initDatabase() {
  try {
    // Ensure directory exists
    await fs.mkdir(SQLITE_DIR, { recursive: true });
    
    // Open database connection
    db = await open({
      filename: SQLITE_PATH,
      driver: sqlite3.Database
    });
    
    // Create tables if they don't exist
    await db.exec(`
      CREATE TABLE IF NOT EXISTS pages (
        id TEXT PRIMARY KEY,
        title TEXT,
        parent_id TEXT,
        url TEXT,
        last_edited TIMESTAMP,
        content TEXT,
        metadata TEXT,
        cache_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
      
      CREATE TABLE IF NOT EXISTS databases (
        id TEXT PRIMARY KEY,
        title TEXT,
        parent_id TEXT,
        url TEXT,
        schema TEXT,
        last_edited TIMESTAMP,
        metadata TEXT,
        cache_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
      
      CREATE TABLE IF NOT EXISTS blocks (
        id TEXT PRIMARY KEY,
        parent_id TEXT,
        type TEXT,
        content TEXT,
        has_children BOOLEAN,
        last_edited TIMESTAMP,
        cache_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_parent_id (parent_id)
      );
    `);
    
    log('INFO', 'SQLite database initialized', { path: SQLITE_PATH });
  } catch (error) {
    log('ERROR', `Database initialization failed: ${error.message}`);
    db = null;
  }
}

// Create socket directory if it doesn't exist
(async () => {
  try {
    await fs.mkdir(SOCKET_DIR, { recursive: true });
    log('INFO', `Ensured socket directory exists: ${SOCKET_DIR}`);
    
    // Initialize SQLite database
    await initDatabase();
    
    // PID file maintenance
    await fs.writeFile(PID_PATH, String(process.pid));
    setInterval(() => fs.utimes(PID_PATH, new Date(), new Date()).catch(() => {}), 2000);
  } catch (error) {
    log('ERROR', `Initialization failed: ${error.message}`);
  }
})();

// Common Notion operations with caching
async function searchNotion(query, limit = 10, cacheOnly = false) {
  if (!db) {
    log('WARN', 'Database not available for search cache');
    if (cacheOnly) return [];
  }
  
  try {
    // Check cache first if database is available
    if (db) {
      const cacheTime = new Date(Date.now() - CACHE_DURATION * 1000);
      
      // Search in pages cache
      const cachedPages = await db.all(`
        SELECT id, title, parent_id, url, last_edited
        FROM pages
        WHERE title LIKE ? AND cache_time > ?
        LIMIT ?
      `, [`%${query}%`, cacheTime.toISOString(), limit]);
      
      // Search in databases cache
      const cachedDatabases = await db.all(`
        SELECT id, title, parent_id, url, last_edited
        FROM databases
        WHERE title LIKE ? AND cache_time > ?
        LIMIT ?
      `, [`%${query}%`, cacheTime.toISOString(), limit]);
      
      // If we have enough results from cache, return them
      const cachedResults = [...cachedPages, ...cachedDatabases].slice(0, limit);
      if (cachedResults.length >= limit || cacheOnly) {
        log('INFO', 'Returning cached search results', { count: cachedResults.length });
        return cachedResults;
      }
    }
    
    // Only proceed with live search if we have a client and aren't in cache-only mode
    if (!notionClient || cacheOnly) {
      return [];
    }
    
    // Perform live search
    const response = await notionClient.search({
      query,
      page_size: limit
    });
    
    // Process and cache results
    const results = response.results.map(item => {
      const result = {
        id: item.id,
        type: item.object,
        url: item.url,
        last_edited: item.last_edited_time
      };
      
      // Get title based on object type
      if (item.object === 'page') {
        result.title = item.properties?.Title?.title?.[0]?.plain_text || 
                       item.properties?.Name?.title?.[0]?.plain_text || 
                       'Untitled';
        result.parent_id = item.parent?.page_id || item.parent?.database_id;
        
        // Cache page in database
        if (db) {
          db.run(`
            INSERT OR REPLACE INTO pages 
            (id, title, parent_id, url, last_edited, metadata, cache_time) 
            VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
          `, [
            item.id, 
            result.title, 
            result.parent_id, 
            item.url, 
            item.last_edited_time,
            JSON.stringify(item)
          ]).catch(err => log('ERROR', `Failed to cache page: ${err.message}`));
        }
      } else if (item.object === 'database') {
        result.title = item.title?.[0]?.plain_text || 'Untitled Database';
        result.parent_id = item.parent?.page_id;
        
        // Cache database in SQLite
        if (db) {
          db.run(`
            INSERT OR REPLACE INTO databases 
            (id, title, parent_id, url, schema, last_edited, metadata, cache_time) 
            VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
          `, [
            item.id, 
            result.title, 
            result.parent_id, 
            item.url, 
            JSON.stringify(item.properties),
            item.last_edited_time,
            JSON.stringify(item)
          ]).catch(err => log('ERROR', `Failed to cache database: ${err.message}`));
        }
      }
      
      return result;
    });
    
    log('INFO', 'Performed live Notion search', { count: results.length });
    return results;
  } catch (error) {
    log('ERROR', `Search operation failed: ${error.message}`);
    return [];
  }
}

async function getDatabase(databaseId, cacheOnly = false) {
  if (!db) {
    log('WARN', 'Database not available for database cache');
    if (cacheOnly) return null;
  }
  
  try {
    // Check cache first if database is available
    if (db) {
      const cacheTime = new Date(Date.now() - CACHE_DURATION * 1000);
      
      const cachedDatabase = await db.get(`
        SELECT * FROM databases
        WHERE id = ? AND cache_time > ?
      `, [databaseId, cacheTime.toISOString()]);
      
      if (cachedDatabase) {
        log('INFO', 'Retrieved database from cache', { id: databaseId });
        
        // Parse the metadata JSON
        try {
          cachedDatabase.metadata = JSON.parse(cachedDatabase.metadata);
          cachedDatabase.schema = JSON.parse(cachedDatabase.schema);
        } catch (e) {
          log('WARN', 'Failed to parse cached database JSON', { error: e.message });
        }
        
        return cachedDatabase;
      }
    }
    
    // Only proceed with live fetch if we have a client and aren't in cache-only mode
    if (!notionClient || cacheOnly) {
      return null;
    }
    
    // Fetch database from Notion
    const database = await notionClient.databases.retrieve({ database_id: databaseId });
    
    // Extract properties
    const result = {
      id: database.id,
      title: database.title?.[0]?.plain_text || 'Untitled Database',
      parent_id: database.parent?.page_id,
      url: database.url,
      schema: database.properties,
      last_edited: database.last_edited_time,
      metadata: database
    };
    
    // Cache in SQLite
    if (db) {
      await db.run(`
        INSERT OR REPLACE INTO databases 
        (id, title, parent_id, url, schema, last_edited, metadata, cache_time) 
        VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
      `, [
        result.id, 
        result.title, 
        result.parent_id, 
        result.url, 
        JSON.stringify(result.schema),
        result.last_edited,
        JSON.stringify(database)
      ]);
    }
    
    log('INFO', 'Retrieved database from Notion', { id: databaseId });
    return result;
  } catch (error) {
    log('ERROR', `Failed to get database: ${error.message}`);
    return null;
  }
}

async function queryDatabase(databaseId, filter = {}, sorts = [], pageSize = 100) {
  if (!notionClient) {
    log('WARN', 'Notion client not available for database query');
    return [];
  }
  
  try {
    // Query database from Notion
    const response = await notionClient.databases.query({
      database_id: databaseId,
      filter: Object.keys(filter).length > 0 ? filter : undefined,
      sorts: sorts.length > 0 ? sorts : undefined,
      page_size: pageSize
    });
    
    // Process and cache results
    const results = response.results.map(page => {
      const result = {
        id: page.id,
        url: page.url,
        last_edited: page.last_edited_time,
        properties: {}
      };
      
      // Process properties based on type
      Object.entries(page.properties).forEach(([key, prop]) => {
        if (prop.type === 'title' && prop.title) {
          result.properties[key] = prop.title.map(t => t.plain_text).join('');
          // If this is the title property, set it as the page title for easier access
          if (key === 'Title' || key === 'Name') {
            result.title = result.properties[key];
          }
        } else if (prop.type === 'rich_text' && prop.rich_text) {
          result.properties[key] = prop.rich_text.map(t => t.plain_text).join('');
        } else if (prop.type === 'number' && prop.number !== null) {
          result.properties[key] = prop.number;
        } else if (prop.type === 'select' && prop.select) {
          result.properties[key] = prop.select.name;
        } else if (prop.type === 'multi_select' && prop.multi_select) {
          result.properties[key] = prop.multi_select.map(s => s.name);
        } else if (prop.type === 'date' && prop.date) {
          result.properties[key] = prop.date.start;
        } else if (prop.type === 'checkbox') {
          result.properties[key] = prop.checkbox;
        } else if (prop.type === 'url' && prop.url) {
          result.properties[key] = prop.url;
        } else if (prop.type === 'email' && prop.email) {
          result.properties[key] = prop.email;
        } else if (prop.type === 'phone_number' && prop.phone_number) {
          result.properties[key] = prop.phone_number;
        } else if (prop.type === 'formula' && prop.formula) {
          result.properties[key] = prop.formula.string || prop.formula.number || 
                                  prop.formula.boolean || prop.formula.date;
        }
      });
      
      // Cache page in SQLite
      if (db) {
        db.run(`
          INSERT OR REPLACE INTO pages 
          (id, title, parent_id, url, last_edited, metadata, cache_time) 
          VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
        `, [
          page.id, 
          result.title || 'Untitled', 
          databaseId, 
          page.url, 
          page.last_edited_time,
          JSON.stringify(page)
        ]).catch(err => log('ERROR', `Failed to cache page from query: ${err.message}`));
      }
      
      return result;
    });
    
    log('INFO', 'Queried database', { 
      id: databaseId, 
      results: results.length,
      has_more: response.has_more 
    });
    
    return {
      results,
      has_more: response.has_more,
      next_cursor: response.next_cursor
    };
  } catch (error) {
    log('ERROR', `Database query failed: ${error.message}`);
    return { results: [], has_more: false };
  }
}

async function getPage(pageId, cacheOnly = false) {
  if (!db) {
    log('WARN', 'Database not available for page cache');
    if (cacheOnly) return null;
  }
  
  try {
    // Check cache first if database is available
    if (db) {
      const cacheTime = new Date(Date.now() - CACHE_DURATION * 1000);
      
      const cachedPage = await db.get(`
        SELECT * FROM pages
        WHERE id = ? AND cache_time > ?
      `, [pageId, cacheTime.toISOString()]);
      
      if (cachedPage) {
        log('INFO', 'Retrieved page from cache', { id: pageId });
        
        // Parse the metadata JSON
        try {
          cachedPage.metadata = JSON.parse(cachedPage.metadata);
          if (cachedPage.content) {
            cachedPage.content = JSON.parse(cachedPage.content);
          }
        } catch (e) {
          log('WARN', 'Failed to parse cached page JSON', { error: e.message });
        }
        
        return cachedPage;
      }
    }
    
    // Only proceed with live fetch if we have a client and aren't in cache-only mode
    if (!notionClient || cacheOnly) {
      return null;
    }
    
    // Fetch page from Notion
    const page = await notionClient.pages.retrieve({ page_id: pageId });
    
    // Extract title from properties
    let title = 'Untitled';
    for (const [key, prop] of Object.entries(page.properties)) {
      if (prop.type === 'title' && prop.title && prop.title.length > 0) {
        title = prop.title.map(t => t.plain_text).join('');
        break;
      }
    }
    
    const result = {
      id: page.id,
      title,
      parent_id: page.parent?.database_id || page.parent?.page_id,
      url: page.url,
      last_edited: page.last_edited_time,
      properties: page.properties,
      metadata: page
    };
    
    // Cache in SQLite
    if (db) {
      await db.run(`
        INSERT OR REPLACE INTO pages 
        (id, title, parent_id, url, last_edited, metadata, cache_time) 
        VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
      `, [
        result.id, 
        result.title, 
        result.parent_id, 
        result.url, 
        result.last_edited,
        JSON.stringify(page)
      ]);
    }
    
    log('INFO', 'Retrieved page from Notion', { id: pageId });
    return result;
  } catch (error) {
    log('ERROR', `Failed to get page: ${error.message}`);
    return null;
  }
}

async function getPageBlocks(pageId, cacheOnly = false) {
  if (!db) {
    log('WARN', 'Database not available for blocks cache');
    if (cacheOnly) return [];
  }
  
  try {
    // Check cache first if database is available
    if (db) {
      const cacheTime = new Date(Date.now() - CACHE_DURATION * 1000);
      
      const cachedBlocks = await db.all(`
        SELECT * FROM blocks
        WHERE parent_id = ? AND cache_time > ?
        ORDER BY id
      `, [pageId, cacheTime.toISOString()]);
      
      if (cachedBlocks && cachedBlocks.length > 0) {
        log('INFO', 'Retrieved blocks from cache', { 
          page_id: pageId,
          count: cachedBlocks.length 
        });
        
        // Parse the content JSON
        cachedBlocks.forEach(block => {
          try {
            if (block.content) {
              block.content = JSON.parse(block.content);
            }
          } catch (e) {
            log('WARN', 'Failed to parse cached block JSON', { 
              id: block.id,
              error: e.message 
            });
          }
        });
        
        return cachedBlocks;
      }
    }
    
    // Only proceed with live fetch if we have a client and aren't in cache-only mode
    if (!notionClient || cacheOnly) {
      return [];
    }
    
    // Fetch blocks from Notion
    const { results } = await notionClient.blocks.children.list({ 
      block_id: pageId,
      page_size: 100
    });
    
    // Process blocks
    const processedBlocks = [];
    
    for (const block of results) {
      const blockData = {
        id: block.id,
        parent_id: pageId,
        type: block.type,
        has_children: block.has_children,
        last_edited: block.last_edited_time
      };
      
      // Extract content based on block type
      if (block[block.type] && block[block.type].rich_text) {
        blockData.text = block[block.type].rich_text.map(t => t.plain_text).join('');
      }
      
      blockData.content = block;
      processedBlocks.push(blockData);
      
      // Cache in SQLite
      if (db) {
        await db.run(`
          INSERT OR REPLACE INTO blocks 
          (id, parent_id, type, content, has_children, last_edited, cache_time) 
          VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
        `, [
          blockData.id, 
          blockData.parent_id, 
          blockData.type, 
          JSON.stringify(block),
          blockData.has_children ? 1 : 0,
          blockData.last_edited
        ]);
      }
    }
    
    log('INFO', 'Retrieved blocks from Notion', { 
      page_id: pageId,
      count: processedBlocks.length 
    });
    
    return processedBlocks;
  } catch (error) {
    log('ERROR', `Failed to get blocks: ${error.message}`);
    return [];
  }
}

async function createPage(parentId, properties, children = []) {
  if (!notionClient) {
    log('WARN', 'Notion client not available for page creation');
    return null;
  }
  
  try {
    // Determine parent type (database or page)
    let parent;
    
    // Check if parent ID looks like a database ID
    if (parentId.includes('-')) {
      // Try to get the parent as a database first
      try {
        const database = await getDatabase(parentId, true);
        if (database) {
          parent = { database_id: parentId };
        } else {
          parent = { page_id: parentId };
        }
      } catch (e) {
        parent = { page_id: parentId };
      }
    } else {
      parent = { page_id: parentId };
    }
    
    // Create the page
    const newPage = await notionClient.pages.create({
      parent,
      properties,
      children
    });
    
    // Cache the new page
    if (db) {
      // Extract title
      let title = 'Untitled';
      for (const [key, prop] of Object.entries(newPage.properties)) {
        if (prop.type === 'title' && prop.title && prop.title.length > 0) {
          title = prop.title.map(t => t.plain_text).join('');
          break;
        }
      }
      
      await db.run(`
        INSERT OR REPLACE INTO pages 
        (id, title, parent_id, url, last_edited, metadata, cache_time) 
        VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
      `, [
        newPage.id, 
        title, 
        parent.database_id || parent.page_id, 
        newPage.url, 
        newPage.last_edited_time,
        JSON.stringify(newPage)
      ]);
      
      log('INFO', 'Cached newly created page', { id: newPage.id });
    }
    
    log('INFO', 'Created new page', { 
      id: newPage.id,
      parent_type: parent.database_id ? 'database' : 'page',
      parent_id: parent.database_id || parent.page_id
    });
    
    return {
      id: newPage.id,
      url: newPage.url
    };
  } catch (error) {
    log('ERROR', `Failed to create page: ${error.message}`);
    return null;
  }
}

// Initialize the server
const server = new Server(
  { name: 'notion', version: '6.1.0' },
  { capabilities: { tools: {} } }
);

// Register tools
server.registerTools([
  {
    name: 'notion_search',
    description: 'Search for pages or databases in Notion',
    inputSchema: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'Search term' },
        limit: { type: 'number', default: 10, description: 'Maximum number of results' },
        cache_only: { type: 'boolean', default: false, description: 'Only search in cache' }
      },
      required: ['query']
    },
    handler: async ({ query, limit = 10, cache_only = false }) => {
      return await searchNotion(query, limit, cache_only);
    }
  },
  {
    name: 'notion_get_database',
    description: 'Get a Notion database by ID',
    inputSchema: {
      type: 'object',
      properties: {
        database_id: { type: 'string', description: 'Notion database ID' },
        cache_only: { type: 'boolean', default: false, description: 'Only get from cache' }
      },
      required: ['database_id']
    },
    handler: async ({ database_id, cache_only = false }) => {
      return await getDatabase(database_id, cache_only);
    }
  },
  {
    name: 'notion_query_database',
    description: 'Query a Notion database',
    inputSchema: {
      type: 'object',
      properties: {
        database_id: { type: 'string', description: 'Notion database ID' },
        filter: { type: 'object', default: {}, description: 'Notion filter object' },
        sorts: { type: 'array', default: [], description: 'Sort specifications' },
        page_size: { type: 'number', default: 100, description: 'Results per page' }
      },
      required: ['database_id']
    },
    handler: async ({ database_id, filter = {}, sorts = [], page_size = 100 }) => {
      return await queryDatabase(database_id, filter, sorts, page_size);
    }
  },
  {
    name: 'notion_get_page',
    description: 'Get a Notion page by ID',
    inputSchema: {
      type: 'object',
      properties: {
        page_id: { type: 'string', description: 'Notion page ID' },
        cache_only: { type: 'boolean', default: false, description: 'Only get from cache' }
      },
      required: ['page_id']
    },
    handler: async ({ page_id, cache_only = false }) => {
      return await getPage(page_id, cache_only);
    }
  },
  {
    name: 'notion_get_blocks',
    description: 'Get blocks from a Notion page',
    inputSchema: {
      type: 'object',
      properties: {
        page_id: { type: 'string', description: 'Notion page ID' },
        cache_only: { type: 'boolean', default: false, description: 'Only get from cache' }
      },
      required: ['page_id']
    },
    handler: async ({ page_id, cache_only = false }) => {
      return await getPageBlocks(page_id, cache_only);
    }
  },
  {
    name: 'notion_create_page',
    description: 'Create a new Notion page',
    inputSchema: {
      type: 'object',
      properties: {
        parent_id: { type: 'string', description: 'Parent page or database ID' },
        properties: { type: 'object', description: 'Page properties' },
        children: { type: 'array', default: [], description: 'Page content blocks' }
      },
      required: ['parent_id', 'properties']
    },
    handler: async ({ parent_id, properties, children = [] }) => {
      return await createPage(parent_id, properties, children);
    }
  },
  {
    name: 'notion_clear_cache',
    description: 'Clear the Notion cache',
    inputSchema: {
      type: 'object',
      properties: {
        type: { 
          type: 'string', 
          enum: ['all', 'pages', 'databases', 'blocks'],
          default: 'all',
          description: 'Type of cache to clear' 
        },
        older_than: { 
          type: 'number', 
          description: 'Clear cache older than this many seconds',
          default: 0
        }
      }
    },
    handler: async ({ type = 'all', older_than = 0 }) => {
      if (!db) {
        return { error: 'Database not available' };
      }
      
      try {
        let clearCount = 0;
        const cutoffTime = new Date(Date.now() - older_than * 1000).toISOString();
        
        if (type === 'all' || type === 'pages') {
          const result = await db.run(`
            DELETE FROM pages 
            WHERE cache_time < ?
          `, [cutoffTime]);
          clearCount += result.changes;
        }
        
        if (type === 'all' || type === 'databases') {
          const result = await db.run(`
            DELETE FROM databases 
            WHERE cache_time < ?
          `, [cutoffTime]);
          clearCount += result.changes;
        }
        
        if (type === 'all' || type === 'blocks') {
          const result = await db.run(`
            DELETE FROM blocks 
            WHERE cache_time < ?
          `, [cutoffTime]);
          clearCount += result.changes;
        }
        
        log('INFO', 'Cache cleared', { 
          type, 
          older_than,
          items_removed: clearCount 
        });
        
        return { 
          success: true, 
          cleared: clearCount,
          type,
          older_than_seconds: older_than
        };
      } catch (error) {
        log('ERROR', `Failed to clear cache: ${error.message}`);
        return { error: error.message };
      }
    }
  },
  {
    name: 'notion_cache_stats',
    description: 'Get statistics about the Notion cache',
    inputSchema: {
      type: 'object',
      properties: {}
    },
    handler: async () => {
      if (!db) {
        return { error: 'Database not available' };
      }
      
      try {
        const stats = {
          total_items: 0,
          pages: {
            count: 0,
            size_estimate: 0,
            oldest: null,
            newest: null
          },
          databases: {
            count: 0,
            size_estimate: 0,
            oldest: null,
            newest: null
          },
          blocks: {
            count: 0,
            size_estimate: 0,
            oldest: null,
            newest: null
          }
        };
        
        // Pages stats
        const pageStats = await db.get(`
          SELECT 
            COUNT(*) as count,
            MIN(cache_time) as oldest,
            MAX(cache_time) as newest,
            SUM(LENGTH(metadata)) as size_estimate
          FROM pages
        `);
        
        if (pageStats) {
          stats.pages.count = pageStats.count;
          stats.pages.size_estimate = pageStats.size_estimate || 0;
          stats.pages.oldest = pageStats.oldest;
          stats.pages.newest = pageStats.newest;
          stats.total_items += pageStats.count;
        }
        
        // Databases stats
        const dbStats = await db.get(`
          SELECT 
            COUNT(*) as count,
            MIN(cache_time) as oldest,
            MAX(cache_time) as newest,
            SUM(LENGTH(metadata)) as size_estimate
          FROM databases
        `);
        
        if (dbStats) {
          stats.databases.count = dbStats.count;
          stats.databases.size_estimate = dbStats.size_estimate || 0;
          stats.databases.oldest = dbStats.oldest;
          stats.databases.newest = dbStats.newest;
          stats.total_items += dbStats.count;
        }
        
        // Blocks stats
        const blockStats = await db.get(`
          SELECT 
            COUNT(*) as count,
            MIN(cache_time) as oldest,
            MAX(cache_time) as newest,
            SUM(LENGTH(content)) as size_estimate
          FROM blocks
        `);
        
        if (blockStats) {
          stats.blocks.count = blockStats.count;
          stats.blocks.size_estimate = blockStats.size_estimate || 0;
          stats.blocks.oldest = blockStats.oldest;
          stats.blocks.newest = blockStats.newest;
          stats.total_items += blockStats.count;
        }
        
        // Add total size and formatting
        stats.total_size_mb = Math.round((stats.pages.size_estimate + 
                                         stats.databases.size_estimate + 
                                         stats.blocks.size_estimate) / 1024 / 1024 * 100) / 100;
        
        log('INFO', 'Retrieved cache stats', { total_items: stats.total_items });
        return stats;
      } catch (error) {
        log('ERROR', `Failed to get cache stats: ${error.message}`);
        return { error: error.message };
      }
    }
  }
]);

// Connect to transport
log('INFO', 'Server initialized, connecting transport');
server.connect(new StdioServerTransport());

// Memory optimization
if (global.gc) {
  setInterval(() => {
    const memBefore = process.memoryUsage();
    global.gc();
    const memAfter = process.memoryUsage();
    
    log('DEBUG', 'Explicit garbage collection performed', {
      before: `${(memBefore.heapUsed/1048576).toFixed(1)} MB`,
      after: `${(memAfter.heapUsed/1048576).toFixed(1)} MB`,
      diff: `${((memBefore.heapUsed-memAfter.heapUsed)/1048576).toFixed(1)} MB`
    });
  }, 300000); // Run every 5 minutes
}

// Perform cache maintenance periodically
setInterval(async () => {
  if (!db) return;
  
  try {
    // Vacuum database to reclaim space
    await db.run('VACUUM');
    
    // Remove very old entries (older than 7 days)
    const cutoffTime = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
    
    const pages = await db.run('DELETE FROM pages WHERE cache_time < ?', [cutoffTime]);
    const databases = await db.run('DELETE FROM databases WHERE cache_time < ?', [cutoffTime]);
    const blocks = await db.run('DELETE FROM blocks WHERE cache_time < ?', [cutoffTime]);
    
    log('INFO', 'Cache maintenance performed', {
      pages_removed: pages.changes,
      databases_removed: databases.changes,
      blocks_removed: blocks.changes
    });
  } catch (error) {
    log('ERROR', `Cache maintenance failed: ${error.message}`);
  }
}, 3600000); // Run every hour

log('INFO', 'Notion MCP server with SQLite metadata ready');
