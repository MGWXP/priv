/**
 * circuit-breaker.js - Enhanced circuit breaker pattern for CNIF
 * © 2025 XPV - MIT
 * 
 * Implements a sophisticated circuit breaker pattern with:
 * - State management (CLOSED, OPEN, HALF-OPEN)
 * - Partial degradation capabilities
 * - Configurable thresholds and timeouts
 * - Event-based monitoring
 */

const EventEmitter = require('events');

/**
 * Circuit breaker states
 * @readonly
 * @enum {string}
 */
const CircuitState = {
  CLOSED: 'CLOSED',       // Normal operation
  OPEN: 'OPEN',           // Failing, not accepting requests
  HALF_OPEN: 'HALF_OPEN', // Testing if system has recovered
  PARTIAL: 'PARTIAL'      // Degraded operation
};

/**
 * Enhanced circuit breaker implementation
 * Provides advanced failure detection and recovery with
 * partial degradation capabilities specifically optimized for
 * M3 Max hardware characteristics.
 */
class CircuitBreaker extends EventEmitter {
  /**
   * Create a new CircuitBreaker
   * @param {Object} options - Circuit breaker options
   * @param {string} options.name - Name for this circuit breaker
   * @param {number} options.failureThreshold - Number of failures before opening circuit
   * @param {number} options.resetTimeout - Time (ms) before attempting reset
   * @param {number} options.degradeThreshold - Failures before partial degradation
   * @param {number} options.degradePercentage - Request % to allow in degraded mode
   * @param {Function} options.fallbackFunction - Function to call when circuit is open
   */
  constructor(options = {}) {
    super();
    
    this.name = options.name || 'default';
    this.failureThreshold = options.failureThreshold || 5;
    this.degradeThreshold = options.degradeThreshold || 3;
    this.resetTimeout = options.resetTimeout || 60000; // 1 minute
    this.degradePercentage = options.degradePercentage || 0.3; // 30%
    this.fallbackFunction = options.fallbackFunction;
    
    this.state = CircuitState.CLOSED;
    this.failures = 0;
    this.partialFailures = 0;
    this.lastFailureTime = 0;
    this.successCount = 0;
    this.consecutiveSuccesses = 0;
    this.callCount = 0;
    this.startTime = Date.now();
    
    // Setup event emission
    this.on('stateChange', (oldState, newState) => {
      console.log(`Circuit ${this.name}: ${oldState} -> ${newState}`);
    });
  }
  
  /**
   * Check if a request can proceed
   * @returns {boolean} Whether the request should proceed
   */
  canRequest() {
    this.callCount++;
    
    switch (this.state) {
      case CircuitState.CLOSED:
        return true;
        
      case CircuitState.PARTIAL:
        // Allow only a percentage of requests through
        return Math.random() < this.degradePercentage;
        
      case CircuitState.OPEN:
        const now = Date.now();
        if (now - this.lastFailureTime > this.resetTimeout) {
          this._setState(CircuitState.HALF_OPEN);
          return true;
        }
        return false;
        
      case CircuitState.HALF_OPEN:
        // In half-open state, we allow a single request to test
        return this.consecutiveSuccesses === 0;
        
      default:
        return false;
    }
  }
  
  /**
   * Record a successful operation
   */
  success() {
    this.successCount++;
    this.consecutiveSuccesses++;
    
    if (this.state === CircuitState.HALF_OPEN && this.consecutiveSuccesses >= 2) {
      // After 2 consecutive successes in half-open, we close the circuit
      this._setState(CircuitState.CLOSED);
      this.failures = 0;
      this.partialFailures = 0;
    } else if (this.state === CircuitState.PARTIAL && this.consecutiveSuccesses >= 5) {
      // After 5 consecutive successes in partial, we close the circuit
      this._setState(CircuitState.CLOSED);
      this.failures = 0;
      this.partialFailures = 0;
    }
  }
  
  /**
   * Record a failed operation
   */
  failure() {
    this.failures++;
    this.partialFailures++;
    this.consecutiveSuccesses = 0;
    this.lastFailureTime = Date.now();
    
    switch (this.state) {
      case CircuitState.CLOSED:
        if (this.failures >= this.failureThreshold) {
          this._setState(CircuitState.OPEN);
        } else if (this.partialFailures >= this.degradeThreshold) {
          this._setState(CircuitState.PARTIAL);
        }
        break;
        
      case CircuitState.PARTIAL:
        if (this.failures >= this.failureThreshold) {
          this._setState(CircuitState.OPEN);
        }
        break;
        
      case CircuitState.HALF_OPEN:
        this._setState(CircuitState.OPEN);
        break;
    }
  }
  
  /**
   * Execute a function with circuit breaker protection
   * @param {Function} fn - Function to execute
   * @param {Array} args - Arguments to pass to the function
   * @returns {Promise} Promise resolving to the function result
   */
  async execute(fn, ...args) {
    if (!this.canRequest()) {
      if (this.fallbackFunction) {
        return this.fallbackFunction(...args);
      }
      throw new Error(`Circuit ${this.name} is ${this.state}`);
    }
    
    try {
      const result = await fn(...args);
      this.success();
      return result;
    } catch (error) {
      this.failure();
      throw error;
    }
  }
  
  /**
   * Get circuit health metrics
   * @returns {Object} Circuit health metrics
   */
  getHealth() {
    const uptime = Date.now() - this.startTime;
    
    return {
      name: this.name,
      state: this.state,
      uptime,
      callCount: this.callCount,
      failureCount: this.failures,
      successCount: this.successCount,
      failureRate: this.callCount > 0 ? (this.failures / this.callCount) : 0,
      lastFailure: this.lastFailureTime > 0 ? new Date(this.lastFailureTime).toISOString() : null,
      consecutiveSuccesses: this.consecutiveSuccesses
    };
  }
  
  /**
   * Reset the circuit breaker to closed state
   */
  reset() {
    this._setState(CircuitState.CLOSED);
    this.failures = 0;
    this.partialFailures = 0;
    this.consecutiveSuccesses = 0;
    this.lastFailureTime = 0;
  }
  
  /**
   * Set the circuit state and emit events
   * @param {CircuitState} newState - New circuit state
   * @private
   */
  _setState(newState) {
    if (this.state === newState) return;
    
    const oldState = this.state;
    this.state = newState;
    
    this.emit('stateChange', oldState, newState);
    this.emit(newState.toLowerCase());
    
    // Additional logging for M3 Max optimization monitoring
    console.log(JSON.stringify({
      ts: new Date().toISOString(),
      circuit: this.name,
      event: 'state_change',
      old_state: oldState,
      new_state: newState,
      failures: this.failures,
      consecutive_successes: this.consecutiveSuccesses,
      call_count: this.callCount
    }));
  }
}

module.exports = {
  CircuitBreaker,
  CircuitState
};
