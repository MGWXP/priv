#!/usr/bin/env node
/**
 * test-schema-registry.js - Advanced schema registry testing for CNIF
 * © 2025 XPV - MIT
 * 
 * Comprehensive test script for schema registry verification with
 * schema creation, registration, validation, and metrics reporting.
 */

const SchemaRegistry = require('./schema-registry.cjs');
const fs = require('fs');
const path = require('path');
const os = require('os');

// Create a registry instance
const registry = new SchemaRegistry({
  schemaDirClaude: process.env.ANCHOR_HOME ? `${process.env.ANCHOR_HOME}/schemas/claude` : './schemas/claude',
  schemaDirNotion: process.env.ANCHOR_HOME ? `${process.env.ANCHOR_HOME}/schemas/notion` : './schemas/notion',
  validateOnLoad: true
});

// Create test schema
const createTestSchema = () => {
  return {
    id: 'test-schema',
    version: '1-0-0',
    description: 'A test schema for validation',
    schema: {
      type: 'object',
      required: ['name', 'age', 'roles'],
      properties: {
        name: {
          type: 'string',
          description: 'User name'
        },
        age: {
          type: 'integer',
          minimum: 0,
          maximum: 150,
          description: 'User age'
        },
        email: {
          type: 'string',
          pattern: '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$',
          description: 'User email'
        },
        roles: {
          type: 'array',
          items: {
            type: 'string',
            enum: ['admin', 'user', 'guest']
          },
          description: 'User roles'
        },
        address: {
          type: 'object',
          properties: {
            street: {
              type: 'string'
            },
            city: {
              type: 'string'
            },
            zip: {
              type: 'string'
            }
          },
          description: 'User address'
        }
      }
    }
  };
};

// Create valid test data
const createValidData = () => {
  return {
    name: 'John Doe',
    age: 30,
    email: 'john.doe@example.com',
    roles: ['user', 'admin'],
    address: {
      street: '123 Main St',
      city: 'San Francisco',
      zip: '94105'
    }
  };
};

// Create invalid test data
const createInvalidData = () => {
  return {
    name: 'Jane Doe',
    age: 200, // Invalid: age > 150
    email: 'invalid-email', // Invalid: not an email
    // Missing: roles (required)
    address: {
      street: '456 Market St',
      // Missing: city
      zip: '94105'
    }
  };
};

// Initialize and test
async function runTest() {
  try {
    console.log('Initializing schema registry...');
    await registry.initialize();
    
    // List loaded schemas
    const claudeSchemas = registry.getAllSchemas('claude');
    const notionSchemas = registry.getAllSchemas('notion');
    
    claudeSchemas.forEach(schema => {
      console.log(`Loaded schema: claude/${schema.id}@${schema.version}`);
    });
    
    notionSchemas.forEach(schema => {
      console.log(`Loaded schema: notion/${schema.id}@${schema.version}`);
    });
    
    console.log('Schema registry initialized\n');
    
    // Create test schema
    console.log('Creating test schema...\n');
    const testSchema = createTestSchema();
    
    // Register test schema
    console.log('Registering test schema...\n');
    await registry.registerSchema('claude', testSchema);
    
    // Get schema metrics
    const metrics = registry.getMetrics();
    console.log('Schema metrics:');
    console.log(JSON.stringify(metrics, null, 2));
    console.log('');
    
    // Validate data against schema
    console.log('Testing schema validation:');
    
    // Valid data
    const validData = createValidData();
    const validResult = registry.validateData('claude', 'test-schema', validData);
    
    console.log(`\nValidation of valid data: ${validResult.valid ? '✅ PASSED' : '❌ FAILED'}`);
    if (!validResult.valid) {
      console.log('Validation errors:', validResult.errors);
    } else {
      console.log(`Validation time: ${validResult.validationTimeMs.toFixed(3)}ms`);
    }
    
    // Invalid data
    const invalidData = createInvalidData();
    const invalidResult = registry.validateData('claude', 'test-schema', invalidData);
    
    console.log(`\nValidation of invalid data: ${invalidResult.valid ? '❌ SHOULD FAIL' : '✅ FAILED AS EXPECTED'}`);
    if (!invalidResult.valid) {
      console.log('Validation errors:', invalidResult.errors);
    }
    
    // System info (for debugging)
    console.log('\nSystem Information:');
    console.log(`- Node version: ${process.version}`);
    console.log(`- Platform: ${process.platform} (${os.type()} ${os.release()})`);
    console.log(`- Architecture: ${process.arch}`);
    console.log(`- CPU Model: ${os.cpus()[0].model}`);
    console.log(`- CPU Count: ${os.cpus().length}`);
    console.log(`- Total Memory: ${Math.round(os.totalmem() / (1024 * 1024 * 1024))} GB`);
    console.log(`- Free Memory: ${Math.round(os.freemem() / (1024 * 1024 * 1024))} GB`);
    
    // Create a coherence marker for test completion
    const coherenceDir = path.join(process.env.ANCHOR_HOME || '.', 'coherence_lock');
    try {
      fs.mkdirSync(coherenceDir, { recursive: true });
      const timestamp = new Date().toISOString().replace(/[:.]/g, '');
      const markerPath = path.join(coherenceDir, `schema_test_${timestamp}.marker`);
      fs.writeFileSync(markerPath, JSON.stringify(metrics, null, 2));
      console.log(`\nCreated test completion marker: ${markerPath}`);
    } catch (err) {
      console.warn(`\nWarning: Could not create coherence marker: ${err.message}`);
    }
    
    console.log('\n✅ Schema registry test completed successfully');
  } catch (err) {
    console.error(`\n❌ Test failed: ${err.message}`);
    console.error(err.stack);
    process.exit(1);
  }
}

// Check if this is the main module
if (require.main === module) {
  runTest();
}

module.exports = { runTest, createTestSchema, createValidData, createInvalidData };
