/**
 * mcp-orchestrator.cjs - MCP orchestrator for CNIF
 * © 2025 XPV - MIT
 * 
 * This module coordinates communication between MCP services.
 */

const fs = require('fs');
const net = require('net');
const path = require('path');

// Configuration
const SOCKET_DIR = process.env.SOCKET_DIR || '/Users/XPV/Desktop/anchor-core/sockets';
const SERVER_NAME = process.env.MCP_SERVER_NAME || 'mcp-orchestrator';
const SOCKET_PATH = path.join(SOCKET_DIR, `${SERVER_NAME}.sock`);
const LOG_DIR = process.env.LOG_DIR || path.join(process.env.HOME, 'Library/Logs/Claude');
const LOG_FILE = path.join(LOG_DIR, `${SERVER_NAME}.log`);
const ANCHOR_HOME = process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core';

// Logger
function log(level, message, extra = {}) {
  const logEntry = JSON.stringify({
    ts: new Date().toISOString(),
    level,
    component: SERVER_NAME,
    pid: process.pid,
    message,
    extra: extra || {}
  });
  
  console.log(logEntry);
  
  try {
    fs.appendFileSync(LOG_FILE, logEntry + '\n');
  } catch (err) {
    console.error(`Failed to write to log file: ${err.message}`);
  }
}

// Ensure directories exist
try {
  fs.mkdirSync(SOCKET_DIR, { recursive: true });
  fs.mkdirSync(LOG_DIR, { recursive: true });
} catch (err) {
  log('ERROR', `Failed to create directories: ${err.message}`);
}

// Service connection class
class ServiceConnection {
  constructor(serviceName) {
    this.serviceName = serviceName;
    this.socketPath = path.join(SOCKET_DIR, `${serviceName}.sock`);
    this.connected = false;
    this.socket = null;
    this.buffer = '';
    this.messageQueue = [];
    this.reconnectTimeout = null;
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = 10;
    this.reconnectDelay = 1000; // Start with 1 second
  }
  
  connect() {
    return new Promise((resolve, reject) => {
      if (this.connected) {
        resolve(true);
        return;
      }
      
      if (!fs.existsSync(this.socketPath)) {
        reject(new Error(`Socket file not found: ${this.socketPath}`));
        return;
      }
      
      this.socket = net.createConnection({ path: this.socketPath });
      
      this.socket.on('connect', () => {
        log('INFO', `Connected to ${this.serviceName}`);
        this.connected = true;
        this.reconnectAttempts = 0;
        this.reconnectDelay = 1000;
        
        // Send handshake
        this.sendMessage({
          type: 'handshake',
          client: SERVER_NAME,
          timestamp: new Date().toISOString()
        });
        
        // Process any queued messages
        while (this.messageQueue.length > 0) {
          const message = this.messageQueue.shift();
          this.sendMessage(message);
        }
        
        resolve(true);
      });
      
      this.socket.on('data', (data) => {
        this.buffer += data.toString();
        
        // Process complete messages
        const messages = this.getMessages();
        
        for (const message of messages) {
          try {
            this.handleMessage(message);
          } catch (err) {
            log('ERROR', `Failed to handle message: ${err.message}`, { serviceName: this.serviceName });
          }
        }
      });
      
      this.socket.on('error', (err) => {
        log('ERROR', `Socket error for ${this.serviceName}: ${err.message}`);
        this.connected = false;
        reject(err);
      });
      
      this.socket.on('close', () => {
        if (this.connected) {
          log('WARN', `Connection to ${this.serviceName} closed`);
          this.connected = false;
          
          // Attempt to reconnect
          this.scheduleReconnect();
        }
      });
    });
  }
  
  scheduleReconnect() {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      log('ERROR', `Max reconnect attempts reached for ${this.serviceName}`);
      return;
    }
    
    clearTimeout(this.reconnectTimeout);
    
    // Exponential backoff with jitter
    const delay = this.reconnectDelay * (1 + Math.random() * 0.2);
    this.reconnectTimeout = setTimeout(() => {
      this.reconnectAttempts++;
      log('INFO', `Attempting to reconnect to ${this.serviceName} (attempt ${this.reconnectAttempts})`);
      
      this.connect()
        .then(() => {
          log('INFO', `Reconnected to ${this.serviceName}`);
        })
        .catch(err => {
          log('ERROR', `Failed to reconnect to ${this.serviceName}: ${err.message}`);
          // Increase delay for next attempt (exponential backoff)
          this.reconnectDelay = Math.min(this.reconnectDelay * 2, 30000); // Cap at 30 seconds
          this.scheduleReconnect();
        });
    }, delay);
  }
  
  getMessages() {
    if (!this.buffer.includes('\n')) {
      return [];
    }
    
    const messages = this.buffer.split('\n');
    this.buffer = messages.pop(); // Keep incomplete message in buffer
    
    return messages
      .filter(message => message.trim())
      .map(message => {
        try {
          return JSON.parse(message);
        } catch (err) {
          log('ERROR', `Failed to parse message: ${err.message}`, { serviceName: this.serviceName, message });
          return null;
        }
      })
      .filter(Boolean);
  }
  
  handleMessage(message) {
    log('DEBUG', `Received message from ${this.serviceName}`, { type: message.type });
    
    // Handle different message types
    if (message.type === 'handshake_response') {
      log('INFO', `Handshake successful with ${this.serviceName}`, { version: message.version });
    } else if (message.type === 'heartbeat') {
      // Ignore heartbeats
    } else if (message.type === 'error_response') {
      log('ERROR', `Error from ${this.serviceName}: ${message.error}`);
    } else {
      log('DEBUG', `Unhandled message type: ${message.type}`, { serviceName: this.serviceName });
    }
  }
  
  sendMessage(message) {
    if (!this.connected) {
      log('WARN', `Cannot send message to ${this.serviceName} - not connected`, { messageType: message.type });
      this.messageQueue.push(message);
      
      // Try to connect
      this.connect().catch(err => {
        log('ERROR', `Failed to connect to ${this.serviceName}: ${err.message}`);
      });
      
      return false;
    }
    
    try {
      this.socket.write(JSON.stringify(message) + '\n');
      log('DEBUG', `Sent message to ${this.serviceName}`, { type: message.type });
      return true;
    } catch (err) {
      log('ERROR', `Failed to send message to ${this.serviceName}: ${err.message}`);
      return false;
    }
  }
  
  close() {
    if (this.socket) {
      this.socket.end();
      this.socket = null;
    }
    this.connected = false;
    clearTimeout(this.reconnectTimeout);
  }
}

class MCPOrchestrator {
  constructor() {
    this.services = {
      socket: new ServiceConnection('socket-server'),
      transformer: new ServiceConnection('streaming-transformer'),
      notion: new ServiceConnection('notion')
    };
    
    this.ready = false;
  }
  
  async initialize() {
    log('INFO', 'Initializing MCP orchestrator...');
    
    try {
      // Connect to services
      await Promise.allSettled([
        this.services.socket.connect(),
        this.services.transformer.connect(),
        this.services.notion.connect()
      ]);
      
      log('INFO', 'Connected to available services');
      
      this.ready = true;
      log('INFO', 'MCP orchestrator initialized');
      
      // Start socket server for client connections
      await this.startSocketServer();
      
      return true;
    } catch (err) {
      log('ERROR', `Failed to initialize MCP orchestrator: ${err.message}`);
      throw err;
    }
  }
  
  async startSocketServer() {
    // Remove socket file if it exists
    if (fs.existsSync(SOCKET_PATH)) {
      fs.unlinkSync(SOCKET_PATH);
      log('INFO', `Removed existing socket file: ${SOCKET_PATH}`);
    }
    
    // Create coherence marker
    const coherenceDir = path.join(ANCHOR_HOME, 'coherence_lock');
    fs.mkdirSync(coherenceDir, { recursive: true });
    
    const markerPath = path.join(coherenceDir, `${SERVER_NAME}_${new Date().toISOString().replace(/[:.]/g, '')}.marker`);
    fs.writeFileSync(markerPath, String(process.pid));
    
    log('INFO', `Created coherence marker: ${markerPath}`);
    
    // Create server
    const server = net.createServer((socket) => {
      const clientId = Date.now().toString(36) + Math.random().toString(36).substr(2);
      log('INFO', 'Client connected', { clientId });
      
      let buffer = '';
      
      // Setup heartbeat
      const heartbeatInterval = setInterval(() => {
        try {
          if (socket.writable) {
            socket.write(JSON.stringify({
              type: 'heartbeat',
              timestamp: new Date().toISOString(),
              server: SERVER_NAME
            }) + '\n');
          }
        } catch (err) {
          log('ERROR', `Failed to send heartbeat to client ${clientId}`, { error: err.message });
        }
      }, 30000);
      
      socket.on('data', (data) => {
        buffer += data.toString();
        
        // Process complete messages
        const messages = buffer.split('\n');
        buffer = messages.pop(); // Keep incomplete message in buffer
        
        for (const messageText of messages.filter(m => m.trim())) {
          try {
            const message = JSON.parse(messageText);
            log('DEBUG', `Received message from client ${clientId}`, { type: message.type });
            
            // Handle message
            let response;
            if (message.type === 'handshake') {
              response = { 
                type: 'handshake_response', 
                status: 'success',
                server: SERVER_NAME,
                version: '1.0.0'
              };
            } else if (message.type === 'health_check') {
              response = {
                type: 'health_response',
                status: 'ok',
                services: {
                  socket: this.services.socket.connected,
                  transformer: this.services.transformer.connected,
                  notion: this.services.notion.connected
                },
                ready: this.ready,
                timestamp: new Date().toISOString()
              };
            } else {
              response = {
                type: 'error_response',
                status: 'error',
                error: `Unknown message type: ${message.type}`
              };
            }
            
            // Send response
            socket.write(JSON.stringify(response) + '\n');
          } catch (err) {
            log('ERROR', `Failed to process message: ${err.message}`, { clientId });
            
            // Send error response
            const errorResponse = {
              type: 'error_response',
              status: 'error',
              error: `Failed to process message: ${err.message}`
            };
            socket.write(JSON.stringify(errorResponse) + '\n');
          }
        }
      });
      
      socket.on('end', () => {
        clearInterval(heartbeatInterval);
        log('INFO', 'Client disconnected', { clientId });
      });
      
      socket.on('error', (err) => {
        log('ERROR', `Socket error: ${err.message}`, { clientId });
      });
    });
    
    // Handle server errors
    server.on('error', (err) => {
      log('ERROR', `Server error: ${err.message}`);
      
      if (err.code === 'EADDRINUSE') {
        log('ERROR', `Socket file is already in use: ${SOCKET_PATH}`);
      }
    });
    
    // Start listening
    server.listen(SOCKET_PATH, () => {
      log('INFO', `Server listening on ${SOCKET_PATH}`);
      
      // Set permissions on socket file (666 = rw-rw-rw-)
      try {
        fs.chmodSync(SOCKET_PATH, 0o666);
        log('INFO', `Set permissions on socket file: 0666`);
      } catch (err) {
        log('ERROR', `Failed to set permissions on socket file: ${err.message}`);
      }
    });
    
    // Handle process exit
    process.on('exit', () => {
      try {
        if (fs.existsSync(SOCKET_PATH)) {
          fs.unlinkSync(SOCKET_PATH);
          log('INFO', `Removed socket file on exit: ${SOCKET_PATH}`);
        }
        
        // Close all connections
        for (const service of Object.values(this.services)) {
          service.close();
        }
      } catch (err) {
        log('ERROR', `Failed to clean up resources: ${err.message}`);
      }
    });
    
    // Handle signals
    process.on('SIGINT', () => {
      log('INFO', 'Received SIGINT, shutting down');
      server.close(() => {
        process.exit(0);
      });
    });
    
    process.on('SIGTERM', () => {
      log('INFO', 'Received SIGTERM, shutting down');
      server.close(() => {
        process.exit(0);
      });
    });
  }
}

// Create and initialize orchestrator
const orchestrator = new MCPOrchestrator();
orchestrator.initialize()
  .then(() => {
    log('INFO', `MCP orchestrator started and ready (PID: ${process.pid})`);
  })
  .catch(err => {
    log('ERROR', `Failed to start MCP orchestrator: ${err.message}`);
    process.exit(1);
  });

// Export orchestrator
module.exports = orchestrator;
