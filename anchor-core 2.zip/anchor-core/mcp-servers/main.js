/**
 * main.js - Main entry point for CNIF schema registry
 * © 2025 XPV - MIT
 */

console.log('Loading schema registry service...');
const registry = require('./schema-registry-index');

// The registry will be automatically initialized in the index file
// This file just needs to keep the process running

// Keep process alive
console.log('Schema registry service running. Press Ctrl+C to stop.');
process.on('SIGINT', async () => {
  console.log('Shutting down schema registry service...');
  process.exit(0);
});
