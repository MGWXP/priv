#!/usr/bin/env node
/**
 * slack-wrapper.js - Enhanced Slack MCP Server with M3 Max optimizations
 * Version: 1.0.0
 */

// Set environment variables for optimization
process.env.NODE_OPTIONS ||= '--max-old-space-size=4096';
process.env.UV_THREADPOOL_SIZE ||= '8';

const { Server, StdioServerTransport } = require('@modelcontextprotocol/sdk');
const { WebClient } = require('@slack/web-api');
const fs = require('fs').promises;
const os = require('os');
const path = require('path');

// Critical paths
const ANCHOR_HOME = process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core';
const LOG_DIR = process.env.LOG_DIR || `${os.homedir()}/Library/Logs/Claude`;
const CACHE_DIR = process.env.CACHE_DIR || `${ANCHOR_HOME}/data/slack-cache`;
const PID_PATH = `${ANCHOR_HOME}/mcp-servers/slack.pid`;

// Setup logging
const LOG_LEVEL = {
  DEBUG: 0,
  INFO: 1,
  WARN: 2,
  ERROR: 3
};
const CURRENT_LEVEL = LOG_LEVEL[(process.env.LOG_LEVEL || 'INFO').toUpperCase()] || LOG_LEVEL.INFO;

function log(level, message, extra = {}) {
  if (LOG_LEVEL[level] >= CURRENT_LEVEL) {
    console.error(JSON.stringify({
      timestamp: new Date().toISOString(),
      level,
      service: 'slack',
      message,
      extra,
      pid: process.pid
    }));
  }
}

// Ensure directories exist
(async () => {
  try {
    await fs.mkdir(CACHE_DIR, { recursive: true });
    
    // Write PID file
    await fs.writeFile(PID_PATH, String(process.pid));
    setInterval(() => fs.utimes(PID_PATH, new Date(), new Date()).catch(() => {}), 2000);
  } catch (error) {
    log('ERROR', `Initialization failed: ${error.message}`);
  }
})();

// Initialize Slack client
let slackBot = null;
let slackUser = null;

try {
  const botToken = process.env.SLACK_BOT_TOKEN;
  const userToken = process.env.SLACK_USER_TOKEN;
  
  if (botToken) {
    slackBot = new WebClient(botToken);
    log('INFO', 'Slack bot client initialized');
  } else {
    log('WARN', 'SLACK_BOT_TOKEN not provided');
  }
  
  if (userToken) {
    slackUser = new WebClient(userToken);
    log('INFO', 'Slack user client initialized');
  } else {
    log('WARN', 'SLACK_USER_TOKEN not provided');
  }
} catch (error) {
  log('ERROR', `Failed to initialize Slack client: ${error.message}`);
}

// Initialize cache system
const CACHE_DURATION = parseInt(process.env.SLACK_CACHE_DURATION || '3600', 10); // Default: 1 hour

async function saveToCache(key, data) {
  try {
    const cacheFile = path.join(CACHE_DIR, `${key}.json`);
    const cacheData = JSON.stringify({
      timestamp: Date.now(),
      data
    });
    
    await fs.writeFile(cacheFile, cacheData, 'utf8');
    log('DEBUG', 'Data saved to cache', { key });
  } catch (error) {
    log('ERROR', `Failed to save to cache: ${error.message}`, { key });
  }
}

async function getFromCache(key) {
  try {
    const cacheFile = path.join(CACHE_DIR, `${key}.json`);
    
    // Check if cache file exists
    try {
      await fs.access(cacheFile);
    } catch {
      return null; // File doesn't exist
    }
    
    // Read and parse cache
    const cacheData = JSON.parse(await fs.readFile(cacheFile, 'utf8'));
    
    // Check if cache is expired
    const cacheAge = Date.now() - cacheData.timestamp;
    if (cacheAge > CACHE_DURATION * 1000) {
      log('DEBUG', 'Cache expired', { key, ageSeconds: Math.floor(cacheAge / 1000) });
      return null;
    }
    
    log('DEBUG', 'Data retrieved from cache', { key });
    return cacheData.data;
  } catch (error) {
    log('ERROR', `Failed to read from cache: ${error.message}`, { key });
    return null;
  }
}

// Slack API wrapper functions with caching
async function getConversationsList(cacheOnly = false) {
  const cacheKey = 'conversations_list';
  
  // Try to get from cache first
  const cached = await getFromCache(cacheKey);
  if (cached) {
    return cached;
  }
  
  // If cache-only mode, return empty array
  if (cacheOnly || !slackBot) {
    return [];
  }
  
  try {
    // Get conversations from Slack API
    const result = await slackBot.conversations.list({
      types: 'public_channel,private_channel,mpim,im',
      limit: 1000
    });
    
    // Process the channels
    const channels = result.channels.map(channel => ({
      id: channel.id,
      name: channel.name || channel.id,
      is_private: channel.is_private,
      is_im: channel.is_im,
      is_mpim: channel.is_mpim,
      members: channel.members,
      topic: channel.topic?.value,
      purpose: channel.purpose?.value,
      created: channel.created
    }));
    
    // Save to cache
    await saveToCache(cacheKey, channels);
    
    log('INFO', 'Retrieved conversations list from Slack', { count: channels.length });
    return channels;
  } catch (error) {
    log('ERROR', `Failed to get conversations list: ${error.message}`);
    return [];
  }
}

async function getConversationHistory(channelId, limit = 100, cacheOnly = false) {
  const cacheKey = `history_${channelId}`;
  
  // Try to get from cache first
  const cached = await getFromCache(cacheKey);
  if (cached) {
    return cached;
  }
  
  // If cache-only mode, return empty array
  if (cacheOnly || !slackBot) {
    return [];
  }
  
  try {
    // Get conversation history from Slack API
    const result = await slackBot.conversations.history({
      channel: channelId,
      limit
    });
    
    // Process the messages
    const messages = result.messages.map(message => ({
      ts: message.ts,
      user: message.user,
      text: message.text,
      thread_ts: message.thread_ts,
      reply_count: message.reply_count,
      reactions: message.reactions,
      timestamp: new Date(parseFloat(message.ts) * 1000).toISOString()
    }));
    
    // Save to cache
    await saveToCache(cacheKey, messages);
    
    log('INFO', 'Retrieved conversation history from Slack', { 
      channel: channelId,
      messages: messages.length 
    });
    return messages;
  } catch (error) {
    log('ERROR', `Failed to get conversation history: ${error.message}`, { channel: channelId });
    return [];
  }
}

async function getThreadReplies(channelId, threadTs, cacheOnly = false) {
  const cacheKey = `thread_${channelId}_${threadTs.replace('.', '_')}`;
  
  // Try to get from cache first
  const cached = await getFromCache(cacheKey);
  if (cached) {
    return cached;
  }
  
  // If cache-only mode, return empty array
  if (cacheOnly || !slackBot) {
    return [];
  }
  
  try {
    // Get thread replies from Slack API
    const result = await slackBot.conversations.replies({
      channel: channelId,
      ts: threadTs
    });
    
    // Process the messages
    const messages = result.messages.map(message => ({
      ts: message.ts,
      user: message.user,
      text: message.text,
      thread_ts: message.thread_ts,
      reactions: message.reactions,
      timestamp: new Date(parseFloat(message.ts) * 1000).toISOString()
    }));
    
    // Save to cache
    await saveToCache(cacheKey, messages);
    
    log('INFO', 'Retrieved thread replies from Slack', {
      channel: channelId,
      thread: threadTs,
      replies: messages.length
    });
    return messages;
  } catch (error) {
    log('ERROR', `Failed to get thread replies: ${error.message}`, { 
      channel: channelId,
      thread: threadTs 
    });
    return [];
  }
}

async function getUserInfo(userId, cacheOnly = false) {
  const cacheKey = `user_${userId}`;
  
  // Try to get from cache first
  const cached = await getFromCache(cacheKey);
  if (cached) {
    return cached;
  }
  
  // If cache-only mode, return null
  if (cacheOnly || !slackBot) {
    return null;
  }
  
  try {
    // Get user info from Slack API
    const result = await slackBot.users.info({
      user: userId
    });
    
    // Process user data
    const user = {
      id: result.user.id,
      name: result.user.name,
      real_name: result.user.real_name,
      display_name: result.user.profile.display_name,
      email: result.user.profile.email,
      title: result.user.profile.title,
      is_admin: result.user.is_admin,
      is_bot: result.user.is_bot
    };
    
    // Save to cache
    await saveToCache(cacheKey, user);
    
    log('INFO', 'Retrieved user info from Slack', { user: userId });
    return user;
  } catch (error) {
    log('ERROR', `Failed to get user info: ${error.message}`, { user: userId });
    return null;
  }
}

async function postMessage(channelId, text, threadTs = null) {
  if (!slackBot) {
    log('ERROR', 'Slack bot client not available for posting message');
    return { error: 'Slack client not available' };
  }
  
  try {
    // Create message payload
    const messagePayload = {
      channel: channelId,
      text
    };
    
    // Add thread_ts if provided
    if (threadTs) {
      messagePayload.thread_ts = threadTs;
    }
    
    // Post message to Slack
    const result = await slackBot.chat.postMessage(messagePayload);
    
    log('INFO', 'Posted message to Slack', {
      channel: channelId,
      thread: threadTs || 'new',
      ts: result.ts
    });
    
    return {
      ok: result.ok,
      ts: result.ts,
      channel: result.channel
    };
  } catch (error) {
    log('ERROR', `Failed to post message: ${error.message}`, { 
      channel: channelId,
      thread: threadTs 
    });
    return { error: error.message };
  }
}

async function searchMessages(query, cacheOnly = false) {
  // This endpoint requires a user token
  if (!slackUser) {
    log('ERROR', 'Slack user client not available for search');
    return [];
  }
  
  const cacheKey = `search_${query.replace(/\s+/g, '_')}`;
  
  // Try to get from cache first
  const cached = await getFromCache(cacheKey);
  if (cached) {
    return cached;
  }
  
  // If cache-only mode, return empty array
  if (cacheOnly) {
    return [];
  }
  
  try {
    // Search messages using Slack API
    const result = await slackUser.search.messages({
      query,
      sort: 'timestamp',
      sort_dir: 'desc',
      count: 100
    });
    
    // Process messages
    const messages = result.messages.matches.map(message => ({
      ts: message.ts,
      text: message.text,
      user: message.user,
      username: message.username,
      channel: {
        id: message.channel.id,
        name: message.channel.name
      },
      permalink: message.permalink,
      timestamp: new Date(parseFloat(message.ts) * 1000).toISOString()
    }));
    
    // Save to cache
    await saveToCache(cacheKey, messages);
    
    log('INFO', 'Searched messages in Slack', {
      query,
      results: messages.length
    });
    return messages;
  } catch (error) {
    log('ERROR', `Failed to search messages: ${error.message}`, { query });
    return [];
  }
}

// Initialize the server
const server = new Server(
  { name: 'slack', version: '1.0.0' },
  { capabilities: { tools: {} } }
);

// Register tools
server.registerTools([
  {
    name: 'slack_search_messages',
    description: 'Search messages in Slack',
    inputSchema: {
      type: 'object',
      properties: {
        query: { 
          type: 'string', 
          description: 'Search query' 
        },
        cache_only: { 
          type: 'boolean', 
          default: false, 
          description: 'Only search in cache' 
        }
      },
      required: ['query']
    },
    handler: async ({ query, cache_only = false }) => {
      return await searchMessages(query, cache_only);
    }
  },
  {
    name: 'slack_list_conversations',
    description: 'List channels and direct messages',
    inputSchema: {
      type: 'object',
      properties: {
        cache_only: { 
          type: 'boolean', 
          default: false, 
          description: 'Only get from cache' 
        }
      }
    },
    handler: async ({ cache_only = false }) => {
      return await getConversationsList(cache_only);
    }
  },
  {
    name: 'slack_conversation_history',
    description: 'Get conversation history for a channel or DM',
    inputSchema: {
      type: 'object',
      properties: {
        channel_id: { 
          type: 'string', 
          description: 'Channel or conversation ID' 
        },
        limit: { 
          type: 'number', 
          default: 100, 
          description: 'Maximum number of messages to retrieve' 
        },
        cache_only: { 
          type: 'boolean', 
          default: false, 
          description: 'Only get from cache' 
        }
      },
      required: ['channel_id']
    },
    handler: async ({ channel_id, limit = 100, cache_only = false }) => {
      return await getConversationHistory(channel_id, limit, cache_only);
    }
  },
  {
    name: 'slack_thread_replies',
    description: 'Get replies in a thread',
    inputSchema: {
      type: 'object',
      properties: {
        channel_id: { 
          type: 'string', 
          description: 'Channel ID' 
        },
        thread_ts: { 
          type: 'string', 
          description: 'Thread timestamp (TS)' 
        },
        cache_only: { 
          type: 'boolean', 
          default: false, 
          description: 'Only get from cache' 
        }
      },
      required: ['channel_id', 'thread_ts']
    },
    handler: async ({ channel_id, thread_ts, cache_only = false }) => {
      return await getThreadReplies(channel_id, thread_ts, cache_only);
    }
  },
  {
    name: 'slack_user_info',
    description: 'Get information about a Slack user',
    inputSchema: {
      type: 'object',
      properties: {
        user_id: { 
          type: 'string', 
          description: 'User ID' 
        },
        cache_only: { 
          type: 'boolean', 
          default: false, 
          description: 'Only get from cache' 
        }
      },
      required: ['user_id']
    },
    handler: async ({ user_id, cache_only = false }) => {
      return await getUserInfo(user_id, cache_only);
    }
  },
  {
    name: 'slack_post_message',
    description: 'Post a message to a channel or thread',
    inputSchema: {
      type: 'object',
      properties: {
        channel_id: { 
          type: 'string', 
          description: 'Channel ID to post to' 
        },
        text: { 
          type: 'string', 
          description: 'Message text' 
        },
        thread_ts: { 
          type: 'string', 
          description: 'Thread timestamp for replies (optional)',
          default: null
        }
      },
      required: ['channel_id', 'text']
    },
    handler: async ({ channel_id, text, thread_ts = null }) => {
      return await postMessage(channel_id, text, thread_ts);
    }
  },
  {
    name: 'slack_clear_cache',
    description: 'Clear the Slack cache',
    inputSchema: {
      type: 'object',
      properties: {
        older_than: { 
          type: 'number', 
          description: 'Clear cache older than this many seconds (0 for all)',
          default: 0
        }
      }
    },
    handler: async ({ older_than = 0 }) => {
      try {
        const files = await fs.readdir(CACHE_DIR);
        let cleared = 0;
        
        for (const file of files) {
          const filePath = path.join(CACHE_DIR, file);
          
          // Get file stats
          const stats = await fs.stat(filePath);
          
          // Convert older_than to milliseconds
          const cutoffTime = Date.now() - older_than * 1000;
          
          // Check if file is older than cutoff
          if (older_than === 0 || stats.mtime.getTime() < cutoffTime) {
            await fs.unlink(filePath);
            cleared++;
          }
        }
        
        log('INFO', 'Cache cleared', { 
          files_removed: cleared,
          total_files: files.length,
          older_than_seconds: older_than
        });
        
        return { 
          success: true, 
          cleared,
          total: files.length,
          older_than_seconds: older_than
        };
      } catch (error) {
        log('ERROR', `Failed to clear cache: ${error.message}`);
        return { error: error.message };
      }
    }
  }
]);

// Connect to transport
log('INFO', 'Slack server initialized, connecting to transport');
server.connect(new StdioServerTransport());

// Handle process termination
process.on('exit', () => {
  log('INFO', 'Server shutting down');
  try {
    fs.unlink(PID_PATH);
  } catch (e) {}
});

process.on('SIGINT', () => {
  log('INFO', 'Received SIGINT signal');
  process.exit(0);
});

process.on('SIGTERM', () => {
  log('INFO', 'Received SIGTERM signal');
  process.exit(0);
});

// Optimization for M3 Max hardware
if (global.gc) {
  setInterval(() => {
    const memBefore = process.memoryUsage().heapUsed;
    global.gc();
    const memAfter = process.memoryUsage().heapUsed;
    
    log('DEBUG', 'Explicit garbage collection performed', {
      before: Math.round(memBefore / 1024 / 1024) + ' MB',
      after: Math.round(memAfter / 1024 / 1024) + ' MB',
      freed: Math.round((memBefore - memAfter) / 1024 / 1024) + ' MB'
    });
  }, 300000); // Every 5 minutes
}

log('INFO', 'Slack MCP server ready');
