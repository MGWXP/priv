#!/usr/bin/env node
/**
 * sqlite-wrapper.js - Enhanced SQLite MCP Server with M3 Max optimizations
 * Version: 1.0.0
 */

// Set environment variables for optimization
process.env.NODE_OPTIONS ||= '--max-old-space-size=4096';
process.env.UV_THREADPOOL_SIZE ||= '8';

const { Server, StdioServerTransport } = require('@modelcontextprotocol/sdk');
const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');
const os = require('os');

// Critical paths
const ANCHOR_HOME = process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core';
const DATA_DIR = process.env.DATA_DIR || `${ANCHOR_HOME}/data/sqlite`;
const LOG_DIR = process.env.LOG_DIR || `${os.homedir()}/Library/Logs/Claude`;
const PID_PATH = `${ANCHOR_HOME}/mcp-servers/sqlite.pid`;

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Write PID file
fs.writeFileSync(PID_PATH, String(process.pid));
setInterval(() => {
  try {
    fs.utimesSync(PID_PATH, new Date(), new Date());
  } catch (e) {}
}, 2000);

// Setup logging
const LOG_LEVEL = {
  DEBUG: 0,
  INFO: 1,
  WARN: 2,
  ERROR: 3
};
const CURRENT_LEVEL = LOG_LEVEL[(process.env.LOG_LEVEL || 'INFO').toUpperCase()] || LOG_LEVEL.INFO;

function log(level, message, extra = {}) {
  if (LOG_LEVEL[level] >= CURRENT_LEVEL) {
    console.error(JSON.stringify({
      timestamp: new Date().toISOString(),
      level,
      service: 'sqlite',
      message,
      extra,
      pid: process.pid
    }));
  }
}

// Database connection pool
const dbConnections = new Map();

// Get or create a database connection
function getDatabase(dbPath) {
  if (!dbConnections.has(dbPath)) {
    try {
      // Ensure parent directory exists
      const parentDir = path.dirname(dbPath);
      if (!fs.existsSync(parentDir)) {
        fs.mkdirSync(parentDir, { recursive: true });
      }
      
      // Normalize path to absolute
      const absolutePath = path.isAbsolute(dbPath)
        ? dbPath
        : path.join(DATA_DIR, dbPath);
      
      // Create database connection with optimizations
      const db = new Database(absolutePath, {
        verbose: CURRENT_LEVEL === LOG_LEVEL.DEBUG ? console.log : null
      });
      
      // Apply optimizations
      db.pragma('journal_mode = WAL');
      db.pragma('synchronous = NORMAL');
      db.pragma('temp_store = MEMORY');
      db.pragma('mmap_size = 268435456'); // 256MB memory mapping
      
      dbConnections.set(dbPath, db);
      log('INFO', `Database connection created`, { path: absolutePath });
    } catch (error) {
      log('ERROR', `Failed to create database connection`, { 
        path: dbPath,
        error: error.message
      });
      throw error;
    }
  }
  
  return dbConnections.get(dbPath);
}

// Close all database connections
function closeAllConnections() {
  for (const [path, db] of dbConnections.entries()) {
    try {
      db.close();
      log('INFO', `Database connection closed`, { path });
    } catch (error) {
      log('ERROR', `Failed to close database connection`, {
        path,
        error: error.message
      });
    }
  }
  dbConnections.clear();
}

// SQLite Tools
const server = new Server(
  { name: 'sqlite', version: '1.0.0' },
  { capabilities: { tools: {} } }
);

server.registerTools([
  {
    name: 'sqlite_execute',
    description: 'Execute an SQL statement on a SQLite database',
    inputSchema: {
      type: 'object',
      properties: {
        database: { 
          type: 'string', 
          description: 'Path to SQLite database relative to the data directory, or absolute path' 
        },
        sql: { 
          type: 'string', 
          description: 'SQL statement to execute' 
        },
        params: { 
          type: 'array', 
          description: 'Parameters to use with the SQL statement',
          items: { type: ['string', 'number', 'boolean', 'null'] },
          default: [] 
        }
      },
      required: ['database', 'sql']
    },
    handler: async ({ database, sql, params = [] }) => {
      try {
        const db = getDatabase(database);
        
        // Determine if this is a SELECT statement
        const isSelect = sql.trim().toUpperCase().startsWith('SELECT');
        
        if (isSelect) {
          // For SELECT, use .all() to get all results
          const result = db.prepare(sql).all(...params);
          log('INFO', 'Query executed successfully', { 
            database, 
            rows: result.length 
          });
          return { rows: result };
        } else {
          // For other statements, use .run()
          const result = db.prepare(sql).run(...params);
          log('INFO', 'Statement executed successfully', { 
            database, 
            changes: result.changes 
          });
          return { 
            changes: result.changes,
            lastInsertRowid: result.lastInsertRowid 
          };
        }
      } catch (error) {
        log('ERROR', 'SQL execution failed', { 
          database, 
          sql,
          error: error.message 
        });
        return { error: error.message };
      }
    }
  },
  {
    name: 'sqlite_query',
    description: 'Query data from a SQLite database',
    inputSchema: {
      type: 'object',
      properties: {
        database: { 
          type: 'string', 
          description: 'Path to SQLite database relative to the data directory, or absolute path' 
        },
        sql: { 
          type: 'string', 
          description: 'SQL query to execute (SELECT statement)' 
        },
        params: { 
          type: 'array', 
          description: 'Parameters to use with the SQL query',
          items: { type: ['string', 'number', 'boolean', 'null'] },
          default: [] 
        }
      },
      required: ['database', 'sql']
    },
    handler: async ({ database, sql, params = [] }) => {
      try {
        if (!sql.trim().toUpperCase().startsWith('SELECT')) {
          throw new Error('This function only accepts SELECT statements');
        }
        
        const db = getDatabase(database);
        const result = db.prepare(sql).all(...params);
        
        log('INFO', 'Query executed successfully', { 
          database, 
          rows: result.length 
        });
        
        return { rows: result };
      } catch (error) {
        log('ERROR', 'Query failed', { 
          database, 
          sql,
          error: error.message 
        });
        return { error: error.message };
      }
    }
  },
  {
    name: 'sqlite_get',
    description: 'Get a single row from a SQLite database',
    inputSchema: {
      type: 'object',
      properties: {
        database: { 
          type: 'string', 
          description: 'Path to SQLite database relative to the data directory, or absolute path' 
        },
        sql: { 
          type: 'string', 
          description: 'SQL query to execute (SELECT statement)' 
        },
        params: { 
          type: 'array', 
          description: 'Parameters to use with the SQL query',
          items: { type: ['string', 'number', 'boolean', 'null'] },
          default: [] 
        }
      },
      required: ['database', 'sql']
    },
    handler: async ({ database, sql, params = [] }) => {
      try {
        if (!sql.trim().toUpperCase().startsWith('SELECT')) {
          throw new Error('This function only accepts SELECT statements');
        }
        
        const db = getDatabase(database);
        const result = db.prepare(sql).get(...params);
        
        log('INFO', 'Get executed successfully', { 
          database, 
          found: result !== undefined 
        });
        
        return { row: result };
      } catch (error) {
        log('ERROR', 'Get failed', { 
          database, 
          sql,
          error: error.message 
        });
        return { error: error.message };
      }
    }
  },
  {
    name: 'sqlite_run',
    description: 'Run a statement that modifies the database (INSERT, UPDATE, DELETE)',
    inputSchema: {
      type: 'object',
      properties: {
        database: { 
          type: 'string', 
          description: 'Path to SQLite database relative to the data directory, or absolute path' 
        },
        sql: { 
          type: 'string', 
          description: 'SQL statement to execute (non-SELECT)' 
        },
        params: { 
          type: 'array', 
          description: 'Parameters to use with the SQL statement',
          items: { type: ['string', 'number', 'boolean', 'null'] },
          default: [] 
        }
      },
      required: ['database', 'sql']
    },
    handler: async ({ database, sql, params = [] }) => {
      try {
        if (sql.trim().toUpperCase().startsWith('SELECT')) {
          throw new Error('This function does not accept SELECT statements');
        }
        
        const db = getDatabase(database);
        const result = db.prepare(sql).run(...params);
        
        log('INFO', 'Statement executed successfully', { 
          database, 
          changes: result.changes 
        });
        
        return { 
          changes: result.changes,
          lastInsertRowid: result.lastInsertRowid 
        };
      } catch (error) {
        log('ERROR', 'Statement execution failed', { 
          database, 
          sql,
          error: error.message 
        });
        return { error: error.message };
      }
    }
  },
  {
    name: 'sqlite_transaction',
    description: 'Execute multiple SQL statements in a transaction',
    inputSchema: {
      type: 'object',
      properties: {
        database: { 
          type: 'string', 
          description: 'Path to SQLite database relative to the data directory, or absolute path' 
        },
        statements: { 
          type: 'array', 
          description: 'Array of SQL statements to execute in a transaction',
          items: {
            type: 'object',
            properties: {
              sql: { type: 'string', description: 'SQL statement' },
              params: { 
                type: 'array', 
                description: 'Parameters for the statement',
                items: { type: ['string', 'number', 'boolean', 'null'] },
                default: [] 
              }
            },
            required: ['sql']
          }
        }
      },
      required: ['database', 'statements']
    },
    handler: async ({ database, statements }) => {
      try {
        const db = getDatabase(database);
        
        // Begin transaction
        db.prepare('BEGIN TRANSACTION').run();
        
        const results = [];
        let success = true;
        
        try {
          // Execute each statement
          for (const { sql, params = [] } of statements) {
            const isSelect = sql.trim().toUpperCase().startsWith('SELECT');
            
            if (isSelect) {
              const result = db.prepare(sql).all(...params);
              results.push({ rows: result });
            } else {
              const result = db.prepare(sql).run(...params);
              results.push({ 
                changes: result.changes,
                lastInsertRowid: result.lastInsertRowid 
              });
            }
          }
          
          // Commit transaction
          db.prepare('COMMIT').run();
        } catch (error) {
          // Rollback transaction on error
          db.prepare('ROLLBACK').run();
          success = false;
          throw error;
        }
        
        log('INFO', 'Transaction completed successfully', { 
          database, 
          statements: statements.length 
        });
        
        return { 
          success,
          results
        };
      } catch (error) {
        log('ERROR', 'Transaction failed', { 
          database, 
          error: error.message 
        });
        return { 
          success: false,
          error: error.message 
        };
      }
    }
  },
  {
    name: 'sqlite_list_tables',
    description: 'List all tables in a SQLite database',
    inputSchema: {
      type: 'object',
      properties: {
        database: { 
          type: 'string', 
          description: 'Path to SQLite database relative to the data directory, or absolute path' 
        }
      },
      required: ['database']
    },
    handler: async ({ database }) => {
      try {
        const db = getDatabase(database);
        const result = db.prepare(`
          SELECT name FROM sqlite_master 
          WHERE type='table' 
          ORDER BY name;
        `).all();
        
        log('INFO', 'Listed tables successfully', { 
          database, 
          count: result.length 
        });
        
        return { tables: result.map(row => row.name) };
      } catch (error) {
        log('ERROR', 'Failed to list tables', { 
          database, 
          error: error.message 
        });
        return { error: error.message };
      }
    }
  },
  {
    name: 'sqlite_table_info',
    description: 'Get information about a table structure',
    inputSchema: {
      type: 'object',
      properties: {
        database: { 
          type: 'string', 
          description: 'Path to SQLite database relative to the data directory, or absolute path' 
        },
        table: {
          type: 'string',
          description: 'Table name to get information about'
        }
      },
      required: ['database', 'table']
    },
    handler: async ({ database, table }) => {
      try {
        const db = getDatabase(database);
        
        // Get table columns
        const columns = db.prepare(`PRAGMA table_info(${table});`).all();
        
        // Get indexes
        const indexes = db.prepare(`PRAGMA index_list(${table});`).all();
        
        // Get foreign keys
        const foreignKeys = db.prepare(`PRAGMA foreign_key_list(${table});`).all();
        
        log('INFO', 'Retrieved table information', { 
          database, 
          table,
          columns: columns.length
        });
        
        return { 
          table,
          columns,
          indexes,
          foreignKeys 
        };
      } catch (error) {
        log('ERROR', 'Failed to get table information', { 
          database, 
          table,
          error: error.message 
        });
        return { error: error.message };
      }
    }
  },
  {
    name: 'sqlite_create_table',
    description: 'Create a new table in a SQLite database',
    inputSchema: {
      type: 'object',
      properties: {
        database: { 
          type: 'string', 
          description: 'Path to SQLite database relative to the data directory, or absolute path' 
        },
        table: {
          type: 'string',
          description: 'Name for the new table'
        },
        columns: {
          type: 'array',
          description: 'Column definitions',
          items: {
            type: 'object',
            properties: {
              name: { type: 'string', description: 'Column name' },
              type: { type: 'string', description: 'Column type (TEXT, INTEGER, REAL, BLOB, etc.)' },
              constraints: { type: 'string', description: 'Column constraints (PRIMARY KEY, NOT NULL, etc.)', default: '' }
            },
            required: ['name', 'type']
          }
        },
        ifNotExists: {
          type: 'boolean',
          description: 'Add IF NOT EXISTS clause',
          default: true
        }
      },
      required: ['database', 'table', 'columns']
    },
    handler: async ({ database, table, columns, ifNotExists = true }) => {
      try {
        const db = getDatabase(database);
        
        // Build CREATE TABLE statement
        const columnDefs = columns.map(col => 
          `${col.name} ${col.type}${col.constraints ? ' ' + col.constraints : ''}`
        ).join(', ');
        
        const sql = `CREATE TABLE ${ifNotExists ? 'IF NOT EXISTS ' : ''}${table} (${columnDefs});`;
        
        // Execute the statement
        db.prepare(sql).run();
        
        log('INFO', 'Table created successfully', { 
          database, 
          table 
        });
        
        return { success: true, table };
      } catch (error) {
        log('ERROR', 'Failed to create table', { 
          database, 
          table,
          error: error.message 
        });
        return { error: error.message };
      }
    }
  },
  {
    name: 'sqlite_vacuum',
    description: 'Rebuild the database file to defragment and reduce size',
    inputSchema: {
      type: 'object',
      properties: {
        database: { 
          type: 'string', 
          description: 'Path to SQLite database relative to the data directory, or absolute path' 
        }
      },
      required: ['database']
    },
    handler: async ({ database }) => {
      try {
        const db = getDatabase(database);
        
        // Get database size before vacuum
        const stats = fs.statSync(path.isAbsolute(database) 
          ? database 
          : path.join(DATA_DIR, database));
        const sizeBefore = stats.size;
        
        // Execute VACUUM
        db.prepare('VACUUM;').run();
        
        // Get database size after vacuum
        const statsAfter = fs.statSync(path.isAbsolute(database) 
          ? database 
          : path.join(DATA_DIR, database));
        const sizeAfter = statsAfter.size;
        
        log('INFO', 'Database vacuumed successfully', { 
          database, 
          sizeBefore,
          sizeAfter,
          reduction: sizeBefore - sizeAfter
        });
        
        return { 
          success: true, 
          sizeBefore,
          sizeAfter,
          reduction: sizeBefore - sizeAfter
        };
      } catch (error) {
        log('ERROR', 'Failed to vacuum database', { 
          database,
          error: error.message 
        });
        return { error: error.message };
      }
    }
  },
  {
    name: 'sqlite_list_databases',
    description: 'List all SQLite database files in the data directory',
    inputSchema: {
      type: 'object',
      properties: {
        pattern: {
          type: 'string',
          description: 'Optional pattern to filter database files',
          default: '*.db'
        }
      }
    },
    handler: async ({ pattern = '*.db' }) => {
      try {
        // Read all files in the data directory
        const files = fs.readdirSync(DATA_DIR)
          .filter(file => {
            // Simple pattern matching for *.db
            if (pattern === '*.db') {
              return file.endsWith('.db');
            }
            // Simple pattern matching for *.sqlite
            if (pattern === '*.sqlite') {
              return file.endsWith('.sqlite');
            }
            // Simple pattern matching with * wildcard
            if (pattern.includes('*')) {
              const regex = new RegExp('^' + pattern.replace('*', '.*') + '$');
              return regex.test(file);
            }
            // Exact match
            return file === pattern;
          })
          .map(file => ({
            name: file,
            path: path.join(DATA_DIR, file),
            size: fs.statSync(path.join(DATA_DIR, file)).size,
            modified: fs.statSync(path.join(DATA_DIR, file)).mtime.toISOString()
          }));
        
        log('INFO', 'Listed database files', { count: files.length });
        
        return { 
          databases: files,
          directory: DATA_DIR
        };
      } catch (error) {
        log('ERROR', 'Failed to list database files', { 
          error: error.message 
        });
        return { error: error.message };
      }
    }
  }
]);

// Connect to transport
log('INFO', 'SQLite server initialized, connecting to transport');
server.connect(new StdioServerTransport());

// Handle process termination
process.on('exit', () => {
  log('INFO', 'Server shutting down');
  closeAllConnections();
  try {
    fs.unlinkSync(PID_PATH);
  } catch (e) {}
});

process.on('SIGINT', () => {
  log('INFO', 'Received SIGINT signal');
  process.exit(0);
});

process.on('SIGTERM', () => {
  log('INFO', 'Received SIGTERM signal');
  process.exit(0);
});

// Optimization for M3 Max hardware
if (global.gc) {
  setInterval(() => {
    const memBefore = process.memoryUsage().heapUsed;
    global.gc();
    const memAfter = process.memoryUsage().heapUsed;
    
    log('DEBUG', 'Explicit garbage collection performed', {
      before: Math.round(memBefore / 1024 / 1024) + ' MB',
      after: Math.round(memAfter / 1024 / 1024) + ' MB',
      freed: Math.round((memBefore - memAfter) / 1024 / 1024) + ' MB'
    });
  }, 300000); // Every 5 minutes
}

log('INFO', 'SQLite MCP server ready');
