/**
 * schema-registry-index.js - Entry point for schema registry server
 * © 2025 XPV - MIT
 * 
 * Initializes and manages the schema registry service with proper
 * startup sequence and error handling.
 */

const SchemaRegistry = require('./schema-registry.cjs');
const fs = require('fs');
const path = require('path');
const os = require('os');

// Configuration
const ANCHOR_HOME = process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core';
const SCHEMA_DIR_CLAUDE = path.join(ANCHOR_HOME, 'schemas', 'claude');
const SCHEMA_DIR_NOTION = path.join(ANCHOR_HOME, 'schemas', 'notion');
const COHERENCE_DIR = path.join(ANCHOR_HOME, 'coherence_lock');
const LOG_DIR = process.env.LOG_DIR || path.join(os.homedir(), 'Library/Logs/Claude');
const LOG_FILE = path.join(LOG_DIR, 'schema-registry.log');

// Ensure directories exist
ensureDirectories([
  SCHEMA_DIR_CLAUDE,
  SCHEMA_DIR_NOTION,
  COHERENCE_DIR,
  LOG_DIR
]);

// Initialize logger
function log(level, message, data = null) {
  const timestamp = new Date().toISOString();
  const logEntry = {
    ts: timestamp,
    level,
    component: 'schema-registry',
    pid: process.pid,
    message,
    ...(data ? { data } : {})
  };
  
  const logString = JSON.stringify(logEntry);
  console.log(logString);
  
  try {
    fs.appendFileSync(LOG_FILE, logString + '\n');
  } catch (err) {
    console.error(`Failed to write to log file: ${err.message}`);
  }
}

// Ensure directories exist
function ensureDirectories(dirs) {
  for (const dir of dirs) {
    try {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
        log('INFO', `Created directory: ${dir}`);
      }
    } catch (err) {
      log('ERROR', `Failed to create directory: ${dir}`, { error: err.message });
      process.exit(1);
    }
  }
}

// Create PID file
function createPidFile() {
  const pidFile = path.join(ANCHOR_HOME, 'mcp-servers', 'schema-registry.pid');
  try {
    fs.writeFileSync(pidFile, String(process.pid));
    log('INFO', `Created PID file: ${pidFile}`);
  } catch (err) {
    log('ERROR', `Failed to create PID file: ${pidFile}`, { error: err.message });
  }
}

// Create coherence marker
function createCoherenceMarker() {
  try {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '');
    const markerPath = path.join(COHERENCE_DIR, `schema-registry_${timestamp}.marker`);
    
    const markerData = {
      pid: process.pid,
      timestamp,
      component: 'schema-registry',
      hostname: os.hostname(),
      platform: process.platform,
      nodeVersion: process.version,
      memoryUsage: process.memoryUsage()
    };
    
    fs.writeFileSync(markerPath, JSON.stringify(markerData, null, 2));
    log('INFO', `Created coherence marker: ${markerPath}`);
    
    return markerPath;
  } catch (err) {
    log('ERROR', `Failed to create coherence marker`, { error: err.message });
    return null;
  }
}

// Initialize schema registry
async function initialize() {
  log('INFO', 'Starting schema registry...');
  
  // Create PID file
  createPidFile();
  
  // Create coherence marker
  const markerPath = createCoherenceMarker();
  
  // Check available schemas
  try {
    const claudeSchemas = fs.readdirSync(SCHEMA_DIR_CLAUDE)
      .filter(file => file.endsWith('.json'))
      .map(file => path.join(SCHEMA_DIR_CLAUDE, file));
    
    const notionSchemas = fs.readdirSync(SCHEMA_DIR_NOTION)
      .filter(file => file.endsWith('.json'))
      .map(file => path.join(SCHEMA_DIR_NOTION, file));
    
    log('INFO', 'Found schemas', { 
      claudeCount: claudeSchemas.length, 
      notionCount: notionSchemas.length,
      claudeSchemas: claudeSchemas.map(s => path.basename(s)),
      notionSchemas: notionSchemas.map(s => path.basename(s))
    });
  } catch (err) {
    log('ERROR', 'Failed to check schemas', { error: err.message });
  }
  
  // Create registry
  const registry = new SchemaRegistry({
    schemaDirClaude: SCHEMA_DIR_CLAUDE,
    schemaDirNotion: SCHEMA_DIR_NOTION,
    validateOnLoad: true
  });
  
  // Add event listeners
  registry.on('initialized', () => {
    log('INFO', 'Schema registry initialized');
    // Update coherence marker with successful initialization
    if (markerPath) {
      try {
        const markerData = JSON.parse(fs.readFileSync(markerPath, 'utf8'));
        markerData.status = 'INITIALIZED';
        markerData.schemaMetrics = registry.getMetrics();
        fs.writeFileSync(markerPath, JSON.stringify(markerData, null, 2));
      } catch (err) {
        log('ERROR', 'Failed to update coherence marker', { error: err.message });
      }
    }
  });
  
  registry.on('schema-loaded', (data) => {
    log('INFO', `Schema loaded: ${data.type}/${data.id}@${data.version}`);
  });
  
  registry.on('schema-registered', (data) => {
    log('INFO', `Schema registered: ${data.type}/${data.id}@${data.version}`);
  });
  
  registry.on('schema-validation', (data) => {
    log('INFO', `Schema validation: ${data.type}/${data.id}@${data.version} (valid: ${data.valid})`, {
      errorCount: data.errorCount,
      validationTimeMs: data.validationTimeMs
    });
  });
  
  registry.on('error', (err) => {
    log('ERROR', 'Schema registry error', { error: err.message });
  });
  
  // Initialize registry
  try {
    await registry.initialize();
    
    // Log schema metrics
    const metrics = registry.getMetrics();
    log('INFO', 'Schema registry metrics', metrics);
    
    // Keep the service running
    log('INFO', 'Schema registry service running');
  } catch (err) {
    log('ERROR', 'Failed to initialize schema registry', { error: err.message });
    process.exit(1);
  }
}

// Handle process signals
process.on('SIGINT', () => {
  log('INFO', 'Received SIGINT, shutting down...');
  process.exit(0);
});

process.on('SIGTERM', () => {
  log('INFO', 'Received SIGTERM, shutting down...');
  process.exit(0);
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  log('ERROR', 'Uncaught exception', { error: err.message, stack: err.stack });
  process.exit(1);
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  log('ERROR', 'Unhandled promise rejection', { reason: String(reason) });
  process.exit(1);
});

// Start initialization
initialize().catch(err => {
  log('ERROR', 'Initialization failed', { error: err.message });
  process.exit(1);
});
