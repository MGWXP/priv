#!/usr/bin/env node
/*  socket-server-implementation.js  –  Unix socket implementation for MCP servers */
/*  © 2025 XPV - MIT                                                             */

const fs = require('fs');
const net = require('net');
const path = require('path');

// Circuit Breaker Implementation - Inlined since the external module is not found
class CircuitBreaker {
  constructor(options = {}) {
    this.name = options.name || 'default';
    this.failureThreshold = options.failureThreshold || 5;
    this.resetTimeout = options.resetTimeout || 60000; // 1 minute
    this.failures = 0;
    this.lastFailureTime = 0;
    this.state = 'CLOSED'; // CLOSED, OPEN, HALF_OPEN
    console.log(`Circuit breaker '${this.name}' initialized`);
  }
  
  getHealth() {
    return { state: this.state };
  }
  
  canRequest() {
    if (this.state === 'CLOSED') {
      return true;
    } else if (this.state === 'OPEN') {
      const now = Date.now();
      if (now - this.lastFailureTime > this.resetTimeout) {
        this.state = 'HALF_OPEN';
        return true;
      }
      return false;
    } else if (this.state === 'HALF_OPEN') {
      return true;
    }
    return false;
  }
  
  success() {
    if (this.state === 'HALF_OPEN') {
      this.state = 'CLOSED';
      this.failures = 0;
    }
  }
  
  failure() {
    this.failures++;
    this.lastFailureTime = Date.now();
    
    if (this.state === 'CLOSED' && this.failures >= this.failureThreshold) {
      this.state = 'OPEN';
    } else if (this.state === 'HALF_OPEN') {
      this.state = 'OPEN';
    }
  }
  
  execute(fn) {
    if (!this.canRequest()) {
      return Promise.reject(new Error(`Circuit ${this.name} is ${this.state}`));
    }
    
    try {
      const result = fn();
      this.success();
      return Promise.resolve(result);
    } catch (error) {
      this.failure();
      return Promise.reject(error);
    }
  }
}

const CircuitState = {
  CLOSED: 'CLOSED',
  OPEN: 'OPEN', 
  HALF_OPEN: 'HALF_OPEN'
};

// Configuration
const SOCKET_DIR = process.env.SOCKET_DIR || '/Users/XPV/Desktop/anchor-core/sockets';
const SERVER_NAME = process.env.MCP_SERVER_NAME || 'unknown';
const SOCKET_PATH = path.join(SOCKET_DIR, `${SERVER_NAME}.sock`);
const LOG_DIR = process.env.LOG_DIR || path.join(process.env.HOME, 'Library/Logs/Claude');
const LOG_FILE = path.join(LOG_DIR, `mcp-server-${SERVER_NAME}.log`);

// Ensure directories exist
try {
  fs.mkdirSync(SOCKET_DIR, { recursive: true });
  fs.mkdirSync(LOG_DIR, { recursive: true });
} catch (err) {
  console.error(`Failed to create directories: ${err.message}`);
}

// Initialize circuit breaker
const circuitBreaker = new CircuitBreaker({
  name: `socket-${SERVER_NAME}`,
  failureThreshold: 5,
  resetTimeout: 60000,
  degradeThreshold: 3,
  degradePercentage: 0.3
});

// Logger
function log(level, message, extra = {}) {
  const logEntry = JSON.stringify({
    ts: new Date().toISOString(),
    lvl: level,
    svr: SERVER_NAME,
    msg: message,
    extra,
    pid: process.pid,
    circuitState: circuitBreaker.getHealth().state
  });
  
  console.error(logEntry);
  
  try {
    fs.appendFileSync(LOG_FILE, logEntry + '\n');
  } catch (err) {
    console.error(`Failed to write to log file: ${err.message}`);
  }
}

// Remove socket file if it exists
try {
  if (fs.existsSync(SOCKET_PATH)) {
    fs.unlinkSync(SOCKET_PATH);
    log('INFO', `Removed existing socket file: ${SOCKET_PATH}`);
  }
} catch (err) {
  log('ERROR', `Failed to remove existing socket file: ${err.message}`);
  process.exit(1);
}

// Create coherence marker
try {
  const coherenceDir = path.join(process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core', 'coherence_lock');
  fs.mkdirSync(coherenceDir, { recursive: true });
  
  // Use simple format with just the PID to avoid parsing issues
  const markerPath = path.join(coherenceDir, `${SERVER_NAME}_${new Date().toISOString().replace(/[:.]/g, '')}.marker`);
  fs.writeFileSync(markerPath, String(process.pid));
  
  log('INFO', `Created coherence marker: ${markerPath}`);
} catch (err) {
  log('ERROR', `Failed to create coherence marker: ${err.message}`);
}

// Message buffer for handling partial messages
class MessageBuffer {
  constructor() {
    this.buffer = '';
  }
  
  append(data) {
    this.buffer += data.toString();
  }
  
  getMessages() {
    if (!this.buffer.includes('\n')) {
      return [];
    }
    
    const messages = this.buffer.split('\n');
    this.buffer = messages.pop(); // Keep incomplete message in buffer
    
    return messages.filter(message => message.trim());
  }
}

// Create server
const server = net.createServer((socket) => {
  const clientId = Date.now().toString(36) + Math.random().toString(36).substr(2);
  log('INFO', 'Client connected', { clientId });
  
  // Initialize message buffer for this client
  const messageBuffer = new MessageBuffer();
  
  // Setup heartbeat
  const heartbeatInterval = setInterval(() => {
    try {
      if (socket.writable) {
        socket.write(JSON.stringify({
          type: 'heartbeat',
          timestamp: Date.now(),
          server: SERVER_NAME
        }) + '\n');
      }
    } catch (err) {
      log('ERROR', `Failed to send heartbeat to client ${clientId}`, { error: err.message });
    }
  }, 30000);
  
  socket.on('data', (data) => {
    log('DEBUG', `Received data: ${data.length} bytes`, { clientId });
    
    // Append data to buffer
    messageBuffer.append(data);
    
    // Process complete messages
    const messages = messageBuffer.getMessages();
    
    for (const messageText of messages) {
      try {
        // Check circuit breaker
        if (!circuitBreaker.canRequest()) {
          const errorResponse = {
            type: 'error_response',
            status: 'error',
            error: `Circuit breaker is ${circuitBreaker.getHealth().state}`
          };
          socket.write(JSON.stringify(errorResponse) + '\n');
          continue;
        }
        
        // Process message with circuit breaker protection
        circuitBreaker.execute(() => {
          try {
            // Parse the received data as JSON
            const message = JSON.parse(messageText);
            log('DEBUG', 'Parsed message', { type: message.type, clientId });
            
            // Process the message based on type
            let response;
            if (message.type === 'handshake') {
              response = { 
                type: 'handshake_response', 
                status: 'success',
                server: SERVER_NAME,
                version: '1.0.0'
              };
            } else if (message.type === 'invoke_tool') {
              response = {
                type: 'tool_response',
                id: message.id || 'unknown',
                status: 'success',
                result: `Mock response from ${SERVER_NAME} tool: ${message.tool || 'unknown'}`
              };
            } else {
              response = {
                type: 'error_response',
                status: 'error',
                error: `Unknown message type: ${message.type}`
              };
            }
            
            // Send response
            socket.write(JSON.stringify(response) + '\n');
            log('DEBUG', 'Sent response', { type: response.type, clientId });
            
            // Record success
            circuitBreaker.success();
          } catch (err) {
            log('ERROR', `Failed to process message: ${err.message}`, { clientId });
            
            // Send error response
            const errorResponse = {
              type: 'error_response',
              status: 'error',
              error: `Failed to process message: ${err.message}`
            };
            socket.write(JSON.stringify(errorResponse) + '\n');
            
            // Record failure
            circuitBreaker.failure();
          }
        })
        .catch(err => {
          log('ERROR', `Circuit breaker prevented message processing: ${err.message}`, { clientId });
          
          // Send circuit breaker error response
          const errorResponse = {
            type: 'error_response',
            status: 'error',
            error: `Circuit breaker is ${circuitBreaker.getHealth().state}`
          };
          socket.write(JSON.stringify(errorResponse) + '\n');
        });
      } catch (err) {
        log('ERROR', `Failed to execute message handler: ${err.message}`, { clientId });
      }
    }
  });
  
  socket.on('end', () => {
    clearInterval(heartbeatInterval);
    log('INFO', 'Client disconnected', { clientId });
  });
  
  socket.on('error', (err) => {
    log('ERROR', `Socket error: ${err.message}`, { clientId });
  });
});

// Start listening
server.listen(SOCKET_PATH, () => {
  log('INFO', `Server listening on ${SOCKET_PATH}`);
  
  // Set permissions on socket file (666 = rw-rw-rw-)
  try {
    fs.chmodSync(SOCKET_PATH, 0o666);
    
    // Double-check permissions were set correctly
    const stats = fs.statSync(SOCKET_PATH);
    const perms = stats.mode & 0o777;
    
    if (perms !== 0o666) {
      log('WARN', `Socket permissions not correctly set: ${perms.toString(8)} instead of 666`);
      log('INFO', 'Attempting stronger permission setting...');
      
      // Try more aggressive permission setting using child_process.execSync to run chmod directly
      const { execSync } = require('child_process');
      try {
        execSync(`chmod 666 ${SOCKET_PATH}`);
        log('INFO', 'Manually set socket permissions with chmod command');
      } catch (chmodErr) {
        log('ERROR', `Failed to set permissions with direct chmod: ${chmodErr.message}`);
      }
    } else {
      log('INFO', `Successfully set permissions on socket file: 0666`);
    }
  } catch (err) {
    log('ERROR', `Failed to set permissions on socket file: ${err.message}`);
  }
});

// Handle errors
server.on('error', (err) => {
  log('ERROR', `Server error: ${err.message}`);
  
  if (err.code === 'EADDRINUSE') {
    log('ERROR', `Socket file is already in use: ${SOCKET_PATH}`);
  }
  
  process.exit(1);
});

// Handle process exit
process.on('exit', () => {
  try {
    if (fs.existsSync(SOCKET_PATH)) {
      fs.unlinkSync(SOCKET_PATH);
      log('INFO', `Removed socket file on exit: ${SOCKET_PATH}`);
    }
  } catch (err) {
    log('ERROR', `Failed to remove socket file on exit: ${err.message}`);
  }
});

process.on('SIGINT', () => {
  log('INFO', 'Received SIGINT, shutting down');
  server.close(() => {
    process.exit(0);
  });
});

process.on('SIGTERM', () => {
  log('INFO', 'Received SIGTERM, shutting down');
  server.close(() => {
    process.exit(0);
  });
});

log('INFO', `Started ${SERVER_NAME} MCP socket server (PID: ${process.pid})`);
