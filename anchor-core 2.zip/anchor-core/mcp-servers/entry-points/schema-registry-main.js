/**
 * schema-registry-main.js - Entry point for schema registry service
 */
console.log('Starting schema registry service...');
require('../schema-registry-index');
console.log('Schema registry service initialized.');
