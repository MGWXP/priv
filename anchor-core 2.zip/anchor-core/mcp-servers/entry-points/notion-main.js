/**
 * notion-main.js - Entry point for Notion connection service
 * © 2025 XPV - MIT
 * 
 * Initializes and manages the Notion connection with proper
 * authentication, rate limiting, and error handling.
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const NotionConnection = require('./notion-connection-manager.cjs');

// Configuration
const ANCHOR_HOME = process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core';
const SERVER_NAME = process.env.MCP_SERVER_NAME || 'notion';
const COHERENCE_DIR = path.join(ANCHOR_HOME, 'coherence_lock');
const LOG_DIR = process.env.LOG_DIR || path.join(os.homedir(), 'Library/Logs/Claude');
const LOG_FILE = path.join(LOG_DIR, `${SERVER_NAME}.log`);
const SOCKET_DIR = process.env.SOCKET_DIR || path.join(ANCHOR_HOME, 'sockets');
const SOCKET_PATH = path.join(SOCKET_DIR, `${SERVER_NAME}.sock`);
const CONFIG_DIR = path.join(ANCHOR_HOME, 'config');
const CONFIG_FILE = path.join(CONFIG_DIR, 'notion-config.json');
const DATA_DIR = path.join(ANCHOR_HOME, 'data');

// Ensure directories exist
ensureDirectories([
  COHERENCE_DIR,
  LOG_DIR,
  SOCKET_DIR,
  CONFIG_DIR,
  DATA_DIR,
  path.join(DATA_DIR, 'notion-cache')
]);

// Initialize logger
function log(level, message, data = null) {
  const timestamp = new Date().toISOString();
  const logEntry = {
    ts: timestamp,
    level,
    component: SERVER_NAME,
    pid: process.pid,
    message,
    ...(data ? { data } : {})
  };
  
  const logString = JSON.stringify(logEntry);
  console.log(logString);
  
  try {
    fs.appendFileSync(LOG_FILE, logString + '\n');
  } catch (err) {
    console.error(`Failed to write to log file: ${err.message}`);
  }
}

// Ensure directories exist
function ensureDirectories(dirs) {
  for (const dir of dirs) {
    try {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
        log('INFO', `Created directory: ${dir}`);
      }
    } catch (err) {
      log('ERROR', `Failed to create directory: ${dir}`, { error: err.message });
      process.exit(1);
    }
  }
}

// Create PID file
function createPidFile() {
  const pidFile = path.join(ANCHOR_HOME, 'mcp-servers', `${SERVER_NAME}.pid`);
  try {
    fs.writeFileSync(pidFile, String(process.pid));
    log('INFO', `Created PID file: ${pidFile}`);
  } catch (err) {
    log('ERROR', `Failed to create PID file: ${pidFile}`, { error: err.message });
  }
  
  // Setup cleanup on exit
  process.on('exit', () => {
    try {
      if (fs.existsSync(pidFile)) {
        fs.unlinkSync(pidFile);
        log('INFO', `Removed PID file: ${pidFile}`);
      }
      
      // Clean up socket file
      if (fs.existsSync(SOCKET_PATH)) {
        fs.unlinkSync(SOCKET_PATH);
        log('INFO', `Removed socket file: ${SOCKET_PATH}`);
      }
    } catch (err) {
      console.error(`Failed to clean up resources: ${err.message}`);
    }
  });
}

// Create coherence marker
function createCoherenceMarker() {
  try {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '');
    const markerPath = path.join(COHERENCE_DIR, `${SERVER_NAME}_${timestamp}.marker`);
    
    const markerData = {
      pid: process.pid,
      timestamp,
      component: SERVER_NAME,
      hostname: os.hostname(),
      platform: process.platform,
      nodeVersion: process.version,
      socketPath: SOCKET_PATH,
      memoryUsage: process.memoryUsage()
    };
    
    fs.writeFileSync(markerPath, JSON.stringify(markerData, null, 2));
    log('INFO', `Created coherence marker: ${markerPath}`);
    
    return markerPath;
  } catch (err) {
    log('ERROR', `Failed to create coherence marker`, { error: err.message });
    return null;
  }
}

// Clean up existing socket file if necessary
function cleanupExistingSocket() {
  try {
    if (fs.existsSync(SOCKET_PATH)) {
      log('INFO', `Removing existing socket file: ${SOCKET_PATH}`);
      fs.unlinkSync(SOCKET_PATH);
    }
  } catch (err) {
    log('ERROR', `Failed to remove existing socket file: ${err.message}`);
    process.exit(1);
  }
}

// Load configuration
function loadConfig() {
  try {
    if (!fs.existsSync(CONFIG_FILE)) {
      // Create default config if not exists
      const defaultConfig = {
        apiToken: process.env.NOTION_API_TOKEN || "",
        apiVersion: "2022-06-28",
        baseUrl: "https://api.notion.com/v1",
        rateLimit: {
          maxRequests: 3,
          periodMs: 1000,
          maxRetries: 5
        },
        cacheDir: path.join(DATA_DIR, 'notion-cache'),
        timeout: 30000
      };
      
      fs.writeFileSync(CONFIG_FILE, JSON.stringify(defaultConfig, null, 2));
      log('INFO', `Created default config file: ${CONFIG_FILE}`);
    }
    
    const configData = fs.readFileSync(CONFIG_FILE, 'utf8');
    const config = JSON.parse(configData);
    
    // Validate config
    if (!config.apiToken) {
      log('WARN', 'Notion API token not configured');
    }
    
    log('INFO', 'Loaded configuration', {
      apiVersion: config.apiVersion,
      baseUrl: config.baseUrl,
      cacheDir: config.cacheDir,
      hasToken: Boolean(config.apiToken)
    });
    
    return config;
  } catch (err) {
    log('ERROR', `Failed to load configuration: ${err.message}`);
    process.exit(1);
  }
}

// Initialize and start Notion connection
async function initialize() {
  log('INFO', `Starting ${SERVER_NAME}...`);
  
  // Create PID file
  createPidFile();
  
  // Create coherence marker
  const markerPath = createCoherenceMarker();
  
  // Clean up existing socket file
  cleanupExistingSocket();
  
  // Load configuration
  const config = loadConfig();
  
  // Initialize Notion connection
  try {
    log('INFO', 'Initializing Notion connection...');
    
    const notionConnection = new NotionConnection({
      apiToken: config.apiToken,
      apiVersion: config.apiVersion,
      baseUrl: config.baseUrl,
      rateLimit: config.rateLimit,
      cacheDir: config.cacheDir,
      timeout: config.timeout,
      socketPath: SOCKET_PATH
    });
    
    // Setup event listeners
    notionConnection.on('connected', () => {
      log('INFO', 'Connected to Notion API');
      
      // Update coherence marker
      if (markerPath) {
        try {
          const markerData = JSON.parse(fs.readFileSync(markerPath, 'utf8'));
          markerData.status = 'CONNECTED';
          markerData.connectedAt = new Date().toISOString();
          fs.writeFileSync(markerPath, JSON.stringify(markerData, null, 2));
        } catch (err) {
          log('ERROR', 'Failed to update coherence marker', { error: err.message });
        }
      }
    });
    
    notionConnection.on('error', (err) => {
      log('ERROR', 'Notion API error', { error: err.message });
    });
    
    notionConnection.on('rate-limited', (data) => {
      log('WARN', 'Rate limited by Notion API', data);
    });
    
    notionConnection.on('request', (data) => {
      log('DEBUG', 'Notion API request', {
        method: data.method,
        endpoint: data.endpoint,
        timestamp: data.timestamp
      });
    });
    
    notionConnection.on('response', (data) => {
      log('DEBUG', 'Notion API response', {
        method: data.method,
        endpoint: data.endpoint,
        status: data.status,
        duration: data.duration
      });
    });
    
    // Initialize connection
    await notionConnection.initialize();
    
    // Start socket server
    await notionConnection.startSocketServer();
    
    log('INFO', `${SERVER_NAME} initialization complete, socket server running on ${SOCKET_PATH}`);
    
    // Set proper socket permissions
    fs.chmodSync(SOCKET_PATH, 0o666);
    log('INFO', 'Set socket permissions to 0666');
    
    // Setup periodic health checks
    const healthCheckInterval = setInterval(async () => {
      try {
        // Check socket file exists
        if (!fs.existsSync(SOCKET_PATH)) {
          log('ERROR', `Socket file missing: ${SOCKET_PATH}`);
          // Attempt recovery
          process.emit('SIGTERM');
          return;
        }
        
        // Check API connectivity
        const health = await notionConnection.checkHealth();
        
        log('DEBUG', 'Health check passed', health);
      } catch (err) {
        log('ERROR', 'Health check failed', { error: err.message });
      }
    }, 60000); // Run every minute
    
    // Clear interval on exit
    process.on('exit', () => {
      clearInterval(healthCheckInterval);
    });
  } catch (err) {
    log('ERROR', `Failed to initialize Notion connection: ${err.message}`);
    process.exit(1);
  }
}

// Handle process signals
process.on('SIGINT', () => {
  log('INFO', 'Received SIGINT, shutting down...');
  process.exit(0);
});

process.on('SIGTERM', () => {
  log('INFO', 'Received SIGTERM, shutting down...');
  process.exit(0);
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  log('ERROR', 'Uncaught exception', { error: err.message, stack: err.stack });
  process.exit(1);
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  log('ERROR', 'Unhandled promise rejection', { reason: String(reason) });
  process.exit(1);
});

// Start initialization
initialize().catch(err => {
  log('ERROR', 'Initialization failed', { error: err.message });
  process.exit(1);
});
