/**
 * socket-server-main.js - Entry point for CNIF socket server
 * © 2025 XPV - MIT
 * 
 * This file initializes the socket server with proper configuration
 * and enhances it with additional monitoring and resilience features.
 */

const fs = require('fs');
const path = require('path');
const os = require('os');

// Dynamically import the socket server implementation
const serverImplementation = require('./socket-server-implementation.cjs');

// Configuration
const ANCHOR_HOME = process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core';
const SERVER_NAME = process.env.MCP_SERVER_NAME || 'socket-server';
const COHERENCE_DIR = path.join(ANCHOR_HOME, 'coherence_lock');
const LOG_DIR = process.env.LOG_DIR || path.join(os.homedir(), 'Library/Logs/Claude');
const LOG_FILE = path.join(LOG_DIR, `${SERVER_NAME}.log`);
const SOCKET_DIR = process.env.SOCKET_DIR || path.join(ANCHOR_HOME, 'sockets');
const SOCKET_PATH = path.join(SOCKET_DIR, `${SERVER_NAME}.sock`);

// Ensure directories exist
ensureDirectories([
  COHERENCE_DIR,
  LOG_DIR,
  SOCKET_DIR
]);

// Initialize logger
function log(level, message, data = null) {
  const timestamp = new Date().toISOString();
  const logEntry = {
    ts: timestamp,
    level,
    component: SERVER_NAME,
    pid: process.pid,
    message,
    ...(data ? { data } : {})
  };
  
  const logString = JSON.stringify(logEntry);
  console.log(logString);
  
  try {
    fs.appendFileSync(LOG_FILE, logString + '\n');
  } catch (err) {
    console.error(`Failed to write to log file: ${err.message}`);
  }
}

// Ensure directories exist
function ensureDirectories(dirs) {
  for (const dir of dirs) {
    try {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
        log('INFO', `Created directory: ${dir}`);
      }
    } catch (err) {
      log('ERROR', `Failed to create directory: ${dir}`, { error: err.message });
      process.exit(1);
    }
  }
}

// Create PID file
function createPidFile() {
  const pidFile = path.join(ANCHOR_HOME, 'mcp-servers', `${SERVER_NAME}.pid`);
  try {
    fs.writeFileSync(pidFile, String(process.pid));
    log('INFO', `Created PID file: ${pidFile}`);
  } catch (err) {
    log('ERROR', `Failed to create PID file: ${pidFile}`, { error: err.message });
  }
  
  // Setup cleanup on exit
  process.on('exit', () => {
    try {
      if (fs.existsSync(pidFile)) {
        fs.unlinkSync(pidFile);
        log('INFO', `Removed PID file: ${pidFile}`);
      }
      
      // Clean up socket file
      if (fs.existsSync(SOCKET_PATH)) {
        fs.unlinkSync(SOCKET_PATH);
        log('INFO', `Removed socket file: ${SOCKET_PATH}`);
      }
    } catch (err) {
      console.error(`Failed to clean up resources: ${err.message}`);
    }
  });
}

// Create coherence marker
function createCoherenceMarker() {
  try {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '');
    const markerPath = path.join(COHERENCE_DIR, `${SERVER_NAME}_${timestamp}.marker`);
    
    const markerData = {
      pid: process.pid,
      timestamp,
      component: SERVER_NAME,
      hostname: os.hostname(),
      platform: process.platform,
      nodeVersion: process.version,
      socketPath: SOCKET_PATH,
      memoryUsage: process.memoryUsage()
    };
    
    fs.writeFileSync(markerPath, JSON.stringify(markerData, null, 2));
    log('INFO', `Created coherence marker: ${markerPath}`);
    
    return markerPath;
  } catch (err) {
    log('ERROR', `Failed to create coherence marker`, { error: err.message });
    return null;
  }
}

// Clean up existing socket file if necessary
function cleanupExistingSocket() {
  try {
    if (fs.existsSync(SOCKET_PATH)) {
      log('INFO', `Removing existing socket file: ${SOCKET_PATH}`);
      fs.unlinkSync(SOCKET_PATH);
    }
  } catch (err) {
    log('ERROR', `Failed to remove existing socket file: ${err.message}`);
    process.exit(1);
  }
}

// Initialize and start server
function initialize() {
  log('INFO', `Starting ${SERVER_NAME}...`);
  
  // Create PID file
  createPidFile();
  
  // Create coherence marker
  const markerPath = createCoherenceMarker();
  
  // Clean up existing socket file
  cleanupExistingSocket();
  
  // Configure system for optimal performance
  log('INFO', 'Configuring system for M3 Max optimization...');
  
  // Set M3 Max specific optimizations
  process.env.UV_THREADPOOL_SIZE = process.env.UV_THREADPOOL_SIZE || '12';
  
  // Initialize the server with enhanced monitoring
  log('INFO', `Initializing socket server on ${SOCKET_PATH}`);
  
  // The socket-server-implementation.cjs will handle the server creation
  // and socket binding automatically when imported
  
  // Log initialization completion
  log('INFO', `${SERVER_NAME} initialization complete`);
  
  // Setup periodic health checks
  const healthCheckInterval = setInterval(() => {
    try {
      // Check socket file exists
      if (!fs.existsSync(SOCKET_PATH)) {
        log('ERROR', `Socket file missing: ${SOCKET_PATH}`);
        // Attempt recovery
        process.emit('SIGTERM');
        return;
      }
      
      // Check socket file permissions
      const stats = fs.statSync(SOCKET_PATH);
      const perms = stats.mode & 0o777;
      if (perms !== 0o666) {
        log('WARN', `Socket has incorrect permissions: ${perms.toString(8)}, fixing...`);
        fs.chmodSync(SOCKET_PATH, 0o666);
      }
      
      // Check memory usage
      const memUsage = process.memoryUsage();
      const heapUsedMB = Math.round(memUsage.heapUsed / (1024 * 1024));
      const heapTotalMB = Math.round(memUsage.heapTotal / (1024 * 1024));
      const rssLimitMB = 4096; // 4GB limit
      
      if (memUsage.rss > rssLimitMB * 1024 * 1024) {
        log('WARN', `High memory usage detected: RSS ${Math.round(memUsage.rss / (1024 * 1024))}MB exceeds limit of ${rssLimitMB}MB`);
        // We won't restart here, but we could implement a restart strategy if needed
      }
      
      log('DEBUG', 'Health check passed', { 
        socketExists: true, 
        permissions: '0666',
        memoryMB: { heapUsed: heapUsedMB, heapTotal: heapTotalMB }
      });
      
    } catch (err) {
      log('ERROR', 'Health check failed', { error: err.message });
    }
  }, 60000); // Run every minute
  
  // Clear interval on exit
  process.on('exit', () => {
    clearInterval(healthCheckInterval);
  });
}

// Handle process signals
process.on('SIGINT', () => {
  log('INFO', 'Received SIGINT, shutting down...');
  process.exit(0);
});

process.on('SIGTERM', () => {
  log('INFO', 'Received SIGTERM, shutting down...');
  process.exit(0);
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  log('ERROR', 'Uncaught exception', { error: err.message, stack: err.stack });
  process.exit(1);
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  log('ERROR', 'Unhandled promise rejection', { reason: String(reason) });
  process.exit(1);
});

// Start initialization
initialize();
