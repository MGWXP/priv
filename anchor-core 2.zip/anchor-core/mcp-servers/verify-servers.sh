#!/bin/bash
# enhanced-verify-servers.sh - M3 Max optimized MCP server verification
# © 2025 XPV - MIT License

# Terminal colors for better visibility
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# Core paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
MCP_DIR="${ANCHOR_HOME}/mcp-servers"
LOG_DIR="${HOME}/Library/Logs/Claude"
SOCKET_DIR="${ANCHOR_HOME}/sockets"
CONFIG_DIR="${HOME}/Library/Application Support/Claude"

echo -e "${BLUE}${BOLD}===== MCP System Status (M3 Max) =====${NC}"
echo -e "Timestamp: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e "Hardware: Apple M3 Max ($(sysctl -n hw.memsize | awk '{print $1/1073741824}')GB)"
echo -e "Hostname: $(hostname)"
echo -e "System Load: $(uptime | sed 's/.*load averages: //')"

# System health check
echo -e "\n${BLUE}${BOLD}System Health${NC}"
CPU_IDLE=$(top -l 1 | grep "CPU usage" | awk '{print $7}' | sed 's/%//')
CPU_USAGE=$(echo "scale=1; 100 - $CPU_IDLE" | bc)
MEM_USED=$(vm_stat | grep "Pages active" | awk '{print $3}' | sed 's/\.//')
MEM_TOTAL=$(sysctl -n hw.memsize)
MEM_USED_GB=$(echo "scale=2; $MEM_USED * 4096 / 1024 / 1024 / 1024" | bc)
MEM_TOTAL_GB=$(echo "scale=2; $MEM_TOTAL / 1024 / 1024 / 1024" | bc)
MEM_PERCENT=$(echo "scale=1; $MEM_USED_GB * 100 / $MEM_TOTAL_GB" | bc)

# Display health with color indicators
if [ $(echo "$CPU_USAGE < 70" | bc) -eq 1 ]; then
    echo -e "CPU Usage: ${GREEN}${CPU_USAGE}%${NC}"
else
    echo -e "CPU Usage: ${RED}${CPU_USAGE}% (High)${NC}"
fi

if [ $(echo "$MEM_PERCENT < 75" | bc) -eq 1 ]; then
    echo -e "Memory Usage: ${GREEN}${MEM_USED_GB}GB / ${MEM_TOTAL_GB}GB (${MEM_PERCENT}%)${NC}"
else
    echo -e "Memory Usage: ${RED}${MEM_USED_GB}GB / ${MEM_TOTAL_GB}GB (${MEM_PERCENT}% - High)${NC}"
fi

# Check directories
echo -e "\n${BLUE}${BOLD}Directory Check${NC}"
check_directory() {
    local dir=$1
    local desc=$2
    if [ -d "$dir" ]; then
        local perms=$(stat -f "%Lp" "$dir")
        local owner=$(stat -f "%Su" "$dir")
        echo -e "${GREEN}✓${NC} ${desc}: $dir (permissions: $perms, owner: $owner)"
    else
        echo -e "${RED}✗${NC} ${desc} missing: $dir"
    fi
}

check_directory "$ANCHOR_HOME" "Anchor Home"
check_directory "$MCP_DIR" "MCP Servers"
check_directory "$SOCKET_DIR" "Socket Directory"
check_directory "$LOG_DIR" "Log Directory"
check_directory "$CONFIG_DIR" "Claude Config"

# Check socket files
echo -e "\n${BLUE}${BOLD}Socket Files${NC}"
for server in git-local notion anchor-manager; do
    SOCKET_FILE="${SOCKET_DIR}/${server}.sock"
    if [ -S "$SOCKET_FILE" ]; then
        PERMS=$(stat -f "%Lp" "$SOCKET_FILE")
        echo -e "${GREEN}✓${NC} ${server}.sock: Found (permissions: $PERMS)"
        
        # Check if socket is active by attempting connection
        if nc -U -z -w 1 "$SOCKET_FILE" 2>/dev/null; then
            echo -e "  ${GREEN}•${NC} Socket is active and accepting connections"
        else
            echo -e "  ${RED}•${NC} Socket exists but is not accepting connections"
        fi
    else
        echo -e "${RED}✗${NC} ${server}.sock: Not found or not a socket"
    fi
done

# Check running processes
echo -e "\n${BLUE}${BOLD}Process Check${NC}"
check_process() {
    local name=$1
    local pattern=$2
    local pid_file="${MCP_DIR}/${name}.pid"
    
    # Try to get PID from file
    if [ -f "$pid_file" ]; then
        local pid=$(cat "$pid_file")
        if ps -p "$pid" > /dev/null; then
            # Get process details
            local mem=$(ps -o rss= -p "$pid" | awk '{print $1/1024}')
            local cpu=$(ps -o %cpu= -p "$pid" | awk '{print $1}')
            local time=$(ps -o time= -p "$pid")
            
            echo -e "${GREEN}✓${NC} ${name}: Running (PID: $pid, MEM: ${mem:.1f}MB, CPU: ${cpu}%, Runtime: $time)"
            return 0
        else
            echo -e "${YELLOW}!${NC} ${name}: PID file exists ($pid) but process is not running"
        fi
    fi
    
    # Try to find by pattern
    local pids=$(pgrep -f "$pattern" || echo "")
    if [ -n "$pids" ]; then
        # Get process details
        local pid=$(echo "$pids" | head -1)
        local mem=$(ps -o rss= -p "$pid" | awk '{print $1/1024}')
        local cpu=$(ps -o %cpu= -p "$pid" | awk '{print $1}')
        local time=$(ps -o time= -p "$pid")
        
        echo -e "${GREEN}✓${NC} ${name}: Running (PID: $pid, MEM: ${mem:.1f}MB, CPU: ${cpu}%, Runtime: $time)"
        
        # Check if PID file is missing or incorrect
        if [ ! -f "$pid_file" ] || [ "$(cat "$pid_file")" != "$pid" ]; then
            echo -e "  ${YELLOW}•${NC} PID file missing or incorrect, updating..."
            echo "$pid" > "$pid_file"
        fi
        
        return 0
    else
        echo -e "${RED}✗${NC} ${name}: Not running"
        return 1
    fi
}

check_process "git-local" "git-local.*optimized.js"
check_process "notion" "notion.*\.js"
check_process "anchor-manager" "anchor-manager.*optimized.js"

# Check Claude configuration
echo -e "\n${BLUE}${BOLD}Configuration Check${NC}"
CLAUDE_CONFIG="${CONFIG_DIR}/claude_desktop_config.json"
if [ -f "$CLAUDE_CONFIG" ]; then
    echo -e "${GREEN}✓${NC} Claude configuration found: $CLAUDE_CONFIG"
    
    # Check if configuration contains MCP servers
    if grep -q "mcpServers" "$CLAUDE_CONFIG"; then
        echo -e "  ${GREEN}•${NC} MCP servers configured in Claude"
        
        # Check for each server
        for server in git-local notion anchor-manager; do
            if grep -q "\"$server\"" "$CLAUDE_CONFIG"; then
                echo -e "  ${GREEN}•${NC} $server configured"
            else
                echo -e "  ${RED}•${NC} $server not configured"
            fi
        done
    else
        echo -e "  ${RED}•${NC} No MCP servers configured in Claude"
    fi
else
    echo -e "${RED}✗${NC} Claude configuration not found"
fi

# Check logs
echo -e "\n${BLUE}${BOLD}Log Check${NC}"
check_log() {
    local name=$1
    local log_file="${LOG_DIR}/mcp-server-${name}.log"
    
    if [ -f "$log_file" ]; then
        local size=$(du -h "$log_file" | cut -f1)
        local last_modified=$(stat -f "%Sm" -t "%Y-%m-%d %H:%M:%S" "$log_file")
        local line_count=$(wc -l < "$log_file")
        
        echo -e "${GREEN}✓${NC} ${name} log: $size, $line_count lines, last modified: $last_modified"
        
        # Check for errors
        local error_count=$(grep -c '"lvl":"ERROR"' "$log_file")
        if [ "$error_count" -gt 0 ]; then
            echo -e "  ${RED}•${NC} Contains $error_count errors"
            echo -e "  ${CYAN}Latest errors:${NC}"
            grep '"lvl":"ERROR"' "$log_file" | tail -3 | while read -r line; do
                # Extract error message more cleanly
                local msg=$(echo "$line" | grep -o '"msg":"[^"]*"' | sed 's/"msg":"//;s/"//')
                echo -e "    ${RED}⨯${NC} $msg"
            done
        else
            echo -e "  ${GREEN}•${NC} No errors found"
        fi
        
        # Show recent activity
        echo -e "  ${CYAN}Recent activity:${NC}"
        tail -3 "$log_file" | while read -r line; do
            # Extract timestamp and message
            local ts=$(echo "$line" | grep -o '"ts":"[^"]*"' | sed 's/"ts":"//;s/"//')
            local msg=$(echo "$line" | grep -o '"msg":"[^"]*"' | sed 's/"msg":"//;s/"//')
            echo -e "    • [$ts] $msg"
        done
    else
        echo -e "${RED}✗${NC} ${name} log not found: $log_file"
    fi
}

check_log "git-local"
check_log "notion"
check_log "anchor-manager"

# Environment check
echo -e "\n${BLUE}${BOLD}Environment Check${NC}"
echo -e "Node.js: $(node -v 2>/dev/null || echo 'Not found')"
echo -e "NODE_OPTIONS: ${NODE_OPTIONS:-'Not set'}"
echo -e "UV_THREADPOOL_SIZE: ${UV_THREADPOOL_SIZE:-'Not set'}"
echo -e "ANCHOR_HOME: ${ANCHOR_HOME}"

# Summary and recommendations
echo -e "\n${BLUE}${BOLD}Status Summary${NC}"

# Count running servers
RUNNING=0
for server in git-local notion anchor-manager; do
    if pgrep -f "${server}.*\.js" > /dev/null; then
        RUNNING=$((RUNNING+1))
    fi
done

if [ "$RUNNING" -eq 3 ]; then
    echo -e "${GREEN}All MCP servers are running properly.${NC}"
else
    echo -e "${RED}One or more MCP servers are not running! ($RUNNING/3)${NC}"
    echo -e "Use this command to restart all servers:"
    echo -e "  ${YELLOW}${ANCHOR_HOME}/launch-with-process-manager.sh${NC}"
fi

# Check for common issues
if ! grep -q "^export NODE_OPTIONS=\"--max-old-space-size=" "${ANCHOR_HOME}/.env" 2>/dev/null; then
    echo -e "${YELLOW}⚠️ NODE_OPTIONS not properly set in .env file${NC}"
    echo -e "  Run: ${ANCHOR_HOME}/enhanced-quick-fix.sh"
fi

if [ ! -x "${ANCHOR_HOME}/launch-with-process-manager.sh" ]; then
    echo -e "${YELLOW}⚠️ Launch script not executable${NC}"
    echo -e "  Run: chmod +x ${ANCHOR_HOME}/launch-with-process-manager.sh"
fi

# Check for high memory usage in node processes
NODE_MEM_USAGE=$(ps -eo pmem,comm | grep node | awk '{sum+=$1} END {print sum}')
if [ $(echo "$NODE_MEM_USAGE > 75" | bc) -eq 1 ]; then
    echo -e "${RED}⚠️ High memory usage by Node.js processes (${NODE_MEM_USAGE}%)${NC}"
    echo -e "  Consider restarting servers or adjusting memory limits"
fi

echo -e "\n${BLUE}${BOLD}Next Steps${NC}"
echo -e "1. If any servers are not running, restart them with: ${ANCHOR_HOME}/launch-with-process-manager.sh"
echo -e "2. Restart Claude Desktop to ensure it connects to the MCP servers"
echo -e "3. If issues persist, check the logs for specific error messages"

echo -e "\n${GREEN}Verification complete at $(date '+%Y-%m-%d %H:%M:%S')${NC}"
