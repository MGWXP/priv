#!/usr/bin/env node
/*  anchor-manager-optimized.js  –  L7 MCP component  •  Version 6.0.0           */
/*  © 2025 XPV - MIT                                                             */
process.env.NODE_OPTIONS      ||= '--max-old-space-size=8192';
process.env.UV_THREADPOOL_SIZE ||= '12';
process.env.MCP_SERVER_NAME     = 'anchor-manager';

const PID_PATH = '/Users/XPV/Desktop/anchor-core/mcp-servers/anchor-manager.pid';
const SOCKET_DIR = process.env.SOCKET_DIR || '/Users/XPV/Desktop/anchor-core/sockets';

// Create a local mock of the MCP SDK to avoid dependency issues
const Server = class {
  constructor(info, options) {
    this.info = info;
    this.options = options;
    this.tools = [];
  }
  
  registerTools(tools) {
    this.tools.push(...tools);
    console.error(`Registered ${tools.length} tools`);
  }
  
  connect(transport) {
    console.error(`Server ${this.info.name} v${this.info.version} connected to transport`);
  }
};

class StdioServerTransport {
  constructor() {
    console.error('StdioServerTransport initialized');
  }
}

// ---------------------------------------------------------------------------
// Mock imports until actual packages are installed
// const { Server }             = require('@modelcontextprotocol/sdk/server/index.js');
// const { StdioServerTransport }= require('@modelcontextprotocol/sdk/server/stdio.js');
const { execFile, exec }     = require('child_process');
const { promisify }          = require('util');
const fs                      = require('fs').promises;
const path                    = require('path');
const os                      = require('os');
const execFileAsync           = promisify(execFile);
const execAsync               = promisify(exec);

// Critical paths
const ANCHOR_HOME = process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core';
const MCP_DIR = process.env.MCP_DIR || '/Users/XPV/Desktop/anchor-core/mcp-servers';
const CONFIG_DIR = path.join(os.homedir(), 'Library/Application Support/Claude');
const CONFIG_FILE = path.join(CONFIG_DIR, 'claude_desktop_config.json');
const LOG_DIR = path.join(os.homedir(), 'Library/Logs/Claude');
const COHERENCE_DIR = path.join(ANCHOR_HOME, 'coherence_lock');

// ---------- lightweight logger ------------------------------------------------
const LV = {DEBUG:0,INFO:1,WARN:2,ERROR:3};
const CUR = LV[(process.env.LOG_LEVEL||'INFO').toUpperCase()]||LV.INFO;
function log(l,msg,extra={}){ if(LV[l]>=CUR)console.error(JSON.stringify({ts:new Date().toISOString(),lvl:l,svr:'anchor-manager',msg,extra,pid:process.pid}));}

// Create socket directory if it doesn't exist
(async () => {
  try {
    await fs.mkdir(SOCKET_DIR, { recursive: true });
    log('INFO', `Ensured socket directory exists: ${SOCKET_DIR}`);
  } catch (error) {
    log('ERROR', `Failed to create socket directory: ${error.message}`);
  }
})();

// ---------- PID heartbeat (prevents ENOENT) -----------------------------------
(async()=>{try{await fs.writeFile(PID_PATH,String(process.pid));setInterval(()=>fs.utimes(PID_PATH,new Date(),new Date()).catch(()=>{}),2000);}catch(e){log('WARN','PID file issue',{e})}})();

// ---------- Create required directories ---------------------------------------
(async () => {
  try {
    await fs.mkdir(LOG_DIR, { recursive: true });
    await fs.mkdir(COHERENCE_DIR, { recursive: true });
    log('INFO', `Ensured directories exist`, { log_dir: LOG_DIR, coherence_dir: COHERENCE_DIR });
  } catch (error) {
    log('WARN', `Directory creation issue: ${error.message}`);
  }
})();

// ---------- server ------------------------------------------------------------
const server = new Server(
  { name: 'anchor-manager', version: '6.0.0' },
  { capabilities: { tools: {} } }
);

// ---------- helper functions --------------------------------------------------
async function readClaudeConfig() {
  try {
    const configData = await fs.readFile(CONFIG_FILE, 'utf8');
    return JSON.parse(configData);
  } catch (error) {
    log('ERROR', `Failed to read config: ${error.message}`);
    
    // Return a default config if file doesn't exist
    return {
      mcpServers: {
        'filesystem': { socketPath: `${SOCKET_DIR}/filesystem.sock` },
        'git-local': { socketPath: `${SOCKET_DIR}/git-local.sock` },
        'notion': { socketPath: `${SOCKET_DIR}/notion.sock` },
        'anchor-manager': { socketPath: `${SOCKET_DIR}/anchor-manager.sock` }
      }
    };
  }
}

async function getServerProcesses() {
  try {
    const { stdout } = await execAsync('ps -ef | grep -E "mcp-server|wrapper.js" | grep -v grep');
    
    const processes = stdout.split('\n')
      .filter(line => line.trim())
      .map(line => {
        const parts = line.trim().split(/\s+/);
        const pid = parts[1];
        const command = parts.slice(7).join(' ');
        
        let server = 'unknown';
        if (command.includes('filesystem')) server = 'filesystem';
        if (command.includes('git-local')) server = 'git-local';
        if (command.includes('notion')) server = 'notion';
        if (command.includes('anchor-manager')) server = 'anchor-manager';
        
        return { pid, command, server };
      });
    
    return processes;
  } catch (error) {
    log('ERROR', `Failed to get server processes: ${error.message}`);
    return [];
  }
}

async function checkSocketFiles() {
  try {
    const socketFiles = [
      { name: 'filesystem', path: path.join(SOCKET_DIR, 'filesystem.sock') },
      { name: 'git-local', path: path.join(SOCKET_DIR, 'git-local.sock') },
      { name: 'notion', path: path.join(SOCKET_DIR, 'notion.sock') },
      { name: 'anchor-manager', path: path.join(SOCKET_DIR, 'anchor-manager.sock') }
    ];
    
    const results = [];
    
    for (const socket of socketFiles) {
      try {
        const stats = await fs.stat(socket.path);
        const permissions = stats.mode & 0o777;
        const permString = (permissions & 0o400 ? 'r' : '-') +
                         (permissions & 0o200 ? 'w' : '-') +
                         (permissions & 0o100 ? 'x' : '-') +
                         (permissions & 0o040 ? 'r' : '-') +
                         (permissions & 0o020 ? 'w' : '-') +
                         (permissions & 0o010 ? 'x' : '-') +
                         (permissions & 0o004 ? 'r' : '-') +
                         (permissions & 0o002 ? 'w' : '-') +
                         (permissions & 0o001 ? 'x' : '-');
        
        results.push({
          name: socket.name,
          path: socket.path,
          exists: true,
          isSocket: stats.isSocket(),
          permissions: permString,
          mode: `0${permissions.toString(8)}`
        });
      } catch (error) {
        results.push({
          name: socket.name,
          path: socket.path,
          exists: false,
          error: error.code || error.message
        });
      }
    }
    
    return results;
  } catch (error) {
    log('ERROR', `Failed to check socket files: ${error.message}`);
    return [];
  }
}

// ---------- tool implementations ----------------------------------------------
server.registerTools([
  {
    name: 'anchor_status',
    description: 'Get comprehensive system status for all MCP components',
    inputSchema: {
      type: 'object',
      properties: {
        detailed: { type: 'boolean', default: false },
        component: {
          type: 'string',
          enum: ['filesystem', 'git-local', 'notion', 'anchor-manager', 'all'],
          default: 'all'
        }
      }
    },
    handler: async ({detailed, component}) => {
      try {
        log('INFO', `Getting system status`, { detailed, component });
        
        const status = {
          timestamp: new Date().toISOString(),
          system: {
            hostname: os.hostname(),
            platform: `${os.type()} ${os.release()}`,
            arch: os.arch(),
            uptime: os.uptime(),
            memory: {
              total: os.totalmem(),
              free: os.freemem(),
              used: os.totalmem() - os.freemem()
            }
          },
          anchor: {
            version: '6.0.0',
            home: ANCHOR_HOME,
            mcp_dir: MCP_DIR
          },
          components: {}
        };
        
        // Get MCP configuration
        try {
          const config = await readClaudeConfig();
          status.config = {
            path: CONFIG_FILE,
            servers: Object.keys(config.mcpServers || {})
          };
        } catch (error) {
          status.config = {
            path: CONFIG_FILE,
            error: error.message
          };
        }
        
        // Get server processes
        const processes = await getServerProcesses();
        
        // Get socket status
        const sockets = await checkSocketFiles();
        
        // Process component data
        const components = ['filesystem', 'git-local', 'notion', 'anchor-manager'];
        for (const comp of components) {
          if (component === 'all' || component === comp) {
            const process = processes.find(p => p.server === comp);
            const socket = sockets.find(s => s.name === comp);
            
            status.components[comp] = {
              process: process ? { pid: process.pid, running: true } : { running: false },
              socket: socket ? { 
                exists: socket.exists, 
                path: socket.path,
                permissions: socket.permissions
              } : { exists: false }
            };
          }
        }
        
        return status;
      } catch (error) {
        log('ERROR', `anchor_status failed: ${error.message}`);
        return {
          error: error.message,
          timestamp: new Date().toISOString()
        };
      }
    }
  },
  {
    name: 'anchor_health',
    description: 'Run comprehensive health check across all systems',
    inputSchema: {
      type: 'object',
      properties: {
        fix: { type: 'boolean', default: false }
      }
    },
    handler: async ({fix}) => {
      try {
        log('INFO', `Running health check`, { fix });
        
        const health = {
          timestamp: new Date().toISOString(),
          status: 'checking',
          checks: {},
          fixes: []
        };
        
        // Check socket directory
        try {
          const stats = await fs.stat(SOCKET_DIR);
          const permissions = stats.mode & 0o777;
          
          health.checks.socket_dir = {
            path: SOCKET_DIR,
            exists: true,
            permissions: `0${permissions.toString(8)}`,
            permissions_valid: permissions === 0o775
          };
        } catch (error) {
          health.checks.socket_dir = {
            path: SOCKET_DIR,
            exists: false,
            error: error.message
          };
          
          // Try to fix if requested
          if (fix) {
            try {
              await fs.mkdir(SOCKET_DIR, { recursive: true });
              await fs.chmod(SOCKET_DIR, 0o775);
              health.fixes.push({
                component: 'socket_dir',
                action: 'created',
                path: SOCKET_DIR
              });
            } catch (fixError) {
              health.fixes.push({
                component: 'socket_dir',
                action: 'failed',
                error: fixError.message
              });
            }
          }
        }
        
        // Check socket files
        health.checks.sockets = await checkSocketFiles();
        
        // Check processes
        health.checks.processes = await getServerProcesses();
        
        return health;
      } catch (error) {
        log('ERROR', `anchor_health failed: ${error.message}`);
        return {
          error: error.message,
          timestamp: new Date().toISOString()
        };
      }
    }
  },
  {
    name: 'anchor_restart',
    description: 'Restart all MCP servers',
    inputSchema: {
      type: 'object',
      properties: {
        server: {
          type: 'string',
          enum: ['all', 'git-local', 'notion', 'anchor-manager'],
          default: 'all'
        }
      }
    },
    handler: async ({server}) => {
      try {
        log('INFO', `Restarting servers`, { server });
        
        const result = {
          timestamp: new Date().toISOString(),
          restarted: [],
          failed: []
        };
        
        // Define servers to restart
        const servers = server === 'all' ? 
          ['git-local', 'notion', 'anchor-manager'] : 
          [server];
        
        // Stop each server
        for (const serverName of servers) {
          try {
            const processPattern = serverName.includes('git') ? 'git-local' : 
              serverName.includes('notion') ? 'notion' : 
              serverName.includes('anchor') ? 'anchor-manager' : 
              serverName;
            
            const { stdout: pids } = await execAsync(`pgrep -f "${processPattern}-optimized.js" || echo ""`);
            
            if (pids.trim()) {
              log('INFO', `Stopping ${serverName}`, { pids: pids.trim() });
              await execAsync(`kill ${pids.trim().split('\n').join(' ')}`);
              
              // Wait for process to terminate
              await new Promise(resolve => setTimeout(resolve, 500));
            }
            
            // Start the server based on server name
            const serverPath = path.join(MCP_DIR, `${serverName === 'notion' ? 'notion-v5-wrapper.js' : `${serverName}-optimized.js`}`);
            const logFile = path.join(LOG_DIR, `mcp-server-${serverName}.log`);
            
            log('INFO', `Starting ${serverName}`, { path: serverPath });
            
            // Construct environment variables based on server
            let envVars = `ANCHOR_HOME=${ANCHOR_HOME} NODE_OPTIONS="--max-old-space-size=8192" UV_THREADPOOL_SIZE=12 SOCKET_DIR=${SOCKET_DIR}`;
            
            if (serverName === 'notion') {
              envVars += ` NOTION_API_TOKEN="replace-with-your-token"`;
            }
            
            const startCommand = `${envVars} node "${serverPath}" > "${logFile}" 2>&1 &`;
            await execAsync(startCommand);
            
            // Check if server started
            await new Promise(resolve => setTimeout(resolve, 1000));
            const { stdout: newPid } = await execAsync(`pgrep -f "${processPattern}.*\\.js" || echo ""`);
            
            if (newPid.trim()) {
              result.restarted.push({
                server: serverName,
                pid: newPid.trim()
              });
              log('INFO', `Successfully restarted ${serverName}`, { pid: newPid.trim() });
            } else {
              result.failed.push({
                server: serverName,
                error: 'Process did not start'
              });
              log('ERROR', `Failed to start ${serverName}`);
            }
          } catch (error) {
            result.failed.push({
              server: serverName,
              error: error.message
            });
            log('ERROR', `Error restarting ${serverName}: ${error.message}`);
          }
        }
        
        return result;
      } catch (error) {
        log('ERROR', `anchor_restart failed: ${error.message}`);
        return {
          error: error.message,
          timestamp: new Date().toISOString()
        };
      }
    }
  }
]);

log('INFO', 'Server initialized, connecting transport');
server.connect(new StdioServerTransport());

// ---------- Memory optimization ---------------------------------------------------
setInterval(() => {
  const memBefore = process.memoryUsage();
  
  // Instead of global.gc, we can encourage natural garbage collection
  // by creating and releasing a large temporary object
  const temp = new Array(10000).fill(0);
  
  // Force a minor GC by creating pressure
  for (let i = 0; i < 10; i++) {
    const arr = new Array(100000).fill(0);
    arr.length = 0;
  }
  
  const memAfter = process.memoryUsage();
  log('DEBUG','Memory management', {
    before: `${(memBefore.heapUsed/1048576).toFixed(1)} MB`,
    after: `${(memAfter.heapUsed/1048576).toFixed(1)} MB`,
    diff: `${((memBefore.heapUsed-memAfter.heapUsed)/1048576).toFixed(1)} MB`
  });
}, 60000);

log('INFO', 'Anchor-manager server ready');
