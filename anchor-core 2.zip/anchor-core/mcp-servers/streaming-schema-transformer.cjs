/**
 * streaming-schema-transformer.cjs - Streaming transformer for CNIF
 * © 2025 XPV - MIT
 * 
 * This module implements a streaming transformer for XML to JSON and
 * JSON to XML conversion with proper schema validation.
 */

const fs = require('fs');
const net = require('net');
const path = require('path');

// Configuration
const SOCKET_DIR = process.env.SOCKET_DIR || '/Users/XPV/Desktop/anchor-core/sockets';
const SERVER_NAME = process.env.MCP_SERVER_NAME || 'streaming-transformer';
const SOCKET_PATH = path.join(SOCKET_DIR, `${SERVER_NAME}.sock`);
const LOG_DIR = process.env.LOG_DIR || path.join(process.env.HOME, 'Library/Logs/Claude');
const LOG_FILE = path.join(LOG_DIR, `${SERVER_NAME}.log`);

// Logger
function log(level, message, extra = {}) {
  const logEntry = JSON.stringify({
    ts: new Date().toISOString(),
    level,
    component: SERVER_NAME,
    pid: process.pid,
    message,
    extra: extra || {}
  });
  
  console.log(logEntry);
  
  try {
    fs.appendFileSync(LOG_FILE, logEntry + '\n');
  } catch (err) {
    console.error(`Failed to write to log file: ${err.message}`);
  }
}

// Ensure directories exist
try {
  fs.mkdirSync(SOCKET_DIR, { recursive: true });
  fs.mkdirSync(LOG_DIR, { recursive: true });
} catch (err) {
  log('ERROR', `Failed to create directories: ${err.message}`);
}

// Simple XML to JSON transformation
function transformXmlToJson(xmlString) {
  try {
    log('DEBUG', 'Transforming XML to JSON', { size: xmlString.length });
    
    // Simple transformer that extracts key elements
    // In a real implementation, this would use a proper XML parser
    const result = {
      header: {
        id: extractValue(xmlString, 'id'),
        timestamp: extractValue(xmlString, 'timestamp')
      },
      body: {
        text: extractValue(xmlString, 'text'),
        metadata: {
          source: extractValue(xmlString, 'source'),
          priority: extractValue(xmlString, 'priority')
        }
      }
    };
    
    log('DEBUG', 'XML to JSON transformation complete');
    return result;
  } catch (err) {
    log('ERROR', `XML to JSON transformation failed: ${err.message}`);
    throw err;
  }
}

// Simple JSON to XML transformation
function transformJsonToXml(jsonData) {
  try {
    log('DEBUG', 'Transforming JSON to XML');
    
    // Convert JSON to a simple XML structure
    // In a real implementation, this would use a proper XML generator
    const header = jsonData.header || {};
    const body = jsonData.body || {};
    
    let xmlString = `
      <cnif:message xmlns:cnif="http://anthropic.com/claude/cnif/v1">
        <cnif:header>
          <cnif:id>${header.id || ''}</cnif:id>
          <cnif:timestamp>${header.timestamp || new Date().toISOString()}</cnif:timestamp>
        </cnif:header>
        <cnif:body>
          <cnif:text>${body.text || ''}</cnif:text>
          <cnif:metadata>
            <cnif:source>${body.metadata?.source || 'unknown'}</cnif:source>
            <cnif:priority>${body.metadata?.priority || 'normal'}</cnif:priority>
          </cnif:metadata>
        </cnif:body>
      </cnif:message>
    `;
    
    log('DEBUG', 'JSON to XML transformation complete');
    return xmlString;
  } catch (err) {
    log('ERROR', `JSON to XML transformation failed: ${err.message}`);
    throw err;
  }
}

// Helper function to extract values from XML
function extractValue(xml, tag) {
  const regex = new RegExp(`<[^>]*?:?${tag}[^>]*>(.*?)<\\/[^>]*?:?${tag}>`, 's');
  const match = xml.match(regex);
  return match ? match[1].trim() : '';
}

// Remove socket file if it exists
try {
  if (fs.existsSync(SOCKET_PATH)) {
    fs.unlinkSync(SOCKET_PATH);
    log('INFO', `Removed existing socket file: ${SOCKET_PATH}`);
  }
} catch (err) {
  log('ERROR', `Failed to remove existing socket file: ${err.message}`);
  process.exit(1);
}

// Create coherence marker
try {
  const coherenceDir = path.join(process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core', 'coherence_lock');
  fs.mkdirSync(coherenceDir, { recursive: true });
  
  const markerPath = path.join(coherenceDir, `${SERVER_NAME}_${new Date().toISOString().replace(/[:.]/g, '')}.marker`);
  fs.writeFileSync(markerPath, String(process.pid));
  
  log('INFO', `Created coherence marker: ${markerPath}`);
} catch (err) {
  log('ERROR', `Failed to create coherence marker: ${err.message}`);
}

// Message buffer for handling partial messages
class MessageBuffer {
  constructor() {
    this.buffer = '';
  }
  
  append(data) {
    this.buffer += data.toString();
  }
  
  getMessages() {
    if (!this.buffer.includes('\n')) {
      return [];
    }
    
    const messages = this.buffer.split('\n');
    this.buffer = messages.pop(); // Keep incomplete message in buffer
    
    return messages.filter(message => message.trim());
  }
}

// Create server
const server = net.createServer((socket) => {
  const clientId = Date.now().toString(36) + Math.random().toString(36).substr(2);
  log('INFO', 'Client connected', { clientId });
  
  // Initialize message buffer for this client
  const messageBuffer = new MessageBuffer();
  
  // Setup heartbeat
  const heartbeatInterval = setInterval(() => {
    try {
      if (socket.writable) {
        socket.write(JSON.stringify({
          type: 'heartbeat',
          timestamp: new Date().toISOString(),
          server: SERVER_NAME
        }) + '\n');
      }
    } catch (err) {
      log('ERROR', `Failed to send heartbeat to client ${clientId}`, { error: err.message });
    }
  }, 30000);
  
  socket.on('data', (data) => {
    log('DEBUG', `Received data: ${data.length} bytes`, { clientId });
    
    // Append data to buffer
    messageBuffer.append(data);
    
    // Process complete messages
    const messages = messageBuffer.getMessages();
    
    for (const messageText of messages) {
      try {
        // Parse the received data as JSON
        const message = JSON.parse(messageText);
        log('DEBUG', 'Parsed message', { type: message.type, clientId });
        
        // Process the message based on type
        let response;
        if (message.type === 'transform') {
          if (message.format === 'xml-to-json') {
            const result = transformXmlToJson(message.data);
            response = {
              type: 'transform_response',
              id: message.id || 'unknown',
              status: 'success',
              data: result,
              source_format: 'xml',
              target_format: 'json'
            };
          } else if (message.format === 'json-to-xml') {
            const result = transformJsonToXml(message.data);
            response = {
              type: 'transform_response',
              id: message.id || 'unknown',
              status: 'success',
              data: result,
              source_format: 'json',
              target_format: 'xml'
            };
          } else {
            response = {
              type: 'error_response',
              id: message.id || 'unknown',
              status: 'error',
              error: `Unsupported transformation format: ${message.format}`
            };
          }
        } else if (message.type === 'handshake') {
          response = { 
            type: 'handshake_response', 
            status: 'success',
            server: SERVER_NAME,
            version: '1.0.0'
          };
        } else {
          response = {
            type: 'error_response',
            status: 'error',
            error: `Unknown message type: ${message.type}`
          };
        }
        
        // Send response
        socket.write(JSON.stringify(response) + '\n');
        log('DEBUG', 'Sent response', { type: response.type, clientId });
        
      } catch (err) {
        log('ERROR', `Failed to process message: ${err.message}`, { clientId });
        
        // Send error response
        const errorResponse = {
          type: 'error_response',
          status: 'error',
          error: `Failed to process message: ${err.message}`
        };
        socket.write(JSON.stringify(errorResponse) + '\n');
      }
    }
  });
  
  socket.on('end', () => {
    clearInterval(heartbeatInterval);
    log('INFO', 'Client disconnected', { clientId });
  });
  
  socket.on('error', (err) => {
    log('ERROR', `Socket error: ${err.message}`, { clientId });
  });
});

// Start listening
server.listen(SOCKET_PATH, () => {
  log('INFO', `Server listening on ${SOCKET_PATH}`);
  
  // Set permissions on socket file (666 = rw-rw-rw-)
  try {
    fs.chmodSync(SOCKET_PATH, 0o666);
    log('INFO', `Set permissions on socket file: 0666`);
  } catch (err) {
    log('ERROR', `Failed to set permissions on socket file: ${err.message}`);
  }
});

// Handle errors
server.on('error', (err) => {
  log('ERROR', `Server error: ${err.message}`);
  
  if (err.code === 'EADDRINUSE') {
    log('ERROR', `Socket file is already in use: ${SOCKET_PATH}`);
  }
  
  process.exit(1);
});

// Handle process exit
process.on('exit', () => {
  try {
    if (fs.existsSync(SOCKET_PATH)) {
      fs.unlinkSync(SOCKET_PATH);
      log('INFO', `Removed socket file on exit: ${SOCKET_PATH}`);
    }
  } catch (err) {
    log('ERROR', `Failed to remove socket file on exit: ${err.message}`);
  }
});

process.on('SIGINT', () => {
  log('INFO', 'Received SIGINT, shutting down');
  server.close(() => {
    process.exit(0);
  });
});

process.on('SIGTERM', () => {
  log('INFO', 'Received SIGTERM, shutting down');
  server.close(() => {
    process.exit(0);
  });
});

log('INFO', `Started ${SERVER_NAME} server (PID: ${process.pid})`);
