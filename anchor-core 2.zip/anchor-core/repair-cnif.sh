#!/bin/bash
# repair-cnif.sh - Comprehensive repair for Claude-Notion Integration Framework
# © 2025 XPV - MIT

set -e

# Define colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color
BLUE='\033[0;34m'

# Base paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
SOCKET_DIR="$ANCHOR_HOME/sockets"
COHERENCE_LOCK_DIR="$ANCHOR_HOME/coherence_lock"
LOG_DIR="$HOME/Library/Logs/Claude"
CONFIG_DIR="$ANCHOR_HOME/data"
MCP_DIR="$ANCHOR_HOME/mcp-servers"
PID_DIR="$MCP_DIR"

echo -e "${BLUE}==================================================${NC}"
echo -e "${BLUE}CNIF System Repair                               ${NC}"
echo -e "${BLUE}==================================================${NC}"

# 1. Make all scripts executable
echo -e "\n${BLUE}Making scripts executable...${NC}"
chmod +x "$ANCHOR_HOME/make-scripts-executable.sh"
"$ANCHOR_HOME/make-scripts-executable.sh"

# 2. Kill any running processes
echo -e "\n${BLUE}Stopping any running processes...${NC}"

# Define server list
servers=("socket-server" "notion" "schema-registry" "streaming-transformer" "mcp-orchestrator")

# Kill processes by PID files if they exist
for server in "${servers[@]}"; do
  pid_file="$PID_DIR/$server.pid"
  if [ -f "$pid_file" ]; then
    pid=$(cat "$pid_file")
    if ps -p "$pid" > /dev/null 2>&1; then
      echo -e "${YELLOW}Stopping $server (PID: $pid)...${NC}"
      kill -15 "$pid" 2>/dev/null || kill -9 "$pid" 2>/dev/null || true
    else
      echo -e "${YELLOW}Process $server (PID: $pid) not running${NC}"
    fi
    rm -f "$pid_file"
  fi
done

# 3. Clean up socket files
echo -e "\n${BLUE}Cleaning up socket files...${NC}"
if [ -d "$SOCKET_DIR" ]; then
  find "$SOCKET_DIR" -name "*.sock" -exec rm -f {} \;
  echo -e "${GREEN}✅ Removed socket files${NC}"
else
  mkdir -p "$SOCKET_DIR"
  echo -e "${GREEN}✅ Created socket directory${NC}"
fi

# 4. Clean up coherence markers
echo -e "\n${BLUE}Cleaning up coherence markers...${NC}"
"$ANCHOR_HOME/clean-coherence-markers.sh"

# 5. Check and create directories
echo -e "\n${BLUE}Checking and creating required directories...${NC}"
mkdir -p "$LOG_DIR"
mkdir -p "$SOCKET_DIR"
mkdir -p "$COHERENCE_LOCK_DIR"
mkdir -p "$CONFIG_DIR"
mkdir -p "$PID_DIR"

# Set permissions
chmod 755 "$LOG_DIR"
chmod 755 "$SOCKET_DIR"
chmod 755 "$COHERENCE_LOCK_DIR"
chmod 755 "$CONFIG_DIR"
chmod 755 "$PID_DIR"

echo -e "${GREEN}✅ Directories created and permissions set${NC}"

# 6. Check and create default config if missing
if [ ! -f "$CONFIG_DIR/notion-config.json" ]; then
  echo -e "\n${BLUE}Creating default notion config...${NC}"
  echo '{
    "rootPageId": "",
    "enabledDatabases": [],
    "syncInterval": 30000,
    "rateLimitPerSecond": 3
  }' > "$CONFIG_DIR/notion-config.json"
  echo -e "${GREEN}✅ Created default Notion config${NC}"
fi

# 7. Run optimizations for M3 Max
echo -e "\n${BLUE}Running M3 Max optimizations...${NC}"
if [ -f "$ANCHOR_HOME/m3-optimizer/m3-optimizer.js" ]; then
  node "$ANCHOR_HOME/m3-optimizer/m3-optimizer.js"
  echo -e "${GREEN}✅ M3 Max optimizations applied${NC}"
else
  echo -e "${YELLOW}⚠️ M3 optimizer not found${NC}"
fi

echo -e "\n${GREEN}✅ CNIF system repair complete!${NC}"
echo -e "${BLUE}You can now run the system with:${NC}"
echo -e "  ${YELLOW}cd $ANCHOR_HOME${NC}"
echo -e "  ${YELLOW}./launch-optimized.sh${NC}"
