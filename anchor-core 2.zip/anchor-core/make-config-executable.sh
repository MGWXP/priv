#!/bin/bash
# Make script executable
chmod +x /Users/XPV/Desktop/anchor-core/configure-notion.sh
echo "✅ Configuration script is now executable"
echo "To configure Notion API token, run:"
echo "  /Users/XPV/Desktop/anchor-core/configure-notion.sh"
