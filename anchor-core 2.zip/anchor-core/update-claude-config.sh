#!/bin/bash

# Set directory paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
LOG_DIR="${ANCHOR_HOME}/logs"
CLAUDE_CONFIG_DIR="${HOME}/Library/Application Support/Claude"
CLAUDE_CONFIG_FILE="${CLAUDE_CONFIG_DIR}/claude_desktop_config.json"

# Create log directory if it doesn't exist
mkdir -p "${LOG_DIR}"

# Log function
log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "${LOG_DIR}/claude-config-update.log"
}

log "Starting Claude Desktop config update for GitHub MCP integration"

# Check if Claude config directory exists, create if not
if [ ! -d "${CLAUDE_CONFIG_DIR}" ]; then
  log "Creating Claude config directory: ${CLAUDE_CONFIG_DIR}"
  mkdir -p "${CLAUDE_CONFIG_DIR}"
fi

# Backup existing config
if [ -f "${CLAUDE_CONFIG_FILE}" ]; then
  BACKUP_FILE="${CLAUDE_CONFIG_FILE}.bak.$(date '+%Y%m%d%H%M%S')"
  log "Backing up existing config to ${BACKUP_FILE}"
  cp "${CLAUDE_CONFIG_FILE}" "${BACKUP_FILE}"
fi

# Copy new config
log "Copying new config to ${CLAUDE_CONFIG_FILE}"
cp "${ANCHOR_HOME}/github_claude_config.json" "${CLAUDE_CONFIG_FILE}"

# Load GitHub token from environment file if it exists
if [ -f "${ANCHOR_HOME}/.github-env" ]; then
  source "${ANCHOR_HOME}/.github-env"
  
  # Update placeholders in config
  log "Updating token placeholders in config"
  sed -i "" "s|\${GITHUB_PERSONAL_ACCESS_TOKEN}|${GITHUB_PERSONAL_ACCESS_TOKEN}|g" "${CLAUDE_CONFIG_FILE}"
  sed -i "" "s|\${GITHUB_TOOLSETS}|${GITHUB_TOOLSETS}|g" "${CLAUDE_CONFIG_FILE}"
fi

# Load Notion token from environment file if it exists
if [ -f "${ANCHOR_HOME}/.notion-env" ]; then
  source "${ANCHOR_HOME}/.notion-env"
  
  # Update placeholders in config
  log "Updating Notion token placeholder in config"
  sed -i "" "s|\${NOTION_API_TOKEN}|${NOTION_API_TOKEN}|g" "${CLAUDE_CONFIG_FILE}"
fi

log "✅ Claude Desktop config update complete"
log "Restart Claude Desktop to apply changes"
