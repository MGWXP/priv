#!/bin/bash
# make-module-fixer-executable.sh
# © 2025 XPV - MIT

chmod +x /Users/XPV/Desktop/anchor-core/fix-cnif-modules.sh
echo "✅ Module fixer script is now executable"
echo "Run it with: /Users/XPV/Desktop/anchor-core/fix-cnif-modules.sh"
