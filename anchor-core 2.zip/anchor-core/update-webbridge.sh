#!/bin/bash
# Update all WebSocket Bridge files
# Script will update necessary files and run verification

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "✅ Updating WebSocket Bridge files..."

# Make all scripts executable
chmod +x make-webbridge-executable.sh
./make-webbridge-executable.sh

# Install required dependencies
echo "✅ Installing dependencies..."
cd src/webbridge
npm install sqlite

echo "✅ Dependencies installed successfully"
cd "$SCRIPT_DIR"

# Run verification
echo
echo "✅ Running verification script..."
chmod +x verify-webbridge.sh
./verify-webbridge.sh

echo
echo "✅ WebSocket Bridge update complete!"
echo "To start the WebSocket Bridge, run:"
echo "  $SCRIPT_DIR/start-webbridge.sh"
echo
echo "To access the dashboard, open:"
echo "  http://localhost:8765"
echo
echo "For troubleshooting, see:"
echo "  $SCRIPT_DIR/WEBBRIDGE_TROUBLESHOOTING.md"
