chmod +x /Users/XPV/Desktop/anchor-core/notion-quickstart.sh
echo "✅ Made notion-quickstart.sh executable"
echo "To quickly set up the entire Notion integration in one step, run:"
echo "  /Users/XPV/Desktop/anchor-core/notion-quickstart.sh"
