#!/bin/bash
# create-dashboard-entry.sh - Creates a dashboard entry in Notion with recent status
# For M3 Max (48GB unified memory) hardware 

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

DASHBOARD_ID=$(cat /Users/XPV/Desktop/anchor-core/notion-dashboard-ids/main-dashboard-id.txt)

echo -e "${BLUE}=== Creating Dashboard Status Update ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e ""

# Check if NOTION_API_KEY is set
if [ -z "${NOTION_API_KEY}" ]; then
    echo -e "${YELLOW}NOTION_API_KEY environment variable is not set${NC}"
    echo -e "Would you like to set it now? (y/n)"
    read -r response
    if [[ "$response" =~ ^([yY][eE][sS]|[yY])$ ]]; then
        echo -e "Enter your Notion API Key:"
        read -s NOTION_KEY
        export NOTION_API_KEY="$NOTION_KEY"
        echo -e "${GREEN}✓ NOTION_API_KEY set${NC}"
    else
        echo -e "${RED}Cannot proceed without Notion API Key${NC}"
        exit 1
    fi
fi

# Check system metrics
CPU_USAGE=$(top -l 1 | grep "CPU usage" | awk '{print $3}' | tr -d '%')
MEM_USED=$(vm_stat | grep "Pages active" | awk '{print $3}' | tr -d '.')
MEM_USED_GB=$(echo "scale=2; $MEM_USED * 4096 / 1024 / 1024 / 1024" | bc)
DISK_USAGE=$(df -h /Users | grep /dev | awk '{print $5}' | tr -d '%')

# Check services status
FILESYSTEM_STATUS="Active"
if [ ! -f "/Users/XPV/Desktop/anchor-core/mcp-servers/anchor-manager.pid" ]; then
    FILESYSTEM_STATUS="Inactive"
fi

GIT_STATUS="Active"
if [ ! -f "/Users/XPV/Desktop/anchor-core/mcp-servers/git-local.pid" ]; then
    GIT_STATUS="Inactive"
fi

NOTION_STATUS="Active"
if [ ! -f "/Users/XPV/Desktop/anchor-core/mcp-servers/notion.pid" ]; then
    NOTION_STATUS="Inactive"
fi

SLACK_STATUS="Inactive"
if [ -f "/Users/XPV/Desktop/anchor-core/mcp-servers/slack.pid" ]; then
    SLACK_STATUS="Active"
fi

# Add callout with current system status 
echo -e "Adding system status callout to dashboard..."
STATUS_RESPONSE=$(curl -s -X PATCH "https://api.notion.com/v1/blocks/${DASHBOARD_ID}/children" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "children": [
        {
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Current System Status"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "callout",
            "callout": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Status as of '"$(date '+%Y-%m-%d %H:%M:%S')"'\n\nSystem Metrics:\n• CPU Usage: '"${CPU_USAGE}"'%\n• Memory Used: '"${MEM_USED_GB}"' GB\n• Disk Usage: '"${DISK_USAGE}"'%\n\nServices:\n• Filesystem MCP: '"${FILESYSTEM_STATUS}"'\n• Git-Local MCP: '"${GIT_STATUS}"'\n• Notion MCP: '"${NOTION_STATUS}"'\n• Slack MCP: '"${SLACK_STATUS}"'"
                        }
                    }
                ],
                "icon": {
                    "emoji": "📊"
                },
                "color": "green_background"
            }
        }
    ]
}')

if echo $STATUS_RESPONSE | grep -q "error"; then
    echo -e "${RED}Failed to add status callout${NC}"
    echo $STATUS_RESPONSE
else
    echo -e "${GREEN}✓ Status callout added successfully!${NC}"
fi

# Add database creation status
echo -e "Adding database creation status to dashboard..."
DB_STATUS_RESPONSE=$(curl -s -X PATCH "https://api.notion.com/v1/blocks/${DASHBOARD_ID}/children" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "children": [
        {
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Database Creation Status"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "bulleted_list_item",
            "bulleted_list_item": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Agent Registry: "
                        }
                    },
                    {
                        "type": "text",
                        "text": {
                            "content": "Created"
                        },
                        "annotations": {
                            "bold": true,
                            "color": "green"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "bulleted_list_item",
            "bulleted_list_item": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Component Library: "
                        }
                    },
                    {
                        "type": "text",
                        "text": {
                            "content": "Created"
                        },
                        "annotations": {
                            "bold": true,
                            "color": "green"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "bulleted_list_item",
            "bulleted_list_item": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Project Tracker: "
                        }
                    },
                    {
                        "type": "text",
                        "text": {
                            "content": "Created"
                        },
                        "annotations": {
                            "bold": true,
                            "color": "green"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "bulleted_list_item",
            "bulleted_list_item": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "System Metrics: "
                        }
                    },
                    {
                        "type": "text",
                        "text": {
                            "content": "Ready for Creation"
                        },
                        "annotations": {
                            "bold": true,
                            "color": "yellow"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "bulleted_list_item",
            "bulleted_list_item": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Documentation: "
                        }
                    },
                    {
                        "type": "text",
                        "text": {
                            "content": "Ready for Creation"
                        },
                        "annotations": {
                            "bold": true,
                            "color": "yellow"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "bulleted_list_item",
            "bulleted_list_item": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Meeting Notes: "
                        }
                    },
                    {
                        "type": "text",
                        "text": {
                            "content": "Ready for Creation"
                        },
                        "annotations": {
                            "bold": true,
                            "color": "yellow"
                        }
                    }
                ]
            }
        }
    ]
}')

if echo $DB_STATUS_RESPONSE | grep -q "error"; then
    echo -e "${RED}Failed to add database status list${NC}"
    echo $DB_STATUS_RESPONSE
else
    echo -e "${GREEN}✓ Database status list added successfully!${NC}"
fi

# Add action items section
echo -e "Adding action items to dashboard..."
ACTION_RESPONSE=$(curl -s -X PATCH "https://api.notion.com/v1/blocks/${DASHBOARD_ID}/children" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "children": [
        {
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Action Items"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "to_do",
            "to_do": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Run create-remaining-databases.sh to complete setup"
                        }
                    }
                ],
                "checked": false
            }
        },
        {
            "object": "block",
            "type": "to_do",
            "to_do": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Configure Slack integration with API token"
                        }
                    }
                ],
                "checked": false
            }
        },
        {
            "object": "block",
            "type": "to_do",
            "to_do": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Review DASHBOARD_ERROR_REPORT.md for technical details on API solution"
                        }
                    }
                ],
                "checked": false
            }
        }
    ]
}')

if echo $ACTION_RESPONSE | grep -q "error"; then
    echo -e "${RED}Failed to add action items${NC}"
    echo $ACTION_RESPONSE
else
    echo -e "${GREEN}✓ Action items added successfully!${NC}"
fi

echo -e "\n${GREEN}✓ Dashboard status update complete!${NC}"
echo -e "${YELLOW}View your updated dashboard at: https://www.notion.so/${DASHBOARD_ID}${NC}"
