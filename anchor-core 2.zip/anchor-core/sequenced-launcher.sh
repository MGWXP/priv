#!/bin/bash
# sequenced-launcher.sh - Advanced sequenced launcher for CNIF components
# © 2025 XPV - MIT
#
# This script launches CNIF components in the correct dependency order
# with proper verification of successful initialization.

# Environment setup
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
MCP_SERVERS_DIR="${ANCHOR_HOME}/mcp-servers"
SOCKET_DIR="${ANCHOR_HOME}/sockets"
LOG_DIR="${HOME}/Library/Logs/Claude"
COHERENCE_DIR="${ANCHOR_HOME}/coherence_lock"
TIMESTAMP=$(date +"%Y%m%d%H%M%S")
LOG_FILE="${LOG_DIR}/sequenced-launcher-${TIMESTAMP}.log"

# Ensure directories exist
mkdir -p "${LOG_DIR}"
mkdir -p "${SOCKET_DIR}"
mkdir -p "${COHERENCE_DIR}"

# ANSI color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Log function
log() {
  local level="$1"
  local message="$2"
  local color="${NC}"
  
  case "${level}" in
    "INFO") color="${GREEN}" ;;
    "WARN") color="${YELLOW}" ;;
    "ERROR") color="${RED}" ;;
    "DEBUG") color="${BLUE}" ;;
    "STEP") color="${CYAN}" ;;
    *) color="${NC}" ;;
  esac
  
  echo -e "${color}$(date +"%Y-%m-%d %H:%M:%S") [${level}] ${message}${NC}" | tee -a "${LOG_FILE}"
}

# Wait for a socket file to appear
wait_for_socket() {
  local socket_name="$1"
  local timeout="$2"
  local socket_path="${SOCKET_DIR}/${socket_name}.sock"
  local counter=0
  
  log "INFO" "Waiting for socket: ${socket_path} (timeout: ${timeout}s)"
  
  while [ ! -S "${socket_path}" ] && [ ${counter} -lt ${timeout} ]; do
    sleep 1
    counter=$((counter + 1))
    if [ $((counter % 5)) -eq 0 ]; then
      log "DEBUG" "Still waiting for socket: ${socket_path} (${counter}/${timeout}s)"
    fi
  done
  
  if [ -S "${socket_path}" ]; then
    log "INFO" "✅ Socket ready: ${socket_path}"
    return 0
  else
    log "ERROR" "❌ Socket not available after ${timeout}s: ${socket_path}"
    return 1
  fi
}

# Start a component with proper environment
start_component() {
  local name="$1"
  local cjs_file="$2"
  local entry_point="$3"
  local depends_on="$4"
  local pid_file="${MCP_SERVERS_DIR}/${name}.pid"
  
  log "STEP" "Starting component: ${name}"
  
  # Check dependencies if specified
  if [ -n "${depends_on}" ]; then
    IFS=',' read -ra DEPS <<< "${depends_on}"
    for dep in "${DEPS[@]}"; do
      local dep_socket="${SOCKET_DIR}/${dep}.sock"
      if [ ! -S "${dep_socket}" ]; then
        log "WARN" "⚠️ Dependency not ready: ${dep} (socket: ${dep_socket})"
        wait_for_socket "${dep}" 30
        if [ $? -ne 0 ]; then
          log "ERROR" "❌ Cannot start ${name}: dependency ${dep} not available"
          return 1
        fi
      else
        log "DEBUG" "Dependency ready: ${dep}"
      fi
    done
  fi
  
  # Check if already running
  if [ -f "${pid_file}" ]; then
    local pid=$(cat "${pid_file}")
    if ps -p "${pid}" > /dev/null; then
      log "INFO" "📌 ${name} already running with PID ${pid}"
      return 0
    else
      log "WARN" "⚠️ Found stale PID file for ${name}, will restart"
      rm -f "${pid_file}"
    fi
  fi
  
  # Configure environment
  export MCP_SERVER_NAME="${name}"
  export SOCKET_DIR="${SOCKET_DIR}"
  export LOG_DIR="${LOG_DIR}"
  export ANCHOR_HOME="${ANCHOR_HOME}"
  export NODE_OPTIONS="--max-old-space-size=8192"
  export UV_THREADPOOL_SIZE=12
  
  # Determine how to start the component
  if [ -n "${entry_point}" ]; then
    log "DEBUG" "Using entry point: ${entry_point}"
    node "${entry_point}" > "${LOG_DIR}/${name}.out" 2>&1 &
  else
    log "DEBUG" "Using direct CJS file: ${cjs_file}"
    node "${MCP_SERVERS_DIR}/${cjs_file}" > "${LOG_DIR}/${name}.out" 2>&1 &
  fi
  
  local component_pid=$!
  
  # Save PID
  echo ${component_pid} > "${pid_file}"
  log "INFO" "Started ${name} (PID: ${component_pid})"
  
  # Allow process to start completely
  sleep 2
  
  # Create coherence marker
  local marker_path="${COHERENCE_DIR}/${name}_${TIMESTAMP}.marker"
  echo "${component_pid}" > "${marker_path}"
  log "DEBUG" "Created coherence marker: ${marker_path}"
  
  # Verify component started properly
  if [ "${name}" != "schema-registry" ]; then
    wait_for_socket "${name}" 30
    if [ $? -ne 0 ]; then
      log "ERROR" "❌ Component ${name} failed to create socket, check logs: ${LOG_DIR}/${name}.out"
      kill ${component_pid} 2>/dev/null
      return 1
    fi
  else
    # Special case for schema-registry - wait for initialization message in logs
    sleep 5
    if ! ps -p "${component_pid}" > /dev/null; then
      log "ERROR" "❌ Schema registry failed to start, check logs: ${LOG_DIR}/${name}.out"
      return 1
    fi
      
    # Check if log contains successful initialization message
    if grep -q "Schema registry initialized" "${LOG_DIR}/${name}.out" 2>/dev/null; then
      log "INFO" "✅ Schema registry initialized successfully"
      return 0  # Success, even if no socket
    elif grep -q "Schema registry service running" "${LOG_DIR}/${name}.out" 2>/dev/null; then
      log "INFO" "✅ Schema registry service running"
      return 0  # Success, even if no socket
    else
      log "WARN" "⚠️ Schema registry started but initialization status unknown"
      # Continue anyway, as process is running
      return 0
    fi
  fi
  
  log "INFO" "✅ Component ${name} started successfully"
  return 0
}

# Stop a running component
stop_component() {
  local name="$1"
  local pid_file="${MCP_SERVERS_DIR}/${name}.pid"
  
  if [ -f "${pid_file}" ]; then
    local pid=$(cat "${pid_file}")
    if ps -p "${pid}" > /dev/null; then
      log "INFO" "Stopping ${name} (PID: ${pid})"
      kill "${pid}" 2>/dev/null
      
      # Wait for process to terminate
      local counter=0
      while ps -p "${pid}" > /dev/null && [ ${counter} -lt 10 ]; do
        sleep 1
        counter=$((counter + 1))
      done
      
      if ps -p "${pid}" > /dev/null; then
        log "WARN" "⚠️ Process ${name} (PID: ${pid}) did not terminate, forcing..."
        kill -9 "${pid}" 2>/dev/null
      else
        log "INFO" "✅ Process ${name} terminated"
      fi
    else
      log "INFO" "Process ${name} not running"
    fi
    
    rm -f "${pid_file}"
  else
    log "INFO" "No PID file found for ${name}"
  fi
  
  # Clean up socket file
  local socket_file="${SOCKET_DIR}/${name}.sock"
  if [ -S "${socket_file}" ]; then
    log "DEBUG" "Removing socket file: ${socket_file}"
    rm -f "${socket_file}"
  fi
}

# Stop all components in reverse order
stop_all() {
  log "STEP" "Stopping all components..."
  
  stop_component "mcp-orchestrator"
  stop_component "notion"
  stop_component "streaming-transformer"
  stop_component "socket-server" 
  stop_component "schema-registry"
  
  log "INFO" "✅ All components stopped"
}

# Main script logic
log "INFO" "🚀 Starting CNIF sequenced launcher"

# Check command line arguments
if [ "$1" = "stop" ]; then
  stop_all
  exit 0
fi

# Stop any existing processes first
log "STEP" "Stopping any existing processes..."
stop_all

# Start components in dependency order
log "STEP" "Starting components in sequence..."

# 1. Start schema registry (base dependency)
start_component "schema-registry" "schema-registry.cjs" "${MCP_SERVERS_DIR}/schema-registry-index.js" ""
if [ $? -ne 0 ]; then
  log "ERROR" "❌ Failed to start schema registry, aborting"
  # exit 1
fi

# 2. Start socket server (depends on schema registry)
start_component "socket-server" "socket-server-implementation.cjs" "${MCP_SERVERS_DIR}/entry-points/socket-server-main.js" "schema-registry"
if [ $? -ne 0 ]; then
  log "ERROR" "❌ Failed to start socket server, aborting"
  stop_component "schema-registry"
  # exit 1
fi

# 3. Start streaming transformer (depends on socket server and schema registry)
start_component "streaming-transformer" "streaming-schema-transformer.cjs" "" "socket-server,schema-registry"
if [ $? -ne 0 ]; then
  log "ERROR" "❌ Failed to start streaming transformer, aborting"
  stop_component "socket-server"
  stop_component "schema-registry"
  # exit 1
fi

# 4. Start notion connection (depends on streaming transformer)
start_component "notion" "notion-connection-manager.cjs" "${MCP_SERVERS_DIR}/entry-points/notion-main.js" "streaming-transformer"
if [ $? -ne 0 ]; then
  log "ERROR" "❌ Failed to start notion connection, aborting"
  stop_component "streaming-transformer"
  stop_component "socket-server"
  stop_component "schema-registry"
  # exit 1
fi

# 5. Start MCP orchestrator (depends on all other components)
start_component "mcp-orchestrator" "mcp-orchestrator.cjs" "" "notion,streaming-transformer,socket-server,schema-registry"
if [ $? -ne 0 ]; then
  log "ERROR" "❌ Failed to start MCP orchestrator, aborting"
  stop_component "notion"
  stop_component "streaming-transformer"
  stop_component "socket-server"
  stop_component "schema-registry"
  # exit 1
fi

# Create successful launch marker
echo "CNIF launched at $(date)" > "${COHERENCE_DIR}/CNIF_LAUNCH_${TIMESTAMP}.complete"

log "INFO" "✅ All CNIF components started successfully"
log "INFO" "📋 Component summary:"
ps aux | grep node | grep -v grep | grep mcp-servers
log "INFO" "📝 Log file: ${LOG_FILE}"
log "INFO" "🔍 Use 'tail -f ${LOG_DIR}/*.log' to view detailed logs"

echo -e "\n${GREEN}✅ CNIF initialization complete. System operational.${NC}"
