#!/bin/bash
# verify-enhanced-servers.sh - Verify enhanced socket servers
# © 2025 XPV - MIT

# Define colors for better visibility
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Define paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
MCP_DIR="${ANCHOR_HOME}/mcp-servers"
LOG_DIR="${HOME}/Library/Logs/Claude"
SOCKET_DIR="${ANCHOR_HOME}/sockets"
CONFIG_DIR="${HOME}/Library/Application Support/Claude"
CONFIG_FILE="${CONFIG_DIR}/claude_desktop_config.json"

echo -e "${BLUE}=== Enhanced Socket Servers Check ===${NC}"
echo "Timestamp: $(date '+%Y-%m-%d %H:%M:%S')"
echo "Socket Directory: ${SOCKET_DIR}"
echo "Running on: $(uname -v)"

# Check socket directory
if [ -d "$SOCKET_DIR" ]; then
  echo -e "${GREEN}✓${NC} Socket directory exists"
  ls -la "$SOCKET_DIR"
else
  echo -e "${RED}✗${NC} Socket directory missing"
  mkdir -p "$SOCKET_DIR"
  echo -e "${YELLOW}  Created socket directory${NC}"
fi

# Check log directory
if [ -d "$LOG_DIR" ]; then
  echo -e "${GREEN}✓${NC} Log directory exists"
else
  echo -e "${RED}✗${NC} Log directory missing"
  mkdir -p "$LOG_DIR"
  echo -e "${YELLOW}  Created log directory${NC}"
fi

# Check running processes
echo -e "\n${BLUE}Socket Server Processes:${NC}"
for server in git-local notion anchor-manager; do
  PID_FILE="${MCP_DIR}/${server}.pid"
  if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    if ps -p "$PID" > /dev/null; then
      echo -e "${GREEN}✓${NC} ${server} socket server: Running (PID: $PID)"
    else
      echo -e "${RED}✗${NC} ${server} socket server: Not running (stale PID file: $PID)"
    fi
  else
    echo -e "${RED}✗${NC} ${server} socket server: Not running (no PID file)"
  fi
done

# Check socket files
echo -e "\n${BLUE}Socket Files:${NC}"
for server in git-local notion anchor-manager; do
  SOCKET_FILE="${SOCKET_DIR}/${server}.sock"
  if [ -S "$SOCKET_FILE" ]; then
    PERMS=$(ls -la "$SOCKET_FILE" | awk '{print $1}')
    echo -e "${GREEN}✓${NC} ${server} socket: Exists (permissions: $PERMS)"
  else
    echo -e "${RED}✗${NC} ${server} socket: Missing"
  fi
done

# Test socket connections
echo -e "\n${BLUE}Socket Connection Tests:${NC}"
for server in git-local notion anchor-manager; do
  SOCKET_FILE="${SOCKET_DIR}/${server}.sock"
  if [ -S "$SOCKET_FILE" ]; then
    # Try to connect to the socket with netcat
    if nc -U -z "$SOCKET_FILE" 2>/dev/null; then
      echo -e "${GREEN}✓${NC} ${server} socket: Connection successful"
    else
      echo -e "${YELLOW}!${NC} ${server} socket: File exists but connection failed"
    fi
  else
    echo -e "${RED}✗${NC} ${server} socket: File does not exist"
  fi
done

# Check Claude configuration
echo -e "\n${BLUE}Claude Configuration:${NC}"
if [ -f "$CONFIG_FILE" ]; then
  echo -e "${GREEN}✓${NC} Claude configuration file exists"
  
  # Check for MCP server configuration
  if grep -q "\"socketPath\"" "$CONFIG_FILE"; then
    echo -e "${GREEN}✓${NC} MCP socket paths configured"
    
    # Extract and display the socket paths
    echo -e "\nConfigured socket paths:"
    grep -A 1 "\"socketPath\"" "$CONFIG_FILE" | grep -v "\"socketPath\"" | sed 's/[",]//g' | sed 's/^[ \t]*//'
  else
    echo -e "${RED}✗${NC} MCP socket paths not configured"
  fi
else
  echo -e "${RED}✗${NC} Claude configuration file not found"
fi

# Check log files
echo -e "\n${BLUE}Log Files:${NC}"
for server in git-local notion anchor-manager; do
  LOG_FILE="${LOG_DIR}/mcp-server-${server}.log"
  if [ -f "$LOG_FILE" ]; then
    LAST_MODIFIED=$(stat -f "%Sm" -t "%Y-%m-%d %H:%M:%S" "$LOG_FILE")
    SIZE=$(du -h "$LOG_FILE" | cut -f1)
    echo -e "${GREEN}✓${NC} ${server} log: Exists (Last modified: $LAST_MODIFIED, Size: $SIZE)"
    echo "Latest log entries:"
    tail -n 3 "$LOG_FILE"
    echo "----------------"
  else
    echo -e "${RED}✗${NC} ${server} log: Missing"
  fi
done

# Check M3 optimization
echo -e "\n${BLUE}M3 Max Optimization:${NC}"
if [ -f "${ANCHOR_HOME}/.env" ]; then
  echo -e "${GREEN}✓${NC} M3 Max optimization file exists"
  echo "Current settings:"
  grep -E "NODE_OPTIONS|UV_THREADPOOL_SIZE" "${ANCHOR_HOME}/.env" | sed 's/^export //'
else
  echo -e "${RED}✗${NC} M3 Max optimization file missing"
fi

# Summary
echo -e "\n${BLUE}=== Summary ===${NC}"
RUNNING_COUNT=$(ps -ef | grep -E "enhanced-socket-server.js" | grep -v grep | wc -l)
if [ $RUNNING_COUNT -eq 3 ] && ls -la "${SOCKET_DIR}"/*.sock >/dev/null 2>&1; then
  echo -e "${GREEN}All enhanced socket servers are running properly.${NC}"
  echo "Claude should now be able to connect to all MCP servers."
else
  echo -e "${RED}One or more enhanced socket servers are not running or socket files are missing.${NC}"
  echo "To restart socket servers, run:"
  echo "  ${ANCHOR_HOME}/launch-enhanced-servers.sh"
fi

# Provide next steps
echo -e "\n${BLUE}Next Steps:${NC}"
echo "1. Restart Claude Desktop application if it's already running"
echo "2. Check Developer settings in Claude to verify MCP servers"
echo "3. If issues persist, check logs in: ${LOG_DIR}"
