#!/bin/bash
# recover-cnif.sh - Comprehensive recovery for Claude-Notion Integration Framework
# © 2025 XPV - MIT

set -e

# Define colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color
BLUE='\033[0;34m'

# Base paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
SOCKET_DIR="$ANCHOR_HOME/sockets"
COHERENCE_LOCK_DIR="$ANCHOR_HOME/coherence_lock"
LOG_DIR="$HOME/Library/Logs/Claude"
CONFIG_DIR="$ANCHOR_HOME/data"
MCP_DIR="$ANCHOR_HOME/mcp-servers"
PID_DIR="$MCP_DIR"

echo -e "${BLUE}==================================================${NC}"
echo -e "${BLUE}CNIF System Recovery                              ${NC}"
echo -e "${BLUE}==================================================${NC}"
echo -e "${YELLOW}This script performs a deeper recovery process than repair-cnif.sh${NC}"

# 1. Make all scripts executable
echo -e "\n${BLUE}Making scripts executable...${NC}"
chmod +x "$ANCHOR_HOME/make-scripts-executable.sh"
"$ANCHOR_HOME/make-scripts-executable.sh"

# 2. Kill any running processes (more aggressive)
echo -e "\n${BLUE}Stopping all running processes...${NC}"

# Define server list
servers=("socket-server" "notion" "schema-registry" "streaming-transformer" "mcp-orchestrator" "dashboard")

# Kill processes by PID files if they exist
for server in "${servers[@]}"; do
  pid_file="$PID_DIR/$server.pid"
  if [ -f "$pid_file" ]; then
    pid=$(cat "$pid_file")
    if ps -p "$pid" > /dev/null 2>&1; then
      echo -e "${YELLOW}Stopping $server (PID: $pid)...${NC}"
      kill -15 "$pid" 2>/dev/null || kill -9 "$pid" 2>/dev/null || true
    else
      echo -e "${YELLOW}Process $server (PID: $pid) not running${NC}"
    fi
    rm -f "$pid_file"
  fi
done

# Kill any node processes that might be related
echo -e "${YELLOW}Looking for other node processes...${NC}"
node_pids=$(ps -ef | grep node | grep -v grep | grep -v recover | awk '{print $2}')
if [ -n "$node_pids" ]; then
  echo -e "${YELLOW}Found node processes: $node_pids${NC}"
  for pid in $node_pids; do
    echo -e "${YELLOW}Stopping node process (PID: $pid)...${NC}"
    kill -15 "$pid" 2>/dev/null || kill -9 "$pid" 2>/dev/null || true
  done
fi

# 3. Clean up socket files (more thorough)
echo -e "\n${BLUE}Cleaning up socket files...${NC}"
if [ -d "$SOCKET_DIR" ]; then
  # Remove both socket dir and recreate
  rm -rf "$SOCKET_DIR"
  mkdir -p "$SOCKET_DIR"
  chmod 755 "$SOCKET_DIR"
  echo -e "${GREEN}✅ Socket directory recreated with proper permissions${NC}"
else
  mkdir -p "$SOCKET_DIR"
  chmod 755 "$SOCKET_DIR"
  echo -e "${GREEN}✅ Created socket directory with proper permissions${NC}"
fi

# 4. Clean up coherence markers and recreate directory
echo -e "\n${BLUE}Cleaning up coherence markers...${NC}"
if [ -d "$COHERENCE_LOCK_DIR" ]; then
  # Remove and recreate
  rm -rf "$COHERENCE_LOCK_DIR"
  mkdir -p "$COHERENCE_LOCK_DIR"
  chmod 755 "$COHERENCE_LOCK_DIR"
  echo -e "${GREEN}✅ Coherence lock directory recreated${NC}"
else
  mkdir -p "$COHERENCE_LOCK_DIR"
  chmod 755 "$COHERENCE_LOCK_DIR"
  echo -e "${GREEN}✅ Created coherence lock directory${NC}"
fi

# 5. Clear log files for clean debugging
echo -e "\n${BLUE}Clearing log files for fresh start...${NC}"
mkdir -p "$LOG_DIR"
rm -f "$LOG_DIR"/*.log
echo -e "${GREEN}✅ Log directory cleaned${NC}"

# 6. Create/Recreate config directory
echo -e "\n${BLUE}Setting up configuration...${NC}"
mkdir -p "$CONFIG_DIR"
chmod 755 "$CONFIG_DIR"

# Create default config
echo '{
  "rootPageId": "",
  "enabledDatabases": [],
  "syncInterval": 30000,
  "rateLimitPerSecond": 3
}' > "$CONFIG_DIR/notion-config.json"
echo -e "${GREEN}✅ Created default Notion config${NC}"

# 7. Validate environment with basic test
echo -e "\n${BLUE}Validating Node.js environment...${NC}"
"$ANCHOR_HOME/run-basic-test.sh"

# 8. Test individual components sequentially
echo -e "\n${BLUE}Testing socket server component...${NC}"
"$ANCHOR_HOME/debug-server.sh" socket-server & 
SERVER_PID=$!

echo -e "${YELLOW}Waiting 5 seconds for socket server to initialize...${NC}"
sleep 5

# Check if socket server is running
if ps -p "$SERVER_PID" > /dev/null; then
  echo -e "${GREEN}✅ Socket server test successful${NC}"
  
  # Check socket file
  if [ -e "$SOCKET_DIR/socket-server.sock" ]; then
    perms=$(stat -f "%p" "$SOCKET_DIR/socket-server.sock" | cut -c 3-5)
    echo -e "${GREEN}✅ Socket file created with permissions: $perms${NC}"
    
    # Fix permissions if needed
    if [ "$perms" != "666" ]; then
      echo -e "${YELLOW}Fixing socket permissions...${NC}"
      chmod 666 "$SOCKET_DIR/socket-server.sock"
      perms=$(stat -f "%p" "$SOCKET_DIR/socket-server.sock" | cut -c 3-5)
      echo -e "${GREEN}✅ Socket permissions updated to: $perms${NC}"
    fi
  else
    echo -e "${RED}❌ Socket file not created!${NC}"
  fi
  
  # Stop the test server
  kill $SERVER_PID
  wait $SERVER_PID 2>/dev/null || true
else
  echo -e "${RED}❌ Socket server test failed!${NC}"
  echo -e "${YELLOW}Check logs at $LOG_DIR/socket-server_debug.log${NC}"
fi

echo -e "\n${GREEN}✅ CNIF system recovery complete!${NC}"
echo -e "${BLUE}The system has been reset to a clean state.${NC}"
echo -e "${BLUE}You can now run the system with:${NC}"
echo -e "  ${YELLOW}cd $ANCHOR_HOME${NC}"
echo -e "  ${YELLOW}./launch-optimized.sh${NC}"
