#!/bin/bash
# launch-mcp-servers.sh - Fully optimized MCP server launcher for M3 Max
# © 2025 XPV - MIT License

set -e  # Exit on error

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'

# Core paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
SOCKET_DIR="${ANCHOR_HOME}/sockets"
MCP_DIR="${ANCHOR_HOME}/mcp-servers"
LOG_DIR="${HOME}/Library/Logs/Claude"
DATA_DIR="${ANCHOR_HOME}/data"

# Ensure M3 Max optimizations are applied
export NODE_OPTIONS="--max-old-space-size=16384"
export UV_THREADPOOL_SIZE="12"

echo -e "${BLUE}=== Launching MCP Servers with M3 Max Optimizations (v6.1.0) ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e "Node.js: $(node -v)"
echo -e "Hardware: Apple M3 Max (48GB)"
echo -e "Memory settings: ${NODE_OPTIONS}"
echo -e "Thread pool: UV_THREADPOOL_SIZE=${UV_THREADPOOL_SIZE}"

# Create required directories with proper permissions
mkdir -p "${SOCKET_DIR}"
chmod 775 "${SOCKET_DIR}"
mkdir -p "${LOG_DIR}"
mkdir -p "${DATA_DIR}/sqlite"

# Stop any running servers
echo -e "${YELLOW}Stopping any running MCP servers...${NC}"
pkill -f "git-local-optimized.js|notion.*wrapper.js|anchor-manager-optimized.js|enhanced-socket-server.js" 2>/dev/null || true
sleep 1

# Clean up any leftover socket files
rm -f "${SOCKET_DIR}"/*.sock 2>/dev/null || true

# Clean up PID files
rm -f "${MCP_DIR}"/*.pid 2>/dev/null || true

# Function to launch a server
launch_server() {
    local name=$1
    local script=$2
    local log_file="${LOG_DIR}/mcp-server-${name}.log"
    local pid_file="${MCP_DIR}/${name}.pid"
    
    echo -e "${BLUE}Starting ${name} server...${NC}"
    
    # Launch with optimized environment variables
    SOCKET_DIR="${SOCKET_DIR}" MCP_SERVER_NAME="${name}" \
        NODE_OPTIONS="--max-old-space-size=8192" UV_THREADPOOL_SIZE="12" \
        ANCHOR_HOME="${ANCHOR_HOME}" \
        node "${script}" > "${log_file}" 2>&1 &
    
    PID=$!
    echo $PID > "${pid_file}"
    
    # Give the server a moment to start
    sleep 0.5
    
    # Check if process is still running
    if ps -p $PID > /dev/null; then
        echo -e "${GREEN}✅ Started ${name} server (PID: $PID)${NC}"
    else
        echo -e "${RED}❌ Failed to start ${name} server${NC}"
        cat "${log_file}" | tail -10
    fi
}

# Launch core servers with enhanced socket implementation
echo -e "${BLUE}Launching core MCP servers...${NC}"

# 1. Git Local Server
launch_server "git-local" "${MCP_DIR}/git-local-optimized.js"

# 2. Notion Server (use v5 wrapper or integration based on availability)
if [ -f "${MCP_DIR}/notion-integration.js" ]; then
    launch_server "notion" "${MCP_DIR}/notion-integration.js"
else
    launch_server "notion" "${MCP_DIR}/notion-v5-wrapper.js"
fi

# 3. Anchor Manager
launch_server "anchor-manager" "${MCP_DIR}/anchor-manager-optimized.js"

# Verify sockets exist and have correct permissions
echo -e "${BLUE}Verifying socket files...${NC}"
for server in git-local notion anchor-manager; do
    SOCKET_FILE="${SOCKET_DIR}/${server}.sock"
    if [ -S "${SOCKET_FILE}" ]; then
        PERMS=$(stat -f "%Lp" "${SOCKET_FILE}")
        echo -e "${GREEN}✅ ${server}.sock: Found with permissions ${PERMS}${NC}"
        
        # Fix permissions if needed
        if [ "$PERMS" != "666" ]; then
            chmod 666 "${SOCKET_FILE}"
            echo -e "${YELLOW}⚠️ Fixed permissions on ${server}.sock${NC}"
        fi
    else
        echo -e "${RED}❌ ${server}.sock: Not found or not a socket${NC}"
    fi
done

# Update Claude Desktop configuration
echo -e "${BLUE}Updating Claude Desktop configuration...${NC}"
if [ -f "${ANCHOR_HOME}/new_claude_config.json" ]; then
    CONFIG_DIR="${HOME}/Library/Application Support/Claude"
    mkdir -p "${CONFIG_DIR}"
    cp "${ANCHOR_HOME}/claude_desktop_config.json" "${CONFIG_DIR}/claude_desktop_config.json.bak.$(date +%Y%m%d_%H%M%S)" 2>/dev/null || true
    cp "${ANCHOR_HOME}/new_claude_config.json" "${CONFIG_DIR}/claude_desktop_config.json"
    echo -e "${GREEN}✅ Updated Claude Desktop configuration${NC}"
else
    echo -e "${YELLOW}⚠️ Using existing Claude Desktop configuration${NC}"
fi

echo -e "\n${GREEN}All MCP servers started with M3 Max optimizations!${NC}"
echo -e "${YELLOW}Remember to restart Claude Desktop to connect to the servers${NC}"
echo -e "${BLUE}To verify server status, run: ${ANCHOR_HOME}/mcp-servers/verify-servers.sh${NC}"
