#!/usr/bin/env node

const net = require('net');
const fs = require('fs');
const readline = require('readline');

// Get server name and socket path from command-line arguments
const serverName = process.argv[2];
const socketPath = process.argv[3];

if (!serverName || !socketPath) {
  console.error('Usage: node stdio-socket-bridge.js <server-name> <socket-path>');
  process.exit(1);
}

// Create socket connection
const socket = net.createConnection({ path: socketPath }, () => {
  fs.writeSync(2, `[${serverName}-bridge] Connected to socket: ${socketPath}\n`);
});

// Set up readline for stdin
const rl = readline.createInterface({
  input: process.stdin,
  output: null,
  terminal: false
});

// Forward stdin lines to socket
rl.on('line', (line) => {
  try {
    // Log what we're sending
    fs.writeSync(2, `[${serverName}-bridge] >>> ${line}\n`);
    socket.write(line + '\n');
  } catch (err) {
    fs.writeSync(2, `[${serverName}-bridge] Error sending to socket: ${err.message}\n`);
  }
});

// Forward socket data to stdout
socket.on('data', (data) => {
  try {
    const text = data.toString();
    // Log what we're receiving
    fs.writeSync(2, `[${serverName}-bridge] <<< ${text.trim()}\n`);
    process.stdout.write(data);
  } catch (err) {
    fs.writeSync(2, `[${serverName}-bridge] Error receiving from socket: ${err.message}\n`);
  }
});

// Handle errors
socket.on('error', (err) => {
  fs.writeSync(2, `[${serverName}-bridge] Socket error: ${err.message}\n`);
});

// Handle connection close
socket.on('close', () => {
  fs.writeSync(2, `[${serverName}-bridge] Socket connection closed\n`);
  process.exit(0);
});

// Handle process signal
process.on('SIGINT', () => {
  socket.destroy();
  process.exit(0);
});
