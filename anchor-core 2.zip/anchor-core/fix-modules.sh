#!/bin/bash
# fix-modules.sh - Fix Module System for CNIF
# © 2025 XPV - MIT

set -e

# Define colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color
BLUE='\033[0;34m'

# Base paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
SOCKET_DIR="$ANCHOR_HOME/sockets"
COHERENCE_LOCK_DIR="$ANCHOR_HOME/coherence_lock"
LOG_DIR="$HOME/Library/Logs/Claude"
CONFIG_DIR="$ANCHOR_HOME/data"
MCP_DIR="$ANCHOR_HOME/mcp-servers"
PID_DIR="$MCP_DIR"

echo -e "${BLUE}==================================================${NC}"
echo -e "${BLUE}CNIF Module System Fix                            ${NC}"
echo -e "${BLUE}==================================================${NC}"

# 1. Make sure scripts are executable
echo -e "\n${BLUE}Making scripts executable...${NC}"
chmod +x "$ANCHOR_HOME/make-scripts-executable.sh"
"$ANCHOR_HOME/make-scripts-executable.sh"

# 2. Kill any running processes (more aggressive)
echo -e "\n${BLUE}Stopping all running processes...${NC}"

# Define server list
servers=("socket-server" "notion" "schema-registry" "streaming-transformer" "mcp-orchestrator" "dashboard")

# Kill processes by PID files if they exist
for server in "${servers[@]}"; do
  pid_file="$PID_DIR/$server.pid"
  if [ -f "$pid_file" ]; then
    pid=$(cat "$pid_file")
    if ps -p "$pid" > /dev/null 2>&1; then
      echo -e "${YELLOW}Stopping $server (PID: $pid)...${NC}"
      kill -15 "$pid" 2>/dev/null || kill -9 "$pid" 2>/dev/null || true
    else
      echo -e "${YELLOW}Process $server (PID: $pid) not running${NC}"
    fi
    rm -f "$pid_file"
  fi
done

# 3. Verify Node.js CommonJS support
echo -e "\n${BLUE}Verifying CommonJS support...${NC}"
chmod +x "$ANCHOR_HOME/test-commonjs.sh"
"$ANCHOR_HOME/test-commonjs.sh"

# 4. Test the socket server component
echo -e "\n${BLUE}Testing socket server...${NC}"
"$ANCHOR_HOME/debug-server.sh" socket-server &
SERVER_PID=$!

# Wait a bit for the server to start
sleep 3

# Check if server is running
if ps -p "$SERVER_PID" > /dev/null; then
  echo -e "${GREEN}✅ Socket server started successfully${NC}"
  
  # Check for the socket file
  if [ -e "$SOCKET_DIR/socket-server.sock" ]; then
    echo -e "${GREEN}✅ Socket file created successfully${NC}"
    
    # Get permissions
    perms=$(stat -f "%p" "$SOCKET_DIR/socket-server.sock" | cut -c 3-5)
    echo -e "${GREEN}✅ Socket permissions: $perms${NC}"
    
    # Fix permissions if needed
    if [ "$perms" != "666" ]; then
      echo -e "${YELLOW}Fixing socket permissions...${NC}"
      chmod 666 "$SOCKET_DIR/socket-server.sock"
    fi
  else
    echo -e "${RED}❌ Socket file not created${NC}"
  fi
  
  # Stop the server
  kill "$SERVER_PID"
  wait "$SERVER_PID" 2>/dev/null || true
else
  echo -e "${RED}❌ Socket server test failed${NC}"
  echo -e "${YELLOW}Check debug log for details: $LOG_DIR/socket-server_debug.log${NC}"
fi

# 5. Run the system
echo -e "\n${BLUE}Starting the CNIF system...${NC}"
"$ANCHOR_HOME/launch-optimized.sh"

echo -e "\n${GREEN}✅ Module system fix complete!${NC}"
echo -e "${BLUE}CNIF system should now be running with CommonJS support.${NC}"
