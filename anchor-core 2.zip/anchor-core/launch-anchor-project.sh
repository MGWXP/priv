#!/bin/bash
# Launch MCP dashboard and documentation preview

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

echo -e "${BLUE}=== Anchor V6 MCP Project Launcher ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"

# Make sure all scripts are executable
chmod +x /Users/XPV/Desktop/anchor-core/mcp-environment-verifier.sh
chmod +x /Users/XPV/Desktop/anchor-core/mcp-dashboard.sh
chmod +x /Users/XPV/Desktop/anchor-core/mcp-alias-setup.sh
chmod +x /Users/XPV/Desktop/anchor-core/notion-workspace-creator.sh
chmod +x /Users/XPV/Desktop/anchor-core/setup-notion-workspace.sh

# Check if NOTION_API_KEY is set
if [ -z "${NOTION_API_KEY}" ]; then
    echo -e "${YELLOW}Warning: NOTION_API_KEY environment variable is not set${NC}"
    echo -e "Would you like to set it now? (y/n)"
    read -r response
    if [[ "$response" =~ ^([yY][eE][sS]|[yY])$ ]]; then
        echo -e "Enter your Notion API Key:"
        read -s NOTION_KEY
        export NOTION_API_KEY="$NOTION_KEY"
        echo -e "${GREEN}✓ NOTION_API_KEY set${NC}"
    else
        echo -e "${YELLOW}Skipping NOTION_API_KEY setup${NC}"
    fi
fi

# Launch the setup script
echo -e "${BLUE}Setting up Notion workspace...${NC}"
/Users/XPV/Desktop/anchor-core/setup-notion-workspace.sh

# Open the documentation
echo -e "${BLUE}Opening documentation...${NC}"
open /Users/XPV/Desktop/anchor-core/anchor-mcp-documentation.md

# Launch the dashboard
echo -e "${BLUE}Launching MCP dashboard...${NC}"
/Users/XPV/Desktop/anchor-core/mcp-dashboard.sh
