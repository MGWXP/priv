#!/bin/bash
# fix-cnif-modules.sh - Run the CNIF module fixer
# © 2025 XPV - MIT

echo "======================================================"
echo "CNIF Module System Fix (ES Module to CommonJS)         "
echo "======================================================"

# Make the fixer executable
chmod +x /Users/XPV/Desktop/anchor-core/cnif-module-fixer.js

# Run the fixer script
node /Users/XPV/Desktop/anchor-core/cnif-module-fixer.js

# Make it executable
chmod +x /Users/XPV/Desktop/anchor-core/launch-optimized.sh

echo ""
echo "======================================================"
echo "Module system fix complete! Run the system with:       "
echo "/Users/XPV/Desktop/anchor-core/launch-optimized.sh     "
echo "======================================================"
