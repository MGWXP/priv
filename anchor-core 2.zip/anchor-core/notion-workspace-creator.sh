#!/bin/bash
# notion-workspace-creator.sh - Creates the initial Anchor workspace in Notion
# For M3 Max (48GB unified memory) hardware

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

NOTION_PAGE_ID="1f7e48c2bbbd80df86edd35832916f80"

echo -e "${BLUE}=== Creating Anchor Workspace in Notion ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e "Target page: https://www.notion.so/Anchor-${NOTION_PAGE_ID}"
echo -e ""

# Check if NOTION_API_KEY is set
if [ -z "${NOTION_API_KEY}" ]; then
    echo -e "${RED}Error: NOTION_API_KEY environment variable is not set${NC}"
    echo -e "Please set your Notion API key first with:"
    echo -e "export NOTION_API_KEY=\"your_notion_api_key\""
    exit 1
fi

# Create initial workspace structure
echo -e "${BLUE}Creating workspace structure...${NC}"

# Use curl to interact with Notion API
echo -e "${YELLOW}Updating Anchor page content...${NC}"

curl -X PATCH "https://api.notion.com/v1/pages/${NOTION_PAGE_ID}" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "properties": {
      "title": {
        "title": [
          {
            "text": {
              "content": "Anchor V6 MCP Project"
            }
          }
        ]
      }
    }
  }'

echo -e "\n${YELLOW}Creating MCP Servers database...${NC}"

curl -X POST "https://api.notion.com/v1/blocks/${NOTION_PAGE_ID}/children" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "children": [
      {
        "object": "block",
        "type": "heading_2",
        "heading_2": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "MCP Server Configuration"
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "paragraph",
        "paragraph": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "This workspace contains configuration and documentation for the Anchor V6 MCP system running on M3 Max hardware."
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "callout",
        "callout": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "All servers are currently active and optimized for 48GB unified memory with NODE_OPTIONS=--max-old-space-size=8192 and UV_THREADPOOL_SIZE=12"
              }
            }
          ],
          "icon": {
            "emoji": "✅"
          },
          "color": "green"
        }
      },
      {
        "object": "block",
        "type": "heading_3",
        "heading_3": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "MCP Servers Status"
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "table",
        "table": {
          "table_width": 3,
          "has_column_header": true,
          "has_row_header": false,
          "children": [
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [
                    {
                      "type": "text",
                      "text": {
                        "content": "Server"
                      }
                    }
                  ],
                  [
                    {
                      "type": "text",
                      "text": {
                        "content": "Status"
                      }
                    }
                  ],
                  [
                    {
                      "type": "text",
                      "text": {
                        "content": "Tools"
                      }
                    }
                  ]
                ]
              }
            },
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [
                    {
                      "type": "text",
                      "text": {
                        "content": "Filesystem"
                      }
                    }
                  ],
                  [
                    {
                      "type": "text",
                      "text": {
                        "content": "RUNNING"
                      }
                    }
                  ],
                  [
                    {
                      "type": "text",
                      "text": {
                        "content": "11"
                      }
                    }
                  ]
                ]
              }
            },
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [
                    {
                      "type": "text",
                      "text": {
                        "content": "Notion"
                      }
                    }
                  ],
                  [
                    {
                      "type": "text",
                      "text": {
                        "content": "RUNNING"
                      }
                    }
                  ],
                  [
                    {
                      "type": "text",
                      "text": {
                        "content": "19"
                      }
                    }
                  ]
                ]
              }
            },
            {
              "type": "table_row",
              "table_row": {
                "cells": [
                  [
                    {
                      "type": "text",
                      "text": {
                        "content": "Slack"
                      }
                    }
                  ],
                  [
                    {
                      "type": "text",
                      "text": {
                        "content": "RUNNING"
                      }
                    }
                  ],
                  [
                    {
                      "type": "text",
                      "text": {
                        "content": "8"
                      }
                    }
                  ]
                ]
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "heading_3",
        "heading_3": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "System Configuration"
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "code",
        "code": {
          "caption": [],
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "{\n  \"mcpServers\": {\n    \"filesystem\": {\n      \"command\": \"npx\",\n      \"args\": [\n        \"-y\",\n        \"@modelcontextprotocol/server-filesystem\",\n        \"/Users/XPV/Desktop\",\n        \"/Users/XPV/Library\",\n        \"/Users/XPV/Documents\"\n      ],\n      \"env\": {\n        \"NODE_OPTIONS\": \"--max-old-space-size=8192\",\n        \"UV_THREADPOOL_SIZE\": \"12\"\n      }\n    },\n    \"notion\": {\n      \"command\": \"npx\",\n      \"args\": [\n        \"-y\",\n        \"@notionhq/notion-mcp-server\"\n      ],\n      \"env\": {\n        \"NODE_OPTIONS\": \"--max-old-space-size=8192\",\n        \"UV_THREADPOOL_SIZE\": \"12\",\n        \"OPENAPI_MCP_HEADERS\": \"{\\\"Authorization\\\": \\\"Bearer ${NOTION_API_KEY}\\\", \\\"Notion-Version\\\": \\\"2022-06-28\\\" }\"\n      }\n    },\n    \"slack\": {\n      \"command\": \"npx\",\n      \"args\": [\n        \"-y\",\n        \"@modelcontextprotocol/server-slack\"\n      ],\n      \"env\": {\n        \"NODE_OPTIONS\": \"--max-old-space-size=8192\",\n        \"UV_THREADPOOL_SIZE\": \"12\",\n        \"SLACK_BOT_TOKEN\": \"${SLACK_BOT_TOKEN}\",\n        \"SLACK_TEAM_ID\": \"${SLACK_TEAM_ID}\"\n      }\n    }\n  }\n}"
              }
            }
          ],
          "language": "json"
        }
      },
      {
        "object": "block",
        "type": "heading_3",
        "heading_3": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Next Steps"
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "to_do",
        "to_do": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Configure Slack API Integration"
              }
            }
          ],
          "checked": false,
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "to_do",
        "to_do": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Document available tools for each MCP server"
              }
            }
          ],
          "checked": false,
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "to_do",
        "to_do": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Create automated system health monitor"
              }
            }
          ],
          "checked": false,
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "to_do",
        "to_do": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Establish backup and restore procedures"
              }
            }
          ],
          "checked": false,
          "color": "default"
        }
      },
      {
        "object": "block",
        "type": "heading_3",
        "heading_3": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "Management Scripts"
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "bulleted_list_item",
        "bulleted_list_item": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "/Users/XPV/Desktop/anchor-core/mcp-environment-verifier.sh - Verifies the MCP environment"
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "bulleted_list_item",
        "bulleted_list_item": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "/Users/XPV/Desktop/anchor-core/mcp-dashboard.sh - Interactive MCP management dashboard"
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "bulleted_list_item",
        "bulleted_list_item": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "/Users/XPV/Desktop/anchor-core/mcp-alias-setup.sh - Sets up helpful shell aliases"
              }
            }
          ]
        }
      },
      {
        "object": "block",
        "type": "bulleted_list_item",
        "bulleted_list_item": {
          "rich_text": [
            {
              "type": "text",
              "text": {
                "content": "/Users/XPV/Desktop/anchor-core/mcp-system-documentation.md - System documentation"
              }
            }
          ]
        }
      }
    ]
  }'

echo -e "\n${GREEN}✓ Anchor workspace created successfully!${NC}"
echo -e "${YELLOW}View your workspace at: https://www.notion.so/Anchor-${NOTION_PAGE_ID}${NC}"
