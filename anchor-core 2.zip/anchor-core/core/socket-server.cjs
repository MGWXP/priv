/**
 * socket-server.cjs - Enhanced socket server for CNIF
 * © 2025 XPV - MIT
 * 
 * Implements a resilient Unix socket server for MCP communication
 * with circuit breaker pattern, message buffering, and M3 Max optimizations.
 */

const fs = require('fs');
const net = require('net');
const path = require('path');
const os = require('os');
const { EventEmitter } = require('events');
const { CircuitBreaker, CircuitState } = require('./circuit-breaker.cjs');

/**
 * SocketServer implements a Unix socket server with
 * - Message buffering and framing
 * - Circuit breaker pattern
 * - Coherence locking
 * - Proper resource management
 * - M3 Max optimizations
 */
class SocketServer extends EventEmitter {
  /**
   * Create a new SocketServer
   * @param {object} options - Server options
   */
  constructor(options = {}) {
    super();
    
    // Configure from options and environment
    this.options = {
      serverName: options.serverName || process.env.MCP_SERVER_NAME || 'socket-server',
      anchorHome: options.anchorHome || process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core',
      socketDir: options.socketDir || process.env.SOCKET_DIR || path.join(process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core', 'sockets'),
      logDir: options.logDir || process.env.LOG_DIR || path.join(os.homedir(), 'Library/Logs/Claude'),
      socketPath: options.socketPath || null,
      bufferSize: options.bufferSize || 65536, // 64KB buffer
      heartbeatInterval: options.heartbeatInterval || 30000, // 30 seconds
      memoryOptimized: options.memoryOptimized !== false,
      ...options
    };
    
    // Calculate socket path if not provided
    if (!this.options.socketPath) {
      this.options.socketPath = path.join(this.options.socketDir, `${this.options.serverName}.sock`);
    }
    
    // Calculate log file path
    this.logFile = path.join(this.options.logDir, `${this.options.serverName}.log`);
    
    // Initialize metrics
    this.metrics = {
      startTime: Date.now(),
      messagesReceived: 0,
      messagesSent: 0,
      errors: 0,
      clientsConnected: 0,
      clientsTotal: 0,
      lastMessageTime: 0
    };
    
    // Initialize circuit breaker
    this.circuitBreaker = new CircuitBreaker({
      name: `socket-${this.options.serverName}`,
      failureThreshold: 5,
      resetTimeout: 60000,
      degradeThreshold: 3,
      degradePercentage: 0.3
    });
    
    // Initialize state
    this.server = null;
    this.clients = new Map();
    this.isShuttingDown = false;
    this.coherenceMarkerPath = null;
    
    // Bind event handlers to maintain context
    this._handleConnection = this._handleConnection.bind(this);
    this._handleServerError = this._handleServerError.bind(this);
    this._createCoherenceMarker = this._createCoherenceMarker.bind(this);
    
    // Set up process event handlers
    process.on('SIGINT', () => this.stop());
    process.on('SIGTERM', () => this.stop());
    process.on('exit', () => this._cleanup());
  }
  
  /**
   * Start the socket server
   * @returns {Promise<boolean>} Promise resolving to success status
   */
  async start() {
    this.log('INFO', `Starting ${this.options.serverName} socket server...`);
    
    try {
      // Ensure directories exist
      await this._ensureDirectories();
      
      // Clean up existing socket file
      await this._cleanupExistingSocket();
      
      // Create coherence marker
      this.coherenceMarkerPath = this._createCoherenceMarker();
      
      // Create server
      this.server = net.createServer(this._handleConnection);
      
      // Set up error handler
      this.server.on('error', this._handleServerError);
      
      // Start listening
      await new Promise((resolve, reject) => {
        this.server.listen(this.options.socketPath, () => {
          this.log('INFO', `Server listening on ${this.options.socketPath}`);
          
          // Set permissions on socket file (666 = rw-rw-rw-)
          try {
            fs.chmodSync(this.options.socketPath, 0o666);
            const stats = fs.statSync(this.options.socketPath);
            const perms = stats.mode & 0o777;
            
            if (perms !== 0o666) {
              this.log('WARN', `Socket permissions not correctly set: ${perms.toString(8)} instead of 666`);
              
              // Try more aggressive permission setting
              try {
                const { execSync } = require('child_process');
                execSync(`chmod 666 ${this.options.socketPath}`);
                this.log('INFO', 'Manually set socket permissions with chmod command');
              } catch (chmodErr) {
                this.log('ERROR', `Failed to set permissions with direct chmod: ${chmodErr.message}`);
              }
            } else {
              this.log('INFO', 'Set permissions on socket file: 0666');
            }
          } catch (err) {
            this.log('ERROR', `Failed to set permissions on socket file: ${err.message}`);
            // Continue anyway
          }
          
          resolve(true);
        });
        
        this.server.on('error', reject);
      });
      
      // Start health check interval
      this._startHealthCheck();
      
      this.log('INFO', `${this.options.serverName} socket server started (PID: ${process.pid})`);
      this.emit('started');
      
      return true;
    } catch (err) {
      this.log('ERROR', `Failed to start server: ${err.message}`);
      this.emit('error', err);
      throw err;
    }
  }
  
  /**
   * Stop the socket server
   * @returns {Promise<boolean>} Promise resolving to success status
   */
  async stop() {
    if (this.isShuttingDown) {
      return true; // Already shutting down
    }
    
    this.isShuttingDown = true;
    this.log('INFO', 'Shutting down socket server...');
    
    // Notify all clients
    for (const client of this.clients.values()) {
      try {
        if (client.socket && client.socket.writable) {
          client.socket.write(JSON.stringify({
            type: 'server_shutdown',
            timestamp: new Date().toISOString(),
            server: this.options.serverName
          }) + '\n');
        }
      } catch (err) {
        this.log('ERROR', `Error notifying client of shutdown: ${err.message}`, { clientId: client.id });
      }
    }
    
    // Close server and all client connections
    if (this.server) {
      await new Promise(resolve => {
        this.server.close(resolve);
        
        // Force close all client connections
        for (const client of this.clients.values()) {
          try {
            if (client.socket) {
              client.socket.destroy();
            }
          } catch (err) {
            this.log('ERROR', `Error closing client socket: ${err.message}`, { clientId: client.id });
          }
        }
      });
    }
    
    // Clear clients map
    this.clients.clear();
    
    // Stop health check
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
      this.healthCheckInterval = null;
    }
    
    // Clean up resources
    this._cleanup();
    
    this.log('INFO', `${this.options.serverName} socket server stopped`);
    this.emit('stopped');
    
    return true;
  }
  
  /**
   * Handle client connection
   * @param {net.Socket} socket - Client socket
   * @private
   */
  _handleConnection(socket) {
    const clientId = Date.now().toString(36) + Math.random().toString(36).substr(2);
    
    // Update metrics
    this.metrics.clientsConnected++;
    this.metrics.clientsTotal++;
    
    // Configure socket for performance
    if (socket.setNoDelay) socket.setNoDelay(true);
    if (this.options.bufferSize && socket.setRecvBufferSize) {
      socket.setRecvBufferSize(this.options.bufferSize);
    }
    if (this.options.bufferSize && socket.setSendBufferSize) {
      socket.setSendBufferSize(this.options.bufferSize);
    }
    
    // Initialize client state
    const client = {
      id: clientId,
      socket,
      connected: true,
      buffer: '',
      heartbeatInterval: null,
      lastMessageTime: Date.now(),
      messagesReceived: 0,
      messagesSent: 0,
      errors: 0
    };
    
    this.clients.set(clientId, client);
    
    this.log('INFO', 'Client connected', { clientId });
    this.emit('client-connected', { clientId });
    
    // Setup heartbeat
    client.heartbeatInterval = setInterval(() => {
      try {
        if (socket.writable) {
          const heartbeat = {
            type: 'heartbeat',
            timestamp: new Date().toISOString(),
            server: this.options.serverName
          };
          
          socket.write(JSON.stringify(heartbeat) + '\n');
          
          // Update metrics
          client.messagesSent++;
          this.metrics.messagesSent++;
        }
      } catch (err) {
        this.log('ERROR', `Failed to send heartbeat: ${err.message}`, { clientId });
        client.errors++;
        this.metrics.errors++;
      }
    }, this.options.heartbeatInterval);
    
    // Handle data
    socket.on('data', (data) => {
      try {
        // Update metrics
        client.lastMessageTime = Date.now();
        this.metrics.lastMessageTime = client.lastMessageTime;
        
        // Append data to buffer
        client.buffer += data.toString();
        
        // Get complete messages
        const messages = this._getMessages(client.buffer);
        client.buffer = messages.remainder;
        
        // Process messages
        for (const message of messages.messages) {
          this._processMessage(message, client);
        }
      } catch (err) {
        this.log('ERROR', `Error processing data: ${err.message}`, { clientId });
        client.errors++;
        this.metrics.errors++;
      }
    });
    
    // Handle disconnection
    socket.on('end', () => {
      this._handleClientDisconnect(clientId);
    });
    
    // Handle errors
    socket.on('error', (err) => {
      this.log('ERROR', `Socket error: ${err.message}`, { clientId });
      client.errors++;
      this.metrics.errors++;
    });
    
    // Handle socket close
    socket.on('close', () => {
      this._handleClientDisconnect(clientId);
    });
  }
  
  /**
   * Handle client disconnection
   * @param {string} clientId - Client ID
   * @private
   */
  _handleClientDisconnect(clientId) {
    const client = this.clients.get(clientId);
    if (!client) return;
    
    if (client.connected) {
      client.connected = false;
      
      // Clear heartbeat interval
      if (client.heartbeatInterval) {
        clearInterval(client.heartbeatInterval);
        client.heartbeatInterval = null;
      }
      
      // Update metrics
      this.metrics.clientsConnected--;
      
      this.log('INFO', 'Client disconnected', { clientId });
      this.emit('client-disconnected', { clientId });
      
      // Remove client after a delay to allow for reconnects
      setTimeout(() => {
        this.clients.delete(clientId);
      }, 5000);
    }
  }
  
  /**
   * Handle server error
   * @param {Error} err - Error object
   * @private
   */
  _handleServerError(err) {
    this.log('ERROR', `Server error: ${err.message}`);
    this.metrics.errors++;
    
    if (err.code === 'EADDRINUSE') {
      this.log('ERROR', `Socket file is already in use: ${this.options.socketPath}`);
    }
    
    this.emit('error', err);
    
    // Attempt recovery
    if (!this.isShuttingDown) {
      this.log('INFO', 'Attempting server recovery...');
      
      // Try to clean up and restart
      this._cleanup();
      
      setTimeout(() => {
        if (!this.isShuttingDown) {
          this.start().catch(error => {
            this.log('ERROR', `Failed to restart server: ${error.message}`);
          });
        }
      }, 5000);
    }
  }
  
  /**
   * Process a received message
   * @param {object} message - Parsed message
   * @param {object} client - Client object
   * @private
   */
  _processMessage(message, client) {
    try {
      // Update metrics
      client.messagesReceived++;
      this.metrics.messagesReceived++;
      
      this.log('DEBUG', 'Received message', { clientId: client.id, type: message.type });
      
      // Emit message event
      this.emit('message', { message, clientId: client.id });
      
      // Check circuit breaker
      if (!this.circuitBreaker.canRequest()) {
        this.sendErrorResponse(client.id, {
          error: `Circuit breaker is ${this.circuitBreaker.getHealth().state}`,
          type: message.type,
          id: message.id
        });
        return;
      }
      
      // Process message with circuit breaker protection
      this.circuitBreaker.execute(() => {
        try {
          // Process the message based on type
          let response;
          
          switch (message.type) {
            case 'handshake':
              response = { 
                type: 'handshake_response', 
                status: 'success',
                server: this.options.serverName,
                version: '1.0.0'
              };
              break;
              
            case 'health_check':
              response = {
                type: 'health_response',
                status: 'ok',
                server: this.options.serverName,
                uptime: Date.now() - this.metrics.startTime,
                metrics: this.getMetrics(),
                circuit: this.circuitBreaker.getHealth()
              };
              break;
              
            case 'invoke_tool':
              // Delegate to tool handler (to be implemented by subclasses)
              this._handleToolInvocation(message, client);
              return;
              
            default:
              // Allow subclasses to handle other message types
              if (!this._handleCustomMessageType(message, client)) {
                response = {
                  type: 'error_response',
                  status: 'error',
                  error: `Unknown message type: ${message.type}`
                };
              } else {
                // Custom handler took care of it
                return;
              }
          }
          
          // Send response if it exists
          if (response) {
            this.sendResponse(client.id, response);
          }
          
          // Record success
          this.circuitBreaker.success();
        } catch (err) {
          this.log('ERROR', `Failed to process message: ${err.message}`, { clientId: client.id });
          
          // Send error response
          this.sendErrorResponse(client.id, {
            error: `Failed to process message: ${err.message}`,
            type: message.type,
            id: message.id
          });
          
          // Record failure
          this.circuitBreaker.failure();
        }
      })
      .catch(err => {
        this.log('ERROR', `Circuit breaker prevented message processing: ${err.message}`, { clientId: client.id });
        
        // Send circuit breaker error response
        this.sendErrorResponse(client.id, {
          error: `Circuit breaker is ${this.circuitBreaker.getHealth().state}`,
          type: message.type,
          id: message.id
        });
      });
    } catch (err) {
      this.log('ERROR', `Failed to execute message handler: ${err.message}`, { clientId: client.id });
      client.errors++;
      this.metrics.errors++;
    }
  }
  
  /**
   * Handle tool invocation (to be overridden by subclasses)
   * @param {object} message - Message object
   * @param {object} client - Client object
   * @private
   */
  _handleToolInvocation(message, client) {
    // Default implementation - subclasses should override
    this.sendErrorResponse(client.id, {
      error: 'Tool invocation not implemented by this server',
      type: message.type,
      id: message.id
    });
  }
  
  /**
   * Handle custom message type (to be overridden by subclasses)
   * @param {object} message - Message object
   * @param {object} client - Client object
   * @returns {boolean} True if message was handled
   * @private
   */
  _handleCustomMessageType(message, client) {
    // Default implementation - subclasses should override
    return false;
  }
  
  /**
   * Parse messages from buffer
   * @param {string} buffer - Buffer string
   * @returns {object} Object with messages and remainder
   * @private
   */
  _getMessages(buffer) {
    if (!buffer.includes('\n')) {
      return { messages: [], remainder: buffer };
    }
    
    const parts = buffer.split('\n');
    const remainder = parts.pop(); // Keep incomplete message
    
    const messages = parts
      .filter(message => message.trim())
      .map(message => {
        try {
          return JSON.parse(message);
        } catch (err) {
          this.log('ERROR', `Failed to parse message: ${err.message}`);
          return null;
        }
      })
      .filter(Boolean); // Remove nulls
    
    return { messages, remainder };
  }
  
  /**
   * Send a response to a client
   * @param {string} clientId - Client ID
   * @param {object} response - Response object
   * @returns {boolean} Success status
   */
  sendResponse(clientId, response) {
    const client = this.clients.get(clientId);
    if (!client || !client.connected) {
      this.log('WARN', `Cannot send response to disconnected client`, { clientId });
      return false;
    }
    
    try {
      const responseString = JSON.stringify(response) + '\n';
      client.socket.write(responseString);
      
      // Update metrics
      client.messagesSent++;
      this.metrics.messagesSent++;
      
      this.log('DEBUG', 'Sent response', { clientId, type: response.type });
      this.emit('response-sent', { clientId, response });
      
      return true;
    } catch (err) {
      this.log('ERROR', `Failed to send response: ${err.message}`, { clientId });
      client.errors++;
      this.metrics.errors++;
      
      return false;
    }
  }
  
  /**
   * Send an error response to a client
   * @param {string} clientId - Client ID
   * @param {object} error - Error details
   * @returns {boolean} Success status
   */
  sendErrorResponse(clientId, error) {
    const response = {
      type: 'error_response',
      status: 'error',
      error: error.error || 'Unknown error',
      request_type: error.type,
      request_id: error.id
    };
    
    return this.sendResponse(clientId, response);
  }
  
  /**
   * Broadcast a message to all connected clients
   * @param {object} message - Message to broadcast
   * @returns {number} Number of clients that received the message
   */
  broadcast(message) {
    let successCount = 0;
    
    for (const client of this.clients.values()) {
      if (client.connected) {
        if (this.sendResponse(client.id, message)) {
          successCount++;
        }
      }
    }
    
    return successCount;
  }
  
  /**
   * Get server metrics
   * @returns {object} Metrics object
   */
  getMetrics() {
    return {
      ...this.metrics,
      uptime: Date.now() - this.metrics.startTime,
      circuitBreakerState: this.circuitBreaker.getHealth().state,
      memoryUsage: process.memoryUsage(),
      activeClients: this.clients.size,
      isShuttingDown: this.isShuttingDown
    };
  }
  
  /**
   * Start health check interval
   * @private
   */
  _startHealthCheck() {
    // Clean up any existing interval
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
    }
    
    // Create new health check interval
    this.healthCheckInterval = setInterval(() => {
      try {
        // Check socket file exists
        if (!fs.existsSync(this.options.socketPath)) {
          this.log('ERROR', `Socket file missing: ${this.options.socketPath}`);
          
          // Attempt recovery
          this._cleanup();
          
          if (!this.isShuttingDown) {
            this.start().catch(err => {
              this.log('ERROR', `Failed to restart server: ${err.message}`);
            });
          }
          
          return;
        }
        
        // Check socket file permissions
        const stats = fs.statSync(this.options.socketPath);
        const perms = stats.mode & 0o777;
        if (perms !== 0o666) {
          this.log('WARN', `Socket has incorrect permissions: ${perms.toString(8)}, fixing...`);
          fs.chmodSync(this.options.socketPath, 0o666);
        }
        
        // Check memory usage
        const memUsage = process.memoryUsage();
        const heapUsedMB = Math.round(memUsage.heapUsed / (1024 * 1024));
        const heapTotalMB = Math.round(memUsage.heapTotal / (1024 * 1024));
        const rssLimitMB = 4096; // 4GB limit
        
        if (memUsage.rss > rssLimitMB * 1024 * 1024) {
          this.log('WARN', `High memory usage detected: RSS ${Math.round(memUsage.rss / (1024 * 1024))}MB exceeds limit of ${rssLimitMB}MB`);
        }
        
        // Emit health check event
        this.emit('health-check', {
          socketExists: true,
          permissions: '0666',
          memoryMB: { heapUsed: heapUsedMB, heapTotal: heapTotalMB },
          metrics: this.getMetrics()
        });
      } catch (err) {
        this.log('ERROR', `Health check failed: ${err.message}`);
        this.metrics.errors++;
      }
    }, 60000); // Run every minute
  }
  
  /**
   * Ensure required directories exist
   * @private
   */
  async _ensureDirectories() {
    const directories = [
      this.options.socketDir,
      this.options.logDir,
      path.join(this.options.anchorHome, 'coherence_lock')
    ];
    
    for (const dir of directories) {
      try {
        await fs.promises.mkdir(dir, { recursive: true });
      } catch (err) {
        // Ignore if directory already exists
        if (err.code !== 'EEXIST') {
          this.log('ERROR', `Failed to create directory: ${err.message}`, { dir });
          throw err;
        }
      }
    }
  }
  
  /**
   * Clean up existing socket file
   * @private
   */
  async _cleanupExistingSocket() {
    try {
      if (fs.existsSync(this.options.socketPath)) {
        this.log('INFO', `Removing existing socket file: ${this.options.socketPath}`);
        await fs.promises.unlink(this.options.socketPath);
      }
    } catch (err) {
      this.log('ERROR', `Failed to remove existing socket file: ${err.message}`);
      throw err;
    }
  }
  
  /**
   * Create coherence marker
   * @returns {string} Marker file path
   * @private
   */
  _createCoherenceMarker() {
    try {
      const coherenceDir = path.join(this.options.anchorHome, 'coherence_lock');
      
      // Create timestamp string with invalid characters replaced
      const timestamp = new Date().toISOString().replace(/[:.]/g, '');
      
      // Create marker path
      const markerPath = path.join(coherenceDir, `${this.options.serverName}_${timestamp}.marker`);
      
      // Create marker data
      const markerData = {
        pid: process.pid,
        server: this.options.serverName,
        socketPath: this.options.socketPath,
        startTime: new Date().toISOString(),
        hostname: os.hostname(),
        platform: process.platform,
        arch: os.arch(),
        nodeVersion: process.version
      };
      
      // Write marker file
      fs.writeFileSync(markerPath, JSON.stringify(markerData, null, 2));
      
      this.log('INFO', `Created coherence marker: ${markerPath}`);
      
      return markerPath;
    } catch (err) {
      this.log('ERROR', `Failed to create coherence marker: ${err.message}`);
      return null;
    }
  }
  
  /**
   * Clean up resources
   * @private
   */
  _cleanup() {
    // Remove socket file
    try {
      if (fs.existsSync(this.options.socketPath)) {
        fs.unlinkSync(this.options.socketPath);
        this.log('INFO', `Removed socket file: ${this.options.socketPath}`);
      }
    } catch (err) {
      this.log('ERROR', `Failed to remove socket file: ${err.message}`);
    }
    
    // Remove coherence marker
    if (this.coherenceMarkerPath) {
      try {
        if (fs.existsSync(this.coherenceMarkerPath)) {
          fs.unlinkSync(this.coherenceMarkerPath);
          this.log('INFO', `Removed coherence marker: ${this.coherenceMarkerPath}`);
        }
      } catch (err) {
        this.log('ERROR', `Failed to remove coherence marker: ${err.message}`);
      }
    }
  }
  
  /**
   * Log a message
   * @param {string} level - Log level
   * @param {string} message - Log message
   * @param {object} [extra] - Extra data to log
   */
  log(level, message, extra = {}) {
    const logEntry = JSON.stringify({
      ts: new Date().toISOString(),
      level,
      component: this.options.serverName,
      pid: process.pid,
      message,
      ...extra
    });
    
    console.log(logEntry);
    
    try {
      // Ensure log directory exists
      if (!fs.existsSync(this.options.logDir)) {
        fs.mkdirSync(this.options.logDir, { recursive: true });
      }
      
      // Append log entry
      fs.appendFileSync(this.logFile, logEntry + '\n');
    } catch (err) {
      console.error(`Failed to write to log file: ${err.message}`);
    }
  }
}

module.exports = {
  SocketServer
};
