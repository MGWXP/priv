/**
 * circuit-breaker.cjs - Unified circuit breaker pattern for CNIF
 * © 2025 XPV - MIT
 * 
 * Implements a sophisticated circuit breaker pattern with:
 * - State management (CLOSED, OPEN, HALF-OPEN, PARTIAL)
 * - Metrics collection and reporting
 * - Event-based monitoring
 * - Partial degradation capabilities
 * - M3 Max performance optimizations
 */

const EventEmitter = require('events');
const os = require('os');

/**
 * Circuit breaker states
 * @readonly
 * @enum {string}
 */
const CircuitState = {
  CLOSED: 'CLOSED',       // Normal operation
  OPEN: 'OPEN',           // Failing, not accepting requests
  HALF_OPEN: 'HALF_OPEN', // Testing if system has recovered
  PARTIAL: 'PARTIAL'      // Degraded operation (allowing percentage of requests)
};

/**
 * Enhanced circuit breaker implementation with M3 Max optimizations
 */
class CircuitBreaker extends EventEmitter {
  /**
   * Create a new CircuitBreaker
   * @param {Object} options - Circuit breaker options
   * @param {string} options.name - Name for this circuit breaker
   * @param {number} options.failureThreshold - Number of failures before opening circuit
   * @param {number} options.resetTimeout - Time (ms) before attempting reset
   * @param {number} options.degradeThreshold - Failures before partial degradation
   * @param {number} options.degradePercentage - Request % to allow in degraded mode
   * @param {Function} options.fallbackFunction - Function to call when circuit is open
   * @param {boolean} options.metrics - Whether to collect detailed metrics
   */
  constructor(options = {}) {
    super();
    
    // Configure options with sensible defaults
    this.name = options.name || 'default';
    this.failureThreshold = options.failureThreshold || 5;
    this.degradeThreshold = options.degradeThreshold || 3;
    this.resetTimeout = options.resetTimeout || 60000; // 1 minute
    this.degradePercentage = options.degradePercentage || 0.3; // 30%
    this.fallbackFunction = options.fallbackFunction;
    this.collectMetrics = options.metrics !== false;
    
    // State management
    this.state = CircuitState.CLOSED;
    this.failures = 0;
    this.partialFailures = 0;
    this.lastFailureTime = 0;
    this.successCount = 0;
    this.failureCount = 0;
    this.consecutiveSuccesses = 0;
    this.consecutiveFailures = 0;
    this.callCount = 0;
    
    // M3 Max optimized timers
    this.failureTimer = null;
    this.resetTimer = null;
    
    // Performance metrics
    this.startTime = Date.now();
    this.lastStateChangeTime = this.startTime;
    this.stateHistory = [{
      state: this.state,
      timestamp: this.startTime
    }];
    
    // Monitoring - emit events on state change
    this.on('stateChange', (oldState, newState) => {
      const metrics = this.collectMetrics ? this.getHealth() : {};
      
      // Use M3 memory-optimized JSON serialization
      const logEntry = {
        ts: new Date().toISOString(),
        circuit: this.name,
        event: 'state_change',
        old_state: oldState,
        new_state: newState,
        failures: this.failures,
        consecutive_successes: this.consecutiveSuccesses
      };
      
      if (this.collectMetrics) {
        logEntry.metrics = metrics;
      }
      
      console.log(JSON.stringify(logEntry));
    });
    
    // Initialize metrics cleanup
    if (this.collectMetrics) {
      // Clean up old metrics every hour
      setInterval(() => {
        const threshold = Date.now() - 24 * 60 * 60 * 1000; // 24 hours
        this.stateHistory = this.stateHistory.filter(item => item.timestamp > threshold);
      }, 60 * 60 * 1000); // 1 hour
    }
  }
  
  /**
   * Check if a request can proceed
   * @returns {boolean} Whether the request should proceed
   */
  canRequest() {
    this.callCount++;
    
    switch (this.state) {
      case CircuitState.CLOSED:
        return true;
        
      case CircuitState.PARTIAL:
        // Allow only a percentage of requests through
        return Math.random() < this.degradePercentage;
        
      case CircuitState.OPEN:
        const now = Date.now();
        if (now - this.lastFailureTime > this.resetTimeout) {
          this._setState(CircuitState.HALF_OPEN);
          return true;
        }
        return false;
        
      case CircuitState.HALF_OPEN:
        // In half-open state, we allow a single request to test
        return this.consecutiveSuccesses === 0;
        
      default:
        return false;
    }
  }
  
  /**
   * Record a successful operation
   */
  success() {
    this.successCount++;
    this.consecutiveSuccesses++;
    this.consecutiveFailures = 0;
    
    if (this.state === CircuitState.HALF_OPEN && this.consecutiveSuccesses >= 2) {
      // After 2 consecutive successes in half-open, we close the circuit
      this._setState(CircuitState.CLOSED);
      this.failures = 0;
      this.partialFailures = 0;
    } else if (this.state === CircuitState.PARTIAL && this.consecutiveSuccesses >= 5) {
      // After 5 consecutive successes in partial, we close the circuit
      this._setState(CircuitState.CLOSED);
      this.failures = 0;
      this.partialFailures = 0;
    }
    
    // Reset failure window
    if (this.failureTimer) {
      clearTimeout(this.failureTimer);
      this.failureTimer = null;
    }
    
    this.emit('success', {
      circuit: this.name,
      state: this.state,
      consecutiveSuccesses: this.consecutiveSuccesses
    });
  }
  
  /**
   * Record a failed operation
   */
  failure() {
    this.failures++;
    this.failureCount++;
    this.partialFailures++;
    this.consecutiveSuccesses = 0;
    this.consecutiveFailures++;
    this.lastFailureTime = Date.now();
    
    // Clear old failures after 30 seconds
    if (this.failureTimer) {
      clearTimeout(this.failureTimer);
    }
    
    this.failureTimer = setTimeout(() => {
      // Reset failure count after window
      if (this.state === CircuitState.CLOSED) {
        this.failures = 0;
        this.partialFailures = 0;
      }
    }, 30000);
    
    switch (this.state) {
      case CircuitState.CLOSED:
        if (this.failures >= this.failureThreshold) {
          this._setState(CircuitState.OPEN);
          
          // Schedule reset attempt
          if (this.resetTimer) {
            clearTimeout(this.resetTimer);
          }
          
          this.resetTimer = setTimeout(() => {
            if (this.state === CircuitState.OPEN) {
              this._setState(CircuitState.HALF_OPEN);
            }
          }, this.resetTimeout);
          
        } else if (this.partialFailures >= this.degradeThreshold) {
          this._setState(CircuitState.PARTIAL);
        }
        break;
        
      case CircuitState.PARTIAL:
        if (this.failures >= this.failureThreshold) {
          this._setState(CircuitState.OPEN);
          
          // Schedule reset attempt
          if (this.resetTimer) {
            clearTimeout(this.resetTimer);
          }
          
          this.resetTimer = setTimeout(() => {
            if (this.state === CircuitState.OPEN) {
              this._setState(CircuitState.HALF_OPEN);
            }
          }, this.resetTimeout);
        }
        break;
        
      case CircuitState.HALF_OPEN:
        this._setState(CircuitState.OPEN);
        
        // Schedule reset attempt
        if (this.resetTimer) {
          clearTimeout(this.resetTimer);
        }
        
        this.resetTimer = setTimeout(() => {
          if (this.state === CircuitState.OPEN) {
            this._setState(CircuitState.HALF_OPEN);
          }
        }, this.resetTimeout);
        break;
    }
    
    this.emit('failure', {
      circuit: this.name,
      state: this.state,
      failures: this.failures,
      consecutiveFailures: this.consecutiveFailures
    });
  }
  
  /**
   * Execute a function with circuit breaker protection
   * @param {Function} fn - Function to execute
   * @param {...any} args - Arguments to pass to the function
   * @returns {Promise} Promise resolving to the function result
   */
  async execute(fn, ...args) {
    if (!this.canRequest()) {
      if (this.fallbackFunction) {
        return this.fallbackFunction(...args);
      }
      throw new Error(`Circuit ${this.name} is ${this.state}`);
    }
    
    try {
      // Optimize for promises and non-promises
      const result = fn(...args);
      
      if (result instanceof Promise) {
        return result.then(
          // Success handler
          value => {
            this.success();
            return value;
          },
          // Error handler
          error => {
            this.failure();
            throw error;
          }
        );
      }
      
      // Regular value (not a promise)
      this.success();
      return result;
    } catch (error) {
      this.failure();
      throw error;
    }
  }
  
  /**
   * Get circuit health metrics
   * @returns {Object} Circuit health metrics
   */
  getHealth() {
    const uptime = Date.now() - this.startTime;
    const stateUptime = Date.now() - this.lastStateChangeTime;
    
    const metrics = {
      name: this.name,
      state: this.state,
      uptime,
      stateUptime,
      callCount: this.callCount,
      failureCount: this.failureCount,
      successCount: this.successCount,
      failures: this.failures,
      failureRate: this.callCount > 0 ? (this.failureCount / this.callCount) : 0,
      lastFailure: this.lastFailureTime > 0 ? new Date(this.lastFailureTime).toISOString() : null,
      consecutiveSuccesses: this.consecutiveSuccesses,
      consecutiveFailures: this.consecutiveFailures
    };
    
    // Add state history if metrics collection is enabled
    if (this.collectMetrics) {
      metrics.stateHistory = this.stateHistory.slice(-10); // Last 10 state changes
    }
    
    return metrics;
  }
  
  /**
   * Reset the circuit breaker to closed state
   */
  reset() {
    this._setState(CircuitState.CLOSED);
    this.failures = 0;
    this.partialFailures = 0;
    this.consecutiveSuccesses = 0;
    this.consecutiveFailures = 0;
    this.lastFailureTime = 0;
    
    // Clear timers
    if (this.failureTimer) {
      clearTimeout(this.failureTimer);
      this.failureTimer = null;
    }
    
    if (this.resetTimer) {
      clearTimeout(this.resetTimer);
      this.resetTimer = null;
    }
    
    this.emit('reset', {
      circuit: this.name,
      state: this.state
    });
  }
  
  /**
   * Set the circuit state and emit events
   * @param {CircuitState} newState - New circuit state
   * @private
   */
  _setState(newState) {
    if (this.state === newState) return;
    
    const oldState = this.state;
    this.state = newState;
    this.lastStateChangeTime = Date.now();
    
    // Record state change history if metrics collection is enabled
    if (this.collectMetrics) {
      this.stateHistory.push({
        state: newState,
        timestamp: this.lastStateChangeTime,
        from: oldState
      });
      
      // Limit history size for memory optimization
      if (this.stateHistory.length > 100) {
        this.stateHistory.shift();
      }
    }
    
    this.emit('stateChange', oldState, newState);
    this.emit(newState.toLowerCase());
  }
}

module.exports = {
  CircuitBreaker,
  CircuitState
};
