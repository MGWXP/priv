/**
 * mcp-orchestrator.cjs - Enhanced MCP orchestrator for CNIF
 * © 2025 XPV - MIT
 * 
 * Coordinates communication between MCP services with resilience
 * patterns and M3 Max optimizations.
 */

const fs = require('fs');
const net = require('net');
const path = require('path');
const EventEmitter = require('events');
const { SocketServer } = require('./socket-server.cjs');
const { CircuitBreaker } = require('./circuit-breaker.cjs');

/**
 * ServiceConnection manages connection to an MCP service
 */
class ServiceConnection extends EventEmitter {
  /**
   * Create a new ServiceConnection
   * @param {string} serviceName - Service name
   * @param {object} options - Connection options
   */
  constructor(serviceName, options = {}) {
    super();
    
    this.serviceName = serviceName;
    this.options = {
      socketDir: options.socketDir || process.env.SOCKET_DIR || '/Users/XPV/Desktop/anchor-core/sockets',
      connectTimeout: options.connectTimeout || 5000,
      reconnectDelay: options.reconnectDelay || 1000,
      maxReconnectDelay: options.maxReconnectDelay || 30000,
      maxReconnectAttempts: options.maxReconnectAttempts || 10,
      heartbeatInterval: options.heartbeatInterval || 30000,
      ...options
    };
    
    // Calculate socket path
    this.socketPath = path.join(this.options.socketDir, `${serviceName}.sock`);
    
    // Initialize state
    this.connected = false;
    this.connecting = false;
    this.socket = null;
    this.buffer = '';
    this.messageQueue = [];
    this.reconnectAttempts = 0;
    this.reconnectTimeout = null;
    this.heartbeatInterval = null;
    this.lastMessageId = 0;
    this.pendingRequests = new Map();
    this.lastHeartbeat = 0;
    
    // Create circuit breaker
    this.circuitBreaker = new CircuitBreaker({
      name: `service-${serviceName}`,
      failureThreshold: 3,
      resetTimeout: 30000,
      degradeThreshold: 2
    });
    
    // Bind methods to maintain context
    this.connect = this.connect.bind(this);
    this.disconnect = this.disconnect.bind(this);
    this.sendMessage = this.sendMessage.bind(this);
    this.handleData = this.handleData.bind(this);
    this.handleDisconnect = this.handleDisconnect.bind(this);
    this.handleError = this.handleError.bind(this);
    this.scheduleReconnect = this.scheduleReconnect.bind(this);
  }
  
  /**
   * Connect to the service
   * @returns {Promise<boolean>} Promise resolving to connection status
   */
  connect() {
    return new Promise((resolve, reject) => {
      if (this.connected) {
        resolve(true);
        return;
      }
      
      if (this.connecting) {
        this.once('connected', () => resolve(true));
        this.once('error', err => reject(err));
        return;
      }
      
      this.connecting = true;
      
      // Check if socket file exists
      fs.access(this.socketPath, fs.constants.R_OK | fs.constants.W_OK, (err) => {
        if (err) {
          this.connecting = false;
          reject(new Error(`Socket file not accessible: ${this.socketPath}`));
          return;
        }
        
        // Create socket
        this.socket = net.createConnection({ path: this.socketPath });
        
        // Set up connection timeout
        const connectionTimeout = setTimeout(() => {
          if (!this.connected) {
            this.socket.destroy();
            this.connecting = false;
            reject(new Error(`Connection to ${this.serviceName} timed out`));
          }
        }, this.options.connectTimeout);
        
        // Handle connect event
        this.socket.once('connect', () => {
          // Clear connection timeout
          clearTimeout(connectionTimeout);
          
          // Update state
          this.connected = true;
          this.connecting = false;
          this.reconnectAttempts = 0;
          
          // Set up heartbeat
          this.setupHeartbeat();
          
          // Set up event handlers
          this.socket.on('data', this.handleData);
          this.socket.on('end', this.handleDisconnect);
          this.socket.on('error', this.handleError);
          
          // Send handshake
          this.sendHandshake()
            .then(() => {
              // Process any queued messages
              this.processQueue();
              
              // Emit connected event
              this.emit('connected', { serviceName: this.serviceName });
              
              // Resolve promise
              resolve(true);
            })
            .catch(err => {
              // Disconnect on handshake failure
              this.disconnect();
              
              // Reject promise
              reject(err);
            });
        });
        
        // Handle connection errors
        this.socket.once('error', (err) => {
          // Clear connection timeout
          clearTimeout(connectionTimeout);
          
          // Update state
          this.connecting = false;
          
          // Reject promise
          reject(err);
        });
      });
    });
  }
  
  /**
   * Send handshake message
   * @returns {Promise<object>} Handshake response
   */
  async sendHandshake() {
    return new Promise((resolve, reject) => {
      const messageId = this.getNextMessageId();
      
      // Create handshake message
      const handshake = {
        type: 'handshake',
        id: messageId,
        client: 'mcp-orchestrator',
        timestamp: new Date().toISOString()
      };
      
      // Create promise resolver
      const resolver = {
        resolve,
        reject,
        timeout: setTimeout(() => {
          this.pendingRequests.delete(messageId);
          reject(new Error(`Handshake with ${this.serviceName} timed out`));
        }, this.options.connectTimeout)
      };
      
      // Add to pending requests
      this.pendingRequests.set(messageId, resolver);
      
      // Send handshake
      this.socket.write(JSON.stringify(handshake) + '\n');
    });
  }
  
  /**
   * Process message queue
   */
  processQueue() {
    // Process all queued messages
    while (this.messageQueue.length > 0) {
      const message = this.messageQueue.shift();
      this.sendMessageRaw(message.message, message.resolver);
    }
  }
  
  /**
   * Set up heartbeat
   */
  setupHeartbeat() {
    // Clear any existing heartbeat
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
    }
    
    // Set up new heartbeat
    this.heartbeatInterval = setInterval(() => {
      if (!this.connected) {
        return;
      }
      
      try {
        // Check how long since last heartbeat
        const now = Date.now();
        if (this.lastHeartbeat > 0 && now - this.lastHeartbeat > this.options.heartbeatInterval * 2) {
          // We've missed multiple heartbeats, disconnect
          this.emit('heartbeat-timeout', {
            serviceName: this.serviceName,
            lastHeartbeat: new Date(this.lastHeartbeat).toISOString(),
            timeSinceLastHeartbeat: now - this.lastHeartbeat
          });
          
          this.disconnect();
          return;
        }
        
        // Send heartbeat request if socket is writable
        if (this.socket && this.socket.writable) {
          const heartbeat = {
            type: 'heartbeat',
            id: this.getNextMessageId(),
            timestamp: new Date().toISOString()
          };
          
          this.socket.write(JSON.stringify(heartbeat) + '\n');
        }
      } catch (err) {
        this.emit('error', {
          serviceName: this.serviceName,
          error: err.message,
          operation: 'heartbeat'
        });
      }
    }, this.options.heartbeatInterval);
  }
  
  /**
   * Handle data from socket
   * @param {Buffer} data - Received data
   */
  handleData(data) {
    try {
      // Convert buffer to string and append to message buffer
      this.buffer += data.toString();
      
      // Process complete messages
      let newlineIndex;
      while ((newlineIndex = this.buffer.indexOf('\n')) !== -1) {
        // Extract message
        const messageText = this.buffer.substring(0, newlineIndex);
        this.buffer = this.buffer.substring(newlineIndex + 1);
        
        // Skip empty messages
        if (!messageText.trim()) {
          continue;
        }
        
        try {
          // Parse message
          const message = JSON.parse(messageText);
          
          // Handle message
          this.handleMessage(message);
        } catch (err) {
          this.emit('error', {
            serviceName: this.serviceName,
            error: `Failed to parse message: ${err.message}`,
            message: messageText
          });
        }
      }
    } catch (err) {
      this.emit('error', {
        serviceName: this.serviceName,
        error: `Error handling data: ${err.message}`
      });
    }
  }
  
  /**
   * Handle a message
   * @param {object} message - Parsed message object
   */
  handleMessage(message) {
    // Update last heartbeat time
    if (message.type === 'heartbeat') {
      this.lastHeartbeat = Date.now();
      this.emit('heartbeat', {
        serviceName: this.serviceName,
        timestamp: message.timestamp
      });
      return;
    }
    
    // Handle handshake response
    if (message.type === 'handshake_response') {
      // Find pending request
      const pendingRequest = this.pendingRequests.get(message.id);
      if (pendingRequest) {
        // Clear timeout
        clearTimeout(pendingRequest.timeout);
        
        // Remove from pending requests
        this.pendingRequests.delete(message.id);
        
        // Resolve promise
        pendingRequest.resolve(message);
      }
      
      // Emit handshake event
      this.emit('handshake', {
        serviceName: this.serviceName,
        version: message.version,
        server: message.server
      });
      
      return;
    }
    
    // Handle response
    if (message.id) {
      // Find pending request
      const pendingRequest = this.pendingRequests.get(message.id);
      if (pendingRequest) {
        // Clear timeout
        clearTimeout(pendingRequest.timeout);
        
        // Remove from pending requests
        this.pendingRequests.delete(message.id);
        
        // Check for error response
        if (message.type === 'error_response') {
          pendingRequest.reject(new Error(message.error || 'Unknown error'));
        } else {
          // Resolve promise
          pendingRequest.resolve(message);
        }
        
        return;
      }
    }
    
    // Emit message event for unhandled messages
    this.emit('message', {
      serviceName: this.serviceName,
      message
    });
  }
  
  /**
   * Handle socket disconnection
   */
  handleDisconnect() {
    if (!this.connected) {
      return;
    }
    
    // Update state
    this.connected = false;
    
    // Clear heartbeat interval
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
    }
    
    // Emit disconnected event
    this.emit('disconnected', { serviceName: this.serviceName });
    
    // Reject all pending requests
    for (const [id, request] of this.pendingRequests) {
      clearTimeout(request.timeout);
      request.reject(new Error(`Connection to ${this.serviceName} closed`));
    }
    
    // Clear pending requests
    this.pendingRequests.clear();
    
    // Schedule reconnect
    this.scheduleReconnect();
  }
  
  /**
   * Handle socket error
   * @param {Error} err - Socket error
   */
  handleError(err) {
    this.emit('error', {
      serviceName: this.serviceName,
      error: err.message
    });
    
    // Disconnect on error
    if (this.connected) {
      this.disconnect();
    }
  }
  
  /**
   * Disconnect from the service
   */
  disconnect() {
    if (!this.connected) {
      return;
    }
    
    // Update state
    this.connected = false;
    
    // Clear heartbeat interval
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
    }
    
    // Close socket
    if (this.socket) {
      this.socket.removeAllListeners();
      this.socket.destroy();
      this.socket = null;
    }
    
    // Emit disconnected event
    this.emit('disconnected', { serviceName: this.serviceName });
    
    // Reject all pending requests
    for (const [id, request] of this.pendingRequests) {
      clearTimeout(request.timeout);
      request.reject(new Error(`Connection to ${this.serviceName} closed`));
    }
    
    // Clear pending requests
    this.pendingRequests.clear();
  }
  
  /**
   * Schedule reconnection
   */
  scheduleReconnect() {
    // Clear any existing timeout
    if (this.reconnectTimeout) {
      clearTimeout(this.reconnectTimeout);
    }
    
    // Check if we've reached max attempts
    if (this.reconnectAttempts >= this.options.maxReconnectAttempts) {
      this.emit('max-reconnect-attempts', {
        serviceName: this.serviceName,
        attempts: this.reconnectAttempts
      });
      return;
    }
    
    // Increment attempts
    this.reconnectAttempts++;
    
    // Calculate delay with exponential backoff
    const delay = Math.min(
      this.options.maxReconnectDelay,
      this.options.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1)
    );
    
    // Add jitter (±25%)
    const jitter = delay * 0.25 * (Math.random() * 2 - 1);
    const reconnectDelay = delay + jitter;
    
    // Schedule reconnect
    this.reconnectTimeout = setTimeout(() => {
      this.emit('reconnect-attempt', {
        serviceName: this.serviceName,
        attempt: this.reconnectAttempts,
        delay: reconnectDelay
      });
      
      // Attempt to reconnect
      this.connect()
        .catch(err => {
          this.emit('reconnect-failed', {
            serviceName: this.serviceName,
            attempt: this.reconnectAttempts,
            error: err.message
          });
          
          // Schedule next reconnect
          this.scheduleReconnect();
        });
    }, reconnectDelay);
  }
  
  /**
   * Send a message to the service
   * @param {object} message - Message to send
   * @param {object} options - Send options
   * @returns {Promise<object>} Service response
   */
  sendMessage(message, options = {}) {
    // Add message ID if not provided
    if (!message.id) {
      message.id = this.getNextMessageId();
    }
    
    return new Promise((resolve, reject) => {
      // Create timeout
      const timeout = setTimeout(() => {
        this.pendingRequests.delete(message.id);
        reject(new Error(`Request to ${this.serviceName} timed out`));
      }, options.timeout || 30000);
      
      // Create resolver
      const resolver = { resolve, reject, timeout };
      
      // Check connection state
      if (!this.connected) {
        if (options.queueIfDisconnected) {
          // Queue message
          this.messageQueue.push({ message, resolver });
          
          // Try to connect
          this.connect().catch(() => {
            // Connection failed, will retry automatically
          });
        } else {
          // Reject immediately
          clearTimeout(timeout);
          reject(new Error(`Not connected to ${this.serviceName}`));
        }
        
        return;
      }
      
      // Send message
      this.sendMessageRaw(message, resolver);
    });
  }
  
  /**
   * Send a raw message to the service
   * @param {object} message - Message to send
   * @param {object} resolver - Promise resolver
   */
  sendMessageRaw(message, resolver) {
    try {
      // Check circuit breaker
      if (!this.circuitBreaker.canRequest()) {
        // Circuit breaker is open, reject
        clearTimeout(resolver.timeout);
        resolver.reject(new Error(`Circuit breaker for ${this.serviceName} is ${this.circuitBreaker.getHealth().state}`));
        return;
      }
      
      // Add to pending requests
      this.pendingRequests.set(message.id, resolver);
      
      // Send message
      this.socket.write(JSON.stringify(message) + '\n');
      
      // Record success with circuit breaker
      this.circuitBreaker.success();
    } catch (err) {
      // Record failure with circuit breaker
      this.circuitBreaker.failure();
      
      // Remove from pending requests
      this.pendingRequests.delete(message.id);
      
      // Clear timeout
      clearTimeout(resolver.timeout);
      
      // Reject promise
      resolver.reject(err);
      
      // Disconnect on error
      this.disconnect();
    }
  }
  
  /**
   * Get next message ID
   * @returns {string} Message ID
   */
  getNextMessageId() {
    this.lastMessageId++;
    return `${this.serviceName}-${Date.now()}-${this.lastMessageId}`;
  }
  
  /**
   * Get connection health
   * @returns {object} Health information
   */
  getHealth() {
    return {
      serviceName: this.serviceName,
      connected: this.connected,
      connecting: this.connecting,
      reconnectAttempts: this.reconnectAttempts,
      pendingRequests: this.pendingRequests.size,
      queuedMessages: this.messageQueue.length,
      lastHeartbeat: this.lastHeartbeat ? new Date(this.lastHeartbeat).toISOString() : null,
      circuitBreaker: this.circuitBreaker.getHealth()
    };
  }
}

/**
 * MCPOrchestrator coordinates communication between MCP services
 * with resilience patterns and intelligent routing.
 */
class MCPOrchestrator extends SocketServer {
  /**
   * Create a new MCPOrchestrator
   * @param {object} options - Orchestrator options
   */
  constructor(options = {}) {
    super({
      serverName: 'mcp-orchestrator',
      ...options
    });
    
    // Initialize services
    this.services = {};
    this.serviceStatus = {};
    this.toolRegistry = new Map();
    
    // Track tool invocation metrics
    this.toolMetrics = {
      invocations: {},
      errors: {}
    };
    
    // Bind methods
    this._handleToolInvocation = this._handleToolInvocation.bind(this);
  }
  
  /**
   * Initialize the orchestrator
   * @returns {Promise<boolean>} Success status
   */
  async initialize() {
    try {
      this.log('INFO', 'Initializing MCP orchestrator...');
      
      // Connect to required services
      await this.connectToServices();
      
      // Register tools
      this.registerTools();
      
      // Start socket server
      await super.start();
      
      this.log('INFO', 'MCP orchestrator initialized');
      
      return true;
    } catch (err) {
      this.log('ERROR', `Failed to initialize orchestrator: ${err.message}`);
      throw err;
    }
  }
  
  /**
   * Connect to MCP services
   * @returns {Promise<boolean>} Success status
   */
  async connectToServices() {
    // Define services to connect to
    const serviceNames = [
      'socket-server',
      'schema-registry',
      'streaming-transformer',
      'notion'
    ];
    
    // Connect to each service
    for (const serviceName of serviceNames) {
      try {
        await this.connectToService(serviceName);
        this.log('INFO', `Connected to ${serviceName} service`);
      } catch (err) {
        this.log('WARN', `Failed to connect to ${serviceName} service: ${err.message}`);
        this.serviceStatus[serviceName] = {
          connected: false,
          error: err.message
        };
      }
    }
    
    return true;
  }
  
  /**
   * Connect to a specific service
   * @param {string} serviceName - Service to connect to
   * @returns {Promise<boolean>} Success status
   */
  async connectToService(serviceName) {
    // Create service connection if needed
    if (!this.services[serviceName]) {
      const service = new ServiceConnection(serviceName, this.options);
      
      // Set up event handlers
      service.on('connected', (data) => {
        this.log('INFO', `Service ${serviceName} connected`);
        this.serviceStatus[serviceName] = {
          connected: true,
          timestamp: new Date().toISOString()
        };
      });
      
      service.on('disconnected', (data) => {
        this.log('WARN', `Service ${serviceName} disconnected`);
        this.serviceStatus[serviceName] = {
          connected: false,
          timestamp: new Date().toISOString()
        };
      });
      
      service.on('error', (data) => {
        this.log('ERROR', `Service ${serviceName} error: ${data.error}`);
      });
      
      service.on('heartbeat', (data) => {
        // Update service status
        if (this.serviceStatus[serviceName]) {
          this.serviceStatus[serviceName].lastHeartbeat = data.timestamp;
        }
      });
      
      // Store service connection
      this.services[serviceName] = service;
    }
    
    // Connect to service
    await this.services[serviceName].connect();
    
    // Update service status
    this.serviceStatus[serviceName] = {
      connected: true,
      timestamp: new Date().toISOString()
    };
    
    return true;
  }
  
  /**
   * Register available tools
   */
  registerTools() {
    // Socket server tools
    this.registerTool('handshake', 'socket-server');
    this.registerTool('health_check', 'socket-server');
    
    // Schema registry tools
    this.registerTool('validate-schema', 'schema-registry');
    this.registerTool('get-schema', 'schema-registry');
    this.registerTool('register-schema', 'schema-registry');
    
    // Transformer tools
    this.registerTool('transform-xml-to-json', 'streaming-transformer');
    this.registerTool('transform-json-to-xml', 'streaming-transformer');
    
    // Notion tools
    this.registerTool('search-notion', 'notion');
    this.registerTool('query-database', 'notion');
    this.registerTool('get-page', 'notion');
    this.registerTool('update-page', 'notion');
    this.registerTool('create-page', 'notion');
    this.registerTool('get-databases', 'notion');
    this.registerTool('get-blocks', 'notion');
    
    // Register standard Notion API tools
    [
      'API-get-user',
      'API-get-users',
      'API-get-self',
      'API-post-database-query',
      'API-post-search',
      'API-get-block-children',
      'API-patch-block-children',
      'API-retrieve-a-block',
      'API-update-a-block',
      'API-delete-a-block',
      'API-retrieve-a-page',
      'API-patch-page',
      'API-post-page',
      'API-create-a-database',
      'API-update-a-database',
      'API-retrieve-a-database',
      'API-retrieve-a-page-property',
      'API-retrieve-a-comment',
      'API-create-a-comment'
    ].forEach(tool => this.registerTool(tool, 'notion'));
  }
  
  /**
   * Register a tool
   * @param {string} toolName - Tool name
   * @param {string} serviceName - Service that handles the tool
   */
  registerTool(toolName, serviceName) {
    if (!this.services[serviceName]) {
      this.log('WARN', `Cannot register tool ${toolName} for unknown service ${serviceName}`);
      return;
    }
    
    this.toolRegistry.set(toolName, serviceName);
    
    // Initialize metrics
    if (!this.toolMetrics.invocations[toolName]) {
      this.toolMetrics.invocations[toolName] = 0;
    }
    
    if (!this.toolMetrics.errors[toolName]) {
      this.toolMetrics.errors[toolName] = 0;
    }
    
    this.log('DEBUG', `Registered tool ${toolName} for service ${serviceName}`);
  }
  
  /**
   * Handle tool invocation
   * @param {object} message - Tool invocation message
   * @param {object} client - Client object
   * @private
   */
  _handleToolInvocation(message, client) {
    const toolName = message.tool;
    const requestId = message.id || 'unknown';
    
    // Track invocation
    if (this.toolMetrics.invocations[toolName] !== undefined) {
      this.toolMetrics.invocations[toolName]++;
    } else {
      this.toolMetrics.invocations[toolName] = 1;
    }
    
    // Check if we know this tool
    const serviceName = this.toolRegistry.get(toolName);
    if (!serviceName) {
      this.log('WARN', `Unknown tool requested: ${toolName}`, { clientId: client.id });
      
      // Track error
      if (this.toolMetrics.errors[toolName] !== undefined) {
        this.toolMetrics.errors[toolName]++;
      } else {
        this.toolMetrics.errors[toolName] = 1;
      }
      
      this.sendErrorResponse(client.id, {
        error: `Unknown tool: ${toolName}`,
        type: message.type,
        id: requestId
      });
      
      return;
    }
    
    // Check if service is connected
    if (!this.services[serviceName] || !this.services[serviceName].connected) {
      this.log('WARN', `Service ${serviceName} for tool ${toolName} is not connected`, { clientId: client.id });
      
      // Track error
      this.toolMetrics.errors[toolName]++;
      
      this.sendErrorResponse(client.id, {
        error: `Service ${serviceName} for tool ${toolName} is not available`,
        type: message.type,
        id: requestId
      });
      
      // Try to connect to service
      if (this.services[serviceName]) {
        this.services[serviceName].connect().catch(err => {
          this.log('ERROR', `Failed to connect to ${serviceName}: ${err.message}`);
        });
      }
      
      return;
    }
    
    // Forward tool invocation to service
    this.services[serviceName].sendMessage({
      type: 'invoke_tool',
      id: requestId,
      tool: toolName,
      parameters: message.parameters || {}
    })
    .then(response => {
      // Forward response to client
      this.sendResponse(client.id, {
        type: 'tool_response',
        id: requestId,
        status: 'success',
        result: response.result
      });
    })
    .catch(err => {
      // Track error
      this.toolMetrics.errors[toolName]++;
      
      // Send error response
      this.sendErrorResponse(client.id, {
        error: err.message,
        type: message.type,
        id: requestId
      });
    });
  }
  
  /**
   * Handle custom message type
   * @param {object} message - Message object
   * @param {object} client - Client object
   * @returns {boolean} True if message was handled
   * @private
   */
  _handleCustomMessageType(message, client) {
    // Handle service status request
    if (message.type === 'service_status') {
      this.sendResponse(client.id, {
        type: 'service_status_response',
        id: message.id || 'unknown',
        status: 'success',
        services: this.serviceStatus,
        tools: Array.from(this.toolRegistry.keys())
      });
      
      return true;
    }
    
    // Handle tool list request
    if (message.type === 'list_tools') {
      this.sendResponse(client.id, {
        type: 'tool_list_response',
        id: message.id || 'unknown',
        status: 'success',
        tools: Array.from(this.toolRegistry.keys())
      });
      
      return true;
    }
    
    return false;
  }
  
  /**
   * Get orchestrator metrics
   * @returns {object} Metrics
   */
  getMetrics() {
    const baseMetrics = super.getMetrics();
    
    // Service metrics
    const serviceMetrics = {};
    for (const [name, service] of Object.entries(this.services)) {
      serviceMetrics[name] = service.getHealth();
    }
    
    // Tool metrics
    const toolMetrics = {
      invocations: { ...this.toolMetrics.invocations },
      errors: { ...this.toolMetrics.errors },
      errorRates: {}
    };
    
    // Calculate error rates
    for (const [tool, invocations] of Object.entries(toolMetrics.invocations)) {
      if (invocations > 0) {
        toolMetrics.errorRates[tool] = (toolMetrics.errors[tool] || 0) / invocations;
      } else {
        toolMetrics.errorRates[tool] = 0;
      }
    }
    
    return {
      ...baseMetrics,
      services: serviceMetrics,
      tools: {
        registered: this.toolRegistry.size,
        metrics: toolMetrics
      }
    };
  }
  
  /**
   * Stop the orchestrator
   * @returns {Promise<boolean>} Success status
   */
  async stop() {
    this.log('INFO', 'Stopping MCP orchestrator...');
    
    // Disconnect from all services
    for (const [name, service] of Object.entries(this.services)) {
      try {
        service.disconnect();
        this.log('INFO', `Disconnected from ${name} service`);
      } catch (err) {
        this.log('ERROR', `Error disconnecting from ${name} service: ${err.message}`);
      }
    }
    
    // Stop socket server
    await super.stop();
    
    this.log('INFO', 'MCP orchestrator stopped');
    
    return true;
  }
}

module.exports = {
  MCPOrchestrator,
  ServiceConnection
};
