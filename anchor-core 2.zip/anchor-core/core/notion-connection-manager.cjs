/**
 * notion-connection-manager.cjs - Enhanced Notion connection manager for CNIF
 * © 2025 XPV - MIT
 * 
 * Manages Notion API connections with rate limiting, exponential backoff,
 * and circuit breaker pattern for resilience.
 */

const fs = require('fs');
const path = require('path');
const EventEmitter = require('events');
const { CircuitBreaker } = require('./circuit-breaker.cjs');

/**
 * NotionConnectionManager handles communication with Notion API
 * with built-in resilience patterns and M3 Max optimizations.
 */
class NotionConnectionManager extends EventEmitter {
  /**
   * Create a new NotionConnectionManager
   * @param {object} options - Connection options
   */
  constructor(options = {}) {
    super();
    
    // Configure from options and environment
    this.options = {
      apiToken: options.apiToken || process.env.NOTION_API_TOKEN || '',
      apiVersion: options.apiVersion || process.env.NOTION_API_VERSION || '2022-06-28',
      baseUrl: options.apiUrl || process.env.NOTION_API_URL || 'https://api.notion.com/v1',
      maxRetries: options.maxRetries || 5,
      baseDelay: options.baseDelay || 1000, // 1 second
      maxDelay: options.maxDelay || 32000, // 32 seconds
      timeoutMs: options.timeoutMs || 30000, // 30 seconds
      rateLimitPerSecond: options.rateLimitPerSecond || 3,
      rateLimitPerMinute: options.rateLimitPerMinute || 180,
      memoryOptimized: options.memoryOptimized !== false,
      configPath: options.configPath || null,
      logDir: options.logDir || process.env.LOG_DIR || path.join(process.env.HOME || '/Users/XPV', 'Library/Logs/Claude'),
      ...options
    };
    
    // Calculate config path if not provided
    if (!this.options.configPath) {
      const anchorHome = process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core';
      this.options.configPath = path.join(anchorHome, 'config', 'notion-config.json');
    }
    
    // Set up logfile path
    this.logFile = path.join(this.options.logDir, 'notion-connection.log');
    
    // Initialize state
    this.initialized = false;
    this.initPromise = null;
    
    // API state tracking
    this.apiRequests = 0;
    this.apiErrors = 0;
    this.rateLimitRemaining = {
      second: this.options.rateLimitPerSecond,
      minute: this.options.rateLimitPerMinute
    };
    this.rateLimitReset = {
      second: Date.now() + 1000,
      minute: Date.now() + 60000
    };
    
    // Request queue for rate limiting
    this.requestQueue = [];
    this.processingQueue = false;
    
    // Circuit breakers for API endpoints
    this.circuitBreakers = {
      default: new CircuitBreaker({
        name: 'notion-api',
        failureThreshold: 5,
        resetTimeout: 60000,
        degradeThreshold: 3
      }),
      databases: new CircuitBreaker({
        name: 'notion-api-databases',
        failureThreshold: 5,
        resetTimeout: 60000,
        degradeThreshold: 3
      }),
      pages: new CircuitBreaker({
        name: 'notion-api-pages',
        failureThreshold: 5,
        resetTimeout: 60000,
        degradeThreshold: 3
      }),
      blocks: new CircuitBreaker({
        name: 'notion-api-blocks',
        failureThreshold: 5,
        resetTimeout: 60000,
        degradeThreshold: 3
      }),
      search: new CircuitBreaker({
        name: 'notion-api-search',
        failureThreshold: 5,
        resetTimeout: 60000,
        degradeThreshold: 3
      })
    };
    
    // Set up rate limit timers
    this._setupRateLimitTimers();
  }
  
  /**
   * Initialize the connection
   * @returns {Promise<boolean>} Success status
   */
  async initialize() {
    if (this.initialized) {
      return true;
    }
    
    if (this.initPromise) {
      return this.initPromise;
    }
    
    this.initPromise = (async () => {
      try {
        this.log('INFO', 'Initializing Notion connection...');
        
        // Load configuration if available
        await this._loadConfig();
        
        // Check for API token
        if (!this.options.apiToken) {
          this.log('WARN', 'No API token configured, functionality will be limited');
        }
        
        // Ensure log directory exists
        await this._ensureLogDirectory();
        
        // Test connection if API token is available
        if (this.options.apiToken) {
          await this._testConnection();
        }
        
        this.initialized = true;
        this.emit('initialized');
        
        this.log('INFO', 'Notion connection initialized');
        return true;
      } catch (err) {
        this.log('ERROR', `Initialization failed: ${err.message}`);
        this.emit('error', err);
        throw err;
      } finally {
        this.initPromise = null;
      }
    })();
    
    return this.initPromise;
  }
  
  /**
   * Load configuration from file
   * @private
   */
  async _loadConfig() {
    try {
      if (fs.existsSync(this.options.configPath)) {
        const configData = await fs.promises.readFile(this.options.configPath, 'utf8');
        const config = JSON.parse(configData);
        
        // Update options with config values
        if (config.apiToken && !this.options.apiToken) {
          this.options.apiToken = config.apiToken;
        }
        
        if (config.apiVersion) {
          this.options.apiVersion = config.apiVersion;
        }
        
        if (config.baseUrl) {
          this.options.baseUrl = config.baseUrl;
        }
        
        if (config.rateLimits) {
          if (config.rateLimits.maxRequestsPerSecond) {
            this.options.rateLimitPerSecond = config.rateLimits.maxRequestsPerSecond;
          }
          
          if (config.rateLimits.maxRequestsPerMinute) {
            this.options.rateLimitPerMinute = config.rateLimits.maxRequestsPerMinute;
          }
        }
        
        // Update rate limit state
        this.rateLimitRemaining.second = this.options.rateLimitPerSecond;
        this.rateLimitRemaining.minute = this.options.rateLimitPerMinute;
        
        this.log('INFO', 'Loaded configuration', {
          apiVersion: this.options.apiVersion,
          baseUrl: this.options.baseUrl,
          hasToken: Boolean(this.options.apiToken)
        });
      } else {
        // Create default config file
        await this._createDefaultConfig();
      }
    } catch (err) {
      this.log('ERROR', `Failed to load configuration: ${err.message}`);
      // We'll continue with default options
    }
  }
  
  /**
   * Create default configuration file
   * @private
   */
  async _createDefaultConfig() {
    try {
      const configDir = path.dirname(this.options.configPath);
      
      // Create directory if it doesn't exist
      await fs.promises.mkdir(configDir, { recursive: true });
      
      // Create default config
      const defaultConfig = {
        apiToken: '',
        apiVersion: this.options.apiVersion,
        baseUrl: this.options.baseUrl,
        rateLimits: {
          maxRequestsPerSecond: this.options.rateLimitPerSecond,
          maxRequestsPerMinute: this.options.rateLimitPerMinute,
          enableAdaptiveRateLimiting: true
        },
        retry: {
          maxRetries: this.options.maxRetries,
          baseDelay: this.options.baseDelay,
          maxDelay: this.options.maxDelay,
          factor: 2,
          jitterFactor: 0.25
        },
        circuitBreaker: {
          failureThreshold: 5,
          resetTimeout: 60000,
          degradeThreshold: 3,
          degradePercentage: 0.3
        }
      };
      
      // Write config file
      await fs.promises.writeFile(
        this.options.configPath,
        JSON.stringify(defaultConfig, null, 2)
      );
      
      this.log('INFO', `Created default configuration at ${this.options.configPath}`);
    } catch (err) {
      this.log('ERROR', `Failed to create default configuration: ${err.message}`);
    }
  }
  
  /**
   * Ensure log directory exists
   * @private
   */
  async _ensureLogDirectory() {
    try {
      await fs.promises.mkdir(this.options.logDir, { recursive: true });
    } catch (err) {
      if (err.code !== 'EEXIST') {
        this.log('ERROR', `Failed to create log directory: ${err.message}`);
        throw err;
      }
    }
  }
  
  /**
   * Test connection to Notion API
   * @private
   */
  async _testConnection() {
    try {
      const result = await this.getUsers();
      this.log('INFO', 'Connection test successful', { 
        users: result.results.length
      });
      return true;
    } catch (err) {
      this.log('ERROR', `Connection test failed: ${err.message}`);
      throw err;
    }
  }
  
  /**
   * Setup rate limit timers
   * @private
   */
  _setupRateLimitTimers() {
    // Reset per-second rate limit
    setInterval(() => {
      this.rateLimitRemaining.second = this.options.rateLimitPerSecond;
      this.rateLimitReset.second = Date.now() + 1000;
      
      // Process queue if we have pending requests
      if (this.requestQueue.length > 0 && !this.processingQueue) {
        this._processQueue();
      }
    }, 1000);
    
    // Reset per-minute rate limit
    setInterval(() => {
      this.rateLimitRemaining.minute = this.options.rateLimitPerMinute;
      this.rateLimitReset.minute = Date.now() + 60000;
    }, 60000);
  }
  
  /**
   * Process request queue
   * @private
   */
  async _processQueue() {
    if (this.processingQueue || this.requestQueue.length === 0) {
      return;
    }
    
    this.processingQueue = true;
    
    try {
      while (this.requestQueue.length > 0) {
        // Check rate limits
        if (this.rateLimitRemaining.second <= 0 || this.rateLimitRemaining.minute <= 0) {
          // We've hit a rate limit, wait for reset
          const now = Date.now();
          const waitTime = Math.max(
            this.rateLimitRemaining.second <= 0 ? this.rateLimitReset.second - now : 0,
            this.rateLimitRemaining.minute <= 0 ? this.rateLimitReset.minute - now : 0
          );
          
          if (waitTime > 0) {
            this.log('DEBUG', `Rate limit reached, waiting ${waitTime}ms before processing queue`);
            await new Promise(resolve => setTimeout(resolve, waitTime));
            continue;
          }
        }
        
        // Get next request from queue
        const request = this.requestQueue.shift();
        
        try {
          // Decrement rate limit counters
          this.rateLimitRemaining.second--;
          this.rateLimitRemaining.minute--;
          
          // Execute request
          const result = await this._executeRequest(
            request.endpoint,
            request.method,
            request.data,
            request.options
          );
          
          // Call resolver
          request.resolve(result);
        } catch (err) {
          // Call reject handler
          request.reject(err);
        }
      }
    } finally {
      this.processingQueue = false;
    }
  }
  
  /**
   * Execute a request to the Notion API
   * @param {string} endpoint - API endpoint
   * @param {string} method - HTTP method
   * @param {object} data - Request data
   * @param {object} options - Request options
   * @returns {Promise<object>} API response
   * @private
   */
  async _executeRequest(endpoint, method, data, options = {}) {
    // Track request start time
    const startTime = Date.now();
    
    // Increment request counter
    this.apiRequests++;
    
    // Choose circuit breaker based on endpoint
    const circuitBreaker = this._getCircuitBreakerForEndpoint(endpoint);
    
    try {
      // Check if circuit breaker allows the request
      if (!circuitBreaker.canRequest()) {
        throw new Error(`Circuit breaker is ${circuitBreaker.getHealth().state}`);
      }
      
      // Configure fetch options
      const fetchOptions = {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Notion-Version': this.options.apiVersion,
          ...options.headers
        },
        body: data ? JSON.stringify(data) : undefined
      };
      
      // Add authorization if available
      if (this.options.apiToken) {
        fetchOptions.headers.Authorization = `Bearer ${this.options.apiToken}`;
      }
      
      // Add timeout
      const timeoutMs = options.timeoutMs || this.options.timeoutMs;
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
      fetchOptions.signal = controller.signal;
      
      // Determine full URL
      const url = endpoint.startsWith('http') ? 
        endpoint : 
        `${this.options.baseUrl}${endpoint.startsWith('/') ? '' : '/'}${endpoint}`;
      
      // Execute with retry logic
      let attempt = 0;
      let lastError = null;
      
      while (attempt <= this.options.maxRetries) {
        try {
          // Make the request
          const response = await fetch(url, fetchOptions);
          
          // Clear timeout
          clearTimeout(timeoutId);
          
          // Update rate limit information from headers
          this._updateRateLimitsFromHeaders(response.headers);
          
          // Check for rate limiting response
          if (response.status === 429) {
            // Extract retry-after header
            const retryAfter = parseInt(response.headers.get('Retry-After') || '1', 10);
            
            // Log rate limit hit
            this.log('WARN', `Rate limit hit, retrying after ${retryAfter}s`, {
              endpoint,
              attempt: attempt + 1,
              maxRetries: this.options.maxRetries
            });
            
            // Wait for retry-after seconds
            await new Promise(resolve => setTimeout(resolve, retryAfter * 1000));
            
            // Try again
            attempt++;
            continue;
          }
          
          // Parse response
          const responseData = await response.json();
          
          // Check for error response
          if (!response.ok) {
            throw new Error(`Notion API error: ${response.status} - ${responseData.message || 'Unknown error'}`);
          }
          
          // Record success with circuit breaker
          circuitBreaker.success();
          
          // Return successful response
          return responseData;
        } catch (err) {
          lastError = err;
          
          // Check if we're aborting
          if (err.name === 'AbortError') {
            throw new Error(`Request timeout after ${timeoutMs}ms`);
          }
          
          // Check if we've reached max retries
          if (attempt >= this.options.maxRetries) {
            break;
          }
          
          // Calculate retry delay with exponential backoff and jitter
          const delay = Math.min(
            this.options.maxDelay,
            this.options.baseDelay * Math.pow(2, attempt)
          );
          
          // Add jitter (±25%)
          const jitter = delay * 0.25 * (Math.random() * 2 - 1);
          const retryDelay = delay + jitter;
          
          this.log('WARN', `Request failed, retrying in ${Math.round(retryDelay)}ms`, {
            endpoint,
            error: err.message,
            attempt: attempt + 1,
            maxRetries: this.options.maxRetries
          });
          
          // Wait before retrying
          await new Promise(resolve => setTimeout(resolve, retryDelay));
          
          // Increment attempt counter
          attempt++;
        }
      }
      
      // If we get here, all retries failed
      this.apiErrors++;
      
      // Record failure with circuit breaker
      circuitBreaker.failure();
      
      // Throw last error
      throw lastError || new Error('Request failed after multiple retries');
    } catch (err) {
      // Track error
      this.apiErrors++;
      
      // Record failure with circuit breaker
      circuitBreaker.failure();
      
      // Log error
      this.log('ERROR', `API request failed: ${err.message}`, {
        endpoint,
        method,
        circuitBreaker: circuitBreaker.getHealth().state
      });
      
      // Rethrow
      throw err;
    } finally {
      // Track request duration
      const duration = Date.now() - startTime;
      
      // Log request completion
      this.log('DEBUG', `API request completed in ${duration}ms`, {
        endpoint,
        method,
        duration
      });
      
      // Emit request metrics
      this.emit('request', {
        endpoint,
        method,
        duration,
        success: !lastError
      });
    }
  }
  
  /**
   * Update rate limit information from response headers
   * @param {Headers} headers - Response headers
   * @private
   */
  _updateRateLimitsFromHeaders(headers) {
    // Extract rate limit headers
    const rateLimitPerSecond = headers.get('X-RateLimit-Limit-Second');
    const rateLimitRemainingSecond = headers.get('X-RateLimit-Remaining-Second');
    const rateLimitPerMinute = headers.get('X-RateLimit-Limit-Minute');
    const rateLimitRemainingMinute = headers.get('X-RateLimit-Remaining-Minute');
    
    // Update rate limit values if available
    if (rateLimitPerSecond) {
      this.options.rateLimitPerSecond = parseInt(rateLimitPerSecond, 10);
    }
    
    if (rateLimitRemainingSecond) {
      this.rateLimitRemaining.second = parseInt(rateLimitRemainingSecond, 10);
    }
    
    if (rateLimitPerMinute) {
      this.options.rateLimitPerMinute = parseInt(rateLimitPerMinute, 10);
    }
    
    if (rateLimitRemainingMinute) {
      this.rateLimitRemaining.minute = parseInt(rateLimitRemainingMinute, 10);
    }
  }
  
  /**
   * Get appropriate circuit breaker for an endpoint
   * @param {string} endpoint - API endpoint
   * @returns {CircuitBreaker} Circuit breaker
   * @private
   */
  _getCircuitBreakerForEndpoint(endpoint) {
    if (endpoint.includes('/databases')) {
      return this.circuitBreakers.databases;
    } else if (endpoint.includes('/pages')) {
      return this.circuitBreakers.pages;
    } else if (endpoint.includes('/blocks')) {
      return this.circuitBreakers.blocks;
    } else if (endpoint.includes('/search')) {
      return this.circuitBreakers.search;
    } else {
      return this.circuitBreakers.default;
    }
  }
  
  /**
   * Queue a request with rate limiting
   * @param {string} endpoint - API endpoint
   * @param {string} method - HTTP method
   * @param {object} data - Request data
   * @param {object} options - Request options
   * @returns {Promise<object>} API response
   * @private
   */
  _queueRequest(endpoint, method, data, options = {}) {
    return new Promise((resolve, reject) => {
      // Add request to queue
      this.requestQueue.push({
        endpoint,
        method,
        data,
        options,
        resolve,
        reject
      });
      
      // Start processing queue if not already processing
      if (!this.processingQueue) {
        this._processQueue();
      }
    });
  }
  
  /**
   * Make a request to the Notion API
   * @param {string} endpoint - API endpoint
   * @param {string} method - HTTP method
   * @param {object} data - Request data
   * @param {object} options - Request options
   * @returns {Promise<object>} API response
   */
  async request(endpoint, method, data, options = {}) {
    if (!this.initialized) {
      await this.initialize();
    }
    
    return this._queueRequest(endpoint, method, data, options);
  }
  
  /**
   * Get users from the Notion API
   * @param {object} options - Request options
   * @returns {Promise<object>} API response
   */
  async getUsers(options = {}) {
    return this.request('users', 'GET', null, options);
  }
  
  /**
   * Get user by ID
   * @param {string} userId - User ID
   * @param {object} options - Request options
   * @returns {Promise<object>} API response
   */
  async getUser(userId, options = {}) {
    return this.request(`users/${userId}`, 'GET', null, options);
  }
  
  /**
   * Get bot/auth user information
   * @param {object} options - Request options
   * @returns {Promise<object>} API response
   */
  async getSelf(options = {}) {
    return this.request('users/me', 'GET', null, options);
  }
  
  /**
   * Query a database
   * @param {string} databaseId - Database ID
   * @param {object} query - Query parameters
   * @param {object} options - Request options
   * @returns {Promise<object>} API response
   */
  async queryDatabase(databaseId, query = {}, options = {}) {
    return this.request(`databases/${databaseId}/query`, 'POST', query, options);
  }
  
  /**
   * Retrieve a database
   * @param {string} databaseId - Database ID
   * @param {object} options - Request options
   * @returns {Promise<object>} API response
   */
  async getDatabase(databaseId, options = {}) {
    return this.request(`databases/${databaseId}`, 'GET', null, options);
  }
  
  /**
   * Create a database
   * @param {object} data - Database data
   * @param {object} options - Request options
   * @returns {Promise<object>} API response
   */
  async createDatabase(data, options = {}) {
    return this.request('databases', 'POST', data, options);
  }
  
  /**
   * Update a database
   * @param {string} databaseId - Database ID
   * @param {object} data - Update data
   * @param {object} options - Request options
   * @returns {Promise<object>} API response
   */
  async updateDatabase(databaseId, data, options = {}) {
    return this.request(`databases/${databaseId}`, 'PATCH', data, options);
  }
  
  /**
   * Retrieve a page
   * @param {string} pageId - Page ID
   * @param {object} options - Request options
   * @returns {Promise<object>} API response
   */
  async getPage(pageId, options = {}) {
    return this.request(`pages/${pageId}`, 'GET', null, options);
  }
  
  /**
   * Create a page
   * @param {object} data - Page data
   * @param {object} options - Request options
   * @returns {Promise<object>} API response
   */
  async createPage(data, options = {}) {
    return this.request('pages', 'POST', data, options);
  }
  
  /**
   * Update a page
   * @param {string} pageId - Page ID
   * @param {object} data - Update data
   * @param {object} options - Request options
   * @returns {Promise<object>} API response
   */
  async updatePage(pageId, data, options = {}) {
    return this.request(`pages/${pageId}`, 'PATCH', data, options);
  }
  
  /**
   * Get block children
   * @param {string} blockId - Block ID
   * @param {object} params - Query parameters
   * @param {object} options - Request options
   * @returns {Promise<object>} API response
   */
  async getBlockChildren(blockId, params = {}, options = {}) {
    // Build query string
    const queryParams = new URLSearchParams();
    if (params.start_cursor) queryParams.append('start_cursor', params.start_cursor);
    if (params.page_size) queryParams.append('page_size', params.page_size);
    
    const queryString = queryParams.toString();
    const endpoint = `blocks/${blockId}/children${queryString ? `?${queryString}` : ''}`;
    
    return this.request(endpoint, 'GET', null, options);
  }
  
  /**
   * Append block children
   * @param {string} blockId - Block ID
   * @param {Array} children - Child blocks
   * @param {object} options - Request options
   * @returns {Promise<object>} API response
   */
  async appendBlockChildren(blockId, children, options = {}) {
    return this.request(`blocks/${blockId}/children`, 'PATCH', { children }, options);
  }
  
  /**
   * Search Notion
   * @param {object} query - Search query
   * @param {object} options - Request options
   * @returns {Promise<object>} API response
   */
  async search(query = {}, options = {}) {
    return this.request('search', 'POST', query, options);
  }
  
  /**
   * Retrieve a comment
   * @param {string} blockId - Block ID
   * @param {object} params - Query parameters
   * @param {object} options - Request options
   * @returns {Promise<object>} API response
   */
  async getComments(blockId, params = {}, options = {}) {
    // Build query string
    const queryParams = new URLSearchParams();
    if (params.start_cursor) queryParams.append('start_cursor', params.start_cursor);
    if (params.page_size) queryParams.append('page_size', params.page_size);
    
    const queryString = queryParams.toString();
    const endpoint = `comments?block_id=${blockId}${queryString ? `&${queryString}` : ''}`;
    
    return this.request(endpoint, 'GET', null, options);
  }
  
  /**
   * Create a comment
   * @param {object} data - Comment data
   * @param {object} options - Request options
   * @returns {Promise<object>} API response
   */
  async createComment(data, options = {}) {
    return this.request('comments', 'POST', data, options);
  }
  
  /**
   * Get connection health status
   * @returns {object} Health status
   */
  getHealth() {
    return {
      initialized: this.initialized,
      apiRequests: this.apiRequests,
      apiErrors: this.apiErrors,
      requestQueue: this.requestQueue.length,
      circuitBreakers: {
        default: this.circuitBreakers.default.getHealth(),
        databases: this.circuitBreakers.databases.getHealth(),
        pages: this.circuitBreakers.pages.getHealth(),
        blocks: this.circuitBreakers.blocks.getHealth(),
        search: this.circuitBreakers.search.getHealth()
      },
      rateLimits: {
        perSecond: {
          limit: this.options.rateLimitPerSecond,
          remaining: this.rateLimitRemaining.second,
          reset: new Date(this.rateLimitReset.second).toISOString()
        },
        perMinute: {
          limit: this.options.rateLimitPerMinute,
          remaining: this.rateLimitRemaining.minute,
          reset: new Date(this.rateLimitReset.minute).toISOString()
        }
      }
    };
  }
  
  /**
   * Log a message
   * @param {string} level - Log level
   * @param {string} message - Log message
   * @param {object} [data] - Additional data
   */
  log(level, message, data = {}) {
    const logEntry = JSON.stringify({
      timestamp: new Date().toISOString(),
      level,
      component: 'notion-connection-manager',
      message,
      ...data
    });
    
    console.log(logEntry);
    
    try {
      fs.appendFileSync(this.logFile, logEntry + '\n');
    } catch (err) {
      console.error(`Failed to write to log file: ${err.message}`);
    }
  }
}

module.exports = {
  NotionConnectionManager
};
