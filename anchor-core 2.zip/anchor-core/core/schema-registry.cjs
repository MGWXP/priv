/**
 * schema-registry.cjs - Enhanced schema registry for CNIF
 * © 2025 XPV - MIT
 * 
 * Implements a versioned schema registry with SchemaVer approach
 * (MODEL-REVISION-ADDITION) and comprehensive validation.
 */

const fs = require('fs');
const path = require('path');
const EventEmitter = require('events');

/**
 * SchemaRegistry manages schema versioning and validation
 * for Claude-Notion integration with memory optimizations
 * for M3 Max hardware.
 */
class SchemaRegistry extends EventEmitter {
  /**
   * Create a new SchemaRegistry
   * @param {object} options - Registry options
   */
  constructor(options = {}) {
    super();
    
    // Configure paths and options with sensible defaults
    this.options = {
      schemaDirClaude: options.schemaDirClaude || 
                       path.join(process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core', 'schemas', 'claude'),
      schemaDirNotion: options.schemaDirNotion || 
                       path.join(process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core', 'schemas', 'notion'),
      cacheEnabled: options.cacheEnabled !== false,
      validateOnLoad: options.validateOnLoad !== false,
      memoryOptimized: options.memoryOptimized !== false,
      autoReload: options.autoReload === true
    };
    
    // Schema storage with Map for optimal key-based lookup
    this.schemas = {
      claude: new Map(),
      notion: new Map()
    };
    
    // Schema version storage
    this.versions = {
      claude: new Map(),
      notion: new Map()
    };
    
    // Cache for validated schemas to reduce validation overhead
    this.validationCache = new Map();
    
    // Track initialization state
    this.initialized = false;
    this.initializePromise = null;
    
    // Set up file watchers if auto-reload is enabled
    if (this.options.autoReload) {
      this._setupWatchers();
    }
  }
  
  /**
   * Initialize the registry
   * @returns {Promise<boolean>} Success status
   */
  async initialize() {
    // Return existing promise if already initializing
    if (this.initializePromise) {
      return this.initializePromise;
    }
    
    this.initializePromise = (async () => {
      try {
        // Create schema directories if they don't exist
        await this._ensureDirectory(this.options.schemaDirClaude);
        await this._ensureDirectory(this.options.schemaDirNotion);
        
        // Load schema files
        await Promise.all([
          this._loadSchemas('claude', this.options.schemaDirClaude, this.schemas.claude),
          this._loadSchemas('notion', this.options.schemaDirNotion, this.schemas.notion)
        ]);
        
        this.initialized = true;
        this.emit('initialized');
        
        return true;
      } catch (err) {
        this.emit('error', err);
        throw err;
      } finally {
        // Clear the initialization promise
        this.initializePromise = null;
      }
    })();
    
    return this.initializePromise;
  }
  
  /**
   * Ensure directory exists
   * @param {string} dir - Directory path
   * @private
   */
  async _ensureDirectory(dir) {
    try {
      await fs.promises.mkdir(dir, { recursive: true });
    } catch (err) {
      // Ignore if directory already exists
      if (err.code !== 'EEXIST') {
        console.error(`Error creating directory ${dir}: ${err.message}`);
        throw err;
      }
    }
  }
  
  /**
   * Set up file watchers for auto-reloading schemas
   * @private
   */
  _setupWatchers() {
    const watchDir = (dir, type) => {
      try {
        fs.watch(dir, { persistent: false }, async (eventType, filename) => {
          if (eventType === 'change' && filename.endsWith('.json')) {
            console.log(`Schema file changed: ${filename}`);
            try {
              // Load the changed schema
              const schemaPath = path.join(dir, filename);
              await this._loadSchema(type, schemaPath, this.schemas[type]);
              this.emit('schema-updated', { type, file: filename });
            } catch (err) {
              console.error(`Error reloading schema ${filename}: ${err.message}`);
              this.emit('error', err);
            }
          }
        });
      } catch (err) {
        console.error(`Error setting up watcher for ${dir}: ${err.message}`);
      }
    };
    
    // Set up watchers after initialization
    this.on('initialized', () => {
      watchDir(this.options.schemaDirClaude, 'claude');
      watchDir(this.options.schemaDirNotion, 'notion');
    });
  }
  
  /**
   * Load schemas from directory
   * @param {string} type - Schema type ('claude' or 'notion')
   * @param {string} dir - Directory path
   * @param {Map} targetMap - Target map to store schemas
   * @private
   */
  async _loadSchemas(type, dir, targetMap) {
    try {
      const files = await fs.promises.readdir(dir);
      
      // Load schemas in parallel for better performance
      const loadPromises = files
        .filter(file => file.endsWith('.json'))
        .map(file => this._loadSchema(type, path.join(dir, file), targetMap));
      
      await Promise.all(loadPromises);
      
      this.emit('schemas-loaded', { 
        type, 
        count: targetMap.size,
        directory: dir
      });
    } catch (err) {
      console.error(`Error reading schema directory ${dir}: ${err.message}`);
      this.emit('error', err);
      throw err;
    }
  }
  
  /**
   * Load an individual schema file
   * @param {string} type - Schema type ('claude' or 'notion')
   * @param {string} filePath - Path to schema file
   * @param {Map} targetMap - Target map to store schema
   * @private
   */
  async _loadSchema(type, filePath, targetMap) {
    try {
      const content = await fs.promises.readFile(filePath, 'utf8');
      const schema = JSON.parse(content);
      
      // Validate schema structure
      if (this.options.validateOnLoad && !this._validateSchemaStructure(schema)) {
        console.warn(`Invalid schema structure: ${filePath}`);
        this.emit('schema-invalid', { type, path: filePath });
        return false;
      }
      
      // Extract schema information
      const id = schema.id || path.basename(filePath, '.json');
      const version = schema.version || '1-0-0'; // Default version
      
      // Store schema by ID
      targetMap.set(id, schema);
      
      // Update version tracking
      if (!this.versions[type].has(id)) {
        this.versions[type].set(id, []);
      }
      
      const versions = this.versions[type].get(id);
      
      // Only add version if not already present
      if (!versions.includes(version)) {
        versions.push(version);
        // Sort versions in descending order (latest first)
        versions.sort((a, b) => this._compareVersions(b, a));
      }
      
      this.emit('schema-loaded', { 
        type, 
        id, 
        version, 
        path: filePath 
      });
      
      return true;
    } catch (err) {
      console.error(`Error loading schema ${filePath}: ${err.message}`);
      this.emit('error', err);
      return false;
    }
  }
  
  /**
   * Compare SchemaVer versions (MODEL-REVISION-ADDITION)
   * @param {string} v1 - First version string
   * @param {string} v2 - Second version string
   * @returns {number} Comparison result (-1, 0, 1)
   * @private
   */
  _compareVersions(v1, v2) {
    const parse = (v) => {
      const parts = v.split('-').map(Number);
      return { 
        model: parts[0] || 0, 
        revision: parts[1] || 0, 
        addition: parts[2] || 0 
      };
    };
    
    const a = parse(v1);
    const b = parse(v2);
    
    // Compare model (major) version
    if (a.model !== b.model) return a.model - b.model;
    
    // Compare revision (minor) version
    if (a.revision !== b.revision) return a.revision - b.revision;
    
    // Compare addition (patch) version
    return a.addition - b.addition;
  }
  
  /**
   * Validate schema structure
   * @param {object} schema - Schema to validate
   * @returns {boolean} Validation result
   * @private
   */
  _validateSchemaStructure(schema) {
    if (!schema || typeof schema !== 'object') return false;
    
    // Basic structure validation
    if (!schema.id && !schema.title) return false;
    if (!schema.version && !schema.$schema) return false;
    if (!schema.schema && !schema.properties) return false;
    
    return true;
  }
  
  /**
   * Get a schema by type, ID and version
   * @param {string} type - Schema type ('claude' or 'notion')
   * @param {string} id - Schema ID
   * @param {string} [version] - Schema version (optional, uses latest if not specified)
   * @returns {object|null} Schema or null if not found
   */
  getSchema(type, id, version) {
    if (!this.initialized) {
      throw new Error('Schema registry not initialized');
    }
    
    if (!this.schemas[type]) {
      throw new Error(`Invalid schema type: ${type}`);
    }
    
    if (!this.schemas[type].has(id)) {
      return null;
    }
    
    const schema = this.schemas[type].get(id);
    
    // If no specific version requested, return the schema
    if (!version) {
      return schema;
    }
    
    // Otherwise check if this is the requested version
    if (schema.version === version) {
      return schema;
    }
    
    // If specific version requested and doesn't match, try to load it
    const schemaDir = type === 'claude' ? this.options.schemaDirClaude : this.options.schemaDirNotion;
    const schemaPath = path.join(schemaDir, `${id}-${version}.json`);
    
    try {
      if (fs.existsSync(schemaPath)) {
        const versionedSchema = JSON.parse(fs.readFileSync(schemaPath, 'utf8'));
        
        // Cache this version for future requests
        if (this.options.cacheEnabled) {
          this.schemas[type].set(`${id}@${version}`, versionedSchema);
        }
        
        return versionedSchema;
      }
    } catch (err) {
      console.error(`Error loading schema version ${id}@${version}: ${err.message}`);
    }
    
    return null;
  }
  
  /**
   * Get latest schema version by type and ID
   * @param {string} type - Schema type ('claude' or 'notion')
   * @param {string} id - Schema ID
   * @returns {string|null} Latest version or null if not found
   */
  getLatestVersion(type, id) {
    if (!this.initialized) {
      throw new Error('Schema registry not initialized');
    }
    
    if (!this.versions[type] || !this.versions[type].has(id)) {
      return null;
    }
    
    const versions = this.versions[type].get(id);
    return versions[0] || null; // First version is the latest (sorted in descending order)
  }
  
  /**
   * Register a new schema
   * @param {string} type - Schema type ('claude' or 'notion')
   * @param {object} schema - Schema to register
   * @returns {Promise<boolean>} Success status
   */
  async registerSchema(type, schema) {
    if (!this.initialized) {
      throw new Error('Schema registry not initialized');
    }
    
    if (!this.schemas[type]) {
      throw new Error(`Invalid schema type: ${type}`);
    }
    
    // Validate schema structure
    if (!this._validateSchemaStructure(schema)) {
      throw new Error('Invalid schema structure');
    }
    
    const id = schema.id;
    const version = schema.version || '1-0-0';
    
    // Store schema
    this.schemas[type].set(id, schema);
    
    // Update version tracking
    if (!this.versions[type].has(id)) {
      this.versions[type].set(id, []);
    }
    
    const versions = this.versions[type].get(id);
    
    // Only add version if not already present
    if (!versions.includes(version)) {
      versions.push(version);
      // Sort versions in descending order (latest first)
      versions.sort((a, b) => this._compareVersions(b, a));
    }
    
    // Determine schema directory
    const schemaDir = type === 'claude' ? this.options.schemaDirClaude : this.options.schemaDirNotion;
    
    // Save schema to disk
    const schemaPath = path.join(schemaDir, `${id}-${version}.json`);
    
    try {
      await fs.promises.writeFile(schemaPath, JSON.stringify(schema, null, 2));
      
      this.emit('schema-registered', { 
        type, 
        id, 
        version, 
        path: schemaPath 
      });
      
      return true;
    } catch (err) {
      console.error(`Error writing schema to ${schemaPath}: ${err.message}`);
      this.emit('error', err);
      throw err;
    }
  }
  
  /**
   * Validate data against schema
   * @param {string} type - Schema type ('claude' or 'notion')
   * @param {string} id - Schema ID
   * @param {object} data - Data to validate
   * @param {string} [version] - Schema version (optional, uses latest if not specified)
   * @returns {object} Validation result { valid: boolean, errors: array }
   */
  validateData(type, id, data, version) {
    if (!this.initialized) {
      throw new Error('Schema registry not initialized');
    }
    
    // Get the schema
    const schema = this.getSchema(type, id, version);
    
    if (!schema) {
      throw new Error(`Schema not found: ${type}/${id}${version ? `@${version}` : ''}`);
    }
    
    // Check cache for validation result if enabled
    const cacheKey = `${type}:${id}:${version || 'latest'}:${JSON.stringify(data)}`;
    
    if (this.options.cacheEnabled && this.validationCache.has(cacheKey)) {
      return this.validationCache.get(cacheKey);
    }
    
    // Track validation start time for performance metrics
    const startTime = process.hrtime.bigint();
    
    // Collect validation errors
    const errors = [];
    const schemaObj = schema.schema || schema;
    
    try {
      // Validate data against schema
      this._validateObject(data, schemaObj, '', errors);
      
      // Calculate validation time
      const endTime = process.hrtime.bigint();
      const validationTimeMs = Number(endTime - startTime) / 1000000;
      
      // Create validation result
      const result = {
        valid: errors.length === 0,
        errors,
        validationTimeMs,
        schemaId: id,
        schemaVersion: version || schema.version || 'unknown'
      };
      
      // Store in cache if enabled and not too large
      if (this.options.cacheEnabled && 
          JSON.stringify(result).length < 10000 && // Don't cache large results
          errors.length < 10) { // Don't cache heavily invalid data
        this.validationCache.set(cacheKey, result);
        
        // Limit cache size for memory optimization
        if (this.validationCache.size > 1000) {
          // Remove oldest entries (simple approach, could be improved)
          const keysToDelete = Array.from(this.validationCache.keys()).slice(0, 100);
          for (const key of keysToDelete) {
            this.validationCache.delete(key);
          }
        }
      }
      
      // Emit validation event
      this.emit('schema-validation', {
        type,
        id,
        version: version || schema.version || 'unknown',
        valid: result.valid,
        errorCount: errors.length,
        validationTimeMs
      });
      
      return result;
    } catch (err) {
      const error = {
        path: '',
        message: err.message
      };
      
      errors.push(error);
      
      this.emit('schema-validation-error', {
        type,
        id,
        version: version || schema.version || 'unknown',
        error: err.message
      });
      
      return {
        valid: false,
        errors,
        schemaId: id,
        schemaVersion: version || schema.version || 'unknown',
        error: err.message
      };
    }
  }
  
  /**
   * Validate object against schema
   * @param {object} data - Data to validate
   * @param {object} schema - Schema to validate against
   * @param {string} path - Current path
   * @param {array} errors - Error array
   * @private
   */
  _validateObject(data, schema, path, errors) {
    // Handle different schema formats
    const schemaType = schema.type || 'object';
    
    switch (schemaType) {
      case 'object':
        this._validateObjectType(data, schema, path, errors);
        break;
        
      case 'array':
        this._validateArrayType(data, schema, path, errors);
        break;
        
      case 'string':
        this._validateStringType(data, schema, path, errors);
        break;
        
      case 'number':
      case 'integer':
        this._validateNumberType(data, schema, path, errors);
        break;
        
      case 'boolean':
        this._validateBooleanType(data, schema, path, errors);
        break;
        
      case 'null':
        this._validateNullType(data, schema, path, errors);
        break;
        
      default:
        // For unknown types, just check basic type
        if (typeof data !== schemaType) {
          errors.push({
            path,
            message: `Expected ${schemaType} but got ${typeof data}`
          });
        }
    }
    
    // Handle schema extensions like enum, const, etc.
    this._validateEnumValues(data, schema, path, errors);
    this._validateConstValue(data, schema, path, errors);
  }
  
  /**
   * Validate object type
   * @param {object} data - Data to validate
   * @param {object} schema - Schema to validate against
   * @param {string} path - Current path
   * @param {array} errors - Error array
   * @private
   */
  _validateObjectType(data, schema, path, errors) {
    if (typeof data !== 'object' || data === null || Array.isArray(data)) {
      errors.push({
        path,
        message: `Expected object but got ${data === null ? 'null' : typeof data}`
      });
      return;
    }
    
    // Validate required properties
    if (schema.required) {
      for (const prop of schema.required) {
        if (!(prop in data)) {
          errors.push({
            path: path ? `${path}.${prop}` : prop,
            message: `Missing required property: ${prop}`
          });
        }
      }
    }
    
    // Validate properties
    if (schema.properties) {
      for (const [prop, propSchema] of Object.entries(schema.properties)) {
        if (prop in data) {
          this._validateObject(
            data[prop],
            propSchema,
            path ? `${path}.${prop}` : prop,
            errors
          );
        }
      }
    }
    
    // Validate additionalProperties
    if (schema.additionalProperties === false) {
      for (const prop in data) {
        if (!schema.properties || !(prop in schema.properties)) {
          errors.push({
            path: path ? `${path}.${prop}` : prop,
            message: `Property not allowed: ${prop}`
          });
        }
      }
    } else if (schema.additionalProperties && typeof schema.additionalProperties === 'object') {
      for (const prop in data) {
        if (!schema.properties || !(prop in schema.properties)) {
          this._validateObject(
            data[prop],
            schema.additionalProperties,
            path ? `${path}.${prop}` : prop,
            errors
          );
        }
      }
    }
  }
  
  /**
   * Validate array type
   * @param {array} data - Data to validate
   * @param {object} schema - Schema to validate against
   * @param {string} path - Current path
   * @param {array} errors - Error array
   * @private
   */
  _validateArrayType(data, schema, path, errors) {
    if (!Array.isArray(data)) {
      errors.push({
        path,
        message: `Expected array but got ${typeof data}`
      });
      return;
    }
    
    // Validate items
    if (schema.items) {
      for (let i = 0; i < data.length; i++) {
        this._validateObject(
          data[i],
          schema.items,
          path ? `${path}[${i}]` : `[${i}]`,
          errors
        );
      }
    }
    
    // Validate minItems
    if (schema.minItems !== undefined && data.length < schema.minItems) {
      errors.push({
        path,
        message: `Array has ${data.length} items, but minimum is ${schema.minItems}`
      });
    }
    
    // Validate maxItems
    if (schema.maxItems !== undefined && data.length > schema.maxItems) {
      errors.push({
        path,
        message: `Array has ${data.length} items, but maximum is ${schema.maxItems}`
      });
    }
    
    // Validate uniqueItems
    if (schema.uniqueItems === true) {
      const seen = new Set();
      for (let i = 0; i < data.length; i++) {
        const value = data[i];
        const valueStr = JSON.stringify(value);
        if (seen.has(valueStr)) {
          errors.push({
            path: path ? `${path}[${i}]` : `[${i}]`,
            message: `Duplicate value found at index ${i}`
          });
        }
        seen.add(valueStr);
      }
    }
  }
  
  /**
   * Validate string type
   * @param {string} data - Data to validate
   * @param {object} schema - Schema to validate against
   * @param {string} path - Current path
   * @param {array} errors - Error array
   * @private
   */
  _validateStringType(data, schema, path, errors) {
    if (typeof data !== 'string') {
      errors.push({
        path,
        message: `Expected string but got ${typeof data}`
      });
      return;
    }
    
    // Validate pattern
    if (schema.pattern) {
      const regex = new RegExp(schema.pattern);
      if (!regex.test(data)) {
        errors.push({
          path,
          message: `String does not match pattern: ${schema.pattern}`
        });
      }
    }
    
    // Validate minLength
    if (schema.minLength !== undefined && data.length < schema.minLength) {
      errors.push({
        path,
        message: `String length is ${data.length}, but minimum is ${schema.minLength}`
      });
    }
    
    // Validate maxLength
    if (schema.maxLength !== undefined && data.length > schema.maxLength) {
      errors.push({
        path,
        message: `String length is ${data.length}, but maximum is ${schema.maxLength}`
      });
    }
    
    // Validate format (basic implementation)
    if (schema.format) {
      // Implement basic format validation
      switch (schema.format) {
        case 'email':
          if (!data.includes('@')) {
            errors.push({
              path,
              message: `Invalid email format: ${data}`
            });
          }
          break;
          
        case 'uri':
          try {
            new URL(data);
          } catch (e) {
            errors.push({
              path,
              message: `Invalid URI format: ${data}`
            });
          }
          break;
          
        case 'date-time':
          if (isNaN(Date.parse(data))) {
            errors.push({
              path,
              message: `Invalid date-time format: ${data}`
            });
          }
          break;
      }
    }
  }
  
  /**
   * Validate number type
   * @param {number} data - Data to validate
   * @param {object} schema - Schema to validate against
   * @param {string} path - Current path
   * @param {array} errors - Error array
   * @private
   */
  _validateNumberType(data, schema, path, errors) {
    if (typeof data !== 'number') {
      errors.push({
        path,
        message: `Expected ${schema.type} but got ${typeof data}`
      });
      return;
    }
    
    // Validate integer type
    if (schema.type === 'integer' && !Number.isInteger(data)) {
      errors.push({
        path,
        message: 'Expected integer but got float'
      });
    }
    
    // Validate minimum
    if (schema.minimum !== undefined) {
      if (schema.exclusiveMinimum === true && data <= schema.minimum) {
        errors.push({
          path,
          message: `Value ${data} is not greater than ${schema.minimum}`
        });
      } else if (data < schema.minimum) {
        errors.push({
          path,
          message: `Value ${data} is less than minimum ${schema.minimum}`
        });
      }
    }
    
    // Validate maximum
    if (schema.maximum !== undefined) {
      if (schema.exclusiveMaximum === true && data >= schema.maximum) {
        errors.push({
          path,
          message: `Value ${data} is not less than ${schema.maximum}`
        });
      } else if (data > schema.maximum) {
        errors.push({
          path,
          message: `Value ${data} is greater than maximum ${schema.maximum}`
        });
      }
    }
    
    // Validate multipleOf
    if (schema.multipleOf !== undefined) {
      const remainder = data % schema.multipleOf;
      if (remainder !== 0 && Math.abs(remainder - schema.multipleOf) > Number.EPSILON) {
        errors.push({
          path,
          message: `Value ${data} is not a multiple of ${schema.multipleOf}`
        });
      }
    }
  }
  
  /**
   * Validate boolean type
   * @param {boolean} data - Data to validate
   * @param {object} schema - Schema to validate against
   * @param {string} path - Current path
   * @param {array} errors - Error array
   * @private
   */
  _validateBooleanType(data, schema, path, errors) {
    if (typeof data !== 'boolean') {
      errors.push({
        path,
        message: `Expected boolean but got ${typeof data}`
      });
    }
  }
  
  /**
   * Validate null type
   * @param {null} data - Data to validate
   * @param {object} schema - Schema to validate against
   * @param {string} path - Current path
   * @param {array} errors - Error array
   * @private
   */
  _validateNullType(data, schema, path, errors) {
    if (data !== null) {
      errors.push({
        path,
        message: `Expected null but got ${typeof data}`
      });
    }
  }
  
  /**
   * Validate enum values
   * @param {any} data - Data to validate
   * @param {object} schema - Schema to validate against
   * @param {string} path - Current path
   * @param {array} errors - Error array
   * @private
   */
  _validateEnumValues(data, schema, path, errors) {
    if (schema.enum) {
      const found = schema.enum.some(value => 
        JSON.stringify(value) === JSON.stringify(data)
      );
      
      if (!found) {
        errors.push({
          path,
          message: `Value ${JSON.stringify(data)} is not one of the allowed values: ${JSON.stringify(schema.enum)}`
        });
      }
    }
  }
  
  /**
   * Validate const value
   * @param {any} data - Data to validate
   * @param {object} schema - Schema to validate against
   * @param {string} path - Current path
   * @param {array} errors - Error array
   * @private
   */
  _validateConstValue(data, schema, path, errors) {
    if (schema.const !== undefined) {
      if (JSON.stringify(data) !== JSON.stringify(schema.const)) {
        errors.push({
          path,
          message: `Value ${JSON.stringify(data)} is not equal to const value ${JSON.stringify(schema.const)}`
        });
      }
    }
  }
  
  /**
   * Get all registered schemas of a type
   * @param {string} type - Schema type ('claude' or 'notion')
   * @returns {Array} Array of schema objects
   */
  getAllSchemas(type) {
    if (!this.initialized) {
      throw new Error('Schema registry not initialized');
    }
    
    if (!this.schemas[type]) {
      throw new Error(`Invalid schema type: ${type}`);
    }
    
    return Array.from(this.schemas[type].values());
  }
  
  /**
   * Get schema metrics
   * @returns {object} Schema registry metrics
   */
  getMetrics() {
    return {
      initialized: this.initialized,
      schemaCount: {
        claude: this.schemas.claude.size,
        notion: this.schemas.notion.size,
        total: this.schemas.claude.size + this.schemas.notion.size
      },
      latestVersions: {
        claude: Object.fromEntries(
          Array.from(this.versions.claude.entries())
            .map(([id, versions]) => [id, versions[0] || null])
        ),
        notion: Object.fromEntries(
          Array.from(this.versions.notion.entries())
            .map(([id, versions]) => [id, versions[0] || null])
        )
      },
      cachingEnabled: this.options.cacheEnabled,
      cacheSize: this.validationCache.size,
      memoryOptimized: this.options.memoryOptimized
    };
  }
  
  /**
   * Reload all schemas from disk
   * @returns {Promise<object>} Result with loaded schema counts
   */
  async reload() {
    // Clear schema storage
    this.schemas.claude.clear();
    this.schemas.notion.clear();
    this.versions.claude.clear();
    this.versions.notion.clear();
    
    // Clear validation cache
    this.validationCache.clear();
    
    // Load schemas
    await Promise.all([
      this._loadSchemas('claude', this.options.schemaDirClaude, this.schemas.claude),
      this._loadSchemas('notion', this.options.schemaDirNotion, this.schemas.notion)
    ]);
    
    this.emit('schemas-reloaded');
    
    return {
      claudeCount: this.schemas.claude.size,
      notionCount: this.schemas.notion.size,
      totalCount: this.schemas.claude.size + this.schemas.notion.size
    };
  }
}

module.exports = SchemaRegistry;
