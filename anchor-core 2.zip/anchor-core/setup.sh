#!/bin/bash
# Set up CNIF for execution

# Make recovery script executable and run it
chmod +x recover-cnif.sh
./recover-cnif.sh

# Run the basic test to verify environment
./run-basic-test.sh

# Ready to start
echo "\nReady to start CNIF. Run the following command to launch:\n"
echo "  ./launch-optimized.sh"
