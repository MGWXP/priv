# Enhanced Notion Integration for Claude

This guide explains how to set up and use the enhanced Notion integration for Claude with SQLite metadata storage, optimized for your M3 Max hardware.

## Overview

The enhanced Notion integration provides the following features:

- **SQLite Metadata Storage**: Caches Notion data locally for faster access and reduced API calls
- **M3 Max Optimization**: Configured for optimal performance on Apple silicon
- **Comprehensive API Coverage**: Full support for Notion's API capabilities
- **Enhanced Error Handling**: Robust error recovery and logging
- **Memory Management**: Efficient memory usage with garbage collection

## Setup Instructions

1. **Run the setup script**

```bash
cd /Users/XPV/Desktop/anchor-core
bash ./make-notion-setup-executable.sh
```

2. **Configure your Notion API token**

You'll need a Notion integration token. If you don't have one already:
   - Go to [https://www.notion.so/my-integrations](https://www.notion.so/my-integrations)
   - Click "New integration"
   - Name it (e.g., "Claude Integration")
   - Select the workspace to install it in
   - Copy the "Internal Integration Token"

3. **Ensure permissions**

For each Notion page/database you want Claude to access:
   - Open the page in Notion
   - Click "Share" in the top right
   - Click "Add people, emails, groups, or integrations"
   - Find your integration and click "Invite"

## Using the Integration

The Notion integration provides the following tools that Claude can use:

### Basic Operations

- **notion_search**: Search for pages or databases in Notion
- **notion_get_database**: Get a Notion database by ID
- **notion_query_database**: Query a Notion database with filters
- **notion_get_page**: Get a Notion page by ID
- **notion_get_blocks**: Get blocks from a Notion page
- **notion_create_page**: Create a new Notion page

### Cache Management

- **notion_clear_cache**: Clear the Notion cache
- **notion_cache_stats**: Get statistics about the Notion cache

## Example Prompts for Claude

Here are some example prompts you can use with Claude to test the integration:

- "Search my Notion workspace for documents about [topic]"
- "Create a new page in my Notion database with [these details]"
- "Get the contents of my Notion page about [topic]"
- "Find all items in my [database name] database with status 'In Progress'"
- "Show me cache statistics for my Notion integration"

## Common Issues & Troubleshooting

### Permissions Issues

**Problem:** Claude cannot access certain pages or databases
**Solution:** Make sure you've shared each page/database with your integration in Notion

### API Rate Limits

**Problem:** Hitting Notion API rate limits
**Solution:** The SQLite caching system will help, but you can adjust the cache duration in the .env file:

```
NOTION_CACHE_DURATION=3600  # 1 hour in seconds
```

### Token Issues

**Problem:** Invalid or expired token
**Solution:** Generate a new token and update it in `.env`

## Monitoring & Management

- Check logs: `cd /Users/XPV/Desktop/anchor-core && tail -f ~/Library/Logs/Claude/mcp-server-notion.log`
- Restart the service: `cd /Users/XPV/Desktop/anchor-core && npm run restart`
- Run Notion integration standalone: `cd /Users/XPV/Desktop/anchor-core && npm run notion`

## Technical Details

### SQLite Schema

The integration uses the following tables:

- **pages**: Caches page metadata and content
- **databases**: Caches database schemas and metadata
- **blocks**: Caches content blocks from pages

### Performance Optimizations

- Memory usage is optimized for M3 Max with appropriate thread pool settings
- Garbage collection is run periodically to maintain performance
- Database maintenance optimizes storage usage

## Next Steps & Customization

- **Custom Filtering**: You can add custom filters by editing the notion-integration.js file
- **Integration with Other Services**: Consider connecting Notion with your other MCP servers
- **Automated Workflows**: Set up recurring tasks to update Notion pages

## Additional Resources

- [Notion API Documentation](https://developers.notion.com/reference/intro)
- [Claude MCP Documentation](https://docs.anthropic.com/claude/docs/model-context-protocol)
- [SQLite Documentation](https://www.sqlite.org/docs.html)
