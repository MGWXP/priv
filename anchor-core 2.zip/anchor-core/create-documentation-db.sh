#!/bin/bash
# create-documentation-db.sh - Creates Documentation Database in Notion
# For M3 Max (48GB unified memory) hardware

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

NOTION_PAGE_ID="1f7e48c2-bbbd-80df-86ed-d35832916f80"

echo -e "${BLUE}=== Creating Documentation Database in Notion ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e ""

# Check if NOTION_API_KEY is set
if [ -z "${NOTION_API_KEY}" ]; then
    echo -e "${YELLOW}NOTION_API_KEY environment variable is not set${NC}"
    echo -e "Would you like to set it now? (y/n)"
    read -r response
    if [[ "$response" =~ ^([yY][eE][sS]|[yY])$ ]]; then
        echo -e "Enter your Notion API Key:"
        read -s NOTION_KEY
        export NOTION_API_KEY="$NOTION_KEY"
        echo -e "${GREEN}✓ NOTION_API_KEY set${NC}"
    else
        echo -e "${RED}Cannot proceed without Notion API Key${NC}"
        exit 1
    fi
fi

# Create Documentation database
echo -e "Creating Documentation database..."
RESPONSE=$(curl -s -X POST "https://api.notion.com/v1/databases" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "parent": {
        "type": "page_id",
        "page_id": "'"${NOTION_PAGE_ID}"'"
    },
    "title": [
        {
            "type": "text",
            "text": {
                "content": "Documentation"
            }
        }
    ],
    "properties": {
        "Doc ID": {
            "title": {}
        },
        "Type": {
            "select": {
                "options": [
                    {"name": "API Reference", "color": "blue"},
                    {"name": "Guide", "color": "green"},
                    {"name": "Tutorial", "color": "purple"},
                    {"name": "Architecture", "color": "orange"},
                    {"name": "Specification", "color": "yellow"}
                ]
            }
        },
        "Components": {
            "relation": {
                "database_id": "1f8e48c2-bbbd-8123-977b-f35e3fa545e5",
                "single_property": {}
            }
        },
        "Status": {
            "select": {
                "options": [
                    {"name": "Draft", "color": "gray"},
                    {"name": "In Review", "color": "yellow"},
                    {"name": "Published", "color": "green"},
                    {"name": "Outdated", "color": "red"}
                ]
            }
        },
        "Last Updated": {
            "date": {}
        },
        "Author": {
            "rich_text": {}
        },
        "Version": {
            "rich_text": {}
        }
    }
}')

# Extract database ID from response
DB_ID=$(echo $RESPONSE | grep -o '"id":"[^"]*' | cut -d'"' -f4)

if [ -z "$DB_ID" ]; then
    echo -e "${RED}Failed to create Documentation database${NC}"
    echo $RESPONSE
    exit 1
fi

echo -e "${GREEN}✓ Documentation database created successfully!${NC}"
echo -e "Database ID: ${DB_ID}"

# Extract property IDs for reference
echo $RESPONSE | grep -o '"id":"[^"]*' | cut -d'"' -f4

# Create sample documentation entry
echo -e "Creating sample documentation entry for MCP Integration Guide..."
DOC_RESPONSE=$(curl -s -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "parent": {
        "database_id": "'"${DB_ID}"'"
    },
    "properties": {
        "Doc ID": {
            "title": [
                {
                    "text": {
                        "content": "DOC-0001"
                    }
                }
            ]
        },
        "Type": {
            "select": {
                "name": "Guide"
            }
        },
        "Status": {
            "select": {
                "name": "Published"
            }
        },
        "Last Updated": {
            "date": {
                "start": "'"$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")"'"
            }
        },
        "Author": {
            "rich_text": [
                {
                    "text": {
                        "content": "Axiomatic Nexa Team"
                    }
                }
            ]
        },
        "Version": {
            "rich_text": [
                {
                    "text": {
                        "content": "1.0.0"
                    }
                }
            ]
        }
    },
    "children": [
        {
            "object": "block",
            "type": "heading_1",
            "heading_1": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "MCP Integration Guide"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "paragraph",
            "paragraph": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "This guide explains how to integrate the Model Context Protocol with Anchor components."
                        }
                    }
                ]
            }
        }
    ]
}')

if echo $DOC_RESPONSE | grep -q "error"; then
    echo -e "${YELLOW}Sample documentation entry created with warnings${NC}"
else
    echo -e "${GREEN}✓ Sample documentation entry created successfully!${NC}"
fi

# Create second sample documentation entry
echo -e "Creating sample documentation entry for Notion API Reference..."
DOC_RESPONSE2=$(curl -s -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "parent": {
        "database_id": "'"${DB_ID}"'"
    },
    "properties": {
        "Doc ID": {
            "title": [
                {
                    "text": {
                        "content": "DOC-0002"
                    }
                }
            ]
        },
        "Type": {
            "select": {
                "name": "API Reference"
            }
        },
        "Status": {
            "select": {
                "name": "In Review"
            }
        },
        "Last Updated": {
            "date": {
                "start": "'"$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")"'"
            }
        },
        "Author": {
            "rich_text": [
                {
                    "text": {
                        "content": "Axiomatic Nexa Team"
                    }
                }
            ]
        },
        "Version": {
            "rich_text": [
                {
                    "text": {
                        "content": "0.9.5"
                    }
                }
            ]
        }
    },
    "children": [
        {
            "object": "block",
            "type": "heading_1",
            "heading_1": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Notion API Reference"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "paragraph",
            "paragraph": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Complete reference for the Notion API integration with Anchor components."
                        }
                    }
                ]
            }
        }
    ]
}')

if echo $DOC_RESPONSE2 | grep -q "error"; then
    echo -e "${YELLOW}Second documentation entry created with warnings${NC}"
else
    echo -e "${GREEN}✓ Second documentation entry created successfully!${NC}"
fi

# Save database ID for future reference
echo "${DB_ID}" > /Users/XPV/Desktop/anchor-core/documentation-db-id.txt
mkdir -p /Users/XPV/Desktop/anchor-core/notion-db-ids
echo "${DB_ID}" > /Users/XPV/Desktop/anchor-core/notion-db-ids/documentation-id.txt

echo -e "\n${GREEN}✓ Documentation database setup complete!${NC}"
echo -e "${YELLOW}View your database at: https://www.notion.so/${DB_ID}${NC}"

# Mark the Documentation task as completed
curl -X PATCH "https://api.notion.com/v1/blocks/1f8e48c2-bded-419c-93ee-e82f8a3e6c9f" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "to_do": {
        "checked": true
    }
  }'
