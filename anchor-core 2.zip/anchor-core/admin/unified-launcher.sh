#!/bin/bash
# unified-launcher.sh - M3 Max optimized launcher for Claude-Notion Integration Framework
# © 2025 XPV - MIT
#
# Unified launcher script for CNIF that combines features from:
# - launch-optimized.sh
# - launch-mcp-servers.sh
# - anchor-system-optimizer.sh

# Define colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color
BLUE='\033[0;34m'

# Base paths from environment or defaults
ANCHOR_HOME="${ANCHOR_HOME:-/Users/XPV/Desktop/anchor-core}"
LOG_DIR="${LOG_DIR:-$HOME/Library/Logs/Claude}"
SOCKET_DIR="${SOCKET_DIR:-$ANCHOR_HOME/sockets}"
COHERENCE_LOCK_DIR="${COHERENCE_LOCK_DIR:-$ANCHOR_HOME/coherence_lock}"
CONFIG_DIR="${CONFIG_DIR:-$ANCHOR_HOME/config}"
MCP_DIR="${MCP_DIR:-$ANCHOR_HOME/mcp-servers}"
PID_DIR="${PID_DIR:-$MCP_DIR}"
TOOLS_DIR="${TOOLS_DIR:-$ANCHOR_HOME/tools}"

# Exit on errors (but wait until after cleanup)
trap_with_cleanup() {
  cleanup
  exit 1
}

# Load optimized environment if available
if [ -f "$ANCHOR_HOME/.env" ]; then
  echo -e "${BLUE}Loading optimized environment...${NC}"
  source "$ANCHOR_HOME/.env"
else
  # Run optimizer to generate env file
  echo -e "${YELLOW}No .env file found, running optimizer...${NC}"
  node "$ANCHOR_HOME/tools/unified-m3-optimizer.js"
  if [ $? -ne 0 ]; then
    echo -e "${RED}Failed to run optimizer. Exiting.${NC}"
    exit 1
  fi
  source "$ANCHOR_HOME/.env"
fi

# Initialize directories
echo -e "${BLUE}Creating required directories...${NC}"
mkdir -p "$LOG_DIR"
mkdir -p "$SOCKET_DIR"
mkdir -p "$COHERENCE_LOCK_DIR"
mkdir -p "$CONFIG_DIR"

# Create a default Notion config if missing
if [ ! -f "$CONFIG_DIR/notion-config.json" ]; then
  echo -e "${YELLOW}Creating default Notion config...${NC}"
  echo '{
    "rootPageId": "",
    "enabledDatabases": [],
    "syncInterval": 30000,
    "rateLimitPerSecond": 3
  }' > "$CONFIG_DIR/notion-config.json"
fi

# Define server configurations - using array format for compatibility
SERVER_NAMES=("socket-server" "schema-registry" "streaming-transformer" "notion" "mcp-orchestrator")
SERVER_SCRIPTS=("$MCP_DIR/socket-server-implementation.cjs" "$MCP_DIR/schema-registry.cjs" "$MCP_DIR/streaming-schema-transformer.cjs" "$MCP_DIR/notion-connection-manager.cjs" "$MCP_DIR/mcp-orchestrator.cjs")

# Function to get script path by server name
get_server_script() {
  local server_name=$1
  local index=0
  for name in "${SERVER_NAMES[@]}"; do
    if [ "$name" = "$server_name" ]; then
      echo "${SERVER_SCRIPTS[$index]}"
      return 0
    fi
    index=$((index + 1))
  done
  echo ""
}

# Clean up function
cleanup() {
  echo -e "${YELLOW}Shutting down all servers...${NC}"
  
  # Kill all running servers with timeout to prevent hanging
  for server in "${SERVER_NAMES[@]}"; do
    if [ -f "$PID_DIR/$server.pid" ]; then
      pid=$(cat "$PID_DIR/$server.pid")
      if ps -p "$pid" > /dev/null; then
        echo -e "${YELLOW}Stopping $server (PID: $pid)...${NC}"
        kill -15 "$pid" 2>/dev/null || true
      else
        echo -e "${YELLOW}Process $server (PID: $pid) not running${NC}"
      fi
    fi
  done
  
  # Give processes a moment to terminate gracefully
  sleep 2
  
  # Force kill any remaining processes
  for server in "${SERVER_NAMES[@]}"; do
    if [ -f "$PID_DIR/$server.pid" ]; then
      pid=$(cat "$PID_DIR/$server.pid")
      if ps -p "$pid" > /dev/null; then
        echo -e "${YELLOW}Force killing $server (PID: $pid)...${NC}"
        kill -9 "$pid" 2>/dev/null || true
      fi
    fi
  done
  
  # Remove socket files
  echo -e "${YELLOW}Removing socket files...${NC}"
  rm -f "$SOCKET_DIR"/*.sock
  
  # Remove coherence markers
  echo -e "${YELLOW}Removing coherence markers...${NC}"
  rm -f "$COHERENCE_LOCK_DIR"/*.marker
  
  echo -e "${GREEN}Cleanup complete${NC}"
}

# Set trap for clean shutdown
trap cleanup EXIT INT TERM

# Stop any existing servers
echo -e "${BLUE}Stopping any existing servers...${NC}"
cleanup

# Skip memory pools - they seem to be causing issues
echo -e "${BLUE}Skipping memory pools for stability...${NC}"

# Start each server
echo -e "${BLUE}Starting services...${NC}"

# Start the servers in the correct order
ordered_servers=("schema-registry" "streaming-transformer" "socket-server" "notion" "mcp-orchestrator")

for server in "${ordered_servers[@]}"; do
  script=$(get_server_script "$server")
  if [ -z "$script" ]; then
    echo -e "${RED}Error: Script not found for $server${NC}"
    continue
  fi
  
  echo -e "${BLUE}Starting $server...${NC}"
  # Set environment variables for this server
  export MCP_SERVER_NAME="$server"
  
  # Start the server without memory pools for stability
  node "$script" > "$LOG_DIR/$server.log" 2>&1 &
  pid=$!
  
  # Verify process actually started
  if ! ps -p "$pid" > /dev/null; then
    echo -e "${RED}ERROR: Process for $server failed to start!${NC}"
    continue
  fi
  
  # Save PID
  echo "$pid" > "$PID_DIR/$server.pid"
  
  echo -e "${GREEN}Started $server (PID: $pid)${NC}"
  
  # Add a slight delay to ensure logging is initialized before checking
  sleep 0.5
  
  # Wait a second to stagger startups
  sleep 1
done

# Wait for all servers to initialize
echo -e "${BLUE}Waiting for services to initialize...${NC}"
sleep 3

# Check health
echo -e "${BLUE}Checking service health...${NC}"
failed=false

for server in "${SERVER_NAMES[@]}"; do
  if [ -f "$PID_DIR/$server.pid" ]; then
    pid=$(cat "$PID_DIR/$server.pid")
    if ps -p "$pid" > /dev/null; then
      echo -e "${GREEN}✅ $server is running (PID: $pid)${NC}"
    else
      echo -e "${RED}❌ $server failed to start${NC}"
      failed=true
    fi
  else
    echo -e "${RED}❌ No PID file for $server${NC}"
    failed=true
  fi
  
  # Check socket file for socket servers
  if [ "$server" = "socket-server" ]; then
    if [ -e "$SOCKET_DIR/$server.sock" ]; then
      echo -e "${GREEN}✅ Socket file exists for $server${NC}"
    else
      echo -e "${RED}❌ Socket file missing for $server${NC}"
      failed=true
    fi
  fi
done

if [ "$failed" = true ]; then
  echo -e "${RED}❌ Some services failed to start properly${NC}"
  echo -e "${YELLOW}Check logs in $LOG_DIR for details${NC}"
else
  echo -e "${GREEN}✅ All services started successfully${NC}"
  echo -e "${BLUE}CNIF is running with basic optimizations${NC}"
  echo -e "${BLUE}Logs available in $LOG_DIR${NC}"
  echo -e "${BLUE}Socket files in $SOCKET_DIR${NC}"
fi

# Keep script running to maintain trap handlers
echo -e "${GREEN}Press Ctrl+C to stop all services${NC}"
wait
