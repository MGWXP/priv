#!/bin/bash
# cnif-cli.sh - Unified CLI for Claude-Notion Integration Framework
# © 2025 XPV - MIT

# Define colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'

# Base paths
ANCHOR_HOME="${ANCHOR_HOME:-/Users/XPV/Desktop/anchor-core}"
ADMIN_DIR="${ADMIN_DIR:-$ANCHOR_HOME/admin}"
TOOLS_DIR="${TOOLS_DIR:-$ANCHOR_HOME/tools}"
MCP_DIR="${MCP_DIR:-$ANCHOR_HOME/mcp-servers}"
SOCKET_DIR="${SOCKET_DIR:-$ANCHOR_HOME/sockets}"
LOG_DIR="${LOG_DIR:-$HOME/Library/Logs/Claude}"

# Load .env file if available
if [ -f "$ANCHOR_HOME/.env" ]; then
  source "$ANCHOR_HOME/.env"
fi

# CLI Version
VERSION="1.0.0"

# Function to display help
show_help() {
  echo -e "${BOLD}CNIF CLI v${VERSION}${NC} - Unified CLI for Claude-Notion Integration Framework"
  echo
  echo -e "Usage: ${BOLD}$(basename $0) [command] [options]${NC}"
  echo
  echo -e "${BOLD}Commands:${NC}"
  echo -e "  ${CYAN}start${NC}           Start all CNIF services"
  echo -e "  ${CYAN}stop${NC}            Stop all CNIF services"
  echo -e "  ${CYAN}restart${NC}         Restart all CNIF services"
  echo -e "  ${CYAN}status${NC}          Show status of all CNIF services"
  echo -e "  ${CYAN}logs${NC} [service]  Show logs for a specific service or all services"
  echo -e "  ${CYAN}optimize${NC}        Run M3 optimizer to tune system for best performance"
  echo -e "  ${CYAN}clean${NC}           Clean up stale PID files and socket files"
  echo -e "  ${CYAN}dashboard${NC}       Start the web dashboard"
  echo -e "  ${CYAN}help${NC}            Show this help message"
  echo -e "  ${CYAN}version${NC}         Show version information"
  echo
  echo -e "${BOLD}Available services:${NC}"
  echo -e "  socket-server, schema-registry, streaming-transformer, notion, mcp-orchestrator"
  echo
  echo -e "${BOLD}Examples:${NC}"
  echo -e "  $(basename $0) start        # Start all services"
  echo -e "  $(basename $0) logs notion  # Show logs for Notion service"
  echo -e "  $(basename $0) optimize     # Run M3 optimizer"
  echo
}

# Function to start services
start_services() {
  echo -e "${BLUE}Starting CNIF services...${NC}"
  "$ADMIN_DIR/unified-launcher.sh"
}

# Function to stop services
stop_services() {
  echo -e "${BLUE}Stopping CNIF services...${NC}"
  
  # Get the PIDs of all running services
  PIDs=""
  
  # Core services
  for pidfile in "$MCP_DIR"/*.pid; do
    if [ -f "$pidfile" ]; then
      pid=$(cat "$pidfile")
      if ps -p "$pid" > /dev/null; then
        PIDs="$PIDs $pid"
      fi
    fi
  done
  
  # Dashboard
  if [ -f "$ANCHOR_HOME/dashboard.pid" ]; then
    pid=$(cat "$ANCHOR_HOME/dashboard.pid")
    if ps -p "$pid" > /dev/null; then
      PIDs="$PIDs $pid"
    fi
  fi
  
  # Send SIGTERM to all PIDs
  if [ -n "$PIDs" ]; then
    echo -e "${BLUE}Stopping processes: $PIDs${NC}"
    kill -15 $PIDs 2>/dev/null || true
    
    # Wait a bit for processes to terminate
    sleep 2
    
    # Force kill if still running
    for pid in $PIDs; do
      if ps -p "$pid" > /dev/null; then
        echo -e "${YELLOW}Process $pid still running, sending SIGKILL...${NC}"
        kill -9 "$pid" 2>/dev/null || true
      fi
    done
  else
    echo -e "${YELLOW}No running services found${NC}"
  fi
  
  # Clean up PID files
  rm -f "$MCP_DIR"/*.pid "$ANCHOR_HOME/dashboard.pid" 2>/dev/null || true
  
  # Clean up socket files
  rm -f "$SOCKET_DIR"/*.sock 2>/dev/null || true
  
  echo -e "${GREEN}All services stopped${NC}"
}

# Function to restart services
restart_services() {
  echo -e "${BLUE}Restarting CNIF services...${NC}"
  stop_services
  sleep 2
  start_services
}

# Function to show service status
show_status() {
  echo -e "${BLUE}CNIF Services Status:${NC}"
  
  running_count=0
  stopped_count=0
  
  # Check core services
  services=("socket-server" "schema-registry" "streaming-transformer" "notion" "mcp-orchestrator")
  
  for service in "${services[@]}"; do
    pidfile="$MCP_DIR/$service.pid"
    if [ -f "$pidfile" ]; then
      pid=$(cat "$pidfile")
      if ps -p "$pid" > /dev/null; then
        echo -e "${GREEN}✅ $service is running (PID: $pid)${NC}"
        running_count=$((running_count + 1))
      else
        echo -e "${RED}❌ $service is not running (stale PID file: $pid)${NC}"
        stopped_count=$((stopped_count + 1))
      fi
    else
      echo -e "${RED}❌ $service is not running (no PID file)${NC}"
      stopped_count=$((stopped_count + 1))
    fi
    
    # Check socket file for socket-server
    if [ "$service" = "socket-server" ]; then
      if [ -e "$SOCKET_DIR/$service.sock" ]; then
        echo -e "  ${GREEN}↳ Socket file exists for $service${NC}"
      else
        echo -e "  ${RED}↳ Socket file missing for $service${NC}"
      fi
    fi
  done
  
  # Check dashboard
  if [ -f "$ANCHOR_HOME/dashboard.pid" ]; then
    pid=$(cat "$ANCHOR_HOME/dashboard.pid")
    if ps -p "$pid" > /dev/null; then
      echo -e "${GREEN}✅ Dashboard is running (PID: $pid)${NC}"
      running_count=$((running_count + 1))
    else
      echo -e "${RED}❌ Dashboard is not running (stale PID file: $pid)${NC}"
      stopped_count=$((stopped_count + 1))
    fi
  else
    echo -e "${RED}❌ Dashboard is not running (no PID file)${NC}"
    stopped_count=$((stopped_count + 1))
  fi
  
  # Summary
  echo
  echo -e "${BLUE}Summary: ${GREEN}$running_count running${NC}, ${RED}$stopped_count stopped${NC}"
  
  # System information
  echo
  echo -e "${BLUE}System Information:${NC}"
  echo -e "• Memory: $(vm_stat | grep 'Pages free' | awk '{print $3}' | tr -d '.') free pages"
  echo -e "• CPU Load: $(sysctl -n hw.ncpu) cores, load avg: $(uptime | awk -F'load averages:' '{print $2}')"
  if [ -f "$ANCHOR_HOME/.env" ]; then
    echo -e "• Environment: ${GREEN}Optimized${NC}"
  else
    echo -e "• Environment: ${YELLOW}Not optimized${NC}"
  fi
}

# Function to show service logs
show_logs() {
  service="$1"
  
  if [ -z "$service" ]; then
    echo -e "${YELLOW}No service specified, showing all logs${NC}"
    tail -n 20 "$LOG_DIR"/*.log
  else
    logfile="$LOG_DIR/$service.log"
    if [ -f "$logfile" ]; then
      echo -e "${BLUE}Showing logs for $service${NC}"
      tail -n 50 "$logfile"
    else
      echo -e "${RED}No log file found for $service${NC}"
      echo -e "${YELLOW}Available logs:${NC}"
      ls -1 "$LOG_DIR"/*.log
    fi
  fi
}

# Function to run optimizer
run_optimizer() {
  echo -e "${BLUE}Running M3 optimizer...${NC}"
  node "$TOOLS_DIR/unified-m3-optimizer.js"
}

# Function to clean up stale files
clean_up() {
  echo -e "${BLUE}Cleaning up stale files...${NC}"
  
  # Stop any running services first
  stop_services
  
  # Clean up PID files
  echo -e "${YELLOW}Removing PID files...${NC}"
  rm -f "$MCP_DIR"/*.pid "$ANCHOR_HOME/dashboard.pid" 2>/dev/null || true
  
  # Clean up socket files
  echo -e "${YELLOW}Removing socket files...${NC}"
  rm -f "$SOCKET_DIR"/*.sock 2>/dev/null || true
  
  # Clean up coherence markers
  echo -e "${YELLOW}Removing coherence markers...${NC}"
  rm -f "$ANCHOR_HOME/coherence_lock"/*.marker 2>/dev/null || true
  
  echo -e "${GREEN}Cleanup complete${NC}"
}

# Function to start dashboard
start_dashboard() {
  echo -e "${BLUE}Starting CNIF dashboard...${NC}"
  
  # Check if dashboard is already running
  if [ -f "$ANCHOR_HOME/dashboard.pid" ]; then
    pid=$(cat "$ANCHOR_HOME/dashboard.pid")
    if ps -p "$pid" > /dev/null; then
      echo -e "${YELLOW}Dashboard is already running (PID: $pid)${NC}"
      echo -e "${BLUE}Visit: http://localhost:8765${NC}"
      return
    fi
  fi
  
  # Start dashboard
  if [ -f "$ANCHOR_HOME/dashboard/server.js" ]; then
    node "$ANCHOR_HOME/dashboard/server.js" > "$LOG_DIR/dashboard.log" 2>&1 &
    pid=$!
    echo "$pid" > "$ANCHOR_HOME/dashboard.pid"
    echo -e "${GREEN}Dashboard started (PID: $pid)${NC}"
    echo -e "${BLUE}Visit: http://localhost:8765${NC}"
  else
    echo -e "${RED}Dashboard server not found${NC}"
  fi
}

# Function to show version info
show_version() {
  echo -e "${BOLD}CNIF CLI v${VERSION}${NC}"
  echo -e "Claude-Notion Integration Framework"
  echo -e "© 2025 XPV - MIT"
  echo
  echo -e "System Paths:"
  echo -e "• ANCHOR_HOME: $ANCHOR_HOME"
  echo -e "• MCP_DIR: $MCP_DIR"
  echo -e "• SOCKET_DIR: $SOCKET_DIR"
  echo -e "• LOG_DIR: $LOG_DIR"
  echo
  echo -e "Environment:"
  if [ -f "$ANCHOR_HOME/.env" ]; then
    echo -e "• Status: ${GREEN}Optimized${NC}"
    echo -e "• NODE_OPTIONS: $NODE_OPTIONS"
    echo -e "• UV_THREADPOOL_SIZE: $UV_THREADPOOL_SIZE"
  else
    echo -e "• Status: ${YELLOW}Not optimized${NC}"
  fi
}

# Main command handler
if [ $# -eq 0 ]; then
  show_help
  exit 0
fi

command="$1"
shift

case "$command" in
  start)
    start_services
    ;;
  stop)
    stop_services
    ;;
  restart)
    restart_services
    ;;
  status)
    show_status
    ;;
  logs)
    show_logs "$1"
    ;;
  optimize)
    run_optimizer
    ;;
  clean)
    clean_up
    ;;
  dashboard)
    start_dashboard
    ;;
  help)
    show_help
    ;;
  version)
    show_version
    ;;
  *)
    echo -e "${RED}Unknown command: $command${NC}"
    show_help
    exit 1
    ;;
esac

exit 0
