#!/bin/bash
# Run with: chmod +x /Users/XPV/Desktop/anchor-core/make-unified-optimizer-executable.sh && /Users/XPV/Desktop/anchor-core/make-unified-optimizer-executable.sh
# make-unified-optimizer-executable.sh - Make the unified optimizer executable
# © 2025 XPV - MIT

# Set path to unified optimizer
OPTIMIZER_PATH="/Users/XPV/Desktop/anchor-core/tools/unified-m3-optimizer.js"

# Make executable
chmod +x "$OPTIMIZER_PATH"
echo "✅ Made unified optimizer executable: $OPTIMIZER_PATH"

# Run optimizer to create initial configuration
echo "🚀 Running unified optimizer to create initial configuration..."
node "$OPTIMIZER_PATH"

echo "✅ Configuration complete!"
echo "🔧 To manage your CNIF system, use the new CLI tool:"
echo "   /Users/XPV/Desktop/anchor-core/admin/cnif-cli.sh [command]"
echo "   or the convenience symlink:"
echo "   /Users/XPV/Desktop/anchor-core/cnif [command]"
