#!/bin/bash
# cnif-system-check.sh - CNIF System Status Checker
# © 2025 XPV - MIT
#
# This script performs a comprehensive system check of the CNIF implementation

# Environment setup
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
LOG_DIR="${HOME}/Library/Logs/Claude"
TIMESTAMP=$(date +"%Y%m%d%H%M%S")
LOG_FILE="${LOG_DIR}/cnif-system-check-${TIMESTAMP}.log"
SOCKET_DIR="${ANCHOR_HOME}/sockets"
SCHEMA_DIR="${ANCHOR_HOME}/schemas"
MCP_SERVERS_DIR="${ANCHOR_HOME}/mcp-servers"
COHERENCE_LOCK_DIR="${ANCHOR_HOME}/coherence_lock"

# Ensure log directory exists
mkdir -p "${LOG_DIR}"

# ANSI color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Log function
log() {
  local level="$1"
  local message="$2"
  local color="${NC}"
  
  case "${level}" in
    "INFO") color="${GREEN}" ;;
    "WARN") color="${YELLOW}" ;;
    "ERROR") color="${RED}" ;;
    "DEBUG") color="${BLUE}" ;;
    *) color="${NC}" ;;
  esac
  
  echo -e "${color}$(date +"%Y-%m-%d %H:%M:%S") [${level}] ${message}${NC}" | tee -a "${LOG_FILE}"
}

# Print header
print_header() {
  local title="$1"
  echo -e "\n${CYAN}======================================================================${NC}"
  echo -e "${CYAN}= ${title}${NC}"
  echo -e "${CYAN}======================================================================${NC}"
}

# Check if a process is running
check_process() {
  local process_name="$1"
  local grep_pattern="$2"
  
  ps aux | grep -v grep | grep "${grep_pattern}" > /dev/null
  if [ $? -eq 0 ]; then
    log "INFO" "✅ ${process_name} is running"
    return 0
  else
    log "WARN" "⚠️ ${process_name} is not running"
    return 1
  fi
}

# Check file exists and is readable
check_file() {
  local file_path="$1"
  local file_name="$2"
  
  if [ -f "${file_path}" ]; then
    if [ -r "${file_path}" ]; then
      log "INFO" "✅ ${file_name} exists and is readable"
      return 0
    else
      log "WARN" "⚠️ ${file_name} exists but is not readable"
      return 1
    fi
  else
    log "WARN" "⚠️ ${file_name} does not exist"
    return 1
  fi
}

# Check directory exists and is writable
check_directory() {
  local dir_path="$1"
  local dir_name="$2"
  
  if [ -d "${dir_path}" ]; then
    if [ -w "${dir_path}" ]; then
      log "INFO" "✅ ${dir_name} exists and is writable"
      return 0
    else
      log "WARN" "⚠️ ${dir_name} exists but is not writable"
      return 1
    fi
  else
    log "WARN" "⚠️ ${dir_name} does not exist"
    return 1
  fi
}

# Check socket permissions
check_socket_permissions() {
  local socket_file="$1"
  
  if [ -S "${socket_file}" ]; then
    local perms=$(stat -f "%Lp" "${socket_file}")
    
    if [ "${perms}" = "666" ]; then
      log "INFO" "✅ Socket file ${socket_file} has correct permissions (666)"
      return 0
    else
      log "WARN" "⚠️ Socket file ${socket_file} has incorrect permissions: ${perms}, should be 666"
      return 1
    fi
  else
    log "WARN" "⚠️ Socket file ${socket_file} does not exist or is not a socket"
    return 1
  fi
}

# Start comprehensive system check
print_header "CNIF System Status Checker"
log "INFO" "🔍 Starting comprehensive system check at $(date)"
log "INFO" "📝 Log file: ${LOG_FILE}"

# Check for required directories
print_header "Directory Structure"
check_directory "${ANCHOR_HOME}" "Anchor Home"
check_directory "${SOCKET_DIR}" "Socket Directory"
check_directory "${SCHEMA_DIR}" "Schema Directory"
check_directory "${MCP_SERVERS_DIR}" "MCP Servers Directory"
check_directory "${COHERENCE_LOCK_DIR}" "Coherence Lock Directory"
check_directory "${SCHEMA_DIR}/claude" "Claude Schema Directory"
check_directory "${SCHEMA_DIR}/notion" "Notion Schema Directory"

# Check for required files
print_header "Core Files"
check_file "${ANCHOR_HOME}/package.json" "Package JSON"
check_file "${MCP_SERVERS_DIR}/schema-registry.cjs" "Schema Registry Implementation"
check_file "${MCP_SERVERS_DIR}/socket-server-implementation.cjs" "Socket Server Implementation"
check_file "${MCP_SERVERS_DIR}/streaming-schema-transformer.cjs" "Streaming Schema Transformer"
check_file "${MCP_SERVERS_DIR}/notion-connection-manager.cjs" "Notion Connection Manager"
check_file "${MCP_SERVERS_DIR}/mcp-orchestrator.cjs" "MCP Orchestrator"
check_file "${MCP_SERVERS_DIR}/circuit-breaker.cjs" "Circuit Breaker"
check_file "${ANCHOR_HOME}/simple-launcher.sh" "Simple Launcher Script"

# Check for required schema files
print_header "Schema Files"
CLAUDE_SCHEMA_COUNT=$(ls -1 "${SCHEMA_DIR}/claude/"*.json 2>/dev/null | wc -l)
NOTION_SCHEMA_COUNT=$(ls -1 "${SCHEMA_DIR}/notion/"*.json 2>/dev/null | wc -l)

log "INFO" "📊 Found ${CLAUDE_SCHEMA_COUNT} Claude schema files"
log "INFO" "📊 Found ${NOTION_SCHEMA_COUNT} Notion schema files"

# Check package.json configuration
print_header "Module System Configuration"
MODULE_TYPE=$(grep "\"type\":" "${ANCHOR_HOME}/package.json" | awk -F: '{print $2}' | tr -d ' ",')

if [ "${MODULE_TYPE}" = "commonjs" ]; then
  log "INFO" "✅ Package.json correctly configured with type: commonjs"
else
  log "ERROR" "❌ Package.json not correctly configured, found type: ${MODULE_TYPE}"
fi

# Check running processes
print_header "Process Status"
check_process "Socket Server" "socket-server-implementation.cjs"
check_process "Schema Registry" "schema-registry.cjs"
check_process "Streaming Transformer" "streaming-schema-transformer.cjs"
check_process "Notion Connection Manager" "notion-connection-manager.cjs"
check_process "MCP Orchestrator" "mcp-orchestrator.cjs"

# Check socket files and permissions
print_header "Socket Files"
SOCKET_FILES=$(ls -1 "${SOCKET_DIR}"/*.sock 2>/dev/null)
SOCKET_COUNT=$(echo "${SOCKET_FILES}" | grep -v "^$" | wc -l)

log "INFO" "📊 Found ${SOCKET_COUNT} socket files"

if [ ${SOCKET_COUNT} -gt 0 ]; then
  for SOCKET_FILE in ${SOCKET_FILES}; do
    check_socket_permissions "${SOCKET_FILE}"
  done
else
  log "WARN" "⚠️ No socket files found, services may not be running"
fi

# Check log files
print_header "Log Files"
LOG_FILES=$(ls -1 "${LOG_DIR}"/*.log 2>/dev/null)
LOG_COUNT=$(echo "${LOG_FILES}" | grep -v "^$" | wc -l)

log "INFO" "📊 Found ${LOG_COUNT} log files"

if [ ${LOG_COUNT} -gt 0 ]; then
  for LOG_FILE in ${LOG_FILES}; do
    LOG_SIZE=$(du -h "${LOG_FILE}" | awk '{print $1}')
    LOG_DATE=$(date -r "${LOG_FILE}" "+%Y-%m-%d %H:%M:%S")
    log "INFO" "📝 ${LOG_FILE} (${LOG_SIZE}, last modified: ${LOG_DATE})"
  done
else
  log "WARN" "⚠️ No log files found, services may not have generated logs yet"
fi

# Check coherence markers
print_header "Coherence Markers"
MARKER_FILES=$(ls -1 "${COHERENCE_LOCK_DIR}"/*.marker 2>/dev/null)
MARKER_COUNT=$(echo "${MARKER_FILES}" | grep -v "^$" | wc -l)

log "INFO" "📊 Found ${MARKER_COUNT} coherence markers"

if [ ${MARKER_COUNT} -gt 0 ]; then
  RECENT_MARKERS=$(find "${COHERENCE_LOCK_DIR}" -name "*.marker" -mtime -1 | wc -l)
  log "INFO" "📊 ${RECENT_MARKERS} markers created in the last 24 hours"
else
  log "WARN" "⚠️ No coherence markers found, services may not have started properly"
fi

# Run schema registry test
print_header "Schema Registry Test"
log "INFO" "🔍 Running schema registry test..."

node "${MCP_SERVERS_DIR}/test-schema-registry.js" > "${LOG_DIR}/schema-registry-test-${TIMESTAMP}.log" 2>&1
if [ $? -eq 0 ]; then
  log "INFO" "✅ Schema registry test completed successfully"
else
  log "ERROR" "❌ Schema registry test failed"
fi

log "INFO" "📝 Schema registry test log: ${LOG_DIR}/schema-registry-test-${TIMESTAMP}.log"

# Create system status report
print_header "System Status Report"

REPORT_FILE="${ANCHOR_HOME}/CNIF_SYSTEM_STATUS_${TIMESTAMP}.md"

cat > "${REPORT_FILE}" << EOF
# CNIF System Status Report

Generated: $(date)

## System Overview

| Component | Status |
|-----------|--------|
| Module System | $([ "${MODULE_TYPE}" = "commonjs" ] && echo "✅ CORRECT" || echo "❌ INCORRECT") |
| Socket Server | $(check_process "Socket Server" "socket-server-implementation.cjs" > /dev/null && echo "✅ RUNNING" || echo "❌ STOPPED") |
| Schema Registry | $(check_process "Schema Registry" "schema-registry.cjs" > /dev/null && echo "✅ RUNNING" || echo "❌ STOPPED") |
| Streaming Transformer | $(check_process "Streaming Transformer" "streaming-schema-transformer.cjs" > /dev/null && echo "✅ RUNNING" || echo "❌ STOPPED") |
| Notion Connection | $(check_process "Notion Connection Manager" "notion-connection-manager.cjs" > /dev/null && echo "✅ RUNNING" || echo "❌ STOPPED") |
| MCP Orchestrator | $(check_process "MCP Orchestrator" "mcp-orchestrator.cjs" > /dev/null && echo "✅ RUNNING" || echo "❌ STOPPED") |
| Directory Structure | $([ ${CLAUDE_SCHEMA_COUNT} -gt 0 ] && [ ${NOTION_SCHEMA_COUNT} -gt 0 ] && echo "✅ CORRECT" || echo "⚠️ INCOMPLETE") |
| Socket Files | $([ ${SOCKET_COUNT} -gt 0 ] && echo "✅ PRESENT" || echo "❌ MISSING") |
| Log Files | $([ ${LOG_COUNT} -gt 0 ] && echo "✅ PRESENT" || echo "⚠️ NONE") |
| Coherence Markers | $([ ${MARKER_COUNT} -gt 0 ] && echo "✅ PRESENT" || echo "⚠️ NONE") |
| Schema Registry Test | $(node "${MCP_SERVERS_DIR}/test-schema-registry.js" > /dev/null 2>&1 && echo "✅ PASSED" || echo "❌ FAILED") |

## Recommendations

$([ "${MODULE_TYPE}" != "commonjs" ] && echo "- Fix package.json configuration to use commonjs\n" || echo "")
$(check_process "Socket Server" "socket-server-implementation.cjs" > /dev/null || echo "- Start socket server with: /Users/XPV/Desktop/anchor-core/simple-launcher.sh\n")
$(check_process "Schema Registry" "schema-registry.cjs" > /dev/null || echo "- Start schema registry with: /Users/XPV/Desktop/anchor-core/simple-launcher.sh\n")
$([ ${SOCKET_COUNT} -eq 0 ] && echo "- Check socket directory permissions and file creation\n" || echo "")
$(check_socket_permissions "${SOCKET_DIR}/socket-server.sock" > /dev/null || echo "- Fix socket permissions with: /Users/XPV/Desktop/anchor-core/fix-socket-permissions.sh\n")

## System Information

- Timestamp: $(date)
- Hostname: $(hostname)
- User: $(whoami)
- Node Version: $(node -v)
- Operating System: $(uname -a)
- CNIF Version: $(grep "\"version\":" "${ANCHOR_HOME}/package.json" | awk -F: '{print $2}' | tr -d ' ",')

---

Report generated by cnif-system-check.sh
EOF

log "INFO" "✅ Generated system status report: ${REPORT_FILE}"

# Final status
print_header "Summary"
log "INFO" "✅ System check completed"
log "INFO" "📝 System status report: ${REPORT_FILE}"
log "INFO" "📝 Log file: ${LOG_FILE}"

echo -e "\n${GREEN}✅ CNIF System check completed. See ${REPORT_FILE} for details.${NC}"
exit 0
