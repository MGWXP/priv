#!/bin/bash
# WebSocket Bridge Stop Script
# Updated: 2025-05-19

# Define variables
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"

echo "Stopping WebSocket Bridge services..."

# Stop WebSocket bridge
if [ -f "$ANCHOR_HOME/webbridge.pid" ]; then
  PID=$(cat "$ANCHOR_HOME/webbridge.pid")
  if [ -n "$PID" ] && ps -p $PID > /dev/null; then
    echo "Stopping WebSocket bridge (PID: $PID)"
    kill $PID
  else
    echo "WebSocket bridge not running or PID file is stale"
  fi
  rm -f "$ANCHOR_HOME/webbridge.pid"
fi

# Stop Notion sync
if [ -f "$ANCHOR_HOME/notion-sync.pid" ]; then
  PID=$(cat "$ANCHOR_HOME/notion-sync.pid")
  if [ -n "$PID" ] && ps -p $PID > /dev/null; then
    echo "Stopping Notion sync (PID: $PID)"
    kill $PID
  else
    echo "Notion sync not running or PID file is stale"
  fi
  rm -f "$ANCHOR_HOME/notion-sync.pid"
fi

# Stop dashboard server
if [ -f "$ANCHOR_HOME/dashboard.pid" ]; then
  PID=$(cat "$ANCHOR_HOME/dashboard.pid")
  if [ -n "$PID" ] && ps -p $PID > /dev/null; then
    echo "Stopping dashboard server (PID: $PID)"
    kill $PID
  else
    echo "Dashboard server not running or PID file is stale"
  fi
  rm -f "$ANCHOR_HOME/dashboard.pid"
fi

echo "All WebSocket Bridge services stopped"
