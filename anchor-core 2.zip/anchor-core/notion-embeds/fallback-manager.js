// fallback-manager.js - Manages the fallback from iframe to static content
// For M3 Max (48GB unified memory) with macOS Sequoia 15.4.1

/**
 * Fallback Manager for Notion iframes
 * Automatically detects when Notion iframes fail to load and switches to fallback content
 */
class FallbackManager {
    constructor() {
        this.iframeSelector = '.dashboard-item iframe';
        this.fallbackUrls = {
            'component-library.html': 'notion-fallback-renderer.html',
            'agent-registry.html': 'agent-registry-fallback.html',
            'project-tracker.html': 'project-tracker-fallback.html'
        };
        this.timeoutDuration = 5000; // 5 seconds timeout for iframe loading
        this.initialized = false;
    }

    /**
     * Initialize the fallback manager
     */
    init() {
        if (this.initialized) return;
        this.initialized = true;

        console.log('[FallbackManager] Initializing...');
        this.setupIframeMonitoring();
        this.detectExistingIframeState();
    }

    /**
     * Setup event listeners for iframe loading
     */
    setupIframeMonitoring() {
        const iframes = document.querySelectorAll(this.iframeSelector);
        
        iframes.forEach(iframe => {
            if (!iframe.dataset.monitoringSetup) {
                console.log(`[FallbackManager] Setting up monitoring for iframe: ${iframe.src}`);
                
                // Mark this iframe as having monitoring set up
                iframe.dataset.monitoringSetup = 'true';
                
                // Set a timeout to check if iframe loaded successfully
                const timeoutId = setTimeout(() => {
                    this.handleIframeTimeout(iframe);
                }, this.timeoutDuration);
                
                // If iframe loads successfully, clear the timeout
                iframe.addEventListener('load', () => {
                    clearTimeout(timeoutId);
                    this.checkIframeContent(iframe);
                });
                
                // Store the timeout ID for potential cleanup
                iframe.dataset.timeoutId = timeoutId;
            }
        });
    }

    /**
     * Handle case where iframe times out
     */
    handleIframeTimeout(iframe) {
        console.log(`[FallbackManager] Timeout loading iframe: ${iframe.src}`);
        this.switchToFallback(iframe);
    }

    /**
     * Check if iframe content loaded correctly
     */
    checkIframeContent(iframe) {
        try {
            // Try to access iframe content - will throw error if cross-origin issues
            const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
            
            // If we can access the document but it shows an error
            if (iframeDoc.body.innerText.includes('refused to connect') || 
                iframeDoc.body.innerText.includes('error') ||
                iframeDoc.body.innerText.length < 50) {
                console.log(`[FallbackManager] Iframe loaded with errors: ${iframe.src}`);
                this.switchToFallback(iframe);
            } else {
                console.log(`[FallbackManager] Iframe loaded successfully: ${iframe.src}`);
            }
        } catch (error) {
            // Cross-origin error - can't access iframe content
            console.log(`[FallbackManager] Cross-origin error for iframe: ${iframe.src}`);
            this.switchToFallback(iframe);
        }
    }

    /**
     * Switch an iframe to its fallback content
     */
    switchToFallback(iframe) {
        const src = iframe.src;
        const srcFilename = src.split('/').pop();
        
        if (this.fallbackUrls[srcFilename]) {
            const fallbackUrl = this.fallbackUrls[srcFilename];
            console.log(`[FallbackManager] Switching to fallback: ${fallbackUrl}`);
            iframe.src = fallbackUrl;
            
            // Add a visual indicator to the parent dashboard item
            const dashboardItem = iframe.closest('.dashboard-item');
            if (dashboardItem) {
                if (!dashboardItem.classList.contains('using-fallback')) {
                    dashboardItem.classList.add('using-fallback');
                    
                    // Add fallback indicator if not already present
                    if (!dashboardItem.querySelector('.fallback-indicator')) {
                        const indicator = document.createElement('div');
                        indicator.className = 'fallback-indicator';
                        indicator.innerHTML = 'Using Static Data';
                        dashboardItem.appendChild(indicator);
                    }
                }
            }
        } else {
            console.warn(`[FallbackManager] No fallback defined for: ${srcFilename}`);
        }
    }

    /**
     * Check existing iframes that might already be loaded
     */
    detectExistingIframeState() {
        const iframes = document.querySelectorAll(this.iframeSelector);
        
        iframes.forEach(iframe => {
            if (iframe.complete || iframe.readyState === 'complete') {
                this.checkIframeContent(iframe);
            }
        });
    }
}

// Initialize fallback manager when document is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Add the necessary styles for fallback indication
    const style = document.createElement('style');
    style.textContent = `
        .dashboard-item.using-fallback {
            position: relative;
            border: 1px solid #f59e0b;
        }
        .fallback-indicator {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: #f59e0b;
            color: white;
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 0.7em;
            z-index: 10;
        }
    `;
    document.head.appendChild(style);
    
    // Initialize the fallback manager
    window.fallbackManager = new FallbackManager();
    window.fallbackManager.init();
    
    // Also run when dynamic content might be loaded later
    setTimeout(() => {
        window.fallbackManager.setupIframeMonitoring();
    }, 2000);
});
