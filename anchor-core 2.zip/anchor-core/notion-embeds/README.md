# Notion Database Embedding Workaround

## Overview
This directory contains HTML files that provide an alternative approach to embedding Notion databases by using iframes. Since the Notion API does not support creating linked databases programmatically, this approach uses HTML iframe embedding as a workaround.

## Files Included
- **master-dashboard.html**: Main dashboard that embeds all databases
- **agent-registry.html**: Embed for the Agent Registry database
- **component-library.html**: Embed for the Component Library database
- **project-tracker.html**: Embed for the Project Tracker database

## How to Use
1. Open the HTML files in a web browser
2. Ensure you're logged into Notion in the same browser
3. The embedded databases should load in the iframes

## Benefits of This Approach
- Provides a visual dashboard experience
- Allows viewing multiple databases simultaneously
- Works independently of API limitations
- Can be hosted on a simple web server if needed

## Limitations
- Requires the user to be logged into Notion
- May have cross-origin restrictions in some environments
- Iframe embedding may have limited functionality compared to native Notion embedding

## Technical Notes
The iframe approach works by loading the Notion database URLs directly in embedded frames. This is a client-side solution that bypasses the API limitations but requires proper authentication in the browser.

## Database IDs
- Agent Registry: 1f8e48c2-bbbd-8149-aa90-ced3c874efb6
- Component Library: 1f8e48c2-bbbd-81a3-a6bc-d041fa47215c
- Project Tracker: 1f8e48c2-bbbd-813f-ae44-db59ea8a6e32

---

Created: 2025-05-18 18:18:01
