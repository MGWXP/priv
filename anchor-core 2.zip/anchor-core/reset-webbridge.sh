#!/bin/bash
# Reset all WebSocket Bridge processes
# This script stops all running processes and cleans up PID files

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "🔄 Resetting WebSocket Bridge..."

# Kill existing processes
echo "Stopping running processes..."
if [ -f "$SCRIPT_DIR/webbridge.pid" ]; then
  PID=$(cat "$SCRIPT_DIR/webbridge.pid")
  if [ -n "$PID" ]; then
    echo "Stopping WebSocket bridge (PID: $PID)"
    kill -9 $PID 2>/dev/null || true
  fi
  rm -f "$SCRIPT_DIR/webbridge.pid"
fi

if [ -f "$SCRIPT_DIR/notion-sync.pid" ]; then
  PID=$(cat "$SCRIPT_DIR/notion-sync.pid")
  if [ -n "$PID" ]; then
    echo "Stopping Notion sync (PID: $PID)"
    kill -9 $PID 2>/dev/null || true
  fi
  rm -f "$SCRIPT_DIR/notion-sync.pid"
fi

if [ -f "$SCRIPT_DIR/dashboard.pid" ]; then
  PID=$(cat "$SCRIPT_DIR/dashboard.pid")
  if [ -n "$PID" ]; then
    echo "Stopping dashboard server (PID: $PID)"
    kill -9 $PID 2>/dev/null || true
  fi
  rm -f "$SCRIPT_DIR/dashboard.pid"
fi

# Kill any node processes with "webbridge" in the name
echo "Stopping any remaining processes..."
pkill -f "node.*webbridge" || true
pkill -f "node.*notion-sync" || true

# Clean up socket files
echo "Cleaning up socket files..."
rm -f "$SCRIPT_DIR/sockets/*.sock"

echo "✅ WebSocket Bridge reset complete!"
echo "To restart the WebSocket Bridge, run:"
echo "  $SCRIPT_DIR/start-webbridge.sh"
