#!/bin/bash
# CNIF-Architect: Architecture Planning Meta-Protocol
# © 2025 XPV - MIT License
#
# This script creates a clean architecture plan for the refactored codebase
# based on the classification and analysis results.

# Configuration
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
ANALYSIS_DIR="${ANCHOR_HOME}/_analysis"
ARCHITECTURE_DIR="${ANALYSIS_DIR}/architecture"
CLASSIFICATION_DIR="${ANALYSIS_DIR}/classification"
OUTPUT_DIR="${ARCHITECTURE_DIR}/plan"
LOG_DIR="${ANALYSIS_DIR}/logs"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")

# Ensure directories exist
mkdir -p "${OUTPUT_DIR}"
mkdir -p "${LOG_DIR}"

# Log function
log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] [${1}] ${2}" | tee -a "${LOG_DIR}/architect_${TIMESTAMP}.log"
}

log "INFO" "Starting CNIF architecture planning"

# Check if classification has been done
LATEST_CLASSIFICATION_DIR=$(find "${CLASSIFICATION_DIR}/categories" -type d -name "*" | sort -r | head -n 1)
if [ -z "${LATEST_CLASSIFICATION_DIR}" ]; then
  log "ERROR" "No classification data found. Please run classify-codebase.sh first."
  echo "❌ Error: No classification data found. Please run classify-codebase.sh first."
  exit 1
fi

# Find latest classification files
CORE_SERVERS=$(find "${CLASSIFICATION_DIR}/categories" -name "core_servers_*.txt" | sort -r | head -n 1)
UTILITIES=$(find "${CLASSIFICATION_DIR}/categories" -name "utilities_*.txt" | sort -r | head -n 1)
CONFIG_MGMT=$(find "${CLASSIFICATION_DIR}/categories" -name "config_management_*.txt" | sort -r | head -n 1)
LAUNCHERS=$(find "${CLASSIFICATION_DIR}/categories" -name "launchers_*.txt" | sort -r | head -n 1)
TESTING=$(find "${CLASSIFICATION_DIR}/categories" -name "testing_*.txt" | sort -r | head -n 1)
DOCUMENTATION=$(find "${CLASSIFICATION_DIR}/categories" -name "documentation_*.txt" | sort -r | head -n 1)

if [ -z "${CORE_SERVERS}" ] || [ -z "${UTILITIES}" ] || [ -z "${CONFIG_MGMT}" ]; then
  log "ERROR" "Required classification files not found."
  echo "❌ Error: Required classification files not found."
  exit 1
fi

log "INFO" "Using classification files:"
log "INFO" "Core servers: ${CORE_SERVERS}"
log "INFO" "Utilities: ${UTILITIES}"
log "INFO" "Config management: ${CONFIG_MGMT}"

# Define target architecture
GREEN_DIR="${ANCHOR_HOME}/greenfield"
GREENFIELD_STRUCTURE="${OUTPUT_DIR}/greenfield_structure_${TIMESTAMP}.txt"

cat > "${GREENFIELD_STRUCTURE}" << EOF
${GREEN_DIR}/
├── bin/                      # Executable scripts and binaries
├── config/                   # Configuration files
│   ├── default.json          # Default configuration
│   ├── development.json      # Development environment config
│   └── production.json       # Production environment config
├── docs/                     # Documentation
│   ├── api/                  # API documentation
│   ├── architecture/         # Architecture documentation
│   └── guides/               # User guides
├── src/                      # Source code
│   ├── core/                 # Core functionality
│   │   ├── mcp/              # MCP protocol implementation
│   │   ├── schema/           # Schema registry
│   │   └── socket/           # Socket communication
│   ├── servers/              # MCP servers
│   │   ├── filesystem/       # Filesystem MCP server
│   │   ├── github/           # GitHub MCP server
│   │   ├── notion/           # Notion MCP server
│   │   └── slack/            # Slack MCP server
│   ├── transforms/           # Data transformation
│   │   ├── claude-to-notion/ # Claude to Notion transformers
│   │   └── notion-to-claude/ # Notion to Claude transformers
│   └── utils/                # Utilities and helpers
│       ├── config/           # Configuration utilities
│       ├── crypto/           # Cryptography utilities
│       ├── format/           # Data formatting utilities
│       └── system/           # System utilities
├── test/                     # Test files
│   ├── integration/          # Integration tests
│   └── unit/                 # Unit tests
├── tools/                    # Tools and scripts
│   ├── build/                # Build scripts
│   ├── deploy/               # Deployment scripts
│   └── setup/                # Setup scripts
├── types/                    # TypeScript type definitions
├── .env.example              # Example environment variables
├── .gitignore                # Git ignore file
├── package.json              # Package configuration
├── README.md                 # Project readme
└── tsconfig.json             # TypeScript configuration
EOF

# Create mapping between current files and new architecture
MAPPING_FILE="${OUTPUT_DIR}/architecture_mapping_${TIMESTAMP}.csv"
echo "current_file,target_location,action,priority" > "${MAPPING_FILE}"

# Map core servers
log "INFO" "Mapping core server components..."
while IFS= read -r file; do
  filename=$(basename "${file}")
  
  if [[ "${filename}" == *"socket"* || "${filename}" == *"server"* ]]; then
    target="${GREEN_DIR}/src/core/socket/${filename}"
    echo "\"${file}\",\"${target}\",\"copy\",\"high\"" >> "${MAPPING_FILE}"
  elif [[ "${filename}" == *"schema"* || "${filename}" == *"registry"* ]]; then
    target="${GREEN_DIR}/src/core/schema/${filename}"
    echo "\"${file}\",\"${target}\",\"copy\",\"high\"" >> "${MAPPING_FILE}"
  elif [[ "${filename}" == *"git"* ]]; then
    target="${GREEN_DIR}/src/servers/github/${filename}"
    echo "\"${file}\",\"${target}\",\"copy\",\"high\"" >> "${MAPPING_FILE}"
  elif [[ "${filename}" == *"notion"* ]]; then
    target="${GREEN_DIR}/src/servers/notion/${filename}"
    echo "\"${file}\",\"${target}\",\"copy\",\"high\"" >> "${MAPPING_FILE}"
  elif [[ "${filename}" == *"slack"* ]]; then
    target="${GREEN_DIR}/src/servers/slack/${filename}"
    echo "\"${file}\",\"${target}\",\"copy\",\"high\"" >> "${MAPPING_FILE}"
  elif [[ "${filename}" == *"filesystem"* || "${filename}" == *"file"* ]]; then
    target="${GREEN_DIR}/src/servers/filesystem/${filename}"
    echo "\"${file}\",\"${target}\",\"copy\",\"high\"" >> "${MAPPING_FILE}"
  elif [[ "${filename}" == *"transform"* ]]; then
    target="${GREEN_DIR}/src/transforms/${filename}"
    echo "\"${file}\",\"${target}\",\"copy\",\"high\"" >> "${MAPPING_FILE}"
  else
    target="${GREEN_DIR}/src/core/mcp/${filename}"
    echo "\"${file}\",\"${target}\",\"review\",\"medium\"" >> "${MAPPING_FILE}"
  fi
done < "${CORE_SERVERS}"

# Map utilities
log "INFO" "Mapping utilities..."
while IFS= read -r file; do
  filename=$(basename "${file}")
  
  if [[ "${filename}" == *"config"* ]]; then
    target="${GREEN_DIR}/src/utils/config/${filename}"
    echo "\"${file}\",\"${target}\",\"copy\",\"medium\"" >> "${MAPPING_FILE}"
  elif [[ "${filename}" == *"crypt"* || "${filename}" == *"secure"* ]]; then
    target="${GREEN_DIR}/src/utils/crypto/${filename}"
    echo "\"${file}\",\"${target}\",\"copy\",\"medium\"" >> "${MAPPING_FILE}"
  elif [[ "${filename}" == *"format"* || "${filename}" == *"parse"* ]]; then
    target="${GREEN_DIR}/src/utils/format/${filename}"
    echo "\"${file}\",\"${target}\",\"copy\",\"medium\"" >> "${MAPPING_FILE}"
  else
    target="${GREEN_DIR}/src/utils/system/${filename}"
    echo "\"${file}\",\"${target}\",\"review\",\"low\"" >> "${MAPPING_FILE}"
  fi
done < "${UTILITIES}"

# Map configuration
log "INFO" "Mapping configuration files..."
while IFS= read -r file; do
  filename=$(basename "${file}")
  
  if [[ "${filename}" == "package.json" ]]; then
    target="${GREEN_DIR}/${filename}"
    echo "\"${file}\",\"${target}\",\"copy\",\"high\"" >> "${MAPPING_FILE}"
  elif [[ "${filename}" == "tsconfig.json" ]]; then
    target="${GREEN_DIR}/${filename}"
    echo "\"${file}\",\"${target}\",\"copy\",\"high\"" >> "${MAPPING_FILE}"
  elif [[ "${filename}" == *".env"* ]]; then
    target="${GREEN_DIR}/.env.example"
    echo "\"${file}\",\"${target}\",\"anonymize\",\"medium\"" >> "${MAPPING_FILE}"
  elif [[ "${filename}" == *"config"*".json" ]]; then
    target="${GREEN_DIR}/config/default.json"
    echo "\"${file}\",\"${target}\",\"copy\",\"high\"" >> "${MAPPING_FILE}"
  else
    target="${GREEN_DIR}/config/${filename}"
    echo "\"${file}\",\"${target}\",\"review\",\"low\"" >> "${MAPPING_FILE}"
  fi
done < "${CONFIG_MGMT}"

# Map launchers
log "INFO" "Mapping launcher scripts..."
if [ -f "${LAUNCHERS}" ]; then
  while IFS= read -r file; do
    filename=$(basename "${file}")
    
    if [[ "${filename}" == *"start"* || "${filename}" == *"launch"* ]]; then
      target="${GREEN_DIR}/bin/${filename}"
      echo "\"${file}\",\"${target}\",\"copy\",\"medium\"" >> "${MAPPING_FILE}"
    else
      target="${GREEN_DIR}/tools/setup/${filename}"
      echo "\"${file}\",\"${target}\",\"review\",\"low\"" >> "${MAPPING_FILE}"
    fi
  done < "${LAUNCHERS}"
fi

# Map tests
log "INFO" "Mapping test files..."
if [ -f "${TESTING}" ]; then
  while IFS= read -r file; do
    filename=$(basename "${file}")
    
    if [[ "${filename}" == *"integration"* || "${filename}" == *"e2e"* ]]; then
      target="${GREEN_DIR}/test/integration/${filename}"
      echo "\"${file}\",\"${target}\",\"copy\",\"medium\"" >> "${MAPPING_FILE}"
    else
      target="${GREEN_DIR}/test/unit/${filename}"
      echo "\"${file}\",\"${target}\",\"copy\",\"medium\"" >> "${MAPPING_FILE}"
    fi
  done < "${TESTING}"
fi

# Map documentation
log "INFO" "Mapping documentation files..."
if [ -f "${DOCUMENTATION}" ]; then
  while IFS= read -r file; do
    filename=$(basename "${file}")
    
    if [[ "${filename}" == "README.md" ]]; then
      target="${GREEN_DIR}/README.md"
      echo "\"${file}\",\"${target}\",\"copy\",\"high\"" >> "${MAPPING_FILE}"
    elif [[ "${filename}" == *"API"* || "${filename}" == *"api"* ]]; then
      target="${GREEN_DIR}/docs/api/${filename}"
      echo "\"${file}\",\"${target}\",\"copy\",\"medium\"" >> "${MAPPING_FILE}"
    elif [[ "${filename}" == *"GUIDE"* || "${filename}" == *"guide"* || "${filename}" == *"SETUP"* ]]; then
      target="${GREEN_DIR}/docs/guides/${filename}"
      echo "\"${file}\",\"${target}\",\"copy\",\"medium\"" >> "${MAPPING_FILE}"
    else
      target="${GREEN_DIR}/docs/architecture/${filename}"
      echo "\"${file}\",\"${target}\",\"copy\",\"low\"" >> "${MAPPING_FILE}"
    fi
  done < "${DOCUMENTATION}"
fi

# Generate architecture plan report
ARCHITECTURE_PLAN="${OUTPUT_DIR}/architecture_plan_${TIMESTAMP}.md"
MAPPED_FILES_COUNT=$(grep -c "" "${MAPPING_FILE}" || echo "0")
MAPPED_FILES_COUNT=$((MAPPED_FILES_COUNT - 1)) # Subtract header row

cat > "${ARCHITECTURE_PLAN}" << EOF
# CNIF Greenfield Architecture Plan
Generated on: $(date '+%Y-%m-%d %H:%M:%S')

## Overview
This plan outlines the refactoring of the CNIF codebase into a clean, modular architecture.
The refactored codebase will be organized according to a well-defined structure that promotes
maintainability, scalability, and ease of use.

## Target Directory Structure
\`\`\`
$(cat "${GREENFIELD_STRUCTURE}")
\`\`\`

## Migration Summary
- Files Mapped: ${MAPPED_FILES_COUNT}
- High Priority Files: $(grep -c "\"high\"" "${MAPPING_FILE}" || echo "0")
- Medium Priority Files: $(grep -c "\"medium\"" "${MAPPING_FILE}" || echo "0")
- Low Priority Files: $(grep -c "\"low\"" "${MAPPING_FILE}" || echo "0")

## Key Components

### Core MCP Implementation
The core MCP implementation will be located in \`src/core/mcp\` and will provide the foundation
for all MCP servers. It will handle the protocol details, message formatting, and communication
patterns.

### Socket Communication
Socket communication code will be located in \`src/core/socket\` and will handle all Unix socket
creation, management, and communication.

### Schema Registry
The schema registry will be located in \`src/core/schema\` and will manage schema definitions,
validation, and versioning.

### MCP Servers
Individual MCP servers will be located in \`src/servers/\` and will be organized by service:
- \`filesystem\`: File system access
- \`github\`: GitHub integration
- \`notion\`: Notion integration
- \`slack\`: Slack integration

### Utilities
Utility functions will be located in \`src/utils/\` and organized by function:
- \`config\`: Configuration management
- \`crypto\`: Cryptography utilities
- \`format\`: Data formatting and parsing
- \`system\`: System utilities

## Implementation Strategy
1. Create the target directory structure
2. Copy high-priority files first (core components, server implementations)
3. Copy medium-priority files (utilities, configuration, tests)
4. Review and refactor low-priority files as needed
5. Update imports and references to match the new structure
6. Implement integration tests to verify functionality
7. Update documentation to reflect the new architecture

## Dependency Management
All dependencies will be consolidated in a single \`package.json\` file at the root of the project.
The development dependencies will be clearly separated from the runtime dependencies.

## Configuration Management
Configuration will be managed through environment variables and configuration files in the \`config/\`
directory. The configuration system will support different environments (development, production)
and will be loaded based on the \`NODE_ENV\` environment variable.

## Next Steps
1. Create the greenfield directory structure
2. Implement the file migration script
3. Test each component after migration
4. Update imports and references
5. Verify the refactored codebase
EOF

# Generate implementation script template
IMPLEMENTATION_SCRIPT="${OUTPUT_DIR}/implement_architecture_${TIMESTAMP}.sh"

cat > "${IMPLEMENTATION_SCRIPT}" << 'EOF'
#!/bin/bash
# CNIF Architecture Implementation Script
# © 2025 XPV - MIT License
#
# This script implements the architecture plan by creating the directory structure
# and migrating files to their target locations.

# Configuration
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
GREEN_DIR="${ANCHOR_HOME}/greenfield"
MAPPING_FILE="__MAPPING_FILE__"  # Will be replaced with actual path
LOG_FILE="${ANCHOR_HOME}/greenfield_migration.log"

# Ensure log file exists
> "${LOG_FILE}"

# Log function
log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] [${1}] ${2}" | tee -a "${LOG_FILE}"
}

log "INFO" "Starting CNIF greenfield architecture implementation"

# Create directory structure
log "INFO" "Creating directory structure..."

mkdir -p "${GREEN_DIR}/bin"
mkdir -p "${GREEN_DIR}/config"
mkdir -p "${GREEN_DIR}/docs/api"
mkdir -p "${GREEN_DIR}/docs/architecture"
mkdir -p "${GREEN_DIR}/docs/guides"
mkdir -p "${GREEN_DIR}/src/core/mcp"
mkdir -p "${GREEN_DIR}/src/core/schema"
mkdir -p "${GREEN_DIR}/src/core/socket"
mkdir -p "${GREEN_DIR}/src/servers/filesystem"
mkdir -p "${GREEN_DIR}/src/servers/github"
mkdir -p "${GREEN_DIR}/src/servers/notion"
mkdir -p "${GREEN_DIR}/src/servers/slack"
mkdir -p "${GREEN_DIR}/src/transforms/claude-to-notion"
mkdir -p "${GREEN_DIR}/src/transforms/notion-to-claude"
mkdir -p "${GREEN_DIR}/src/utils/config"
mkdir -p "${GREEN_DIR}/src/utils/crypto"
mkdir -p "${GREEN_DIR}/src/utils/format"
mkdir -p "${GREEN_DIR}/src/utils/system"
mkdir -p "${GREEN_DIR}/test/integration"
mkdir -p "${GREEN_DIR}/test/unit"
mkdir -p "${GREEN_DIR}/tools/build"
mkdir -p "${GREEN_DIR}/tools/deploy"
mkdir -p "${GREEN_DIR}/tools/setup"
mkdir -p "${GREEN_DIR}/types"

log "INFO" "Directory structure created"

# Check if mapping file exists
if [ ! -f "${MAPPING_FILE}" ]; then
  log "ERROR" "Mapping file not found: ${MAPPING_FILE}"
  echo "❌ Error: Mapping file not found."
  exit 1
fi

# Process high priority files first
log "INFO" "Processing high priority files..."
grep '"high"' "${MAPPING_FILE}" | while IFS=, read -r source target action priority; do
  # Remove quotes
  source=$(echo "${source}" | tr -d '"')
  target=$(echo "${target}" | tr -d '"')
  action=$(echo "${action}" | tr -d '"')
  
  # Create target directory if it doesn't exist
  mkdir -p "$(dirname "${target}")"
  
  # Process based on action
  case "${action}" in
    "copy")
      cp "${source}" "${target}" 2>>"${LOG_FILE}"
      log "INFO" "Copied: ${source} -> ${target}"
      ;;
    "anonymize")
      # Copy but remove sensitive information
      grep -v "TOKEN\|SECRET\|PASSWORD\|KEY" "${source}" > "${target}" 2>>"${LOG_FILE}"
      log "INFO" "Anonymized: ${source} -> ${target}"
      ;;
    "review")
      # Copy but mark for review
      cp "${source}" "${target}" 2>>"${LOG_FILE}"
      echo "// TODO: Review this file before using in production" > "${target}.review"
      log "INFO" "Copied for review: ${source} -> ${target}"
      ;;
    *)
      log "WARN" "Unknown action '${action}' for file: ${source}"
      ;;
  esac
done

# Process medium priority files
log "INFO" "Processing medium priority files..."
grep '"medium"' "${MAPPING_FILE}" | while IFS=, read -r source target action priority; do
  # Remove quotes
  source=$(echo "${source}" | tr -d '"')
  target=$(echo "${target}" | tr -d '"')
  action=$(echo "${action}" | tr -d '"')
  
  # Create target directory if it doesn't exist
  mkdir -p "$(dirname "${target}")"
  
  # Process based on action
  case "${action}" in
    "copy")
      cp "${source}" "${target}" 2>>"${LOG_FILE}"
      log "INFO" "Copied: ${source} -> ${target}"
      ;;
    "anonymize")
      # Copy but remove sensitive information
      grep -v "TOKEN\|SECRET\|PASSWORD\|KEY" "${source}" > "${target}" 2>>"${LOG_FILE}"
      log "INFO" "Anonymized: ${source} -> ${target}"
      ;;
    "review")
      # Copy but mark for review
      cp "${source}" "${target}" 2>>"${LOG_FILE}"
      echo "// TODO: Review this file before using in production" > "${target}.review"
      log "INFO" "Copied for review: ${source} -> ${target}"
      ;;
    *)
      log "WARN" "Unknown action '${action}' for file: ${source}"
      ;;
  esac
done

# Process low priority files
log "INFO" "Processing low priority files..."
grep '"low"' "${MAPPING_FILE}" | while IFS=, read -r source target action priority; do
  # Remove quotes
  source=$(echo "${source}" | tr -d '"')
  target=$(echo "${target}" | tr -d '"')
  action=$(echo "${action}" | tr -d '"')
  
  # Create target directory if it doesn't exist
  mkdir -p "$(dirname "${target}")"
  
  # Process based on action
  case "${action}" in
    "copy")
      cp "${source}" "${target}" 2>>"${LOG_FILE}"
      log "INFO" "Copied: ${source} -> ${target}"
      ;;
    "anonymize")
      # Copy but remove sensitive information
      grep -v "TOKEN\|SECRET\|PASSWORD\|KEY" "${source}" > "${target}" 2>>"${LOG_FILE}"
      log "INFO" "Anonymized: ${source} -> ${target}"
      ;;
    "review")
      # Copy but mark for review
      cp "${source}" "${target}" 2>>"${LOG_FILE}"
      echo "// TODO: Review this file before using in production" > "${target}.review"
      log "INFO" "Copied for review: ${source} -> ${target}"
      ;;
    *)
      log "WARN" "Unknown action '${action}' for file: ${source}"
      ;;
  esac
done

# Create basic package.json if none exists
if [ ! -f "${GREEN_DIR}/package.json" ]; then
  log "INFO" "Creating basic package.json..."
  cat > "${GREEN_DIR}/package.json" << EOJSON
{
  "name": "cnif-greenfield",
  "version": "1.0.0",
  "description": "Claude-Notion Integration Framework (Greenfield)",
  "main": "src/index.js",
  "scripts": {
    "start": "node src/index.js",
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "author": "XPV",
  "license": "MIT",
  "dependencies": {
  },
  "devDependencies": {
  }
}
EOJSON
fi

# Create basic README.md if none exists
if [ ! -f "${GREEN_DIR}/README.md" ]; then
  log "INFO" "Creating basic README.md..."
  cat > "${GREEN_DIR}/README.md" << EOMD
# CNIF Greenfield

Claude-Notion Integration Framework (Greenfield) is a streamlined, modular implementation
of the MCP protocol for integrating Claude with Notion, GitHub, and other services.

## Features

- MCP protocol implementation for seamless integration
- Socket-based communication for efficient data transfer
- Schema registry for data validation
- Support for multiple services: Notion, GitHub, Slack, and more

## Installation

\`\`\`bash
npm install
\`\`\`

## Usage

\`\`\`bash
npm start
\`\`\`

## Documentation

See the \`docs\` directory for detailed documentation.

## License

MIT
EOMD
fi

# Create basic .gitignore if none exists
if [ ! -f "${GREEN_DIR}/.gitignore" ]; then
  log "INFO" "Creating basic .gitignore..."
  cat > "${GREEN_DIR}/.gitignore" << EOIGNORE
# Dependencies
node_modules/
npm-debug.log
yarn-error.log
yarn-debug.log
package-lock.json

# Environment variables
.env
.env.*
!.env.example

# Build output
dist/
build/
out/

# Logs
logs/
*.log

# Editor and OS files
.idea/
.vscode/
*.swp
*.swo
.DS_Store
Thumbs.db

# Test coverage
coverage/
.nyc_output/

# Temporary files
tmp/
temp/
EOIGNORE
fi

log "INFO" "CNIF greenfield architecture implementation complete"
echo "✅ Greenfield architecture implemented at: ${GREEN_DIR}"
echo "Check ${LOG_FILE} for details."
EOF

# Replace the placeholder mapping file path
sed -i '' "s|__MAPPING_FILE__|${MAPPING_FILE}|g" "${IMPLEMENTATION_SCRIPT}"
chmod +x "${IMPLEMENTATION_SCRIPT}"

log "INFO" "Architecture planning complete. Plan: ${ARCHITECTURE_PLAN}"
echo "✅ CNIF architecture planning complete."
echo "Architecture plan is available at: ${ARCHITECTURE_PLAN}"
echo "Implementation script is available at: ${IMPLEMENTATION_SCRIPT}"
