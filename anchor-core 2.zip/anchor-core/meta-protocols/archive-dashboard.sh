#!/bin/bash
# archive-dashboard.sh - Centralized management dashboard for the archiving protocol
# This script provides a comprehensive overview of archived components and their status

# Set strict error handling
set -e

# ANSI color codes for output formatting
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Make this script executable
chmod +x $0

# Print banner
echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║              ANCHOR V6 ARCHIVING DASHBOARD                     ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"

# Define paths
ARCHIVE_DIR="/Users/XPV/Desktop/anchor-core/archive"
COHERENCE_DIR="/Users/XPV/Desktop/anchor-core/coherence_lock"
BACKUP_DIR="/Users/XPV/Desktop/anchor-core/backups"
LOGS_DIR="/Users/XPV/Desktop/anchor-core/logs"
REPORT_DIR="/Users/XPV/Desktop/anchor-core/analysis"

# Create report directory if it doesn't exist
mkdir -p "$REPORT_DIR"

# Generate timestamp for reports
TIMESTAMP=$(date +"%Y%m%d%H%M%S")
DASHBOARD_REPORT="$REPORT_DIR/archiving-dashboard-$TIMESTAMP.md"

# Function to count archived components by category
count_by_category() {
    local count=0
    if [ -d "$ARCHIVE_DIR/$1" ]; then
        count=$(find "$ARCHIVE_DIR/$1" -type f -not -name "README.md" -not -name "*.meta" | wc -l)
    fi
    echo "$count"
}

# Function to get last archived component in a category
last_archived() {
    local category="$1"
    local last_file=""
    if [ -d "$ARCHIVE_DIR/$category" ]; then
        last_file=$(find "$ARCHIVE_DIR/$category" -type f -not -name "README.md" -not -name "*.meta" -printf "%T@ %p\n" | sort -n | tail -1 | cut -d' ' -f2-)
        if [ -n "$last_file" ]; then
            basename "$last_file"
        else
            echo "None"
        fi
    else
        echo "None"
    fi
}

# Function to get total failure count for a category
get_failure_count() {
    local category="$1"
    local total=0
    if [ -d "$ARCHIVE_DIR/$category" ]; then
        for meta in $(find "$ARCHIVE_DIR/$category" -name "*.meta"); do
            local count=$(grep "FAILURE_COUNT:" "$meta" | awk '{print $2}')
            if [[ "$count" =~ ^[0-9]+$ ]]; then
                total=$((total + count))
            fi
        done
    fi
    echo "$total"
}

# Create dashboard report header
cat > "$DASHBOARD_REPORT" <<EOF
# Anchor V6 Archiving Dashboard

**Generated on:** $(date +"%Y-%m-%d %H:%M:%S")
**System:** Anchor V6
**Protocol Version:** 1.0.0

## Archiving Summary

| Category | Components | Last Archived | Total Failures | Status |
|----------|------------|---------------|----------------|--------|
EOF

# Calculate statistics for each category
CATEGORIES=("module-system-conflicts" "socket-connectivity-issues" "schema-validation-errors" "process-management-issues" "performance-bottlenecks" "deprecated-implementations" "obsolete-configurations")

TOTAL_ARCHIVED=0
TOTAL_FAILURES=0

for category in "${CATEGORIES[@]}"; do
    count=$(count_by_category "$category")
    TOTAL_ARCHIVED=$((TOTAL_ARCHIVED + count))
    
    last=$(last_archived "$category")
    failures=$(get_failure_count "$category")
    TOTAL_FAILURES=$((TOTAL_FAILURES + failures))
    
    # Determine status based on count
    if [ "$count" -eq 0 ]; then
        status="No issues"
    elif [ "$count" -lt 3 ]; then
        status="Low impact"
    elif [ "$count" -lt 5 ]; then
        status="Moderate impact"
    else
        status="High impact"
    fi
    
    # Add to report
    echo "| $category | $count | $last | $failures | $status |" >> "$DASHBOARD_REPORT"
    
    # Display on console
    echo -e "${CYAN}Category: ${MAGENTA}$category${NC}"
    echo -e "  Components: $count"
    echo -e "  Last Archived: $last"
    echo -e "  Total Failures: $failures"
    echo -e "  Status: $status"
    echo ""
done

# Add totals to report
cat >> "$DASHBOARD_REPORT" <<EOF

**Total Components Archived:** $TOTAL_ARCHIVED
**Total Failure Occurrences:** $TOTAL_FAILURES

## Recent Archiving Activity

| Date | Component | Category | Reason |
|------|-----------|----------|--------|
EOF

# Get recent archiving activity from coherence markers
echo -e "${CYAN}Recent Archiving Activity:${NC}"
echo ""
recent_markers=$(find "$COHERENCE_DIR" -name "ARCHIVED_*" -type f -printf "%T@ %p\n" | sort -nr | head -5)

if [ -z "$recent_markers" ]; then
    echo -e "${YELLOW}No recent archiving activity found${NC}"
    echo "No recent archiving activity found" >> "$DASHBOARD_REPORT"
else
    while read -r line; do
        marker_file=$(echo "$line" | cut -d' ' -f2-)
        marker_date=$(date -r "$marker_file" +"%Y-%m-%d %H:%M")
        component=$(basename "$marker_file" | sed 's/ARCHIVED_//' | sed 's/_.*.marker//')
        
        # Try to find metadata for this component
        category=""
        reason=""
        for cat_dir in "$ARCHIVE_DIR"/*; do
            if [ -d "$cat_dir" ]; then
                for meta in $(find "$cat_dir" -name "${component}*.meta"); do
                    category=$(basename "$cat_dir")
                    reason=$(grep "REASON:" "$meta" | cut -d':' -f2- | sed 's/^ //')
                    break
                done
                if [ -n "$category" ]; then
                    break
                fi
            fi
        done
        
        # If no metadata found, show minimal info
        if [ -z "$category" ]; then
            category="Unknown"
            reason="Unknown"
        fi
        
        echo -e "${MAGENTA}$marker_date${NC} - ${CYAN}$component${NC}"
        echo -e "  Category: $category"
        echo -e "  Reason: $reason"
        echo ""
        
        # Add to report
        echo "| $marker_date | $component | $category | $reason |" >> "$DASHBOARD_REPORT"
    done <<< "$recent_markers"
fi

# Add recommendations section to report
cat >> "$DASHBOARD_REPORT" <<EOF

## System Recommendations

Based on the current archiving status, the following recommendations are made:
EOF

# Generate recommendations
if [ "$TOTAL_ARCHIVED" -eq 0 ]; then
    echo "- No components have been archived. Begin by analyzing the system for potential issues." >> "$DASHBOARD_REPORT"
    recommendations="Begin by analyzing the system for potential issues"
elif [ "$TOTAL_ARCHIVED" -lt 5 ]; then
    echo "- Low number of archived components. Continue monitoring for potential issues." >> "$DASHBOARD_REPORT"
    echo "- Consider running a full system analysis to identify additional candidates." >> "$DASHBOARD_REPORT"
    recommendations="Continue monitoring and run a full system analysis"
else
    # Find the category with most issues
    max_count=0
    max_category=""
    for category in "${CATEGORIES[@]}"; do
        count=$(count_by_category "$category")
        if [ "$count" -gt "$max_count" ]; then
            max_count=$count
            max_category=$category
        fi
    done
    
    if [ -n "$max_category" ]; then
        echo "- High concentration of issues in '$max_category' category. Prioritize focus on this area." >> "$DASHBOARD_REPORT"
        echo "- Consider a targeted refactoring effort for components in this category." >> "$DASHBOARD_REPORT"
        recommendations="Focus on $max_category issues and consider targeted refactoring"
    fi
    
    echo "- Regularly review archived components for potential reintegration of optimized replacements." >> "$DASHBOARD_REPORT"
    recommendations="$recommendations and regularly review archived components"
fi

# Add next steps to report
cat >> "$DASHBOARD_REPORT" <<EOF

## Next Steps

1. Run the analysis tool to identify new archiving candidates:
   \`\`\`bash
   ./meta-protocols/analyze-archive-candidates.sh 30 3
   \`\`\`

2. Review candidate components and their error patterns in the analysis directory

3. Archive problematic components and create optimized replacements using:
   \`\`\`bash
   ./meta-protocols/archive-component.sh [component_path] [category] [reason] [replacement_path]
   ./meta-protocols/create-replacement-component.sh [archived_path] [replacement_path] [type]
   \`\`\`

4. Update dependencies and references to use new components

5. Run system verification to ensure functionality:
   \`\`\`bash
   /Users/XPV/Desktop/anchor-core/mcp-servers/verify-servers.sh
   \`\`\`

## Resources

- **Protocol Documentation**: \`/Users/XPV/Desktop/anchor-core/SYSTEMATIC_ARCHIVING_PROTOCOL.md\`
- **Archive Report**: \`/Users/XPV/Desktop/anchor-core/ARCHIVE_REPORT.md\`
- **Analysis Tools**: \`/Users/XPV/Desktop/anchor-core/meta-protocols/\`
EOF

# Create coherence marker
MARKER="$COHERENCE_DIR/ARCHIVING_DASHBOARD_${TIMESTAMP}.marker"
touch "$MARKER"

# Display summary
echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║                     DASHBOARD SUMMARY                          ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${CYAN}Total Components Archived:${NC} $TOTAL_ARCHIVED"
echo -e "${CYAN}Total Failure Occurrences:${NC} $TOTAL_FAILURES"
echo ""
echo -e "${CYAN}Recommendations:${NC}"
echo -e "$recommendations"
echo ""
echo -e "${GREEN}✅ Dashboard report generated:${NC} $DASHBOARD_REPORT"
echo -e "${GREEN}✅ Coherence marker created:${NC} $(basename "$MARKER")"
echo ""
echo -e "${YELLOW}To view the complete dashboard, open:${NC}"
echo -e "$DASHBOARD_REPORT"

exit 0
