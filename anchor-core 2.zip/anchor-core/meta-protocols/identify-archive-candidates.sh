#!/bin/bash
# identify-archive-candidates.sh - Identifies high-priority components for archiving
# This script analyzes source code patterns to find problematic components

# Set strict error handling
set -e

# ANSI color codes for output formatting
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Make this script executable
chmod +x $0

# Print banner
echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║           ANCHOR V6 SOURCE CODE ARCHIVE ANALYZER               ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"

# Define directories to analyze
SOURCE_DIRS=(
  "/Users/XPV/Desktop/anchor-core/lib"
  "/Users/XPV/Desktop/anchor-core/mcp-servers"
  "/Users/XPV/Desktop/anchor-core/entry-points"
  "/Users/XPV/Desktop/anchor-core/core"
)

# Define output locations
TIMESTAMP=$(date +"%Y%m%d%H%M%S")
REPORT_DIR="/Users/XPV/Desktop/anchor-core/analysis"
CANDIDATES_FILE="$REPORT_DIR/source-archive-candidates-$TIMESTAMP.csv"
DETAILED_REPORT="$REPORT_DIR/source-analysis-report-$TIMESTAMP.md"

# Create report directory if it doesn't exist
mkdir -p "$REPORT_DIR"

# Initialize results files
echo "component_path,category,risk_score,issues_found,suggested_action" > "$CANDIDATES_FILE"

cat > "$DETAILED_REPORT" <<EOF
# Anchor V6 Source Code Analysis Report

**Generated on:** $(date +"%Y-%m-%d %H:%M:%S")
**Analyzed directories:**
$(printf "- \`%s\`\n" "${SOURCE_DIRS[@]}")

## Overview

This report analyzes the source code of the Anchor V6 system to identify components that may need archiving based on code patterns that suggest potential issues.

## Analysis Methodology

Components are analyzed for the following code patterns:

1. **Module System Conflicts**: Mixing of CommonJS and ES Module syntax
2. **Socket Connectivity Issues**: Problematic socket handling patterns
3. **Schema Validation Errors**: Improper schema validation approaches
4. **Performance Bottlenecks**: Memory leaks and inefficient resource usage
5. **Error Handling Issues**: Missing or improper error handling

Each component is assigned a risk score based on the number and severity of issues found.

## Analysis Results

| Component | Category | Risk Score | Issues Found | Suggested Action |
|-----------|----------|------------|--------------|------------------|
EOF

# Function to analyze for module system conflicts
check_module_conflicts() {
    local file="$1"
    local issues=0
    local details=""
    
    # Check for mixing require and import
    if grep -q "require(" "$file" && grep -q "import " "$file"; then
        issues=$((issues + 3))
        details+="- Mixing CommonJS require() and ES Module import statements\n"
    fi
    
    # Check for mixing module.exports and export
    if grep -q "module.exports" "$file" && grep -q "export " "$file"; then
        issues=$((issues + 3))
        details+="- Mixing CommonJS module.exports and ES Module export statements\n"
    fi
    
    # Check for ES6 syntax in .js files that might be interpreted as CommonJS
    if [[ "$file" == *.js ]] && ! [[ "$file" == *.mjs ]]; then
        if grep -q "export " "$file" || grep -q "import " "$file"; then
            issues=$((issues + 2))
            details+="- Using ES Module syntax in .js file without explicit .mjs extension\n"
        fi
    fi
    
    echo "$issues:$details"
}

# Function to analyze for socket connectivity issues
check_socket_issues() {
    local file="$1"
    local issues=0
    local details=""
    
    # Check for missing error handling in socket operations
    if grep -q "createServer\|Socket\|connect(" "$file"; then
        if ! grep -q "on('error'" "$file" && ! grep -q 'on("error"' "$file"; then
            issues=$((issues + 3))
            details+="- Socket operations without proper error event handling\n"
        fi
        
        # Check for missing timeout handling
        if ! grep -q "setTimeout\|timeout" "$file"; then
            issues=$((issues + 2))
            details+="- Socket operations without timeout management\n"
        fi
        
        # Check for missing close handling
        if ! grep -q "on('close'" "$file" && ! grep -q 'on("close"' "$file"; then
            issues=$((issues + 1))
            details+="- Socket operations without close event handling\n"
        fi
    fi
    
    echo "$issues:$details"
}

# Function to analyze for schema validation issues
check_schema_validation() {
    local file="$1"
    local issues=0
    local details=""
    
    # Check for schema-related content
    if grep -q "schema\|validate\|validation" "$file"; then
        # Check for try-catch around validation
        if grep -q "validate" "$file" && ! grep -q "try {" "$file"; then
            issues=$((issues + 2))
            details+="- Schema validation without try-catch error handling\n"
        fi
        
        # Check for proper error messaging
        if grep -q "validate" "$file" && ! grep -q "error.message\|errors:" "$file"; then
            issues=$((issues + 2))
            details+="- Schema validation without proper error messaging\n"
        fi
        
        # Check for schema versioning
        if grep -q "schema" "$file" && ! grep -q "version\|schemaVersion" "$file"; then
            issues=$((issues + 1))
            details+="- Schema handling without versioning management\n"
        fi
    fi
    
    echo "$issues:$details"
}

# Function to analyze for performance bottlenecks
check_performance_issues() {
    local file="$1"
    local issues=0
    local details=""
    
    # Check for memory management in large operations
    if grep -q "map\|filter\|reduce\|forEach" "$file"; then
        if grep -q "readFileSync\|readFile" "$file" && ! grep -q "stream\|createReadStream" "$file"; then
            issues=$((issues + 2))
            details+="- Processing large files without streaming\n"
        fi
    fi
    
    # Check for potential memory leaks in event listeners
    if grep -q "addListener\|on(" "$file" && ! grep -q "removeListener\|off(" "$file"; then
        issues=$((issues + 2))
        details+="- Adding event listeners without corresponding removal\n"
    fi
    
    # Check for inefficient data structures for large datasets
    if grep -q "new Array(\|Array.from\|\[\]" "$file" && grep -q "length > 1000\|length > 10000" "$file"; then
        issues=$((issues + 1))
        details+="- Using arrays for potentially large datasets\n"
    fi
    
    # Check for M3 Max optimizations
    if grep -q "process.env.UV_THREADPOOL_SIZE" "$file" || grep -q "max-old-space-size" "$file"; then
        # This is good practice!
        issues=$((issues - 1))
        details+="+ Contains proper M3 Max optimizations\n"
    }
    
    echo "$issues:$details"
}

# Function to analyze for general code quality issues
check_code_quality() {
    local file="$1"
    local issues=0
    local details=""
    
    # Check for missing error handling
    if grep -q "function\|=>" "$file"; then
        # Count async functions without try-catch
        async_funcs=$(grep -c "async function\|async (" "$file")
        try_blocks=$(grep -c "try {" "$file")
        
        if [ "$async_funcs" -gt "$try_blocks" ]; then
            issues=$((issues + 2))
            details+="- Async functions without proper try-catch error handling\n"
        fi
        
        # Check for proper promise error handling
        if grep -q "Promise\|.then(" "$file" && ! grep -q ".catch(" "$file"; then
            issues=$((issues + 2))
            details+="- Promises without .catch() error handling\n"
        fi
    fi
    
    # Check for hardcoded configs that should be environment variables
    if grep -q "const.*=.*['\"]\/Users\/" "$file" || grep -q "let.*=.*['\"]\/Users\/" "$file"; then
        issues=$((issues + 1))
        details+="- Hardcoded file paths instead of environment variables\n"
    fi
    
    # Check for commented-out code (potential technical debt)
    commented_lines=$(grep -c "^[[:space:]]*\/\/" "$file")
    total_lines=$(wc -l < "$file")
    if [ "$total_lines" -gt 50 ] && [ "$commented_lines" -gt $(($total_lines / 10)) ]; then
        issues=$((issues + 1))
        details+="- High ratio of commented-out code (potential technical debt)\n"
    fi
    
    echo "$issues:$details"
}

# Analyze each source directory
echo -e "${CYAN}Analyzing source directories...${NC}"
TOTAL_COMPONENTS=0
HIGH_RISK_COMPONENTS=0

for dir in "${SOURCE_DIRS[@]}"; do
    echo -e "${MAGENTA}Scanning:${NC} $dir"
    
    if [ ! -d "$dir" ]; then
        echo -e "${YELLOW}⚠️ Directory not found, skipping: $dir${NC}"
        continue
    fi
    
    # Find all JS files (.js, .cjs, .mjs)
    files=$(find "$dir" -type f \( -name "*.js" -o -name "*.cjs" -o -name "*.mjs" \))
    
    for file in $files; do
        TOTAL_COMPONENTS=$((TOTAL_COMPONENTS + 1))
        component_name=$(basename "$file")
        echo -e "  ${CYAN}Analyzing:${NC} $component_name"
        
        # Analyze file for different types of issues
        module_check=$(check_module_conflicts "$file")
        module_issues=$(echo "$module_check" | cut -d':' -f1)
        module_details=$(echo "$module_check" | cut -d':' -f2-)
        
        socket_check=$(check_socket_issues "$file")
        socket_issues=$(echo "$socket_check" | cut -d':' -f1)
        socket_details=$(echo "$socket_check" | cut -d':' -f2-)
        
        schema_check=$(check_schema_validation "$file")
        schema_issues=$(echo "$schema_check" | cut -d':' -f1)
        schema_details=$(echo "$schema_check" | cut -d':' -f2-)
        
        perf_check=$(check_performance_issues "$file")
        perf_issues=$(echo "$perf_check" | cut -d':' -f1)
        perf_details=$(echo "$perf_check" | cut -d':' -f2-)
        
        quality_check=$(check_code_quality "$file")
        quality_issues=$(echo "$quality_check" | cut -d':' -f1)
        quality_details=$(echo "$quality_check" | cut -d':' -f2-)
        
        # Calculate total risk score
        risk_score=$((module_issues + socket_issues + schema_issues + perf_issues + quality_issues))
        
        # Determine primary issue category
        category="none"
        max_issues=0
        
        if [ "$module_issues" -gt "$max_issues" ]; then
            max_issues=$module_issues
            category="module-system-conflicts"
        fi
        
        if [ "$socket_issues" -gt "$max_issues" ]; then
            max_issues=$socket_issues
            category="socket-connectivity-issues"
        fi
        
        if [ "$schema_issues" -gt "$max_issues" ]; then
            max_issues=$schema_issues
            category="schema-validation-errors"
        fi
        
        if [ "$perf_issues" -gt "$max_issues" ]; then
            max_issues=$perf_issues
            category="performance-bottlenecks"
        fi
        
        if [ "$quality_issues" -gt "$max_issues" ] && [ "$quality_issues" -gt 0 ]; then
            category="process-management-issues"
        fi
        
        # Only include components with issues in the report
        if [ "$risk_score" -gt 0 ]; then
            # Determine recommended action based on risk score
            action="Monitor"
            if [ "$risk_score" -ge 5 ]; then
                action="High priority for archiving"
                HIGH_RISK_COMPONENTS=$((HIGH_RISK_COMPONENTS + 1))
            elif [ "$risk_score" -ge 3 ]; then
                action="Consider archiving"
            fi
            
            # Add to CSV
            echo "$file,$category,$risk_score,\"$(echo -e ${module_details}${socket_details}${schema_details}${perf_details}${quality_details} | tr '\n' ' ' | sed 's/- //')\",\"$action\"" >> "$CANDIDATES_FILE"
            
            # Add to detailed report
            echo "| $component_name | $category | $risk_score | $(echo -e ${module_details}${socket_details}${schema_details}${perf_details}${quality_details} | sed 's/- /- /g' | tr '\n' '<br>') | $action |" >> "$DETAILED_REPORT"
            
            # Display high-risk components on console
            if [ "$risk_score" -ge 5 ]; then
                echo -e "    ${RED}HIGH RISK:${NC} Score $risk_score - $action"
            elif [ "$risk_score" -ge 3 ]; then
                echo -e "    ${YELLOW}MEDIUM RISK:${NC} Score $risk_score - $action"
            else
                echo -e "    ${GREEN}LOW RISK:${NC} Score $risk_score - $action"
            fi
        fi
    done
done

# Add summary to report
cat >> "$DETAILED_REPORT" <<EOF

## Summary

- **Total Components Analyzed:** $TOTAL_COMPONENTS
- **High Risk Components:** $HIGH_RISK_COMPONENTS
- **Risk Threshold for High Priority:** 5+

## Recommendations

Based on the analysis, the following recommendations are provided:

EOF

if [ "$HIGH_RISK_COMPONENTS" -eq 0 ]; then
    echo "- No high-risk components identified. Continue monitoring and regular analysis." >> "$DETAILED_REPORT"
    recommendations="Continue monitoring the codebase for emerging issues"
else
    echo "- **High Priority Components:** $HIGH_RISK_COMPONENTS components have a risk score of 5+ and should be prioritized for archiving" >> "$DETAILED_REPORT"
    echo "- Use the following command to archive these components:" >> "$DETAILED_REPORT"
    echo "  ```bash" >> "$DETAILED_REPORT"
    echo "  ./meta-protocols/bulk-archive-components.sh \"$CANDIDATES_FILE\"" >> "$DETAILED_REPORT"
    echo "  ```" >> "$DETAILED_REPORT"
    recommendations="Archive the $HIGH_RISK_COMPONENTS high-risk components identified"
fi

echo "- After archiving high-risk components, create optimized replacements using:" >> "$DETAILED_REPORT"
echo "  ```bash" >> "$DETAILED_REPORT"
echo "  ./meta-protocols/create-replacement-component.sh [archived_path] [replacement_path] [type]" >> "$DETAILED_REPORT"
echo "  ```" >> "$DETAILED_REPORT"

# Create coherence marker
COHERENCE_MARKER="/Users/XPV/Desktop/anchor-core/coherence_lock/SOURCE_ANALYSIS_${TIMESTAMP}.marker"
touch "$COHERENCE_MARKER"

# Display summary
echo -e "\n${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║                     ANALYSIS SUMMARY                           ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${CYAN}Total Components Analyzed:${NC} $TOTAL_COMPONENTS"
echo -e "${CYAN}High Risk Components:${NC} $HIGH_RISK_COMPONENTS"
echo ""
echo -e "${CYAN}Recommendations:${NC}"
echo -e "$recommendations"
echo ""
echo -e "${GREEN}✅ Analysis report generated:${NC} $DETAILED_REPORT"
echo -e "${GREEN}✅ Candidates file created:${NC} $CANDIDATES_FILE"
echo -e "${GREEN}✅ Coherence marker created:${NC} $(basename "$COHERENCE_MARKER")"
echo ""
echo -e "${YELLOW}To view the complete analysis, open:${NC}"
echo -e "$DETAILED_REPORT"
echo ""
echo -e "${YELLOW}To archive high-risk components, run:${NC}"
echo -e "./meta-protocols/bulk-archive-components.sh \"$CANDIDATES_FILE\""

exit 0
