#!/bin/bash
# CNIF-Migrator: Code Migration Meta-Protocol
# © 2025 XPV - MIT License
#
# This script implements the architecture plan by creating the directory structure
# and migrating files to their target locations.

# Configuration
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
ANALYSIS_DIR="${ANCHOR_HOME}/_analysis"
ARCHITECTURE_DIR="${ANALYSIS_DIR}/architecture"
GREEN_DIR="${ANCHOR_HOME}/greenfield"
OUTPUT_DIR="${GREEN_DIR}/_migration"
LOG_DIR="${ANALYSIS_DIR}/logs"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
LOG_FILE="${LOG_DIR}/migrator_${TIMESTAMP}.log"

# Ensure directories exist
mkdir -p "${OUTPUT_DIR}"
mkdir -p "${LOG_DIR}"
> "${LOG_FILE}"

# Log function
log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] [${1}] ${2}" | tee -a "${LOG_FILE}"
}

log "INFO" "Starting CNIF code migration"

# Check if architecture planning has been done
MAPPING_FILE=$(find "${ARCHITECTURE_DIR}/plan" -name "architecture_mapping_*.csv" | sort -r | head -n 1)
if [ -z "${MAPPING_FILE}" ]; then
  log "ERROR" "No architecture mapping file found. Please run plan-architecture.sh first."
  echo "❌ Error: No architecture mapping file found. Please run plan-architecture.sh first."
  exit 1
fi

log "INFO" "Using architecture mapping file: ${MAPPING_FILE}"

# Create greenfield directory
log "INFO" "Creating greenfield directory structure..."

mkdir -p "${GREEN_DIR}/bin"
mkdir -p "${GREEN_DIR}/config"
mkdir -p "${GREEN_DIR}/docs/api"
mkdir -p "${GREEN_DIR}/docs/architecture"
mkdir -p "${GREEN_DIR}/docs/guides"
mkdir -p "${GREEN_DIR}/src/core/mcp"
mkdir -p "${GREEN_DIR}/src/core/schema"
mkdir -p "${GREEN_DIR}/src/core/socket"
mkdir -p "${GREEN_DIR}/src/servers/filesystem"
mkdir -p "${GREEN_DIR}/src/servers/github"
mkdir -p "${GREEN_DIR}/src/servers/notion"
mkdir -p "${GREEN_DIR}/src/servers/slack"
mkdir -p "${GREEN_DIR}/src/transforms/claude-to-notion"
mkdir -p "${GREEN_DIR}/src/transforms/notion-to-claude"
mkdir -p "${GREEN_DIR}/src/utils/config"
mkdir -p "${GREEN_DIR}/src/utils/crypto"
mkdir -p "${GREEN_DIR}/src/utils/format"
mkdir -p "${GREEN_DIR}/src/utils/system"
mkdir -p "${GREEN_DIR}/test/integration"
mkdir -p "${GREEN_DIR}/test/unit"
mkdir -p "${GREEN_DIR}/tools/build"
mkdir -p "${GREEN_DIR}/tools/deploy"
mkdir -p "${GREEN_DIR}/tools/setup"
mkdir -p "${GREEN_DIR}/types"

log "INFO" "Directory structure created"

# Process files by priority
process_files_by_priority() {
  local priority=$1
  local label=$2
  
  log "INFO" "Processing ${label} priority files..."
  
  grep "\"${priority}\"" "${MAPPING_FILE}" | tail -n +2 | while IFS=, read -r source target action prio; do
    # Remove quotes
    source=$(echo "${source}" | tr -d '"')
    target=$(echo "${target}" | tr -d '"')
    action=$(echo "${action}" | tr -d '"')
    
    # Skip if source file doesn't exist
    if [ ! -f "${source}" ]; then
      log "WARN" "Source file not found: ${source}"
      continue
    }
    
    # Create target directory if it doesn't exist
    mkdir -p "$(dirname "${target}")"
    
    # Process based on action
    case "${action}" in
      "copy")
        cp "${source}" "${target}" 2>>"${LOG_FILE}" || log "ERROR" "Failed to copy: ${source} -> ${target}"
        if [ $? -eq 0 ]; then
          log "INFO" "Copied: ${source} -> ${target}"
        fi
        ;;
      "anonymize")
        # Copy but remove sensitive information
        grep -v "TOKEN\|SECRET\|PASSWORD\|KEY" "${source}" > "${target}" 2>>"${LOG_FILE}" || log "ERROR" "Failed to anonymize: ${source} -> ${target}"
        if [ $? -eq 0 ]; then
          log "INFO" "Anonymized: ${source} -> ${target}"
        fi
        ;;
      "review")
        # Copy but mark for review
        cp "${source}" "${target}" 2>>"${LOG_FILE}" || log "ERROR" "Failed to copy for review: ${source} -> ${target}"
        if [ $? -eq 0 ]; then
          echo "// TODO: Review this file before using in production" > "${target}.review"
          log "INFO" "Copied for review: ${source} -> ${target}"
        fi
        ;;
      *)
        log "WARN" "Unknown action '${action}' for file: ${source}"
        ;;
    esac
  done
}

# Process files by priority
process_files_by_priority "high" "high"
process_files_by_priority "medium" "medium"
process_files_by_priority "low" "low"

# Create basic package.json if none exists
if [ ! -f "${GREEN_DIR}/package.json" ]; then
  log "INFO" "Creating basic package.json..."
  cat > "${GREEN_DIR}/package.json" << EOF
{
  "name": "cnif-greenfield",
  "version": "1.0.0",
  "description": "Claude-Notion Integration Framework (Greenfield)",
  "main": "src/index.js",
  "scripts": {
    "start": "node src/index.js",
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "type": "commonjs",
  "author": "XPV",
  "license": "MIT",
  "dependencies": {
  },
  "devDependencies": {
  }
}
EOF
fi

# Create basic README.md if none exists
if [ ! -f "${GREEN_DIR}/README.md" ]; then
  log "INFO" "Creating basic README.md..."
  cat > "${GREEN_DIR}/README.md" << EOF
# CNIF Greenfield

Claude-Notion Integration Framework (Greenfield) is a streamlined, modular implementation
of the MCP protocol for integrating Claude with Notion, GitHub, and other services.

## Features

- MCP protocol implementation for seamless integration
- Socket-based communication for efficient data transfer
- Schema registry for data validation
- Support for multiple services: Notion, GitHub, Slack, and more

## Installation

\`\`\`bash
npm install
\`\`\`

## Usage

\`\`\`bash
npm start
\`\`\`

## Documentation

See the \`docs\` directory for detailed documentation.

## License

MIT
EOF
fi

# Create basic .gitignore if none exists
if [ ! -f "${GREEN_DIR}/.gitignore" ]; then
  log "INFO" "Creating basic .gitignore..."
  cat > "${GREEN_DIR}/.gitignore" << EOF
# Dependencies
node_modules/
npm-debug.log
yarn-error.log
yarn-debug.log
package-lock.json

# Environment variables
.env
.env.*
!.env.example

# Build output
dist/
build/
out/

# Logs
logs/
*.log

# Editor and OS files
.idea/
.vscode/
*.swp
*.swo
.DS_Store
Thumbs.db

# Test coverage
coverage/
.nyc_output/

# Temporary files
tmp/
temp/
EOF
fi

# Create index.js entry point
log "INFO" "Creating index.js entry point..."
cat > "${GREEN_DIR}/src/index.js" << EOF
/**
 * CNIF Greenfield Entry Point
 * © 2025 XPV - MIT License
 */

// Import core modules
const path = require('path');
const fs = require('fs');

// Log startup
console.log('Starting CNIF Greenfield...');

// TODO: Import and initialize MCP servers
// TODO: Add proper startup logic

// For now, just log a message
console.log('CNIF Greenfield initialized');
EOF

# Create dependency fix script
log "INFO" "Creating dependency fix script..."
cat > "${GREEN_DIR}/tools/build/fix-dependencies.js" << EOF
/**
 * Dependency Fix Script
 * 
 * This script analyzes the JavaScript files in the project and updates
 * dependencies in package.json based on the require() and import statements.
 * 
 * Usage: node tools/build/fix-dependencies.js
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Configuration
const SRC_DIR = path.join(__dirname, '../../src');
const PACKAGE_JSON_PATH = path.join(__dirname, '../../package.json');

// Read package.json
let packageJson;
try {
  packageJson = JSON.parse(fs.readFileSync(PACKAGE_JSON_PATH, 'utf8'));
  if (!packageJson.dependencies) {
    packageJson.dependencies = {};
  }
} catch (err) {
  console.error('Error reading package.json:', err.message);
  process.exit(1);
}

// Find all JavaScript files
function findJsFiles(dir, fileList = []) {
  const files = fs.readdirSync(dir);
  
  for (const file of files) {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    
    if (stat.isDirectory()) {
      findJsFiles(filePath, fileList);
    } else if (file.endsWith('.js') || file.endsWith('.cjs') || file.endsWith('.mjs')) {
      fileList.push(filePath);
    }
  }
  
  return fileList;
}

// Extract dependencies from file
function extractDependencies(filePath) {
  const content = fs.readFileSync(filePath, 'utf8');
  const dependencies = new Set();
  
  // Match require statements
  const requireRegex = /require\(['"]([^./][^'"]*)['"]\)/g;
  let match;
  while ((match = requireRegex.exec(content)) !== null) {
    const dependency = match[1].split('/')[0];
    if (dependency && !dependency.startsWith('.') && !dependency.startsWith('@modelcontextprotocol')) {
      dependencies.add(dependency);
    }
  }
  
  // Match import statements
  const importRegex = /import .* from ['"]([^./][^'"]*)['"]/g;
  while ((match = importRegex.exec(content)) !== null) {
    const dependency = match[1].split('/')[0];
    if (dependency && !dependency.startsWith('.')) {
      dependencies.add(dependency);
    }
  }
  
  return [...dependencies];
}

// Main function
function main() {
  console.log('Finding JavaScript files...');
  const jsFiles = findJsFiles(SRC_DIR);
  console.log(\`Found \${jsFiles.length} JavaScript files\`);
  
  const allDependencies = new Set();
  
  // Extract dependencies from all files
  for (const file of jsFiles) {
    const dependencies = extractDependencies(file);
    dependencies.forEach(dep => allDependencies.add(dep));
  }
  
  console.log('Dependencies found:');
  allDependencies.forEach(dep => console.log(\` - \${dep}\`));
  
  // Update package.json
  let hasChanges = false;
  
  for (const dep of allDependencies) {
    if (!packageJson.dependencies[dep]) {
      packageJson.dependencies[dep] = '*';
      hasChanges = true;
    }
  }
  
  if (hasChanges) {
    console.log('Updating package.json...');
    fs.writeFileSync(PACKAGE_JSON_PATH, JSON.stringify(packageJson, null, 2));
    console.log('package.json updated');
  } else {
    console.log('No changes needed for package.json');
  }
}

// Run the script
main();
EOF

# Create simple startup script
log "INFO" "Creating startup script..."
cat > "${GREEN_DIR}/bin/start-cnif.sh" << EOF
#!/bin/bash
# CNIF Greenfield Startup Script
# © 2025 XPV - MIT License

# Set directory paths
SCRIPT_DIR="\$(cd "\$(dirname "\${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="\$(dirname "\${SCRIPT_DIR}")"
LOG_DIR="\${PROJECT_ROOT}/logs"

# Create log directory if it doesn't exist
mkdir -p "\${LOG_DIR}"

# Log function
log() {
  echo "[\$(date '+%Y-%m-%d %H:%M:%S')] [\${1}] \${2}" | tee -a "\${LOG_DIR}/cnif.log"
}

log "INFO" "Starting CNIF Greenfield..."

# Run the application
node "\${PROJECT_ROOT}/src/index.js"

EXIT_CODE=\$?

if [ \${EXIT_CODE} -eq 0 ]; then
  log "INFO" "CNIF Greenfield exited successfully"
else
  log "ERROR" "CNIF Greenfield exited with code \${EXIT_CODE}"
fi

exit \${EXIT_CODE}
EOF
chmod +x "${GREEN_DIR}/bin/start-cnif.sh"

# Create verification script
log "INFO" "Creating verification script..."
cat > "${GREEN_DIR}/tools/build/verify-migration.js" << EOF
/**
 * Migration Verification Script
 * 
 * This script verifies that all necessary files have been migrated
 * and that the project structure is correct.
 * 
 * Usage: node tools/build/verify-migration.js
 */

const fs = require('fs');
const path = require('path');

// Configuration
const PROJECT_ROOT = path.join(__dirname, '../..');

// Check required directories
const requiredDirs = [
  'bin',
  'config',
  'docs',
  'src/core/mcp',
  'src/core/schema',
  'src/core/socket',
  'src/servers/filesystem',
  'src/servers/github',
  'src/servers/notion',
  'src/servers/slack',
  'src/transforms',
  'src/utils',
  'test',
  'tools'
];

// Check required files
const requiredFiles = [
  'package.json',
  'README.md',
  '.gitignore',
  'src/index.js',
  'bin/start-cnif.sh'
];

function checkDirectories() {
  console.log('Checking required directories...');
  let allExist = true;
  
  for (const dir of requiredDirs) {
    const dirPath = path.join(PROJECT_ROOT, dir);
    const exists = fs.existsSync(dirPath) && fs.statSync(dirPath).isDirectory();
    
    console.log(\`\${exists ? '✅' : '❌'} \${dir}\`);
    
    if (!exists) {
      allExist = false;
    }
  }
  
  return allExist;
}

function checkFiles() {
  console.log('\\nChecking required files...');
  let allExist = true;
  
  for (const file of requiredFiles) {
    const filePath = path.join(PROJECT_ROOT, file);
    const exists = fs.existsSync(filePath) && fs.statSync(filePath).isFile();
    
    console.log(\`\${exists ? '✅' : '❌'} \${file}\`);
    
    if (!exists) {
      allExist = false;
    }
  }
  
  return allExist;
}

function countFiles() {
  console.log('\\nCounting files by type...');
  
  let jsCounts = { total: 0, core: 0, servers: 0, utils: 0, transforms: 0 };
  let shCounts = { total: 0, bin: 0, tools: 0 };
  let jsonCounts = { total: 0, config: 0, root: 0 };
  let mdCounts = { total: 0, docs: 0, root: 0 };
  
  function countInDir(dir) {
    try {
      const items = fs.readdirSync(dir);
      
      for (const item of items) {
        const itemPath = path.join(dir, item);
        const stat = fs.statSync(itemPath);
        
        if (stat.isDirectory()) {
          countInDir(itemPath);
        } else if (stat.isFile()) {
          const ext = path.extname(item).toLowerCase();
          const relPath = path.relative(PROJECT_ROOT, itemPath);
          
          if (ext === '.js' || ext === '.cjs' || ext === '.mjs') {
            jsCounts.total++;
            
            if (relPath.startsWith('src/core/')) {
              jsCounts.core++;
            } else if (relPath.startsWith('src/servers/')) {
              jsCounts.servers++;
            } else if (relPath.startsWith('src/utils/')) {
              jsCounts.utils++;
            } else if (relPath.startsWith('src/transforms/')) {
              jsCounts.transforms++;
            }
          } else if (ext === '.sh') {
            shCounts.total++;
            
            if (relPath.startsWith('bin/')) {
              shCounts.bin++;
            } else if (relPath.startsWith('tools/')) {
              shCounts.tools++;
            }
          } else if (ext === '.json') {
            jsonCounts.total++;
            
            if (relPath.startsWith('config/')) {
              jsonCounts.config++;
            } else if (relPath.indexOf('/') === -1) {
              jsonCounts.root++;
            }
          } else if (ext === '.md') {
            mdCounts.total++;
            
            if (relPath.startsWith('docs/')) {
              mdCounts.docs++;
            } else if (relPath.indexOf('/') === -1) {
              mdCounts.root++;
            }
          }
        }
      }
    } catch (err) {
      console.error(\`Error reading directory \${dir}: \${err.message}\`);
    }
  }
  
  countInDir(PROJECT_ROOT);
  
  console.log('JavaScript files:');
  console.log(\` - Total: \${jsCounts.total}\`);
  console.log(\` - Core: \${jsCounts.core}\`);
  console.log(\` - Servers: \${jsCounts.servers}\`);
  console.log(\` - Utils: \${jsCounts.utils}\`);
  console.log(\` - Transforms: \${jsCounts.transforms}\`);
  
  console.log('\\nShell scripts:');
  console.log(\` - Total: \${shCounts.total}\`);
  console.log(\` - Bin: \${shCounts.bin}\`);
  console.log(\` - Tools: \${shCounts.tools}\`);
  
  console.log('\\nJSON files:');
  console.log(\` - Total: \${jsonCounts.total}\`);
  console.log(\` - Config: \${jsonCounts.config}\`);
  console.log(\` - Root: \${jsonCounts.root}\`);
  
  console.log('\\nMarkdown files:');
  console.log(\` - Total: \${mdCounts.total}\`);
  console.log(\` - Docs: \${mdCounts.docs}\`);
  console.log(\` - Root: \${mdCounts.root}\`);
}

// Main function
function main() {
  console.log('Verifying CNIF Greenfield migration...');
  
  const dirsOk = checkDirectories();
  const filesOk = checkFiles();
  
  if (dirsOk && filesOk) {
    console.log('\\n✅ All required directories and files exist.');
  } else {
    console.log('\\n❌ Some required directories or files are missing!');
  }
  
  countFiles();
  
  console.log('\\nVerification complete.');
}

// Run the script
main();
EOF

# Generate migration report
MIGRATION_REPORT="${OUTPUT_DIR}/migration_report_${TIMESTAMP}.md"

cat > "${MIGRATION_REPORT}" << EOF
# CNIF Greenfield Migration Report
Generated on: $(date '+%Y-%m-%d %H:%M:%S')

## Overview
This report summarizes the migration of the CNIF codebase to the Greenfield architecture.
The migration process has created a clean, modular codebase structure organized according
to the architecture plan.

## Migration Statistics
- Files Processed: $(grep -c "Copied\|Anonymized" "${LOG_FILE}" || echo "0")
- High Priority Files: $(grep -c "high" "${MAPPING_FILE}" || echo "0")
- Medium Priority Files: $(grep -c "medium" "${MAPPING_FILE}" || echo "0")
- Low Priority Files: $(grep -c "low" "${MAPPING_FILE}" || echo "0")

## Directory Structure
The Greenfield codebase is organized as follows:

\`\`\`
${GREEN_DIR}/
├── bin/                      # Executable scripts and binaries
├── config/                   # Configuration files
├── docs/                     # Documentation
├── src/                      # Source code
│   ├── core/                 # Core functionality
│   ├── servers/              # MCP servers
│   ├── transforms/           # Data transformation
│   └── utils/                # Utilities and helpers
├── test/                     # Test files
├── tools/                    # Tools and scripts
└── types/                    # TypeScript type definitions
\`\`\`

## Next Steps
1. Review the migrated codebase for completeness
2. Fix dependencies using the \`tools/build/fix-dependencies.js\` script
3. Verify the migration using the \`tools/build/verify-migration.js\` script
4. Test the functionality of each component
5. Update documentation to reflect the new architecture

## Verification
Run the verification script to check that all necessary files have been migrated:

\`\`\`bash
cd ${GREEN_DIR}
node tools/build/verify-migration.js
\`\`\`

## Getting Started
To start the CNIF Greenfield application:

\`\`\`bash
cd ${GREEN_DIR}
npm install
./bin/start-cnif.sh
\`\`\`
EOF

log "INFO" "Migration complete. Report: ${MIGRATION_REPORT}"
echo "✅ CNIF code migration complete."
echo "Migration report is available at: ${MIGRATION_REPORT}"
echo "Greenfield codebase is available at: ${GREEN_DIR}"
