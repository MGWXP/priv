#!/bin/bash
# archive-component.sh - Implements the Systematic Archiving Protocol
# Usage: ./archive-component.sh [component_path] [category] [reason] [replacement_path]

# Set strict error handling
set -e

# ANSI color codes for output formatting
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Print banner
echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║                  ANCHOR V6 COMPONENT ARCHIVER                  ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"

# Validate arguments
if [ $# -lt 3 ]; then
    echo -e "${RED}❌ ERROR: Insufficient arguments${NC}"
    echo -e "${YELLOW}Usage: ./archive-component.sh [component_path] [category] [reason] [replacement_path]${NC}"
    echo -e "\nValid categories:"
    echo -e "  - module-system-conflicts"
    echo -e "  - socket-connectivity-issues"
    echo -e "  - schema-validation-errors"
    echo -e "  - process-management-issues"
    echo -e "  - performance-bottlenecks"
    echo -e "  - deprecated-implementations"
    echo -e "  - obsolete-configurations"
    exit 1
fi

COMPONENT_PATH=$1
CATEGORY=$2
REASON=$3
REPLACEMENT_PATH=${4:-"None"}
TIMESTAMP=$(date +"%Y%m%d%H%M%S")
COMPONENT_NAME=$(basename $COMPONENT_PATH)
ARCHIVE_DIR="/Users/XPV/Desktop/anchor-core/archive/$CATEGORY"
BACKUP_DIR="/Users/XPV/Desktop/anchor-core/backups/$TIMESTAMP"

# Validate the component path exists
if [ ! -f "$COMPONENT_PATH" ]; then
    echo -e "${RED}❌ ERROR: Component file does not exist: $COMPONENT_PATH${NC}"
    exit 1
fi

# Validate category
VALID_CATEGORIES=("module-system-conflicts" "socket-connectivity-issues" "schema-validation-errors" "process-management-issues" "performance-bottlenecks" "deprecated-implementations" "obsolete-configurations")
if [[ ! " ${VALID_CATEGORIES[@]} " =~ " ${CATEGORY} " ]]; then
    echo -e "${RED}❌ ERROR: Invalid category: $CATEGORY${NC}"
    echo -e "${YELLOW}Valid categories: ${VALID_CATEGORIES[*]}${NC}"
    exit 1
fi

echo -e "${CYAN}📋 Processing component: ${MAGENTA}$COMPONENT_NAME${NC}"
echo -e "${CYAN}📂 Category: ${MAGENTA}$CATEGORY${NC}"

# Create archive directory if it doesn't exist
if [ ! -d "$ARCHIVE_DIR" ]; then
    echo -e "${YELLOW}Creating archive directory: $ARCHIVE_DIR${NC}"
    mkdir -p $ARCHIVE_DIR
fi

# Create backup directory
echo -e "${CYAN}📦 Creating backup in: ${MAGENTA}$BACKUP_DIR${NC}"
mkdir -p $BACKUP_DIR
cp $COMPONENT_PATH $BACKUP_DIR/

# Find dependencies on this component
echo -e "${CYAN}🔍 Identifying component dependencies...${NC}"
DEPENDENTS=$(grep -r --include="*.js" --include="*.cjs" --include="*.mjs" "require.*$(basename $COMPONENT_PATH .js)\\|import.*$(basename $COMPONENT_PATH .js)" /Users/XPV/Desktop/anchor-core/ | wc -l)
echo -e "${CYAN}   Found ${MAGENTA}$DEPENDENTS${CYAN} references to this component${NC}"

# Extract component dependencies
echo -e "${CYAN}🔍 Extracting component external dependencies...${NC}"
grep -E "require\\|import" $COMPONENT_PATH > $BACKUP_DIR/$(basename $COMPONENT_PATH).dependencies.txt || echo "No dependencies found" > $BACKUP_DIR/$(basename $COMPONENT_PATH).dependencies.txt

# Count failures in logs
echo -e "${CYAN}📊 Analyzing failure patterns...${NC}"
FAILURE_COUNT=$(grep -r "$(basename $COMPONENT_PATH)" /Users/XPV/Desktop/anchor-core/logs/ | grep -i "error\|exception\|fail" | wc -l)
echo -e "${CYAN}   Found ${MAGENTA}$FAILURE_COUNT${CYAN} error references in logs${NC}"

# Archive the component
echo -e "${CYAN}📥 Archiving component...${NC}"
cp $COMPONENT_PATH $ARCHIVE_DIR/$COMPONENT_NAME.$TIMESTAMP

# Create metadata file
echo -e "${CYAN}📝 Creating metadata...${NC}"
cat > $ARCHIVE_DIR/$COMPONENT_NAME.$TIMESTAMP.meta <<EOF
ARCHIVE_DATE: $(date +"%Y-%m-%d %H:%M:%S")
COMPONENT_NAME: $COMPONENT_NAME
ORIGINAL_PATH: $COMPONENT_PATH
FAILURE_TYPE: $CATEGORY
FAILURE_COUNT: $FAILURE_COUNT
DEPENDENTS_COUNT: $DEPENDENTS
REPLACEMENT: $REPLACEMENT_PATH
REASON: $REASON
ARCHIVED_BY: MCP Archiving Protocol v1.0.0
EOF

# Create README if it doesn't exist
if [ ! -f "$ARCHIVE_DIR/README.md" ]; then
    echo -e "${CYAN}📄 Creating category README...${NC}"
    cat > $ARCHIVE_DIR/README.md <<EOF
# $CATEGORY Archive

This directory contains components archived due to $CATEGORY issues.

## Archived Components

| Component | Archived Date | Reason | Replacement |
|-----------|---------------|--------|-------------|
EOF
fi

# Update category README
echo -e "${CYAN}📄 Updating category README...${NC}"
FORMATTED_DATE=$(date +"%Y-%m-%d %H:%M")
echo "| $COMPONENT_NAME | $FORMATTED_DATE | $REASON | $REPLACEMENT_PATH |" >> $ARCHIVE_DIR/README.md

# Document in main archive report
echo -e "${CYAN}📄 Updating main archive report...${NC}"
cat >> /Users/XPV/Desktop/anchor-core/ARCHIVE_REPORT.md <<EOF

### $(date +"%Y-%m-%d") - $COMPONENT_NAME

- **Category**: $CATEGORY
- **Location**: \`/archive/$CATEGORY/$COMPONENT_NAME.$TIMESTAMP\`
- **Replacement**: \`$REPLACEMENT_PATH\`
- **Reason**: $REASON
- **Dependents**: $DEPENDENTS components
- **Failure Count**: $FAILURE_COUNT occurrences in logs
EOF

# Create coherence marker
echo -e "${CYAN}🔄 Creating coherence marker...${NC}"
COHERENCE_MARKER="/Users/XPV/Desktop/anchor-core/coherence_lock/ARCHIVED_$(basename $COMPONENT_PATH)_$(date +"%Y-%m-%dT%H%M%S%3N%z").marker"
touch $COHERENCE_MARKER

# Success message
echo -e "\n${GREEN}✅ Component $COMPONENT_NAME archived successfully in category $CATEGORY${NC}"
echo -e "${GREEN}📁 Archive location: $ARCHIVE_DIR/$COMPONENT_NAME.$TIMESTAMP${NC}"
echo -e "${GREEN}📊 Archive metadata created${NC}"
echo -e "${GREEN}📝 ARCHIVE_REPORT.md updated${NC}"

# Suggest next steps if replacement path is provided
if [ "$REPLACEMENT_PATH" != "None" ]; then
    echo -e "\n${YELLOW}⚠️ Next steps:${NC}"
    echo -e "1. ${CYAN}Update all imports/requires to point to $REPLACEMENT_PATH${NC}"
    echo -e "2. ${CYAN}Verify system integrity with verify-servers.sh${NC}"
    echo -e "3. ${CYAN}Run system tests to ensure functionality${NC}"
fi

exit 0
