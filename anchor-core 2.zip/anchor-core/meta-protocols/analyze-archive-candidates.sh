#!/bin/bash
# analyze-archive-candidates.sh - Identify components that may need archiving
# Usage: ./analyze-archive-candidates.sh [days_to_analyze] [min_error_threshold]

# Set strict error handling
set -e

# ANSI color codes for output formatting
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Print banner
echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║               ANCHOR V6 ARCHIVE CANDIDATE ANALYZER             ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"

# Default parameters
DAYS_TO_ANALYZE=${1:-7}  # Default to 7 days
ERROR_THRESHOLD=${2:-3}  # Default to 3 errors

# Timestamp for output files
TIMESTAMP=$(date +"%Y%m%d%H%M%S")
OUTPUT_DIR="/Users/XPV/Desktop/anchor-core/analysis"
OUTPUT_FILE="$OUTPUT_DIR/archive-candidates-$TIMESTAMP.csv"
DETAIL_FILE="$OUTPUT_DIR/archive-candidates-detail-$TIMESTAMP.md"

# Create output directory
mkdir -p $OUTPUT_DIR

echo -e "${CYAN}📊 Analyzing components over past $DAYS_TO_ANALYZE days with error threshold of $ERROR_THRESHOLD...${NC}"

# Get date for filtering
FILTER_DATE=$(date -v-${DAYS_TO_ANALYZE}d +%Y-%m-%d)

# Initialize output files
echo "component_path,category,error_count,suggested_action" > $OUTPUT_FILE
echo "# Archive Candidate Analysis Report" > $DETAIL_FILE
echo "" >> $DETAIL_FILE
echo "Generated on: $(date)" >> $DETAIL_FILE
echo "Analysis period: $DAYS_TO_ANALYZE days (since $FILTER_DATE)" >> $DETAIL_FILE
echo "Minimum error threshold: $ERROR_THRESHOLD errors" >> $DETAIL_FILE
echo "" >> $DETAIL_FILE

# Analyze log files for errors
echo -e "${CYAN}🔍 Scanning log files for error patterns...${NC}"
echo "## Error Frequency Analysis" >> $DETAIL_FILE
echo "" >> $DETAIL_FILE
echo "| Component | Error Count | Sample Errors |" >> $DETAIL_FILE
echo "|-----------|-------------|---------------|" >> $DETAIL_FILE

# Get all JS/CJS files in mcp-servers
find /Users/XPV/Desktop/anchor-core/mcp-servers -type f \( -name "*.js" -o -name "*.cjs" \) | while read COMPONENT_PATH; do
    COMPONENT_NAME=$(basename $COMPONENT_PATH)
    
    # Count errors in logs related to this component
    ERROR_COUNT=$(grep -r --include="*.log" --include="*.out" "$COMPONENT_NAME" /Users/XPV/Desktop/anchor-core/logs/ | grep -i "error\|exception\|fail" | wc -l)
    
    if [ $ERROR_COUNT -ge $ERROR_THRESHOLD ]; then
        echo -e "${YELLOW}⚠️ Found candidate: $COMPONENT_NAME with $ERROR_COUNT errors${NC}"
        
        # Determine appropriate category based on error patterns
        CATEGORY="deprecated-implementations" # Default
        
        if grep -q "Cannot find module\|import.*from\|require" /Users/XPV/Desktop/anchor-core/logs/* | grep -q "$COMPONENT_NAME"; then
            CATEGORY="module-system-conflicts"
        elif grep -q "ECONNREFUSED\|socket\|connection" /Users/XPV/Desktop/anchor-core/logs/* | grep -q "$COMPONENT_NAME"; then
            CATEGORY="socket-connectivity-issues"
        elif grep -q "schema\|validation\|invalid" /Users/XPV/Desktop/anchor-core/logs/* | grep -q "$COMPONENT_NAME"; then
            CATEGORY="schema-validation-errors"
        elif grep -q "pid\|process.*killed\|SIGTERM" /Users/XPV/Desktop/anchor-core/logs/* | grep -q "$COMPONENT_NAME"; then
            CATEGORY="process-management-issues"
        elif grep -q "memory\|leak\|CPU\|timeout\|performance" /Users/XPV/Desktop/anchor-core/logs/* | grep -q "$COMPONENT_NAME"; then
            CATEGORY="performance-bottlenecks"
        fi
        
        # Get sample errors (first 3)
        SAMPLE_ERRORS=$(grep -r --include="*.log" --include="*.out" "$COMPONENT_NAME" /Users/XPV/Desktop/anchor-core/logs/ | grep -i "error\|exception\|fail" | head -3 | sed 's/^.*://' | tr '\n' '|' | sed 's/|/<br>/g')
        
        # Add to CSV
        echo "$COMPONENT_PATH,$CATEGORY,$ERROR_COUNT,Candidate for archiving" >> $OUTPUT_FILE
        
        # Add to detail report
        echo "| $COMPONENT_NAME | $ERROR_COUNT | $SAMPLE_ERRORS |" >> $DETAIL_FILE
        
        # Check for alternatives/replacements
        if [[ "$COMPONENT_NAME" == *.js ]] && [ -f "${COMPONENT_PATH%.*}.cjs" ]; then
            echo -e "${GREEN}✅ Found potential replacement: ${COMPONENT_PATH%.*}.cjs${NC}"
            # Append replacement info to CSV
            sed -i '' "s|$COMPONENT_PATH,$CATEGORY,$ERROR_COUNT,Candidate for archiving|$COMPONENT_PATH,$CATEGORY,$ERROR_COUNT,Replace with ${COMPONENT_PATH%.*}.cjs|" $OUTPUT_FILE
        fi
    fi
done

# Add coherence marker analysis
echo -e "${CYAN}🔄 Analyzing coherence markers...${NC}"
echo "" >> $DETAIL_FILE
echo "## Coherence Lock Analysis" >> $DETAIL_FILE
echo "" >> $DETAIL_FILE
echo "| Component | Marker Count | Last Marker Time |" >> $DETAIL_FILE
echo "|-----------|--------------|------------------|" >> $DETAIL_FILE

find /Users/XPV/Desktop/anchor-core/coherence_lock -type f -name "*.marker" | sort | while read MARKER_PATH; do
    MARKER_NAME=$(basename $MARKER_PATH)
    COMPONENT_NAME=$(echo $MARKER_NAME | cut -d'_' -f1)
    
    # Count markers for this component
    MARKER_COUNT=$(find /Users/XPV/Desktop/anchor-core/coherence_lock -name "${COMPONENT_NAME}_*.marker" | wc -l)
    
    # Get last marker time
    LAST_MARKER=$(find /Users/XPV/Desktop/anchor-core/coherence_lock -name "${COMPONENT_NAME}_*.marker" | sort | tail -1)
    LAST_MARKER_TIME=$(echo $(basename $LAST_MARKER) | grep -o '[0-9]\{4\}-[0-9]\{2\}-[0-9]\{2\}T[0-9]\{6\}' || echo "Unknown")
    
    # Only add unique entries
    if ! grep -q "| $COMPONENT_NAME |" $DETAIL_FILE; then
        echo "| $COMPONENT_NAME | $MARKER_COUNT | $LAST_MARKER_TIME |" >> $DETAIL_FILE
    fi
done

# Generate recommendations
echo -e "${CYAN}📋 Generating recommendations...${NC}"
echo "" >> $DETAIL_FILE
echo "## Recommendations" >> $DETAIL_FILE
echo "" >> $DETAIL_FILE

# Count total candidates
CANDIDATE_COUNT=$(cat $OUTPUT_FILE | wc -l)
CANDIDATE_COUNT=$((CANDIDATE_COUNT - 1))  # Subtract header line

echo -e "${GREEN}✅ Analysis complete! Found $CANDIDATE_COUNT archiving candidates${NC}"
echo -e "${CYAN}📝 Results saved to:${NC}"
echo -e "   ${MAGENTA}$OUTPUT_FILE${NC}"
echo -e "   ${MAGENTA}$DETAIL_FILE${NC}"

# Add recommendations
if [ $CANDIDATE_COUNT -gt 0 ]; then
    echo "Found $CANDIDATE_COUNT components that may need archiving based on error frequency and coherence marker analysis." >> $DETAIL_FILE
    echo "" >> $DETAIL_FILE
    echo "To archive these components, use the following command:" >> $DETAIL_FILE
    echo "" >> $DETAIL_FILE
    echo "```bash" >> $DETAIL_FILE
    echo "./meta-protocols/bulk-archive-components.sh $OUTPUT_FILE" >> $DETAIL_FILE
    echo "```" >> $DETAIL_FILE
    
    echo -e "\n${YELLOW}⚠️ To archive all identified candidates, run:${NC}"
    echo -e "${CYAN}./meta-protocols/bulk-archive-components.sh $OUTPUT_FILE${NC}"
else
    echo "No archiving candidates found that meet the criteria of $ERROR_THRESHOLD errors in the last $DAYS_TO_ANALYZE days." >> $DETAIL_FILE
fi

# Create coherence marker for analysis operation
COHERENCE_MARKER="/Users/XPV/Desktop/anchor-core/coherence_lock/ARCHIVE_ANALYSIS_$(date +"%Y-%m-%dT%H%M%S%3N%z").marker"
touch $COHERENCE_MARKER

exit 0
