#!/bin/bash
# CNIF-Classifier: Code Classification Meta-Protocol
# © 2025 XPV - MIT License
#
# This script classifies code files into functional categories:
# - Core server components
# - Utilities and helpers
# - Configuration management
# - Launch scripts
# - Testing scripts
# - Documentation

# Configuration
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
ANALYSIS_DIR="${ANCHOR_HOME}/_analysis"
CLASSIFICATION_DIR="${ANALYSIS_DIR}/classification"
OUTPUT_DIR="${CLASSIFICATION_DIR}/categories"
LOG_DIR="${ANALYSIS_DIR}/logs"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")

# Ensure directories exist
mkdir -p "${OUTPUT_DIR}"
mkdir -p "${LOG_DIR}"

# Log function
log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] [${1}] ${2}" | tee -a "${LOG_DIR}/classifier_${TIMESTAMP}.log"
}

log "INFO" "Starting CNIF code classification"

# Check if analysis reports exist
LATEST_REPORT_DIR=$(ls -td "${ANALYSIS_DIR}/reports/"* 2>/dev/null | head -n 1)

if [ -z "${LATEST_REPORT_DIR}" ]; then
  log "ERROR" "No analysis reports found. Please run analyze-codebase.sh first."
  echo "❌ Error: No analysis reports found. Please run analyze-codebase.sh first."
  exit 1
fi

# Find latest analysis files
JS_FILES_LIST=$(find "${ANALYSIS_DIR}/reports" -name "js_files_*.txt" | sort -r | head -n 1)
SH_FILES_LIST=$(find "${ANALYSIS_DIR}/reports" -name "sh_files_*.txt" | sort -r | head -n 1)
JSON_FILES_LIST=$(find "${ANALYSIS_DIR}/reports" -name "json_files_*.txt" | sort -r | head -n 1)
CORE_MODULES=$(find "${ANALYSIS_DIR}/reports" -name "core_modules_*.txt" | sort -r | head -n 1)

if [ -z "${JS_FILES_LIST}" ] || [ -z "${SH_FILES_LIST}" ] || [ -z "${JSON_FILES_LIST}" ]; then
  log "ERROR" "Required analysis files not found."
  echo "❌ Error: Required analysis files not found."
  exit 1
fi

log "INFO" "Using analysis reports:"
log "INFO" "JavaScript files: ${JS_FILES_LIST}"
log "INFO" "Shell scripts: ${SH_FILES_LIST}"
log "INFO" "JSON files: ${JSON_FILES_LIST}"
log "INFO" "Core modules: ${CORE_MODULES}"

# Initialize category files
CORE_SERVERS="${OUTPUT_DIR}/core_servers_${TIMESTAMP}.txt"
UTILITIES="${OUTPUT_DIR}/utilities_${TIMESTAMP}.txt"
CONFIG_MGMT="${OUTPUT_DIR}/config_management_${TIMESTAMP}.txt"
LAUNCHERS="${OUTPUT_DIR}/launchers_${TIMESTAMP}.txt"
TESTING="${OUTPUT_DIR}/testing_${TIMESTAMP}.txt"
DOCUMENTATION="${OUTPUT_DIR}/documentation_${TIMESTAMP}.txt"
UNKNOWN="${OUTPUT_DIR}/uncategorized_${TIMESTAMP}.txt"

# Initialize files
> "${CORE_SERVERS}"
> "${UTILITIES}"
> "${CONFIG_MGMT}"
> "${LAUNCHERS}"
> "${TESTING}"
> "${DOCUMENTATION}"
> "${UNKNOWN}"

# 1. Classify JavaScript files
log "INFO" "Classifying JavaScript files..."

while IFS= read -r file; do
  # Skip node_modules
  if [[ "${file}" == *"node_modules"* ]]; then
    continue
  fi
  
  filename=$(basename "${file}")
  content=$(cat "${file}" 2>/dev/null || echo "")
  
  # Core Server Components
  if [[ "${filename}" == *"server"* || "${filename}" == *"socket"* || 
        "${filename}" == *"mcp"* || "${content}" == *"createServer"* ||
        "${filename}" == *"schema-registry"* || "${filename}" == *"transformer"* ||
        "${filename}" == *"orchestrator"* ]]; then
    echo "${file}" >> "${CORE_SERVERS}"
    continue
  fi
  
  # Utilities
  if [[ "${filename}" == *"util"* || "${filename}" == *"helper"* || 
        "${content}" == *"function"*"("* || "${filename}" == *"circuit-breaker"* ||
        "${filename}" == *"validator"* || "${filename}" == *"parser"* ]]; then
    echo "${file}" >> "${UTILITIES}"
    continue
  fi
  
  # Configuration Management
  if [[ "${filename}" == *"config"* || "${filename}" == *"setup"* || 
        "${content}" == *"NODE_OPTIONS"* || "${content}" == *"UV_THREADPOOL_SIZE"* ]]; then
    echo "${file}" >> "${CONFIG_MGMT}"
    continue
  fi
  
  # Testing
  if [[ "${filename}" == *"test"* || "${filename}" == *"spec"* || 
        "${filename}" == *"mock"* || "${content}" == *"describe("* ||
        "${content}" == *"test("* || "${content}" == *"assert("* ]]; then
    echo "${file}" >> "${TESTING}"
    continue
  fi
  
  # If nothing matched, it's unknown
  echo "${file}" >> "${UNKNOWN}"
  
done < "${JS_FILES_LIST}"

# 2. Classify Shell Scripts
log "INFO" "Classifying shell scripts..."

while IFS= read -r file; do
  filename=$(basename "${file}")
  content=$(cat "${file}" 2>/dev/null || echo "")
  
  # Launchers
  if [[ "${filename}" == *"launch"* || "${filename}" == *"start"* || 
        "${filename}" == *"run"* || "${content}" == *"exec "* ]]; then
    echo "${file}" >> "${LAUNCHERS}"
    continue
  fi
  
  # Configuration Management
  if [[ "${filename}" == *"config"* || "${filename}" == *"setup"* || 
        "${filename}" == *"install"* || "${filename}" == *"make"* ]]; then
    echo "${file}" >> "${CONFIG_MGMT}"
    continue
  fi
  
  # Testing
  if [[ "${filename}" == *"test"* || "${filename}" == *"verify"* || 
        "${filename}" == *"check"* || "${filename}" == *"monitor"* ]]; then
    echo "${file}" >> "${TESTING}"
    continue
  fi
  
  # If nothing matched, it's unknown
  echo "${file}" >> "${UNKNOWN}"
  
done < "${SH_FILES_LIST}"

# 3. Classify JSON files
log "INFO" "Classifying JSON files..."

while IFS= read -r file; do
  filename=$(basename "${file}")
  
  # Configuration Files
  if [[ "${filename}" == *"config"* || "${filename}" == *"package.json"* || 
        "${filename}" == *"tsconfig.json"* ]]; then
    echo "${file}" >> "${CONFIG_MGMT}"
    continue
  fi
  
  # Documentation (if it's a schema file)
  if [[ "${filename}" == *"schema"* || "${file}" == *"/schemas/"* ]]; then
    echo "${file}" >> "${DOCUMENTATION}"
    continue
  fi
  
  # If nothing matched, it's unknown
  echo "${file}" >> "${UNKNOWN}"
  
done < "${JSON_FILES_LIST}"

# 4. Classify Markdown files (documentation)
log "INFO" "Classifying markdown documentation..."
MD_FILES=$(find "${ANCHOR_HOME}" -type f -name "*.md" | grep -v "node_modules")

for file in ${MD_FILES}; do
  echo "${file}" >> "${DOCUMENTATION}"
done

# 5. Generate Classification Report
CLASSIFICATION_REPORT="${OUTPUT_DIR}/classification_summary_${TIMESTAMP}.md"

CORE_SERVERS_COUNT=$(wc -l < "${CORE_SERVERS}")
UTILITIES_COUNT=$(wc -l < "${UTILITIES}")
CONFIG_MGMT_COUNT=$(wc -l < "${CONFIG_MGMT}")
LAUNCHERS_COUNT=$(wc -l < "${LAUNCHERS}")
TESTING_COUNT=$(wc -l < "${TESTING}")
DOCUMENTATION_COUNT=$(wc -l < "${DOCUMENTATION}")
UNKNOWN_COUNT=$(wc -l < "${UNKNOWN}")

cat > "${CLASSIFICATION_REPORT}" << EOF
# CNIF Code Classification Summary
Classification Date: $(date '+%Y-%m-%d %H:%M:%S')

## Category Statistics
- Core Server Components: ${CORE_SERVERS_COUNT}
- Utilities and Helpers: ${UTILITIES_COUNT}
- Configuration Management: ${CONFIG_MGMT_COUNT}
- Launchers and Start Scripts: ${LAUNCHERS_COUNT}
- Testing and Verification: ${TESTING_COUNT}
- Documentation and Schemas: ${DOCUMENTATION_COUNT}
- Uncategorized Files: ${UNKNOWN_COUNT}

## Classification Files
- Core Server Components: \`${CORE_SERVERS}\`
- Utilities and Helpers: \`${UTILITIES}\`
- Configuration Management: \`${CONFIG_MGMT}\`
- Launchers and Start Scripts: \`${LAUNCHERS}\`
- Testing and Verification: \`${TESTING}\`
- Documentation and Schemas: \`${DOCUMENTATION}\`
- Uncategorized Files: \`${UNKNOWN}\`

## Next Steps
1. Review core server components to identify essential MCP servers
2. Analyze utilities to identify reusable helper functions
3. Consolidate configuration management approach
4. Simplify launcher scripts to reduce redundancy
5. Verify test coverage for core components
EOF

log "INFO" "Classification complete. Report: ${CLASSIFICATION_REPORT}"
echo "✅ CNIF code classification complete. Report is available at: ${CLASSIFICATION_REPORT}"
