#!/bin/bash
# CNIF-Analyzer: Code Analysis Meta-Protocol
# © 2025 XPV - MIT License
#
# This script analyzes the current CNIF codebase to identify:
# - Core functional components
# - Redundant scripts
# - Dependency relationships
# - Code quality metrics

# Configuration
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
ANALYSIS_DIR="${ANCHOR_HOME}/_analysis"
OUTPUT_DIR="${ANALYSIS_DIR}/reports"
LOG_DIR="${ANALYSIS_DIR}/logs"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")

# Create directories
mkdir -p "${OUTPUT_DIR}"
mkdir -p "${LOG_DIR}"

# Log function
log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] [${1}] ${2}" | tee -a "${LOG_DIR}/analyzer_${TIMESTAMP}.log"
}

log "INFO" "Starting CNIF code analysis"
log "INFO" "Anchor home: ${ANCHOR_HOME}"
log "INFO" "Analysis directory: ${ANALYSIS_DIR}"

# 1. Identify all JavaScript/Node.js files
log "INFO" "Scanning for JavaScript files..."
JS_FILES_LIST="${OUTPUT_DIR}/js_files_${TIMESTAMP}.txt"
find "${ANCHOR_HOME}" -type f -name "*.js" -o -name "*.cjs" -o -name "*.mjs" | sort > "${JS_FILES_LIST}"
JS_FILES_COUNT=$(wc -l < "${JS_FILES_LIST}")
log "INFO" "Found ${JS_FILES_COUNT} JavaScript files"

# 2. Identify all shell scripts
log "INFO" "Scanning for shell scripts..."
SH_FILES_LIST="${OUTPUT_DIR}/sh_files_${TIMESTAMP}.txt"
find "${ANCHOR_HOME}" -type f -name "*.sh" | sort > "${SH_FILES_LIST}"
SH_FILES_COUNT=$(wc -l < "${SH_FILES_LIST}")
log "INFO" "Found ${SH_FILES_COUNT} shell scripts"

# 3. Identify JSON config files
log "INFO" "Scanning for JSON configuration files..."
JSON_FILES_LIST="${OUTPUT_DIR}/json_files_${TIMESTAMP}.txt"
find "${ANCHOR_HOME}" -type f -name "*.json" | sort > "${JSON_FILES_LIST}"
JSON_FILES_COUNT=$(wc -l < "${JSON_FILES_LIST}")
log "INFO" "Found ${JSON_FILES_COUNT} JSON files"

# 4. Create a dependency graph for JavaScript files
log "INFO" "Analyzing JavaScript dependencies..."
DEPENDENCY_GRAPH="${OUTPUT_DIR}/dependency_graph_${TIMESTAMP}.csv"
echo "file,imports,requires" > "${DEPENDENCY_GRAPH}"

while IFS= read -r file; do
  imports=$(grep -E "import .+ from" "${file}" | wc -l)
  requires=$(grep -E "require\(['\"]" "${file}" | wc -l)
  echo "\"${file}\",${imports},${requires}" >> "${DEPENDENCY_GRAPH}"
done < "${JS_FILES_LIST}"

# 5. Identify duplicate and similar files
log "INFO" "Identifying duplicate files..."
DUPLICATES_REPORT="${OUTPUT_DIR}/duplicate_files_${TIMESTAMP}.txt"
SIMILARITY_REPORT="${OUTPUT_DIR}/similar_files_${TIMESTAMP}.csv"

# Find exact duplicates using md5sum
find "${ANCHOR_HOME}" -type f -name "*.js" -o -name "*.cjs" -o -name "*.mjs" -o -name "*.sh" -o -name "*.json" | xargs md5sum 2>/dev/null | sort | uniq -w32 -d --all-repeated=separate > "${DUPLICATES_REPORT}"

log "INFO" "Calculating file similarities..."
echo "file1,file2,similarity_percentage" > "${SIMILARITY_REPORT}"

# 6. Identify dead code (files not referenced anywhere)
log "INFO" "Identifying potentially unused files..."
UNUSED_FILES="${OUTPUT_DIR}/unused_files_${TIMESTAMP}.txt"

# Generate list of all files
TEMP_ALL_FILES=$(mktemp)
find "${ANCHOR_HOME}" -type f -name "*.js" -o -name "*.cjs" -o -name "*.mjs" -o -name "*.sh" -o -name "*.json" > "${TEMP_ALL_FILES}"

# Generate list of references
TEMP_REFS=$(mktemp)
while IFS= read -r file; do
  filename=$(basename "${file}")
  # Skip files in node_modules and hidden directories
  if [[ "${file}" != *"node_modules"* && "${file}" != "*/.*/*" ]]; then
    # Find references to this file in other files
    find "${ANCHOR_HOME}" -type f -name "*.js" -o -name "*.cjs" -o -name "*.mjs" -o -name "*.sh" -o -name "*.json" -exec grep -l "${filename}" {} \; 2>/dev/null >> "${TEMP_REFS}"
  fi
done < "${TEMP_ALL_FILES}"

# Find files that don't appear in the references list
sort "${TEMP_ALL_FILES}" | uniq > "${TEMP_ALL_FILES}.sorted"
sort "${TEMP_REFS}" | uniq > "${TEMP_REFS}.sorted"
comm -23 "${TEMP_ALL_FILES}.sorted" "${TEMP_REFS}.sorted" > "${UNUSED_FILES}"

# Clean up temp files
rm "${TEMP_ALL_FILES}" "${TEMP_REFS}" "${TEMP_ALL_FILES}.sorted" "${TEMP_REFS}.sorted"

# 7. Analyze core functionality modules (most heavily referenced files)
log "INFO" "Identifying core functionality modules..."
CORE_MODULES="${OUTPUT_DIR}/core_modules_${TIMESTAMP}.txt"

# Count references to each file
TEMP_REF_COUNT=$(mktemp)
while IFS= read -r file; do
  filename=$(basename "${file}")
  references=$(find "${ANCHOR_HOME}" -type f -name "*.js" -o -name "*.cjs" -o -name "*.mjs" -o -name "*.sh" -exec grep -l "${filename}" {} \; 2>/dev/null | wc -l)
  echo "${references} ${file}" >> "${TEMP_REF_COUNT}"
done < "${TEMP_ALL_FILES}"

# Sort by reference count and get top 50
sort -nr "${TEMP_REF_COUNT}" | head -n 50 > "${CORE_MODULES}"
rm "${TEMP_REF_COUNT}"

# 8. Generate summary report
SUMMARY_REPORT="${OUTPUT_DIR}/analysis_summary_${TIMESTAMP}.md"

cat > "${SUMMARY_REPORT}" << EOF
# CNIF Codebase Analysis Summary
Analysis Date: $(date '+%Y-%m-%d %H:%M:%S')

## File Statistics
- JavaScript Files: ${JS_FILES_COUNT}
- Shell Scripts: ${SH_FILES_COUNT}
- JSON Configuration Files: ${JSON_FILES_COUNT}
- Total Files Analyzed: $((JS_FILES_COUNT + SH_FILES_COUNT + JSON_FILES_COUNT))

## Key Findings
- Exact Duplicate Files: $(grep -c "" "${DUPLICATES_REPORT}" || echo "0")
- Potentially Unused Files: $(grep -c "" "${UNUSED_FILES}" || echo "0")
- Core Modules Identified: $(grep -c "" "${CORE_MODULES}" || echo "0")

## Analysis Files
- JavaScript Files: \`${JS_FILES_LIST}\`
- Shell Scripts: \`${SH_FILES_LIST}\`
- JSON Configuration Files: \`${JSON_FILES_LIST}\`
- Dependency Graph: \`${DEPENDENCY_GRAPH}\`
- Duplicate Files Report: \`${DUPLICATES_REPORT}\`
- Similarity Report: \`${SIMILARITY_REPORT}\`
- Unused Files: \`${UNUSED_FILES}\`
- Core Modules: \`${CORE_MODULES}\`

## Next Steps
1. Review the core modules to understand the essential functionality
2. Examine duplicate files to eliminate redundancy
3. Verify unused files before removal
4. Create component groups based on the dependency graph
EOF

log "INFO" "Analysis complete. Summary report: ${SUMMARY_REPORT}"
echo "✅ CNIF code analysis complete. Summary report is available at: ${SUMMARY_REPORT}"
