#!/bin/bash
# component-migration-manager.sh - Manages the migration of archived components
# This script handles the coordinated replacement of multiple components

# Set strict error handling
set -e

# ANSI color codes for output formatting
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Make this script executable
chmod +x $0

# Print banner
echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║            ANCHOR V6 COMPONENT MIGRATION MANAGER               ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"

# Define paths
ARCHIVE_DIR="/Users/XPV/Desktop/anchor-core/archive"
COHERENCE_DIR="/Users/XPV/Desktop/anchor-core/coherence_lock"
BACKUP_DIR="/Users/XPV/Desktop/anchor-core/backups"
REPORT_DIR="/Users/XPV/Desktop/anchor-core/analysis"

# Default values
MIGRATION_FILE=""
DRY_RUN=false
VERIFY_AFTER=true

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    key="$1"
    
    case $key in
        -f|--file)
            MIGRATION_FILE="$2"
            shift
            shift
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --no-verify)
            VERIFY_AFTER=false
            shift
            ;;
        -h|--help)
            echo "Usage: $0 [options]"
            echo ""
            echo "Options:"
            echo "  -f, --file FILE       Migration definition file (CSV format)"
            echo "  --dry-run             Show what would be done without making changes"
            echo "  --no-verify           Skip verification after migration"
            echo "  -h, --help            Show this help message"
            echo ""
            echo "Migration file format (CSV):"
            echo "original_component,replacement_component,reason"
            exit 0
            ;;
        *)
            echo -e "${RED}Unknown option: $key${NC}"
            exit 1
            ;;
    esac
done

# Generate timestamp
TIMESTAMP=$(date +"%Y%m%d%H%M%S")
LOG_FILE="$REPORT_DIR/migration-$TIMESTAMP.log"
REPORT_FILE="$REPORT_DIR/migration-report-$TIMESTAMP.md"

# Create report directory if it doesn't exist
mkdir -p "$REPORT_DIR"

# Validate migration file
if [ -z "$MIGRATION_FILE" ]; then
    echo -e "${RED}❌ ERROR: Migration file is required${NC}"
    echo -e "${YELLOW}Use -f or --file to specify the migration file${NC}"
    exit 1
fi

if [ ! -f "$MIGRATION_FILE" ]; then
    echo -e "${RED}❌ ERROR: Migration file does not exist: $MIGRATION_FILE${NC}"
    exit 1
fi

# Read migration file header to validate format
HEADER=$(head -n 1 "$MIGRATION_FILE")
if [[ "$HEADER" != "original_component,replacement_component,reason" ]]; then
    echo -e "${RED}❌ ERROR: Invalid migration file format${NC}"
    echo -e "${YELLOW}Expected header: original_component,replacement_component,reason${NC}"
    exit 1
fi

# Initialize log file
echo "ANCHOR V6 COMPONENT MIGRATION LOG" > "$LOG_FILE"
echo "Date: $(date)" >> "$LOG_FILE"
echo "Migration File: $MIGRATION_FILE" >> "$LOG_FILE"
echo "Dry Run: $DRY_RUN" >> "$LOG_FILE"
echo "--------------------------------------------------------" >> "$LOG_FILE"

# Initialize report file
cat > "$REPORT_FILE" <<EOF
# Anchor V6 Component Migration Report

**Generated on:** $(date)
**Migration File:** \`$MIGRATION_FILE\`
**Dry Run:** $DRY_RUN

## Migration Overview

This report documents the migration of components according to the migration plan.

## Components Migrated

| Original Component | Replacement Component | Status | References Updated |
|-------------------|----------------------|--------|-------------------|
EOF

# Create backup directory for this migration
MIGRATION_BACKUP_DIR="$BACKUP_DIR/migration-$TIMESTAMP"
mkdir -p "$MIGRATION_BACKUP_DIR"
echo -e "${CYAN}📦 Created backup directory:${NC} $MIGRATION_BACKUP_DIR"

# Process each migration entry
echo -e "${CYAN}Processing migration entries...${NC}"
LINE_NUM=0
TOTAL_COMPONENTS=0
SUCCESSFUL_MIGRATIONS=0
FAILED_MIGRATIONS=0
TOTAL_REFERENCES=0

# Skip header
tail -n +2 "$MIGRATION_FILE" | while IFS=, read -r ORIGINAL REPLACEMENT REASON; do
    LINE_NUM=$((LINE_NUM + 1))
    TOTAL_COMPONENTS=$((TOTAL_COMPONENTS + 1))
    
    # Skip empty lines
    if [ -z "$ORIGINAL" ]; then
        continue
    fi
    
    echo -e "\n${MAGENTA}[$LINE_NUM] Processing:${NC}"
    echo -e "  ${CYAN}Original:${NC} $ORIGINAL"
    echo -e "  ${CYAN}Replacement:${NC} $REPLACEMENT"
    echo -e "  ${CYAN}Reason:${NC} $REASON"
    
    # Log to file
    echo "[$LINE_NUM] Original: $ORIGINAL" >> "$LOG_FILE"
    echo "[$LINE_NUM] Replacement: $REPLACEMENT" >> "$LOG_FILE"
    echo "[$LINE_NUM] Reason: $REASON" >> "$LOG_FILE"
    
    # Validate components exist
    if [ ! -f "$ORIGINAL" ]; then
        echo -e "  ${RED}❌ ERROR: Original component does not exist${NC}"
        echo "[$LINE_NUM] ERROR: Original component does not exist" >> "$LOG_FILE"
        echo "| $(basename "$ORIGINAL") | $(basename "$REPLACEMENT") | Failed - Original not found | 0 |" >> "$REPORT_FILE"
        FAILED_MIGRATIONS=$((FAILED_MIGRATIONS + 1))
        continue
    fi
    
    if [ ! -f "$REPLACEMENT" ] && [ "$DRY_RUN" = false ]; then
        echo -e "  ${RED}❌ ERROR: Replacement component does not exist${NC}"
        echo "[$LINE_NUM] ERROR: Replacement component does not exist" >> "$LOG_FILE"
        echo "| $(basename "$ORIGINAL") | $(basename "$REPLACEMENT") | Failed - Replacement not found | 0 |" >> "$REPORT_FILE"
        FAILED_MIGRATIONS=$((FAILED_MIGRATIONS + 1))
        continue
    fi
    
    # Create backup of original component
    if [ "$DRY_RUN" = false ]; then
        cp "$ORIGINAL" "$MIGRATION_BACKUP_DIR/$(basename "$ORIGINAL")"
        echo -e "  ${GREEN}✅ Created backup of original component${NC}"
        echo "[$LINE_NUM] Created backup: $MIGRATION_BACKUP_DIR/$(basename "$ORIGINAL")" >> "$LOG_FILE"
    else
        echo -e "  ${YELLOW}⚠️ Would create backup of original component (dry run)${NC}"
        echo "[$LINE_NUM] Would create backup: $MIGRATION_BACKUP_DIR/$(basename "$ORIGINAL") (dry run)" >> "$LOG_FILE"
    fi
    
    # Find all references to the original component
    ORIGINAL_BASE=$(basename "$ORIGINAL" | sed 's/\.[^.]*$//')
    echo -e "  ${CYAN}Searching for references to:${NC} $ORIGINAL_BASE"
    echo "[$LINE_NUM] Searching for references to: $ORIGINAL_BASE" >> "$LOG_FILE"
    
    REFERENCES=$(grep -r --include="*.js" --include="*.cjs" --include="*.mjs" --include="*.json" "require.*$ORIGINAL_BASE\\|import.*$ORIGINAL_BASE\\|from.*$ORIGINAL_BASE" /Users/XPV/Desktop/anchor-core/ | grep -v "$(basename "$MIGRATION_FILE")" | grep -v "node_modules" || echo "")
    
    REF_COUNT=0
    if [ -n "$REFERENCES" ]; then
        REF_COUNT=$(echo "$REFERENCES" | wc -l)
        echo -e "  ${YELLOW}Found $REF_COUNT references to update${NC}"
        echo "[$LINE_NUM] Found $REF_COUNT references to update" >> "$LOG_FILE"
        
        # Process each reference
        REPLACEMENT_BASE=$(basename "$REPLACEMENT" | sed 's/\.[^.]*$//')
        UPDATED_REFS=0
        
        echo "$REFERENCES" | while read -r REF; do
            REF_FILE=$(echo "$REF" | cut -d':' -f1)
            
            # Create backup of reference file
            if [ "$DRY_RUN" = false ]; then
                cp "$REF_FILE" "$MIGRATION_BACKUP_DIR/$(basename "$REF_FILE").ref"
            fi
            
            echo -e "    ${CYAN}Updating reference in:${NC} $REF_FILE"
            echo "[$LINE_NUM] Updating reference in: $REF_FILE" >> "$LOG_FILE"
            
            # Update the reference
            if [ "$DRY_RUN" = false ]; then
                # Create sed pattern to update the reference
                # Handle require statements
                if grep -q "require.*$ORIGINAL_BASE" "$REF_FILE"; then
                    sed -i "" "s/require(['\"].*$ORIGINAL_BASE[\"'])/require('.\/$REPLACEMENT_BASE')/g" "$REF_FILE"
                    UPDATED_REFS=$((UPDATED_REFS + 1))
                fi
                
                # Handle import statements
                if grep -q "import.*$ORIGINAL_BASE" "$REF_FILE" || grep -q "from.*$ORIGINAL_BASE" "$REF_FILE"; then
                    sed -i "" "s/import[[:space:]]*{.*}[[:space:]]*from[[:space:]]*['\"].*$ORIGINAL_BASE['\"]/import { ... } from '.\/$REPLACEMENT_BASE'/g" "$REF_FILE"
                    sed -i "" "s/import[[:space:]]*.*[[:space:]]*from[[:space:]]*['\"].*$ORIGINAL_BASE['\"]/import ... from '.\/$REPLACEMENT_BASE'/g" "$REF_FILE"
                    UPDATED_REFS=$((UPDATED_REFS + 1))
                fi
                
                echo -e "    ${GREEN}✅ Updated reference${NC}"
                echo "[$LINE_NUM] Updated reference in: $REF_FILE" >> "$LOG_FILE"
            else
                echo -e "    ${YELLOW}⚠️ Would update reference (dry run)${NC}"
                echo "[$LINE_NUM] Would update reference in: $REF_FILE (dry run)" >> "$LOG_FILE"
                UPDATED_REFS=$((UPDATED_REFS + 1))
            fi
        done
        
        TOTAL_REFERENCES=$((TOTAL_REFERENCES + UPDATED_REFS))
    else
        echo -e "  ${GREEN}✅ No references to update${NC}"
        echo "[$LINE_NUM] No references to update" >> "$LOG_FILE"
    fi
    
    # Archive the original component
    if [ "$DRY_RUN" = false ]; then
        ORIG_NAME=$(basename "$ORIGINAL")
        CATEGORY="deprecated-implementations"
        
        # Determine appropriate category
        if [[ "$REASON" == *"module system conflict"* || "$REASON" == *"ESM/CommonJS"* ]]; then
            CATEGORY="module-system-conflicts"
        elif [[ "$REASON" == *"socket"* || "$REASON" == *"connection"* ]]; then
            CATEGORY="socket-connectivity-issues"
        elif [[ "$REASON" == *"schema"* || "$REASON" == *"validation"* ]]; then
            CATEGORY="schema-validation-errors"
        elif [[ "$REASON" == *"process"* || "$REASON" == *"lifecycle"* ]]; then
            CATEGORY="process-management-issues"
        elif [[ "$REASON" == *"performance"* || "$REASON" == *"memory"* || "$REASON" == *"CPU"* ]]; then
            CATEGORY="performance-bottlenecks"
        elif [[ "$REASON" == *"configuration"* || "$REASON" == *"config"* ]]; then
            CATEGORY="obsolete-configurations"
        fi
        
        ARCHIVE_COMPONENT_DIR="$ARCHIVE_DIR/$CATEGORY"
        mkdir -p "$ARCHIVE_COMPONENT_DIR"
        
        # Move to archive with timestamp
        cp "$ORIGINAL" "$ARCHIVE_COMPONENT_DIR/$ORIG_NAME.$TIMESTAMP"
        
        # Create metadata
        cat > "$ARCHIVE_COMPONENT_DIR/$ORIG_NAME.$TIMESTAMP.meta" <<EOF
ARCHIVE_DATE: $(date +"%Y-%m-%d %H:%M:%S")
COMPONENT_NAME: $ORIG_NAME
ORIGINAL_PATH: $ORIGINAL
FAILURE_TYPE: $CATEGORY
FAILURE_COUNT: 0
DEPENDENTS_COUNT: $REF_COUNT
REPLACEMENT: $REPLACEMENT
REASON: $REASON
ARCHIVED_BY: MCP Migration Manager v1.0.0
EOF
        
        echo -e "  ${GREEN}✅ Archived component to: ${MAGENTA}$CATEGORY/$ORIG_NAME.$TIMESTAMP${NC}"
        echo "[$LINE_NUM] Archived component to: $ARCHIVE_COMPONENT_DIR/$ORIG_NAME.$TIMESTAMP" >> "$LOG_FILE"
        
        # Create coherence marker
        MARKER="$COHERENCE_DIR/MIGRATED_${ORIG_NAME}_${TIMESTAMP}.marker"
        touch "$MARKER"
        echo -e "  ${GREEN}✅ Created coherence marker:${NC} $(basename "$MARKER")"
        echo "[$LINE_NUM] Created coherence marker: $MARKER" >> "$LOG_FILE"
        
        # Update report
        echo "| $ORIG_NAME | $(basename "$REPLACEMENT") | Successful | $UPDATED_REFS |" >> "$REPORT_FILE"
        SUCCESSFUL_MIGRATIONS=$((SUCCESSFUL_MIGRATIONS + 1))
    else
        echo -e "  ${YELLOW}⚠️ Would archive component (dry run)${NC}"
        echo "[$LINE_NUM] Would archive component (dry run)" >> "$LOG_FILE"
        
        # Update report
        echo "| $(basename "$ORIGINAL") | $(basename "$REPLACEMENT") | Dry Run | $REF_COUNT |" >> "$REPORT_FILE"
        SUCCESSFUL_MIGRATIONS=$((SUCCESSFUL_MIGRATIONS + 1))
    fi
    
    echo "[$LINE_NUM] Completed processing" >> "$LOG_FILE"
    echo "--------------------------------------------------------" >> "$LOG_FILE"
done

# Update ARCHIVE_REPORT.md with migration info
if [ "$DRY_RUN" = false ] && [ "$SUCCESSFUL_MIGRATIONS" -gt 0 ]; then
    cat >> "/Users/XPV/Desktop/anchor-core/ARCHIVE_REPORT.md" <<EOF

### $(date +"%Y-%m-%d") - Component Migration

A coordinated migration of $SUCCESSFUL_MIGRATIONS components was performed:

| Original Component | Replacement Component | Category | References Updated |
|-------------------|----------------------|----------|-------------------|
EOF

    # Add migration entries to archive report
    tail -n +2 "$MIGRATION_FILE" | while IFS=, read -r ORIGINAL REPLACEMENT REASON; do
        if [ -n "$ORIGINAL" ] && [ -n "$REPLACEMENT" ]; then
            # Determine appropriate category
            CATEGORY="deprecated-implementations"
            
            if [[ "$REASON" == *"module system conflict"* || "$REASON" == *"ESM/CommonJS"* ]]; then
                CATEGORY="module-system-conflicts"
            elif [[ "$REASON" == *"socket"* || "$REASON" == *"connection"* ]]; then
                CATEGORY="socket-connectivity-issues"
            elif [[ "$REASON" == *"schema"* || "$REASON" == *"validation"* ]]; then
                CATEGORY="schema-validation-errors"
            elif [[ "$REASON" == *"process"* || "$REASON" == *"lifecycle"* ]]; then
                CATEGORY="process-management-issues"
            elif [[ "$REASON" == *"performance"* || "$REASON" == *"memory"* || "$REASON" == *"CPU"* ]]; then
                CATEGORY="performance-bottlenecks"
            elif [[ "$REASON" == *"configuration"* || "$REASON" == *"config"* ]]; then
                CATEGORY="obsolete-configurations"
            fi
            
            # Count references
            ORIGINAL_BASE=$(basename "$ORIGINAL" | sed 's/\.[^.]*$//')
            REF_COUNT=$(grep -r --include="*.js" --include="*.cjs" --include="*.mjs" --include="*.json" "require.*$ORIGINAL_BASE\\|import.*$ORIGINAL_BASE\\|from.*$ORIGINAL_BASE" /Users/XPV/Desktop/anchor-core/ | grep -v "$(basename "$MIGRATION_FILE")" | grep -v "node_modules" | wc -l || echo "0")
            
            echo "| $(basename "$ORIGINAL") | $(basename "$REPLACEMENT") | $CATEGORY | $REF_COUNT |" >> "/Users/XPV/Desktop/anchor-core/ARCHIVE_REPORT.md"
        fi
    done
fi

# Add summary to report
cat >> "$REPORT_FILE" <<EOF

## Migration Summary

- **Total Components:** $TOTAL_COMPONENTS
- **Successfully Migrated:** $SUCCESSFUL_MIGRATIONS
- **Failed Migrations:** $FAILED_MIGRATIONS
- **Total References Updated:** $TOTAL_REFERENCES
- **Dry Run Mode:** $DRY_RUN

## Next Steps

1. Run system verification to ensure all components function correctly:
   \`\`\`bash
   /Users/XPV/Desktop/anchor-core/mcp-servers/verify-servers.sh
   \`\`\`

2. Verify that all references have been properly updated

3. If any issues are encountered, you can restore from backups:
   \`\`\`bash
   # Backup location
   $MIGRATION_BACKUP_DIR
   \`\`\`

4. Update documentation to reflect the component changes
EOF

# Create coherence marker for overall migration
MIGRATION_MARKER="$COHERENCE_DIR/MIGRATION_COMPLETE_${TIMESTAMP}.marker"
touch "$MIGRATION_MARKER"

# Run verification if requested
if [ "$VERIFY_AFTER" = true ] && [ "$DRY_RUN" = false ]; then
    echo -e "\n${CYAN}Running system verification...${NC}"
    echo "Running system verification..." >> "$LOG_FILE"
    
    if [ -f "/Users/XPV/Desktop/anchor-core/mcp-servers/verify-servers.sh" ]; then
        chmod +x "/Users/XPV/Desktop/anchor-core/mcp-servers/verify-servers.sh"
        "/Users/XPV/Desktop/anchor-core/mcp-servers/verify-servers.sh" >> "$LOG_FILE" 2>&1
        VERIFY_STATUS=$?
        
        if [ $VERIFY_STATUS -eq 0 ]; then
            echo -e "${GREEN}✅ System verification successful${NC}"
            echo "System verification successful" >> "$LOG_FILE"
            cat >> "$REPORT_FILE" <<EOF

## Verification Results

System verification completed successfully. All components are functioning as expected.
EOF
        else
            echo -e "${RED}❌ System verification failed${NC}"
            echo "System verification failed" >> "$LOG_FILE"
            cat >> "$REPORT_FILE" <<EOF

## Verification Results

System verification failed. Please review the logs and restore from backups if necessary.
EOF
        fi
    else
        echo -e "${YELLOW}⚠️ Verification script not found${NC}"
        echo "Verification script not found" >> "$LOG_FILE"
    fi
fi

# Display summary
echo -e "\n${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║                    MIGRATION SUMMARY                           ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${CYAN}Total Components:${NC} $TOTAL_COMPONENTS"
echo -e "${CYAN}Successfully Migrated:${NC} $SUCCESSFUL_MIGRATIONS"
echo -e "${CYAN}Failed Migrations:${NC} $FAILED_MIGRATIONS"
echo -e "${CYAN}Total References Updated:${NC} $TOTAL_REFERENCES"
echo -e "${CYAN}Dry Run Mode:${NC} $DRY_RUN"
echo ""
echo -e "${GREEN}✅ Migration report generated:${NC} $REPORT_FILE"
echo -e "${GREEN}✅ Migration log created:${NC} $LOG_FILE"
echo -e "${GREEN}✅ Coherence marker created:${NC} $(basename "$MIGRATION_MARKER")"
echo -e "${GREEN}✅ Backups stored in:${NC} $MIGRATION_BACKUP_DIR"
echo ""

if [ "$DRY_RUN" = true ]; then
    echo -e "${YELLOW}This was a dry run. No actual changes were made.${NC}"
    echo -e "${YELLOW}To perform the actual migration, run without --dry-run:${NC}"
    echo -e "$0 -f \"$MIGRATION_FILE\""
fi

exit 0
