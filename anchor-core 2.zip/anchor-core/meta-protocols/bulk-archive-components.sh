#!/bin/bash
# bulk-archive-components.sh - Process multiple components for archiving
# Usage: ./bulk-archive-components.sh [component_list_file]

# Set strict error handling
set -e

# ANSI color codes for output formatting
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Print banner
echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║                ANCHOR V6 BULK COMPONENT ARCHIVER               ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"

# Validate arguments
if [ $# -lt 1 ]; then
    echo -e "${RED}❌ ERROR: Please provide a component list file${NC}"
    echo -e "${YELLOW}Usage: ./bulk-archive-components.sh [component_list_file]${NC}"
    echo -e "\nComponent list file format (CSV):"
    echo -e "component_path,category,reason,replacement_path"
    exit 1
fi

COMPONENT_LIST=$1
TIMESTAMP=$(date +"%Y%m%d%H%M%S")
LOG_FILE="/Users/XPV/Desktop/anchor-core/logs/bulk-archive-$TIMESTAMP.log"

# Validate the component list file exists
if [ ! -f "$COMPONENT_LIST" ]; then
    echo -e "${RED}❌ ERROR: Component list file does not exist: $COMPONENT_LIST${NC}"
    exit 1
fi

# Create logs directory if it doesn't exist
mkdir -p "/Users/XPV/Desktop/anchor-core/logs"

# Initialize log file
echo "ANCHOR V6 BULK ARCHIVING OPERATION - $(date)" > $LOG_FILE
echo "Components from: $COMPONENT_LIST" >> $LOG_FILE
echo "--------------------------------" >> $LOG_FILE

# Process each component
TOTAL_COMPONENTS=$(cat $COMPONENT_LIST | wc -l)
SUCCESSFUL=0
FAILED=0

echo -e "${CYAN}🔄 Processing $TOTAL_COMPONENTS components...${NC}"

# Start processing
LINE_NUM=0
while IFS=, read -r COMPONENT_PATH CATEGORY REASON REPLACEMENT_PATH; do
    LINE_NUM=$((LINE_NUM + 1))
    
    # Skip empty lines
    if [ -z "$COMPONENT_PATH" ]; then
        continue
    fi
    
    # Skip comments
    if [[ "$COMPONENT_PATH" == \#* ]]; then
        continue
    }
    
    echo -e "\n${YELLOW}[$LINE_NUM/$TOTAL_COMPONENTS] Processing: $COMPONENT_PATH${NC}"
    
    # Validate required fields
    if [ -z "$CATEGORY" ] || [ -z "$REASON" ]; then
        echo -e "${RED}❌ ERROR: Missing required fields for $COMPONENT_PATH${NC}"
        echo "[$LINE_NUM] FAILED: $COMPONENT_PATH - Missing required fields" >> $LOG_FILE
        FAILED=$((FAILED + 1))
        continue
    fi
    
    # Call the archive-component.sh script
    if ./meta-protocols/archive-component.sh "$COMPONENT_PATH" "$CATEGORY" "$REASON" "$REPLACEMENT_PATH" >> $LOG_FILE 2>&1; then
        echo -e "${GREEN}✅ Successfully archived: $COMPONENT_PATH${NC}"
        echo "[$LINE_NUM] SUCCESS: $COMPONENT_PATH -> $CATEGORY" >> $LOG_FILE
        SUCCESSFUL=$((SUCCESSFUL + 1))
    else
        echo -e "${RED}❌ Failed to archive: $COMPONENT_PATH${NC}"
        echo "[$LINE_NUM] FAILED: $COMPONENT_PATH - Archive operation failed" >> $LOG_FILE
        FAILED=$((FAILED + 1))
    fi
    
done < "$COMPONENT_LIST"

# Generate summary report
echo -e "\n${CYAN}📊 Archiving Summary:${NC}"
echo -e "${GREEN}✅ Successfully archived: $SUCCESSFUL components${NC}"
echo -e "${RED}❌ Failed to archive: $FAILED components${NC}"
echo -e "${CYAN}📝 Log file: $LOG_FILE${NC}"

# Update main report with summary
cat >> /Users/XPV/Desktop/anchor-core/ARCHIVE_REPORT.md <<EOF

## Bulk Archiving Operation - $(date +"%Y-%m-%d")

- **Components Processed**: $TOTAL_COMPONENTS
- **Successfully Archived**: $SUCCESSFUL
- **Failed Operations**: $FAILED
- **Log File**: \`logs/bulk-archive-$TIMESTAMP.log\`
EOF

# Create coherence marker for bulk operation
COHERENCE_MARKER="/Users/XPV/Desktop/anchor-core/coherence_lock/BULK_ARCHIVE_OPERATION_$(date +"%Y-%m-%dT%H%M%S%3N%z").marker"
touch $COHERENCE_MARKER

exit 0
