#!/bin/bash
# initialize-archival-system.sh - Master initialization script for Anchor V6 Archiving System
# This script performs a complete initialization of the archiving protocol framework

# Set strict error handling
set -e

# ANSI color codes for output formatting
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Make this script executable
chmod +x $0

# Print banner
echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║            ANCHOR V6 ARCHIVAL SYSTEM INITIALIZATION            ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"

# Define key directories
BASE_DIR="/Users/XPV/Desktop/anchor-core"
META_DIR="$BASE_DIR/meta-protocols"
ARCHIVE_DIR="$BASE_DIR/archive"
ANALYSIS_DIR="$BASE_DIR/analysis"
COHERENCE_DIR="$BASE_DIR/coherence_lock"
LOGS_DIR="$BASE_DIR/logs"
BACKUP_DIR="$BASE_DIR/backups"

# Timestamp for operations
TIMESTAMP=$(date +"%Y%m%d%H%M%S")
INIT_LOG="$LOGS_DIR/archival-system-init-$TIMESTAMP.log"

# Create log directory if needed
mkdir -p "$LOGS_DIR"

# Start logging
echo "ANCHOR V6 ARCHIVING SYSTEM INITIALIZATION LOG" > "$INIT_LOG"
echo "Started at: $(date)" >> "$INIT_LOG"
echo "Base directory: $BASE_DIR" >> "$INIT_LOG"
echo "----------------------------------------" >> "$INIT_LOG"

# Function to create directory if it doesn't exist
create_directory() {
    local dir="$1"
    local description="$2"
    
    if [ ! -d "$dir" ]; then
        echo -e "${CYAN}Creating $description directory: ${MAGENTA}$dir${NC}"
        mkdir -p "$dir"
        echo "Created directory: $dir ($description)" >> "$INIT_LOG"
    else
        echo -e "${GREEN}✓ $description directory exists: ${MAGENTA}$dir${NC}"
        echo "Directory exists: $dir ($description)" >> "$INIT_LOG"
    fi
}

# Function to verify script exists and is executable
verify_script() {
    local script="$1"
    local description="$2"
    
    if [ -f "$script" ]; then
        echo -e "${GREEN}✓ $description script exists: ${MAGENTA}$(basename "$script")${NC}"
        chmod +x "$script"
        echo "Made executable: $script ($description)" >> "$INIT_LOG"
    else
        echo -e "${RED}✗ $description script missing: ${MAGENTA}$(basename "$script")${NC}"
        echo "Missing script: $script ($description)" >> "$INIT_LOG"
        return 1
    fi
    
    return 0
}

# Step 1: Verify and create directory structure
echo -e "\n${CYAN}Step 1: Verifying directory structure...${NC}"
echo "Step 1: Verifying directory structure" >> "$INIT_LOG"

create_directory "$META_DIR" "Meta-protocols"
create_directory "$ARCHIVE_DIR" "Archive"
create_directory "$ANALYSIS_DIR" "Analysis"
create_directory "$COHERENCE_DIR" "Coherence lock"
create_directory "$BACKUP_DIR" "Backups"

# Create archive category directories
echo -e "\n${CYAN}Creating archive category directories...${NC}"
echo "Creating archive category directories" >> "$INIT_LOG"

CATEGORIES=("module-system-conflicts" "socket-connectivity-issues" "schema-validation-errors" "process-management-issues" "performance-bottlenecks" "deprecated-implementations" "obsolete-configurations")

for category in "${CATEGORIES[@]}"; do
    create_directory "$ARCHIVE_DIR/$category" "Archive category: $category"
done

# Create backup timestamp directory
BACKUP_TIMESTAMP_DIR="$BACKUP_DIR/$TIMESTAMP"
create_directory "$BACKUP_TIMESTAMP_DIR" "Backup timestamp"

# Step 2: Verify core protocol scripts
echo -e "\n${CYAN}Step 2: Verifying protocol scripts...${NC}"
echo "Step 2: Verifying protocol scripts" >> "$INIT_LOG"

PROTOCOL_SCRIPTS=(
    "$META_DIR/analyze-archive-candidates.sh:Analysis tool for log-based candidates"
    "$META_DIR/identify-archive-candidates.sh:Source code analysis tool"
    "$META_DIR/archive-component.sh:Single component archiver"
    "$META_DIR/bulk-archive-components.sh:Bulk component archiver"
    "$META_DIR/create-replacement-component.sh:Replacement component generator"
    "$META_DIR/archive-dashboard.sh:Archiving dashboard generator"
    "$META_DIR/component-migration-manager.sh:Migration manager"
    "$BASE_DIR/archival-protocol-controller.sh:Protocol controller"
    "$BASE_DIR/make-archival-scripts-executable.sh:Script permission manager"
)

MISSING_SCRIPTS=0

for script_info in "${PROTOCOL_SCRIPTS[@]}"; do
    IFS=: read -r script description <<< "$script_info"
    
    if ! verify_script "$script" "$description"; then
        MISSING_SCRIPTS=$((MISSING_SCRIPTS + 1))
    fi
done

if [ $MISSING_SCRIPTS -gt 0 ]; then
    echo -e "\n${YELLOW}Warning: $MISSING_SCRIPTS script(s) missing. System may not function fully.${NC}"
    echo "Warning: $MISSING_SCRIPTS script(s) missing" >> "$INIT_LOG"
else
    echo -e "\n${GREEN}✓ All protocol scripts verified and made executable${NC}"
    echo "All protocol scripts verified" >> "$INIT_LOG"
fi

# Step 3: Verify documentation
echo -e "\n${CYAN}Step 3: Verifying documentation...${NC}"
echo "Step 3: Verifying documentation" >> "$INIT_LOG"

DOC_FILES=(
    "$BASE_DIR/SYSTEMATIC_ARCHIVING_PROTOCOL.md:Protocol documentation"
    "$BASE_DIR/ARCHIVING_PROTOCOL_USER_GUIDE.md:User guide"
    "$META_DIR/ARCHIVAL_IMPLEMENTATION_PLAN.md:Implementation plan"
)

MISSING_DOCS=0

for doc_info in "${DOC_FILES[@]}"; do
    IFS=: read -r doc description <<< "$doc_info"
    
    if [ -f "$doc" ]; then
        echo -e "${GREEN}✓ $description exists: ${MAGENTA}$(basename "$doc")${NC}"
        echo "Documentation exists: $doc ($description)" >> "$INIT_LOG"
    else
        echo -e "${RED}✗ $description missing: ${MAGENTA}$(basename "$doc")${NC}"
        echo "Missing documentation: $doc ($description)" >> "$INIT_LOG"
        MISSING_DOCS=$((MISSING_DOCS + 1))
    fi
done

if [ $MISSING_DOCS -gt 0 ]; then
    echo -e "\n${YELLOW}Warning: $MISSING_DOCS documentation file(s) missing.${NC}"
    echo "Warning: $MISSING_DOCS documentation file(s) missing" >> "$INIT_LOG"
else
    echo -e "\n${GREEN}✓ All documentation files verified${NC}"
    echo "All documentation files verified" >> "$INIT_LOG"
fi

# Step 4: Initialize README files in archive directories
echo -e "\n${CYAN}Step 4: Initializing archive category README files...${NC}"
echo "Step 4: Initializing archive category README files" >> "$INIT_LOG"

for category in "${CATEGORIES[@]}"; do
    README_FILE="$ARCHIVE_DIR/$category/README.md"
    
    if [ ! -f "$README_FILE" ]; then
        echo -e "${CYAN}Creating README for ${MAGENTA}$category${NC}"
        
        # Create category README
        cat > "$README_FILE" <<EOF
# $category Archive

This directory contains components archived due to $category issues.

## Archived Components

| Component | Archived Date | Reason | Replacement |
|-----------|---------------|--------|-------------|
EOF
        
        echo "Created README: $README_FILE" >> "$INIT_LOG"
    else
        echo -e "${GREEN}✓ README exists for ${MAGENTA}$category${NC}"
        echo "README exists: $README_FILE" >> "$INIT_LOG"
    fi
done

# Step 5: Create initialization marker
echo -e "\n${CYAN}Step 5: Creating initialization marker...${NC}"
echo "Step 5: Creating initialization marker" >> "$INIT_LOG"

INIT_MARKER="$COHERENCE_DIR/ARCHIVAL_SYSTEM_INITIALIZED_$TIMESTAMP.marker"

cat > "$INIT_MARKER" <<EOF
ANCHOR V6 ARCHIVAL SYSTEM INITIALIZED
Initialization Date: $(date)
Protocol Version: 1.0.0
Taxonomy Layer: L0-L13 (All)
Hardware Target: M3 Max (48GB unified memory)

Directories Initialized:
- Meta-protocols: $META_DIR
- Archive: $ARCHIVE_DIR
- Analysis: $ANALYSIS_DIR
- Coherence lock: $COHERENCE_DIR
- Backups: $BACKUP_DIR

Archive Categories:
$(printf "- %s\n" "${CATEGORIES[@]}")

Scripts Verified: $((${#PROTOCOL_SCRIPTS[@]} - MISSING_SCRIPTS))/$((${#PROTOCOL_SCRIPTS[@]}))
Documentation Verified: $((${#DOC_FILES[@]} - MISSING_DOCS))/$((${#DOC_FILES[@]}))

System is ready for use.
EOF

echo -e "${GREEN}✓ Created initialization marker: ${MAGENTA}$(basename "$INIT_MARKER")${NC}"
echo "Created initialization marker: $INIT_MARKER" >> "$INIT_LOG"

# Step 6: Run initial dashboard to establish baseline
echo -e "\n${CYAN}Step 6: Generating initial archiving dashboard...${NC}"
echo "Step 6: Generating initial archiving dashboard" >> "$INIT_LOG"

if [ -f "$META_DIR/archive-dashboard.sh" ]; then
    echo -e "${CYAN}Running initial dashboard...${NC}"
    "$META_DIR/archive-dashboard.sh" >> "$INIT_LOG" 2>&1
    echo -e "${GREEN}✓ Initial dashboard generated${NC}"
    echo "Initial dashboard generated" >> "$INIT_LOG"
else
    echo -e "${YELLOW}Warning: Cannot generate initial dashboard (script missing)${NC}"
    echo "Warning: Cannot generate initial dashboard (script missing)" >> "$INIT_LOG"
fi

# Step 7: Final report
echo -e "\n${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║            ARCHIVAL SYSTEM INITIALIZATION COMPLETE               ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"

echo -e "\n${GREEN}✓ Directory structure validated and created${NC}"
echo -e "${GREEN}✓ Protocol scripts verified and made executable${NC}"
echo -e "${GREEN}✓ Documentation verified${NC}"
echo -e "${GREEN}✓ Archive category README files initialized${NC}"
echo -e "${GREEN}✓ Initialization marker created${NC}"
echo -e "${GREEN}✓ Initialization log saved to: ${MAGENTA}$INIT_LOG${NC}"

echo -e "\n${CYAN}The Anchor V6 Archiving System is now initialized and ready for use.${NC}"
echo -e "${CYAN}To begin using the system, run the protocol controller:${NC}"
echo -e "${MAGENTA}$BASE_DIR/archival-protocol-controller.sh${NC}"

# Log completion
echo "----------------------------------------" >> "$INIT_LOG"
echo "Initialization completed at: $(date)" >> "$INIT_LOG"
echo "The Anchor V6 Archiving System is now initialized and ready for use." >> "$INIT_LOG"

exit 0
