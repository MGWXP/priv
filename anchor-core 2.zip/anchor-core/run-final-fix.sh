chmod +x /Users/XPV/Desktop/anchor-core/final-fix-and-launch.sh
/Users/XPV/Desktop/anchor-core/final-fix-and-launch.sh
