#!/bin/bash
# debug-schema-registry.sh

# Set environment variables for debug mode
export NODE_OPTIONS="--max-old-space-size=8192"
export UV_THREADPOOL_SIZE=12
export ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
export MCP_DIR="$ANCHOR_HOME/mcp-servers"
export SOCKET_DIR="$ANCHOR_HOME/sockets"
export LOG_DIR="$HOME/Library/Logs/Claude"
export CONFIG_DIR="$ANCHOR_HOME/data"
export MCP_SERVER_NAME="schema-registry"
export DEBUG=1

# Debug with trace
node --trace-warnings "$MCP_DIR/schema-registry.cjs" > "$LOG_DIR/schema-registry-debug.log" 2>&1

echo "Debug log written to $LOG_DIR/schema-registry-debug.log"
