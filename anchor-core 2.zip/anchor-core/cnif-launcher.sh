#!/bin/bash
# cnif-launcher.sh - Unified launcher for CNIF
# © 2025 XPV - MIT

set -e

# Define colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Base paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
LOG_DIR="$HOME/Library/Logs/Claude"
SOCKET_DIR="$ANCHOR_HOME/sockets"
CONFIG_DIR="$ANCHOR_HOME/config"
COHERENCE_LOCK_DIR="$ANCHOR_HOME/coherence_lock"
ENTRY_POINTS_DIR="$ANCHOR_HOME/entry-points"

# Server configurations
declare -A SERVERS
SERVERS=(
  ["schema-registry"]="$ENTRY_POINTS_DIR/schema-registry-main.js"
  ["streaming-transformer"]="$ENTRY_POINTS_DIR/streaming-transformer-main.js"
  ["socket-server"]="$ENTRY_POINTS_DIR/socket-server-main.js"
  ["notion"]="$ENTRY_POINTS_DIR/notion-connection-main.js"
  ["mcp-orchestrator"]="$ENTRY_POINTS_DIR/mcp-orchestrator-main.js"
)

# Expected startup times (in seconds)
declare -A STARTUP_TIMES
STARTUP_TIMES=(
  ["schema-registry"]=3
  ["streaming-transformer"]=3
  ["socket-server"]=2
  ["notion"]=5
  ["mcp-orchestrator"]=5
)

# M3 Max optimized settings
NODE_OPTIONS="--max-old-space-size=8192"
UV_THREADPOOL_SIZE=12

# Functions
log() {
  local level=$1
  local message=$2
  local timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
  
  case $level in
    INFO)
      echo -e "${BLUE}[$timestamp] [INFO] $message${NC}"
      ;;
    SUCCESS)
      echo -e "${GREEN}[$timestamp] [SUCCESS] $message${NC}"
      ;;
    WARN)
      echo -e "${YELLOW}[$timestamp] [WARN] $message${NC}"
      ;;
    ERROR)
      echo -e "${RED}[$timestamp] [ERROR] $message${NC}"
      ;;
    *)
      echo -e "[$timestamp] [$level] $message"
      ;;
  esac
}

# Create required directories
create_directories() {
  log INFO "Creating required directories..."
  
  mkdir -p "$LOG_DIR"
  mkdir -p "$SOCKET_DIR"
  mkdir -p "$COHERENCE_LOCK_DIR"
  mkdir -p "$CONFIG_DIR"
  mkdir -p "$ANCHOR_HOME/schemas/claude"
  mkdir -p "$ANCHOR_HOME/schemas/notion"
  
  log SUCCESS "Required directories created"
}

# Check if server is already running
is_server_running() {
  local server_name=$1
  local pid_file="$ANCHOR_HOME/$server_name.pid"
  
  if [ -f "$pid_file" ]; then
    local pid=$(cat "$pid_file")
    if ps -p "$pid" > /dev/null; then
      return 0
    fi
  fi
  
  return 1
}

# Clean up function
cleanup() {
  log INFO "Cleaning up resources..."
  
  # Remove socket files
  rm -f "$SOCKET_DIR"/*.sock
  
  # Remove PID files
  rm -f "$ANCHOR_HOME"/*.pid
  
  # Remove coherence markers
  rm -f "$COHERENCE_LOCK_DIR"/*.marker
  
  log SUCCESS "Cleanup complete"
}

# Stop servers
stop_servers() {
  log INFO "Stopping all servers..."
  
  # Send SIGTERM to all running servers
  for server in "${!SERVERS[@]}"; do
    local pid_file="$ANCHOR_HOME/$server.pid"
    
    if [ -f "$pid_file" ]; then
      local pid=$(cat "$pid_file")
      if ps -p "$pid" > /dev/null; then
        log INFO "Stopping $server (PID: $pid)..."
        kill -15 "$pid" || true
      else
        log WARN "Process $server (PID: $pid) not running"
      fi
    fi
  done
  
  # Wait for servers to exit
  sleep 2
  
  # Force kill any remaining servers
  for server in "${!SERVERS[@]}"; do
    local pid_file="$ANCHOR_HOME/$server.pid"
    
    if [ -f "$pid_file" ]; then
      local pid=$(cat "$pid_file")
      if ps -p "$pid" > /dev/null; then
        log WARN "Force stopping $server (PID: $pid)..."
        kill -9 "$pid" || true
      fi
    fi
  done
  
  # Cleanup
  cleanup
  
  log SUCCESS "All servers stopped"
}

# Start a server
start_server() {
  local server_name=$1
  local script=${SERVERS[$server_name]}
  local startup_time=${STARTUP_TIMES[$server_name]}
  
  # Check if server is already running
  if is_server_running "$server_name"; then
    log WARN "$server_name is already running"
    return
  fi
  
  # Start server
  log INFO "Starting $server_name..."
  
  # Set environment variables
  export NODE_OPTIONS="$NODE_OPTIONS"
  export UV_THREADPOOL_SIZE=$UV_THREADPOOL_SIZE
  export ANCHOR_HOME="$ANCHOR_HOME"
  export SOCKET_DIR="$SOCKET_DIR"
  export LOG_DIR="$LOG_DIR"
  export CONFIG_DIR="$CONFIG_DIR"
  export MCP_SERVER_NAME="$server_name"
  
  # Start server in background
  node "$script" > "$LOG_DIR/$server_name.log" 2>&1 &
  
  # Save PID
  local pid=$!
  echo "$pid" > "$ANCHOR_HOME/$server_name.pid"
  
  # Wait for server to start
  sleep "$startup_time"
  
  # Check if server is still running
  if ps -p "$pid" > /dev/null; then
    log SUCCESS "$server_name started (PID: $pid)"
    return 0
  else
    log ERROR "$server_name failed to start"
    return 1
  fi
}

# Start all servers
start_servers() {
  log INFO "Starting all servers..."
  
  # Start servers in the correct order
  local ordered_servers=("schema-registry" "streaming-transformer" "socket-server" "notion" "mcp-orchestrator")
  local failed=false
  
  for server in "${ordered_servers[@]}"; do
    if ! start_server "$server"; then
      failed=true
      break
    fi
    
    # Add a delay between server starts
    sleep 1
  done
  
  if [ "$failed" = true ]; then
    log ERROR "Failed to start all servers"
    stop_servers
    return 1
  fi
  
  log SUCCESS "All servers started successfully"
  return 0
}

# Check server status
check_status() {
  log INFO "Checking server status..."
  
  local all_running=true
  
  for server in "${!SERVERS[@]}"; do
    local pid_file="$ANCHOR_HOME/$server.pid"
    
    if [ -f "$pid_file" ]; then
      local pid=$(cat "$pid_file")
      if ps -p "$pid" > /dev/null; then
        log SUCCESS "$server is running (PID: $pid)"
      else
        log ERROR "$server is not running (PID: $pid)"
        all_running=false
      fi
    else
      log ERROR "$server is not running (no PID file)"
      all_running=false
    fi
  done
  
  # Check socket files
  for server in "${!SERVERS[@]}"; do
    local socket_file="$SOCKET_DIR/$server.sock"
    
    if [ -e "$socket_file" ]; then
      log SUCCESS "Socket file exists for $server"
    else
      log ERROR "Socket file missing for $server"
      all_running=false
    fi
  done
  
  if [ "$all_running" = true ]; then
    log SUCCESS "All servers are running"
    return 0
  else
    log ERROR "Not all servers are running"
    return 1
  fi
}

# Show logs
show_logs() {
  local server=$1
  
  if [ -z "$server" ]; then
    log ERROR "No server specified"
    echo "Usage: $0 logs <server>"
    echo "Available servers: ${!SERVERS[*]}"
    return 1
  fi
  
  if [[ ! "${!SERVERS[@]}" =~ "$server" ]]; then
    log ERROR "Unknown server: $server"
    echo "Available servers: ${!SERVERS[*]}"
    return 1
  fi
  
  local log_file="$LOG_DIR/$server.log"
  
  if [ -f "$log_file" ]; then
    log INFO "Showing logs for $server ($log_file)"
    tail -f "$log_file"
  else
    log ERROR "Log file not found for $server: $log_file"
    return 1
  fi
}

# Show help
show_help() {
  echo "CNIF Launcher"
  echo ""
  echo "Usage: $0 <command>"
  echo ""
  echo "Commands:"
  echo "  start       Start all servers"
  echo "  stop        Stop all servers"
  echo "  restart     Restart all servers"
  echo "  status      Show server status"
  echo "  logs        Show server logs (requires server name)"
  echo "  cleanup     Clean up resources"
  echo "  help        Show this help"
  echo ""
  echo "Examples:"
  echo "  $0 start"
  echo "  $0 logs schema-registry"
  echo ""
  echo "Available servers: ${!SERVERS[*]}"
}

# Main

# Create directories
create_directories

# Process command
if [ $# -eq 0 ]; then
  show_help
  exit 0
fi

case $1 in
  start)
    start_servers
    ;;
  stop)
    stop_servers
    ;;
  restart)
    stop_servers
    start_servers
    ;;
  status)
    check_status
    ;;
  logs)
    show_logs "$2"
    ;;
  cleanup)
    cleanup
    ;;
  help)
    show_help
    ;;
  *)
    log ERROR "Unknown command: $1"
    show_help
    exit 1
    ;;
esac
