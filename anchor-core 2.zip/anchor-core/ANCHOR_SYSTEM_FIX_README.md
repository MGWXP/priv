# Anchor System V6 Fix Documentation

## Overview

This document explains the comprehensive fix implemented for Anchor System V6, addressing issues with socket communication, process management, and M3 Max hardware optimization. The solution ensures stable, high-performance operation of all MCP (Model Context Protocol) servers for Claude integration.

## Key Issues Fixed

1. **Socket Communication Issues:**
   - Stale socket files not being properly cleaned up
   - Inconsistent socket file permissions
   - Missing validation of socket connectivity
   - Race conditions during socket creation and permission setting

2. **NODE_OPTIONS Configuration Issues:**
   - Invalid flags in NODE_OPTIONS (`--expose-gc` and `--initial-old-space-size`)
   - Inconsistent environment variable setting
   - Improper command-line flag handling

3. **Process Management Issues:**
   - Servers starting but terminating prematurely
   - Stale PID files when processes crash
   - Missing automatic recovery from failures
   - Lack of comprehensive health monitoring

4. **M3 Max Optimization Issues:**
   - Improper memory allocation for unified memory architecture
   - Thread pool size not optimized for 12 performance + 4 efficiency cores
   - Inconsistent application of hardware-specific optimizations

## Components Implemented

1. **Enhanced Socket Manager (`socket-manager.js`)**
   - Comprehensive socket lifecycle management
   - Proper permission handling
   - Stale socket detection and cleanup
   - Connection validation

2. **Robust Process Manager (`process-manager.js`)**
   - Process lifecycle management
   - Health monitoring
   - Automatic recovery with exponential backoff
   - Graceful termination

3. **M3 Max Optimizer (`m3-optimizer/m3-optimizer.js`)**
   - Hardware-specific memory allocation
   - Thread pool optimization
   - Metal Performance Shaders detection
   - Core-aware workload distribution

4. **Enhanced Socket Server (`enhanced-socket-server.js`)**
   - Unified implementation of MCP server using the enhanced components
   - Consistent error handling
   - Structured logging
   - Proper signal handling

## Installation Instructions

1. **Make the fix script executable:**
   ```bash
   chmod +x /Users/XPV/Desktop/anchor-core/make_anchor_fix_executable.sh
   /Users/XPV/Desktop/anchor-core/make_anchor_fix_executable.sh
   ```

2. **Run the comprehensive fix script:**
   ```bash
   ./anchor-system-fix.sh
   ```

3. **Verify the installation:**
   ```bash
   ./verify-enhanced-servers.sh
   ```

4. **Restart Claude Desktop** to connect to the enhanced servers.

## Usage

The following scripts are available after installation:

- **`launch-enhanced-servers.sh`**: Start all socket servers with enhanced components
- **`verify-enhanced-servers.sh`**: Check the status of all servers
- **`run-with-pm.sh`**: Launch servers with process manager for continuous monitoring

## Compatibility

This fix is specifically optimized for:
- **Hardware**: Apple M3 Max with 48GB unified memory
- **OS**: macOS Sequoia 15.4.1
- **Node.js**: v20.11.0 or higher
- **Claude Desktop**: Latest version

## Technical Details

### Socket Lifecycle Management

The socket manager implements a robust lifecycle:

1. **Initialization Phase**
   - Check and remove stale socket files
   - Ensure directory structure exists
   - Prepare for socket creation

2. **Creation Phase**
   - Set proper umask (0o000) before socket creation
   - Create the socket file
   - Set explicit permissions (0o666) after creation

3. **Monitoring Phase**
   - Handle connection events
   - Maintain socket health
   - Detect and recover from errors

4. **Cleanup Phase**
   - Proper cleanup on normal termination
   - Signal handling for unexpected termination
   - Stale socket prevention

### Process Management

The process manager provides:

1. **Initialization with Dependency Resolution**
   - Manage startup sequence
   - Check for existing processes
   - Handle resource initialization

2. **Health Monitoring**
   - Regular health checks
   - Process existence verification
   - Socket availability validation
   - Log monitoring

3. **Automatic Recovery**
   - Detect process failures
   - Implement exponential backoff
   - Limit maximum restarts
   - Record and report restart attempts

4. **Graceful Termination**
   - Handle termination signals
   - Proper resource cleanup
   - Coordinated shutdown

### M3 Max Optimizations

Hardware-specific optimizations include:

1. **Memory Allocation**
   - Optimize for 48GB unified memory
   - Set appropriate heap size limits
   - Balance between performance and stability

2. **Thread Pool Configuration**
   - Set UV_THREADPOOL_SIZE to match core count + 1
   - Distribute workload across performance and efficiency cores
   - Balance I/O and CPU-bound tasks

3. **GPU and Neural Engine Integration**
   - Detect and utilize Metal Performance Shaders
   - Optimize for AI workloads
   - Enable efficient GPU offloading

## Troubleshooting

If you encounter issues after applying the fix:

1. **Check server status:**
   ```bash
   ./verify-enhanced-servers.sh
   ```

2. **Review log files:**
   ```bash
   tail -f ~/Library/Logs/Claude/mcp-server-*.log
   ```

3. **Restart the servers:**
   ```bash
   ./launch-enhanced-servers.sh
   ```

4. **Verify Claude configuration:**
   ```bash
   cat ~/Library/Application\ Support/Claude/claude_desktop_config.json
   ```

For persistent issues, run the comprehensive fix script again with:
```bash
./anchor-system-fix.sh
```

---

© 2025 XPV - MIT License
