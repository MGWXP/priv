#!/bin/bash
# fix-cnif-quick.sh - Quick CNIF Module Fix Script
# © 2025 XPV - MIT

set -e

# Define colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color
BLUE='\033[0;34m'

# Base paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
SOCKET_DIR="$ANCHOR_HOME/sockets"
LOG_DIR="$HOME/Library/Logs/Claude"
CONFIG_DIR="$ANCHOR_HOME/data"
MCP_DIR="$ANCHOR_HOME/mcp-servers"

echo -e "${BLUE}==================================================${NC}"
echo -e "${BLUE}CNIF Quick Module Fix                            ${NC}"
echo -e "${BLUE}==================================================${NC}"

# 1. Fix package.json
echo -e "\n${BLUE}Updating package.json...${NC}"
PACKAGE_JSON="$ANCHOR_HOME/package.json"
# Make a backup
cp "$PACKAGE_JSON" "$PACKAGE_JSON.bak"

# Add type: commonjs to package.json
node -e "
const fs = require('fs');
const packageJson = JSON.parse(fs.readFileSync('$PACKAGE_JSON', 'utf8'));
packageJson.type = 'commonjs';
fs.writeFileSync('$PACKAGE_JSON', JSON.stringify(packageJson, null, 2));
console.log('✅ Added type: commonjs to package.json');
"

# 2. Fix schema registry
echo -e "\n${BLUE}Fixing schema-registry.js...${NC}"
SCHEMA_REGISTRY="$MCP_DIR/schema-registry.js"
# Backup original
cp "$SCHEMA_REGISTRY" "$SCHEMA_REGISTRY.bak"

# Extract just the class definition part
cat > "$SCHEMA_REGISTRY" << 'EOF'
/**
 * schema-registry.js - Schema version management for Claude-Notion integration
 * © 2025 XPV - MIT
 * 
 * Implements a versioned schema registry for Claude-Notion integration
 * with SchemaVer versioning (MODEL-REVISION-ADDITION) and validation.
 */

const fs = require('fs');
const path = require('path');
const EventEmitter = require('events');

/**
 * Schema Registry manages schema versioning and lookup
 * Using SchemaVer approach (MODEL-REVISION-ADDITION)
 */
class SchemaRegistry extends EventEmitter {
  /**
   * Create a new SchemaRegistry
   * @param {object} options - Registry options
   */
  constructor(options = {}) {
    super();
    
    this.options = {
      schemaDirClaude: path.join(process.cwd(), 'schemas', 'claude'),
      schemaDirNotion: path.join(process.cwd(), 'schemas', 'notion'),
      cacheEnabled: true,
      validateOnLoad: true,
      ...options
    };
    
    this.claudeSchemas = new Map();
    this.notionSchemas = new Map();
    this.schemaVersions = {
      claude: new Map(),
      notion: new Map()
    };
    
    this.initialized = false;
  }
  
  /**
   * Initialize the registry
   * Loads all schemas from disk
   * @returns {Promise<boolean>} Success status
   */
  async initialize() {
    try {
      // Create schema directories if they don't exist
      await this._ensureDirectory(this.options.schemaDirClaude);
      await this._ensureDirectory(this.options.schemaDirNotion);
      
      // Load Claude schemas
      await this._loadSchemas('claude', this.options.schemaDirClaude, this.claudeSchemas);
      
      // Load Notion schemas
      await this._loadSchemas('notion', this.options.schemaDirNotion, this.notionSchemas);
      
      this.initialized = true;
      this.emit('initialized');
      
      return true;
    } catch (err) {
      this.emit('error', err);
      throw err;
    }
  }
  
  /**
   * Ensure directory exists
   * @param {string} dir - Directory path
   * @private
   */
  async _ensureDirectory(dir) {
    try {
      await fs.promises.mkdir(dir, { recursive: true });
    } catch (err) {
      // Ignore if directory already exists
      if (err.code !== 'EEXIST') {
        throw err;
      }
    }
  }
  
  /**
   * Load schemas from directory
   * @param {string} type - Schema type ('claude' or 'notion')
   * @param {string} dir - Directory path
   * @param {Map} targetMap - Target map to store schemas
   * @private
   */
  async _loadSchemas(type, dir, targetMap) {
    try {
      const files = await fs.promises.readdir(dir);
      
      for (const file of files) {
        if (path.extname(file) === '.json') {
          try {
            const schemaPath = path.join(dir, file);
            const schema = JSON.parse(await fs.promises.readFile(schemaPath, 'utf8'));
            
            // Validate schema structure
            if (this.options.validateOnLoad && !this._validateSchemaStructure(schema)) {
              console.warn('Invalid schema structure: ' + schemaPath);
              continue;
            }
            
            // Extract schema ID and version
            const { id, version } = schema;
            
            if (!id || !version) {
              console.warn('Schema missing id or version: ' + schemaPath);
              continue;
            }
            
            // Store schema
            targetMap.set(id, schema);
            
            // Update version map
            if (!this.schemaVersions[type].has(id)) {
              this.schemaVersions[type].set(id, []);
            }
            
            const versions = this.schemaVersions[type].get(id);
            versions.push(version);
            
            // Sort versions in descending order (latest first)
            versions.sort((a, b) => this._compareVersions(b, a));
            
            this.emit('schema-loaded', { type, id, version, path: schemaPath });
          } catch (err) {
            console.error('Error loading schema ' + file + ': ' + err.message);
          }
        }
      }
    } catch (err) {
      console.error('Error reading schema directory ' + dir + ': ' + err.message);
      throw err;
    }
  }
  
  // Other methods...
  /**
   * Get all registered schemas of a type
   * @param {string} type - Schema type ('claude' or 'notion')
   * @returns {Array} Array of schema objects
   */
  getAllSchemas(type) {
    if (!this.initialized) {
      throw new Error('Schema registry not initialized');
    }
    
    const schemaMap = type === 'claude' ? this.claudeSchemas : this.notionSchemas;
    return Array.from(schemaMap.values());
  }
  
  /**
   * Compare SchemaVer versions (MODEL-REVISION-ADDITION)
   * @param {string} v1 - First version string
   * @param {string} v2 - Second version string
   * @returns {number} Comparison result (-1, 0, 1)
   * @private
   */
  _compareVersions(v1, v2) {
    const parse = (v) => {
      const parts = v.split('-').map(Number);
      return { model: parts[0] || 0, revision: parts[1] || 0, addition: parts[2] || 0 };
    };
    
    const a = parse(v1);
    const b = parse(v2);
    
    if (a.model !== b.model) return a.model - b.model;
    if (a.revision !== b.revision) return a.revision - b.revision;
    return a.addition - b.addition;
  }
  
  /**
   * Validate schema structure
   * @param {object} schema - Schema to validate
   * @returns {boolean} Validation result
   * @private
   */
  _validateSchemaStructure(schema) {
    // Basic structure validation
    if (!schema || typeof schema !== 'object') return false;
    if (!schema.id || typeof schema.id !== 'string') return false;
    if (!schema.version || typeof schema.version !== 'string') return false;
    if (!schema.description || typeof schema.description !== 'string') return false;
    if (!schema.schema || typeof schema.schema !== 'object') return false;
    
    return true;
  }
  
  /**
   * Get schema metrics
   * @returns {object} Schema registry metrics
   */
  getMetrics() {
    return {
      initialized: this.initialized,
      schemaCount: {
        claude: this.claudeSchemas.size,
        notion: this.notionSchemas.size,
        total: this.claudeSchemas.size + this.notionSchemas.size
      }
    };
  }
}

module.exports = SchemaRegistry;
EOF

echo -e "${GREEN}✅ Fixed schema-registry.js${NC}"

# 3. Create .cjs versions of key modules
echo -e "\n${BLUE}Creating .cjs versions of server modules...${NC}"
MODULE_FILES=(
  "socket-server-implementation.js"
  "notion-connection-manager.js"
  "schema-registry.js"
  "streaming-schema-transformer.js"
  "mcp-orchestrator.js"
  "circuit-breaker.js"
)

for file in "${MODULE_FILES[@]}"; do
  source_path="$MCP_DIR/$file"
  target_path="$MCP_DIR/${file/.js/.cjs}"
  
  if [ -f "$source_path" ]; then
    cp "$source_path" "$target_path"
    echo -e "${GREEN}✅ Created $target_path${NC}"
  else
    echo -e "${YELLOW}⚠️ Source file doesn't exist: $source_path${NC}"
  fi
done

# 4. Update launch script to use .cjs files
echo -e "\n${BLUE}Updating launch script...${NC}"
LAUNCH_SCRIPT="$ANCHOR_HOME/launch-optimized.sh"
cp "$LAUNCH_SCRIPT" "$LAUNCH_SCRIPT.bak"

# Use sed to replace the server scripts
sed -i.bak 's|SERVER_SCRIPTS=("\$MCP_DIR/socket-server-implementation.js" "\$MCP_DIR/notion-connection-manager.js" "\$MCP_DIR/schema-registry.js" "\$MCP_DIR/streaming-schema-transformer.js" "\$MCP_DIR/mcp-orchestrator.js")|SERVER_SCRIPTS=("\$MCP_DIR/socket-server-implementation.cjs" "\$MCP_DIR/notion-connection-manager.cjs" "\$MCP_DIR/schema-registry.cjs" "\$MCP_DIR/streaming-schema-transformer.cjs" "\$MCP_DIR/mcp-orchestrator.cjs")|g' "$LAUNCH_SCRIPT"

echo -e "${GREEN}✅ Updated launch script${NC}"

# 5. Create required directories
echo -e "\n${BLUE}Creating required directories...${NC}"
mkdir -p "$SOCKET_DIR"
mkdir -p "$LOG_DIR"
mkdir -p "$CONFIG_DIR"
mkdir -p "$ANCHOR_HOME/schemas/claude"
mkdir -p "$ANCHOR_HOME/schemas/notion"
chmod 777 "$SOCKET_DIR"

echo -e "${GREEN}✅ Created required directories${NC}"

echo -e "\n${GREEN}==================================================${NC}"
echo -e "${GREEN}CNIF Module System Fix Complete!${NC}"
echo -e "${GREEN}==================================================${NC}"
echo -e "\nRun the following command to start the system:"
echo -e "${BLUE}$ANCHOR_HOME/launch-optimized.sh${NC}"
