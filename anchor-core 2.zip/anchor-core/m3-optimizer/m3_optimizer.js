#!/usr/bin/env node
/**
 * M3 Max Optimizer for Anchor System
 * Optimizes Node.js performance for Apple M3 Max with 48GB unified memory
 * © 2025 XPV - MIT
 */

const fs = require('fs');
const os = require('os');
const path = require('path');
const { execSync } = require('child_process');

// Constants for M3 Max optimization
const M3_MAX_CORE_COUNT = 16; // 12 performance cores + 4 efficiency cores
const MEMORY_GB = 48;
const MEMORY_ALLOCATION = Math.floor(MEMORY_GB * 0.6); // Use 60% of available RAM

// Output banner
console.log('┌─────────────────────────────────────────────────────┐');
console.log('│        M3 Max Optimizer for Anchor System           │');
console.log('└─────────────────────────────────────────────────────┘');

// Detect system configuration
const cpuInfo = os.cpus();
const coreCount = cpuInfo.length;
const systemMemoryGB = Math.round(os.totalmem() / (1024 * 1024 * 1024));

console.log(`\nSystem Detection:`);
console.log(`• CPU: ${cpuInfo[0].model}`);
console.log(`• Cores: ${coreCount}`);
console.log(`• Memory: ${systemMemoryGB}GB`);
console.log(`• Architecture: ${os.arch()}`);
console.log(`• Platform: ${os.platform()} ${os.release()}`);

// Calculate optimal thread pool size
// Rule: Use cores + 1 for I/O-heavy applications on Apple Silicon
const optimalThreads = M3_MAX_CORE_COUNT + 1;

// Calculate optimal memory settings
// For Node.js specifically on M3 Max
const oldSpaceSize = Math.min(Math.floor(MEMORY_ALLOCATION * 0.8), 16); // Cap at 16GB to prevent issues
const initialOldSpaceSize = Math.floor(oldSpaceSize * 0.3);

// Apply optimizations - removed --expose-gc as it's not allowed in NODE_OPTIONS
console.log('\nApplying M3 Max Optimizations:');
console.log(`• NODE_OPTIONS: --max-old-space-size=${oldSpaceSize * 1024} --initial-old-space-size=${initialOldSpaceSize * 1024}`);
console.log(`• UV_THREADPOOL_SIZE: ${optimalThreads}`);
console.log(`• CPU Usage: ${M3_MAX_CORE_COUNT} cores allocated`);

// Create the .env file with optimized settings
const ANCHOR_HOME = process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core';
const envPath = path.join(ANCHOR_HOME, '.env');

const envContent = `# M3 Max Optimized Settings
# Generated: ${new Date().toISOString()}
# For: 48GB M3 Max

# Node.js Memory Settings
# NOTE: --expose-gc removed as it's not allowed in NODE_OPTIONS
export NODE_OPTIONS="--max-old-space-size=${oldSpaceSize * 1024} --initial-old-space-size=${initialOldSpaceSize * 1024}"

# Thread Pool Configuration
export UV_THREADPOOL_SIZE=${optimalThreads}

# Environment Variables
export ANCHOR_HOME=${ANCHOR_HOME}
export MCP_DIR=${ANCHOR_HOME}/mcp-servers
export SOCKET_DIR=${ANCHOR_HOME}/sockets

# System paths
export LOG_DIR=${os.homedir()}/Library/Logs/Claude
export CONFIG_DIR=${os.homedir()}/Library/Application Support/Claude

# M3 Specific Settings
export M3_OPTIMIZED=true
export M3_MEMORY_ALLOCATION=${MEMORY_ALLOCATION}GB
export M3_CORE_COUNT=${M3_MAX_CORE_COUNT}
`;

fs.writeFileSync(envPath, envContent);
console.log(`\n✅ Created optimized .env file at: ${envPath}`);

// Check if Metal Performance Shaders (MPS) support is available
try {
  // This command will fail if Metal is not available
  execSync('system_profiler SPDisplaysDataType | grep Metal');
  console.log('\n✅ Metal Performance Shaders support detected');
  console.log('• JavaScript operations that can use GPU acceleration will be offloaded');
  console.log('• Tensor operations optimized for Neural Engine');
} catch (e) {
  console.log('\n⚠️ Metal Performance Shaders not detected - using CPU only mode');
}

// Check for other optimization opportunities
const zshRcPath = path.join(os.homedir(), '.zshrc');
if (fs.existsSync(zshRcPath)) {
  // Add environment variables to .zshrc for persistence
  const zshContent = fs.readFileSync(zshRcPath, 'utf8');
  if (!zshContent.includes('NODE_OPTIONS=')) {
    console.log('\nAdding environment variables to .zshrc for persistence...');
    const appendContent = `
# M3 Max Optimizations for Anchor System
export NODE_OPTIONS="--max-old-space-size=${oldSpaceSize * 1024} --initial-old-space-size=${initialOldSpaceSize * 1024}"
export UV_THREADPOOL_SIZE=${optimalThreads}
export ANCHOR_HOME=${ANCHOR_HOME}
export MCP_DIR=${ANCHOR_HOME}/mcp-servers
export SOCKET_DIR=${ANCHOR_HOME}/sockets
`;
    fs.appendFileSync(zshRcPath, appendContent);
    console.log('✅ Added environment variables to .zshrc');
  }
}

// Create an optimized launch script
const launchScriptPath = path.join(ANCHOR_HOME, 'launch-optimized.sh');
const launchScript = `#!/bin/bash
# M3 Max Optimized Launch Script
# Generated: ${new Date().toISOString()}
set -e

# Load optimized environment
source ${envPath}

# Start all servers with optimized settings
echo "🚀 Starting M3 Max optimized servers..."

# Make sure required directories exist
mkdir -p "$LOG_DIR"
mkdir -p "$SOCKET_DIR"

# Terminate any existing servers
pkill -f "git-local-optimized.js" 2>/dev/null || true
pkill -f "notion-v5-wrapper.js" 2>/dev/null || true
pkill -f "anchor-manager-optimized.js" 2>/dev/null || true
sleep 1

# Start Git Local
echo "Starting Git Local server..."
SOCKET_DIR="${SOCKET_DIR}" MCP_SERVER_NAME="git-local" \\
  node "$MCP_DIR/git-local-optimized.js" > "$LOG_DIR/mcp-server-git-local.log" 2>&1 &
echo $! > "$MCP_DIR/git-local.pid"

# Start Notion
echo "Starting Notion server..."
SOCKET_DIR="${SOCKET_DIR}" MCP_SERVER_NAME="notion" \\
  node "$MCP_DIR/notion-v5-wrapper.js" > "$LOG_DIR/mcp-server-notion.log" 2>&1 &
echo $! > "$MCP_DIR/notion.pid"

# Start Anchor Manager
echo "Starting Anchor Manager server..."
SOCKET_DIR="${SOCKET_DIR}" MCP_SERVER_NAME="anchor-manager" \\
  node "$MCP_DIR/anchor-manager-optimized.js" > "$LOG_DIR/mcp-server-anchor-manager.log" 2>&1 &
echo $! > "$MCP_DIR/anchor-manager.pid"

echo "✅ All servers started with M3 Max optimizations"
echo "🖥 Launch Claude to connect to optimized servers"
`;

fs.writeFileSync(launchScriptPath, launchScript);
fs.chmodSync(launchScriptPath, '755');
console.log(`\n✅ Created optimized launch script: ${launchScriptPath}`);

console.log('\n🎉 M3 Max optimization complete! System configured for optimal performance.');
console.log(`\nTo launch optimized servers, run:\n  ${launchScriptPath}`);
