/**
 * m3-cnif-optimizer.js - M3 Max hardware optimization for CNIF
 * © 2025 XPV - MIT
 * 
 * This specialized optimizer configures system resources for optimal 
 * performance with CNIF workloads on M3 Max hardware with 48GB unified memory.
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn } = require('child_process');

// Configuration
const ANCHOR_HOME = process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core';
const LOG_DIR = process.env.LOG_DIR || path.join(os.homedir(), 'Library/Logs/Claude');
const LOG_FILE = path.join(LOG_DIR, 'm3-optimizer.log');
const ENV_FILE = path.join(ANCHOR_HOME, '.env');

// M3 Max hardware detection constants
const M3_MAX_MODEL_IDENTIFIERS = ['Mac14,8', 'Mac14,13']; // M3 Max identifiers
const MIN_MEMORY_GB = 32; // Minimum memory for M3 Max configurations

// Ensure log directory exists
if (!fs.existsSync(LOG_DIR)) {
  fs.mkdirSync(LOG_DIR, { recursive: true });
}

// Logging
function log(level, message, data = null) {
  const timestamp = new Date().toISOString();
  const logEntry = {
    ts: timestamp,
    level,
    component: 'm3-optimizer',
    pid: process.pid,
    message,
    ...(data ? { data } : {})
  };
  
  const logString = JSON.stringify(logEntry);
  console.log(logString);
  
  try {
    fs.appendFileSync(LOG_FILE, logString + '\n');
  } catch (err) {
    console.error(`Failed to write to log file: ${err.message}`);
  }
}

// Detect if running on M3 Max hardware
async function detectM3MaxHardware() {
  try {
    // Check memory first - M3 Max should have at least 32GB
    const totalMemoryGB = Math.round(os.totalmem() / (1024 * 1024 * 1024));
    
    if (totalMemoryGB < MIN_MEMORY_GB) {
      log('INFO', `System memory ${totalMemoryGB}GB is less than expected for M3 Max (${MIN_MEMORY_GB}GB)`);
      return false;
    }
    
    log('INFO', `System memory: ${totalMemoryGB}GB`);
    
    // Get CPU info
    const cpuInfo = os.cpus();
    const cpuModel = cpuInfo[0]?.model || '';
    const cpuCount = cpuInfo.length;
    
    log('INFO', `CPU: ${cpuModel}, Cores: ${cpuCount}`);
    
    // On macOS, try to get more specific hardware info with system_profiler
    if (process.platform === 'darwin') {
      return new Promise((resolve) => {
        const proc = spawn('system_profiler', ['SPHardwareDataType']);
        let output = '';
        
        proc.stdout.on('data', (data) => {
          output += data.toString();
        });
        
        proc.on('close', (code) => {
          if (code !== 0) {
            log('WARN', `system_profiler exited with code ${code}`);
            // Fall back to simple model detection
            const isArm64 = process.arch === 'arm64';
            const isM3InModel = cpuModel.includes('Apple M3');
            resolve(isArm64 && isM3InModel);
            return;
          }
          
          log('DEBUG', 'Hardware profile', { output });
          
          // Check for M3 Max identifiers
          const isM3Max = M3_MAX_MODEL_IDENTIFIERS.some(id => output.includes(id)) || 
                         (output.includes('M3 Max') || output.includes('M3 Pro'));
                         
          // Check memory again
          const memoryMatch = output.match(/Memory: (\d+) GB/);
          const profileMemoryGB = memoryMatch ? parseInt(memoryMatch[1], 10) : 0;
          
          if (isM3Max) {
            log('INFO', `Detected M3 Max hardware: ${profileMemoryGB}GB RAM`);
            resolve(true);
          } else {
            log('INFO', 'Not running on M3 Max hardware');
            resolve(false);
          }
        });
      });
    } else {
      // For non-macOS, use more generic detection
      const isArm64 = process.arch === 'arm64';
      const isAppleChip = cpuModel.includes('Apple');
      return isArm64 && isAppleChip;
    }
  } catch (err) {
    log('ERROR', `Hardware detection error: ${err.message}`);
    return false;
  }
}

// Generate optimized environment variables for M3 Max
async function generateOptimizedEnvironment(isM3Max) {
  const env = {};
  
  // Total system memory
  const totalMemoryGB = Math.round(os.totalmem() / (1024 * 1024 * 1024));
  
  // Base optimization regardless of hardware
  env.NODE_OPTIONS = '--max-old-space-size=8192';
  env.UV_THREADPOOL_SIZE = '8';
  
  if (isM3Max) {
    log('INFO', 'Applying M3 Max specific optimizations');
    
    // CPU optimization - M3 Max has hybrid architecture with P-cores and E-cores
    const cpuCount = os.cpus().length;
    
    if (cpuCount >= 14) {
      // 12P + 4E core model
      env.UV_THREADPOOL_SIZE = '12';
      log('INFO', 'Optimizing for 12P+4E core configuration');
    } else if (cpuCount >= 10) {
      // 8P + 4E core model
      env.UV_THREADPOOL_SIZE = '10';
      log('INFO', 'Optimizing for 8P+4E core configuration');
    }
    
    // Memory optimization based on total system memory
    if (totalMemoryGB >= 64) {
      // For 64GB model
      env.NODE_OPTIONS = '--max-old-space-size=12288'; // 12GB for Node
      log('INFO', 'Optimizing for 64GB unified memory');
    } else if (totalMemoryGB >= 48) {
      // For 48GB model
      env.NODE_OPTIONS = '--max-old-space-size=8192'; // 8GB for Node
      log('INFO', 'Optimizing for 48GB unified memory');
    } else if (totalMemoryGB >= 32) {
      // For 32GB model
      env.NODE_OPTIONS = '--max-old-space-size=6144'; // 6GB for Node
      log('INFO', 'Optimizing for 32GB unified memory');
    }
    
    // CNIF specific optimizations
    env.CNIF_BUFFER_SIZE = '65536'; // 64K buffer size for socket communication
    env.CNIF_SCHEMA_CACHE_SIZE = '256'; // 256 schema entries in cache
    env.CNIF_SOCKET_BACKLOG = '128'; // Connection backlog
    env.CNIF_POOL_SIZE = '8'; // Connection pool size
    env.CNIF_XML_CHUNK_SIZE = '16384'; // XML chunk size for streaming
    env.CNIF_JSON_CHUNK_SIZE = '16384'; // JSON chunk size for streaming
    env.CNIF_USE_ASYNC_HOOKS = 'true'; // Enable async hooks for better async context tracking
    
  } else {
    log('INFO', 'Applying generic optimizations');
    
    // Generic optimizations for non-M3 Max hardware
    env.CNIF_BUFFER_SIZE = '32768'; // 32K buffer size
    env.CNIF_SCHEMA_CACHE_SIZE = '128'; // 128 schema entries in cache
    env.CNIF_SOCKET_BACKLOG = '64'; // Connection backlog
    env.CNIF_POOL_SIZE = '4'; // Connection pool size
    env.CNIF_XML_CHUNK_SIZE = '8192'; // XML chunk size for streaming
    env.CNIF_JSON_CHUNK_SIZE = '8192'; // JSON chunk size for streaming
  }
  
  // Common settings
  env.CNIF_LOG_LEVEL = 'info';
  env.CNIF_COHERENCE_ENABLED = 'true';
  env.CNIF_CIRCUIT_BREAKER_ENABLED = 'true';
  env.ANCHOR_HOME = ANCHOR_HOME;
  
  return env;
}

// Save environment variables to .env file
function saveEnvironmentVariables(env) {
  try {
    let envContent = '# CNIF Environment Variables - M3 Optimizer\n';
    envContent += `# Generated: ${new Date().toISOString()}\n\n`;
    
    for (const [key, value] of Object.entries(env)) {
      envContent += `${key}=${value}\n`;
    }
    
    fs.writeFileSync(ENV_FILE, envContent);
    log('INFO', `Saved optimized environment to ${ENV_FILE}`);
    return true;
  } catch (err) {
    log('ERROR', `Failed to save environment variables: ${err.message}`);
    return false;
  }
}

// Apply optimizations to running processes if possible
async function applyToRunningProcesses(env) {
  try {
    const processes = fs.readdirSync(path.join(ANCHOR_HOME, 'mcp-servers'))
      .filter(file => file.endsWith('.pid'))
      .map(file => {
        try {
          const pidFile = path.join(ANCHOR_HOME, 'mcp-servers', file);
          const pid = parseInt(fs.readFileSync(pidFile, 'utf8').trim(), 10);
          const name = file.replace('.pid', '');
          return { pid, name };
        } catch (err) {
          return null;
        }
      })
      .filter(Boolean);
    
    log('INFO', `Found ${processes.length} running processes`, { processes });
    
    if (processes.length === 0) {
      return false;
    }
    
    // We can't directly change env vars of running processes
    // But we can update their priority to optimize performance
    for (const proc of processes) {
      try {
        if (process.platform === 'darwin' || process.platform === 'linux') {
          // Use nice to adjust process priority
          // Schema registry and socket server get higher priority (lower nice value)
          const priority = 
            (proc.name === 'schema-registry' || proc.name === 'socket-server') ? 
            -10 : 0;
          
          spawn('renice', [priority.toString(), proc.pid.toString()]);
          
          log('INFO', `Adjusted priority for ${proc.name} (PID: ${proc.pid}) to ${priority}`);
        }
      } catch (err) {
        log('WARN', `Failed to adjust priority for ${proc.name}: ${err.message}`);
      }
    }
    
    return true;
  } catch (err) {
    log('ERROR', `Failed to apply to running processes: ${err.message}`);
    return false;
  }
}

// Generate a launcher script with optimized environment
function generateOptimizedLauncher(env) {
  try {
    const launcherPath = path.join(ANCHOR_HOME, 'm3-optimized-launcher.sh');
    log('INFO', `Generating optimized launcher at ${launcherPath}`);
    
    let launcherContent = `#!/bin/bash
# m3-optimized-launcher.sh - M3 Max optimized launcher for CNIF
# © 2025 XPV - MIT
# Generated: ${new Date().toISOString()}

# Load environment variables
`;

    // Add environment variables
    for (const [key, value] of Object.entries(env)) {
      launcherContent += `export ${key}="${value}"\n`;
    }
    
    // Add launcher code
    launcherContent += `
# Print optimization info
echo "✅ M3 Max optimizations applied"
echo "🧠 Memory allocation: ${env.NODE_OPTIONS}"
echo "⚙️ Thread pool size: ${env.UV_THREADPOOL_SIZE}"
echo "📊 Buffer size: ${env.CNIF_BUFFER_SIZE}"

# Launch the sequenced launcher with optimizations
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
"$ANCHOR_HOME/sequenced-launcher.sh" "$@"
`;
    
    fs.writeFileSync(launcherPath, launcherContent);
    fs.chmodSync(launcherPath, 0o755); // Make executable
    
    log('INFO', `Generated optimized launcher at ${launcherPath}`);
    return true;
  } catch (err) {
    log('ERROR', `Failed to generate optimized launcher: ${err.message}`);
    return false;
  }
}

// Main function
async function main() {
  try {
    log('INFO', 'M3 Max optimizer starting...');
    
    // Detect hardware
    const isM3Max = await detectM3MaxHardware();
    
    // Generate optimized environment
    const optimizedEnv = await generateOptimizedEnvironment(isM3Max);
    log('INFO', 'Generated optimized environment variables', optimizedEnv);
    
    // Save to .env file
    saveEnvironmentVariables(optimizedEnv);
    
    // Apply to running processes if possible
    await applyToRunningProcesses(optimizedEnv);
    
    // Generate optimized launcher
    generateOptimizedLauncher(optimizedEnv);
    
    log('INFO', 'M3 Max optimization complete');
    
    // Create marker file for optimization completion
    const timestamp = new Date().toISOString().replace(/[:.]/g, '');
    const markerFile = path.join(ANCHOR_HOME, `MCP_OPTIMIZATION_COMPLETE_${timestamp}.marker`);
    
    fs.writeFileSync(markerFile, JSON.stringify({
      timestamp: new Date().toISOString(),
      isM3Max,
      optimizations: optimizedEnv,
      system: {
        platform: process.platform,
        arch: process.arch,
        nodeVersion: process.version,
        cpuModel: os.cpus()[0].model,
        cpuCount: os.cpus().length,
        totalMemoryGB: Math.round(os.totalmem() / (1024 * 1024 * 1024))
      }
    }, null, 2));
    
    log('INFO', `Created optimization marker: ${markerFile}`);
  } catch (err) {
    log('ERROR', `M3 Max optimizer failed: ${err.message}`);
    process.exit(1);
  }
}

// If run directly
if (require.main === module) {
  main();
} else {
  // Exported for use in other modules
  module.exports = {
    detectM3MaxHardware,
    generateOptimizedEnvironment,
    saveEnvironmentVariables,
    applyToRunningProcesses,
    generateOptimizedLauncher
  };
}
