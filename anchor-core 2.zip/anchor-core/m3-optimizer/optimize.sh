#!/bin/bash
# optimize.sh - M3 Max hardware optimization for MCP servers
# Adjusts memory, thread pool, and performance settings
# © 2025 XPV - MIT License

# Terminal colors for better output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# -----------------------------------------
# Banner
# -----------------------------------------
cat << "EOF"
 __  __ _____   __  __             
|  \/  |___ /  |  \/  | __ ___  __ 
| |\/| | |_ \  | |\/| |/ _` \ \/ / 
| |  | |___) | | |  | | (_| |>  <  
|_|  |_|____/  |_|  |_|\__,_/_/\_\ 
                                   
 Optimizer for Claude MCP Servers
EOF

echo ""
echo -e "${BLUE}This script optimizes MCP servers for M3 Max hardware${NC}"
echo -e "${YELLOW}For Apple Silicon M3 Max with 48GB unified memory${NC}"
echo ""

# -----------------------------------------
# System detection
# -----------------------------------------
echo -e "${BLUE}=== System Detection ===${NC}"

# Check if running on Apple Silicon
if [ "$(uname -s)" != "Darwin" ]; then
  echo -e "${RED}Error: This script is designed for macOS systems${NC}"
  exit 1
fi

# Check processor type
processor=$(sysctl -n machdep.cpu.brand_string)
echo -e "Processor: $processor"

# Determine if it's an M3 Max
is_m3_max=false
if echo "$processor" | grep -q "Apple M3 Max"; then
  echo -e "${GREEN}✅ M3 Max processor detected${NC}"
  is_m3_max=true
else
  echo -e "${YELLOW}⚠️ Not running on M3 Max processor${NC}"
  echo -e "This script is optimized specifically for M3 Max hardware."
  echo -e "Would you like to continue anyway? (y/n)"
  read -r continue_anyway
  
  if [[ ! $continue_anyway =~ ^[Yy]$ ]]; then
    echo -e "${RED}Optimization cancelled.${NC}"
    exit 1
  fi
fi

# Check total memory
total_memory_bytes=$(sysctl -n hw.memsize)
total_memory_gb=$((total_memory_bytes / 1024 / 1024 / 1024))
echo -e "Total system memory: ${total_memory_gb}GB"

# Check processor cores
performance_cores=$(sysctl -n hw.perflevel0.physicalcpu)
efficiency_cores=$(sysctl -n hw.perflevel1.physicalcpu)
total_cores=$((performance_cores + efficiency_cores))
echo -e "CPU cores: ${performance_cores} performance + ${efficiency_cores} efficiency = ${total_cores} total"

# -----------------------------------------
# Define optimal settings based on hardware
# -----------------------------------------
# Memory allocation size (in MB)
if [ $total_memory_gb -ge 48 ]; then
  # For 48GB models
  heap_size=16384
  sqlite_mmap_size=268435456  # 256MB
elif [ $total_memory_gb -ge 32 ]; then
  # For 32GB models
  heap_size=12288
  sqlite_mmap_size=134217728  # 128MB
else
  # For 16GB or smaller models
  heap_size=8192
  sqlite_mmap_size=67108864  # 64MB
fi

# Thread pool size (cores + 1 for main thread)
thread_pool_size=$((total_cores + 1))

# -----------------------------------------
# Configuration paths
# -----------------------------------------
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
ENV_FILE="${ANCHOR_HOME}/.env"
CONFIG_DIR="${HOME}/Library/Application Support/Claude"
CLAUDE_CONFIG="${CONFIG_DIR}/claude_desktop_config.json"

# -----------------------------------------
# Update .env file
# -----------------------------------------
echo -e "\n${BLUE}=== Updating Environment Configuration ===${NC}"

if [ -f "$ENV_FILE" ]; then
  # Backup existing file
  cp "$ENV_FILE" "${ENV_FILE}.bak.$(date +%Y%m%d%H%M%S)"
  echo -e "${GREEN}✅ Backed up existing .env file${NC}"
  
  # Update or add memory settings
  if grep -q "NODE_OPTIONS" "$ENV_FILE"; then
    sed -i '' "s|NODE_OPTIONS=.*|NODE_OPTIONS=\"--max-old-space-size=${heap_size}\"|" "$ENV_FILE"
  else
    echo -e "\n# M3 Max hardware optimization" >> "$ENV_FILE"
    echo "NODE_OPTIONS=\"--max-old-space-size=${heap_size}\"" >> "$ENV_FILE"
  fi
  
  # Update or add thread pool size
  if grep -q "UV_THREADPOOL_SIZE" "$ENV_FILE"; then
    sed -i '' "s|UV_THREADPOOL_SIZE=.*|UV_THREADPOOL_SIZE=${thread_pool_size}|" "$ENV_FILE"
  else
    echo "UV_THREADPOOL_SIZE=${thread_pool_size}" >> "$ENV_FILE"
  fi
  
  # Add SQLite optimizations
  if grep -q "SQLITE_PRAGMA_JOURNAL_MODE" "$ENV_FILE"; then
    sed -i '' "s|SQLITE_PRAGMA_JOURNAL_MODE=.*|SQLITE_PRAGMA_JOURNAL_MODE=WAL|" "$ENV_FILE"
  else
    echo -e "\n# SQLite optimizations" >> "$ENV_FILE"
    echo "SQLITE_PRAGMA_JOURNAL_MODE=WAL" >> "$ENV_FILE"
    echo "SQLITE_PRAGMA_SYNCHRONOUS=NORMAL" >> "$ENV_FILE"
    echo "SQLITE_PRAGMA_TEMP_STORE=MEMORY" >> "$ENV_FILE"
    echo "SQLITE_MMAP_SIZE=${sqlite_mmap_size}" >> "$ENV_FILE"
  fi
  
  # Add hardware flags
  if ! grep -q "M3_MAX_OPTIMIZED" "$ENV_FILE"; then
    echo -e "\n# Hardware-specific flags" >> "$ENV_FILE"
    echo "M3_MAX_OPTIMIZED=true" >> "$ENV_FILE"
    echo "METAL_DEVICE_WRAPPER_TYPE=1" >> "$ENV_FILE"
    echo "NODE_GC_INTERVAL=300000" >> "$ENV_FILE"
  fi
  
  echo -e "${GREEN}✅ Updated .env file with optimal settings for M3 Max${NC}"
else
  # Create new .env file
  mkdir -p "$ANCHOR_HOME"
  cat > "$ENV_FILE" << EOF
# Anchor System Environment Configuration
# Optimized for M3 Max hardware
# Generated by m3-optimizer/optimize.sh

# System paths
ANCHOR_HOME="$ANCHOR_HOME"
LOG_DIR="${HOME}/Library/Logs/Claude"
DATA_DIR="${ANCHOR_HOME}/data"

# M3 Max hardware optimization
NODE_OPTIONS="--max-old-space-size=${heap_size}"
UV_THREADPOOL_SIZE=${thread_pool_size}

# Hardware-specific flags
M3_MAX_OPTIMIZED=true
METAL_DEVICE_WRAPPER_TYPE=1
NODE_GC_INTERVAL=300000

# SQLite optimizations
SQLITE_PRAGMA_JOURNAL_MODE=WAL
SQLITE_PRAGMA_SYNCHRONOUS=NORMAL
SQLITE_PRAGMA_TEMP_STORE=MEMORY
SQLITE_MMAP_SIZE=${sqlite_mmap_size}
EOF

  echo -e "${GREEN}✅ Created new .env file with optimal settings for M3 Max${NC}"
fi

# -----------------------------------------
# Final recommendations
# -----------------------------------------
echo -e "\n${BLUE}=== M3 Max Optimization Complete ===${NC}"
echo -e "Your system is now configured for optimal performance with the M3 Max processor."

echo -e "\n${YELLOW}Recommended next steps:${NC}"
echo -e "1. Restart MCP servers with: ${ANCHOR_HOME}/launch-optimized.sh"
echo -e "2. Configure Notion access with: ${ANCHOR_HOME}/setup-notion.sh"
echo -e "3. Restart Claude Desktop to connect to the optimized servers"
echo -e "4. Verify that all servers are running with: ${ANCHOR_HOME}/verify-mcp-servers.sh"

echo -e "\n${GREEN}Optimization complete! Your M3 Max is now ready for peak Claude performance.${NC}"
exit 0
