#!/usr/bin/env node
/**
 * M3 Max MCP Server Optimizer
 * Comprehensive optimization for MCP servers on Apple M3 Max (48GB)
 * © 2025 XPV - MIT License
 * 
 * This optimizer provides specialized tuning parameters for Apple's M3 Max architecture,
 * particularly optimizing for the asymmetric core design and unified memory structure.
 */

const fs = require('fs');
const os = require('os');
const path = require('path');
const { execSync } = require('child_process');

// =========================================================================
// Configuration Constants
// =========================================================================

// Hardware details (M3 Max specific)
const HARDWARE = {
  performance_cores: 12,
  efficiency_cores: 4,
  total_cores: 16,
  memory_gb: 48,
  unified_memory: true,
  neural_engine_cores: 16,
  gpu_cores: 40,
  memory_bandwidth_gbps: 400
};

// Path configuration
const PATHS = {
  anchor_home: process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core',
  config_dir: path.join(os.homedir(), 'Library/Application Support/Claude'),
  claude_config: path.join(os.homedir(), 'Library/Application Support/Claude/claude_desktop_config.json'),
  enhanced_config: '/Users/XPV/Desktop/anchor-core/enhanced-config.json',
  log_dir: path.join(os.homedir(), 'Library/Logs/Claude'),
  socket_dir: '/Users/XPV/Desktop/anchor-core/sockets',
  mcp_dir: '/Users/XPV/Desktop/anchor-core/mcp-servers'
};

// Memory allocation - using 70% of system memory for MCP servers
const TOTAL_MEMORY_ALLOCATION = Math.floor(HARDWARE.memory_gb * 0.7);

// Per-server memory allocation (proportional)
const MEMORY_ALLOCATION = {
  'filesystem': { 
    percentage: 20, 
    heap_size: 0,  // Will be calculated
    semi_space: 0  // Will be calculated
  },
  'git-local': { 
    percentage: 15, 
    heap_size: 0,
    semi_space: 0
  },
  'notion': { 
    percentage: 15, 
    heap_size: 0,
    semi_space: 0
  },
  'anchor-manager': { 
    percentage: 15, 
    heap_size: 0,
    semi_space: 0
  },
  'sqlite': { 
    percentage: 12, 
    heap_size: 0,
    semi_space: 0
  },
  'slack': { 
    percentage: 10, 
    heap_size: 0,
    semi_space: 0
  },
  'claude-desktop': { 
    percentage: 13, 
    heap_size: 0,
    semi_space: 0
  }
};

// Thread Pool Allocation
const THREAD_POOL = {
  'filesystem': Math.ceil(HARDWARE.total_cores * 0.8),    // I/O heavy
  'git-local': Math.ceil(HARDWARE.total_cores * 0.8),     // Balanced
  'notion': Math.ceil(HARDWARE.total_cores * 0.75),       // Balanced
  'anchor-manager': Math.ceil(HARDWARE.total_cores * 0.5), // Lightweight
  'sqlite': Math.ceil(HARDWARE.total_cores * 0.5),        // CPU heavy
  'slack': Math.ceil(HARDWARE.total_cores * 0.375)        // Network heavy
};

// Socket optimization parameters
const SOCKET_OPTIMIZATION = {
  buffer_size: 1024 * 1024,  // 1MB buffer size
  keep_alive: true,
  keep_alive_interval: 60000, // 60 seconds
  no_delay: true,
  backlog: 512
};

// =========================================================================
// Utility Functions
// =========================================================================

// Terminal colors for console output
const COLORS = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  dim: '\x1b[2m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m'
};

/**
 * Pretty print formatted message
 */
function printHeader(message) {
  const width = process.stdout.columns || 80;
  const padding = '='.repeat(Math.max(0, (width - message.length - 4) / 2));
  console.log(`\n${COLORS.bright}${COLORS.blue}${padding} ${message} ${padding}${COLORS.reset}`);
}

/**
 * Print success message
 */
function printSuccess(message) {
  console.log(`${COLORS.green}✓ ${message}${COLORS.reset}`);
}

/**
 * Print warning message
 */
function printWarning(message) {
  console.log(`${COLORS.yellow}! ${message}${COLORS.reset}`);
}

/**
 * Print error message
 */
function printError(message) {
  console.log(`${COLORS.red}× ${message}${COLORS.reset}`);
}

/**
 * Print info message
 */
function printInfo(message) {
  console.log(`${COLORS.cyan}• ${message}${COLORS.reset}`);
}

/**
 * Format bytes to human readable string
 */
function formatBytes(bytes, decimals = 2) {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

/**
 * Ensure a directory exists
 */
function ensureDirectoryExists(dirPath) {
  try {
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true });
      printSuccess(`Created directory: ${dirPath}`);
    }
  } catch (error) {
    printError(`Failed to create directory ${dirPath}: ${error.message}`);
  }
}

/**
 * Read JSON file with error handling
 */
function readJsonFile(filePath) {
  try {
    if (fs.existsSync(filePath)) {
      return JSON.parse(fs.readFileSync(filePath, 'utf8'));
    }
    return null;
  } catch (error) {
    printError(`Failed to read or parse JSON file ${filePath}: ${error.message}`);
    return null;
  }
}

/**
 * Write JSON file with error handling
 */
function writeJsonFile(filePath, data) {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
    printSuccess(`Successfully wrote to ${filePath}`);
    return true;
  } catch (error) {
    printError(`Failed to write JSON file ${filePath}: ${error.message}`);
    return false;
  }
}

// =========================================================================
// Main Optimization Functions
// =========================================================================

/**
 * Calculate memory allocations based on system memory
 */
function calculateMemoryAllocation() {
  // Calculate memory allocations
  let total = 0;
  for (const [server, allocation] of Object.entries(MEMORY_ALLOCATION)) {
    // Calculate MB based on percentage
    const memoryMb = Math.floor((allocation.percentage / 100) * TOTAL_MEMORY_ALLOCATION * 1024);
    MEMORY_ALLOCATION[server].heap_size = memoryMb;
    MEMORY_ALLOCATION[server].semi_space = Math.max(16, Math.floor(memoryMb / 128));
    total += allocation.percentage;
  }
  
  // Validate total adds up to 100%
  if (total !== 100) {
    printWarning(`Memory allocation percentages total ${total}%, not 100%`);
  }
  
  return MEMORY_ALLOCATION;
}

/**
 * Create enhanced Claude configuration
 */
function createEnhancedConfig() {
  // Calculate memory allocations
  const memoryAllocation = calculateMemoryAllocation();
  
  // Read existing configuration if available
  const existingConfig = readJsonFile(PATHS.claude_config) || { mcpServers: {} };
  
  // Create enhanced configuration
  const enhancedConfig = {
    mcpServers: {
      // Filesystem server
      "filesystem": {
        "command": "npx",
        "args": [
          "-y",
          "@modelcontextprotocol/server-filesystem",
          "/Users/XPV/Desktop",
          "/Users/XPV/Library",
          "/Users/XPV/Documents"
        ],
        "env": {
          "NODE_OPTIONS": `--max-old-space-size=${memoryAllocation.filesystem.heap_size} --max-semi-space-size=${memoryAllocation.filesystem.semi_space}`,
          "UV_THREADPOOL_SIZE": String(THREAD_POOL.filesystem),
          "MCP_BATCH_SIZE": "512",
          "MCP_READ_BUFFER_SIZE": String(SOCKET_OPTIMIZATION.buffer_size),
          "MCP_PERFORMANCE_MODE": "high",
          "APPLE_PTHREAD_HIGH_PERFORMANCE_DEFAULT": "1"
        }
      },
      
      // Git Local server
      "git-local": {
        "command": "node",
        "args": [
          `${PATHS.mcp_dir}/git-local-optimized.js`
        ],
        "socketPath": `${PATHS.socket_dir}/git-local.sock`,
        "env": {
          "NODE_OPTIONS": `--max-old-space-size=${memoryAllocation['git-local'].heap_size} --max-semi-space-size=${memoryAllocation['git-local'].semi_space}`,
          "UV_THREADPOOL_SIZE": String(THREAD_POOL['git-local']),
          "ANCHOR_HOME": PATHS.anchor_home,
          "SOCKET_DIR": PATHS.socket_dir,
          "LOG_DIR": PATHS.log_dir,
          "LOG_LEVEL": "INFO",
          "GIT_CONFIG_PARAMETERS": "'pack.threads=12' 'pack.windowMemory=1g' 'core.bigFileThreshold=1m'",
          "MCP_SOCKET_BUFFER_SIZE": String(SOCKET_OPTIMIZATION.buffer_size)
        },
        "autoApprove": ["git_status", "git_version"]
      },
      
      // Notion server
      "notion": {
        "command": "node",
        "args": [
          `${PATHS.mcp_dir}/notion-v5-wrapper.js`
        ],
        "socketPath": `${PATHS.socket_dir}/notion.sock`,
        "env": {
          "NODE_OPTIONS": `--max-old-space-size=${memoryAllocation.notion.heap_size} --max-semi-space-size=${memoryAllocation.notion.semi_space} --experimental-worker`,
          "UV_THREADPOOL_SIZE": String(THREAD_POOL.notion),
          "ANCHOR_HOME": PATHS.anchor_home,
          "SOCKET_DIR": PATHS.socket_dir,
          "LOG_DIR": PATHS.log_dir,
          "NOTION_API_TOKEN": "${NOTION_API_TOKEN}",
          "NOTION_PARALLEL_REQUESTS": "12",
          "NOTION_CACHE_TTL": "600",
          "NOTION_CACHE_DIR": `${PATHS.anchor_home}/data/notion-cache`,
          "SOCKET_BUFFER_SIZE": String(SOCKET_OPTIMIZATION.buffer_size),
          "LOG_LEVEL": "INFO"
        },
        "autoApprove": ["notion_search", "notion_get_database"]
      },
      
      // Anchor Manager server
      "anchor-manager": {
        "command": "node",
        "args": [
          `${PATHS.mcp_dir}/anchor-manager-optimized.js`
        ],
        "socketPath": `${PATHS.socket_dir}/anchor-manager.sock`,
        "env": {
          "NODE_OPTIONS": `--max-old-space-size=${memoryAllocation['anchor-manager'].heap_size} --max-semi-space-size=${memoryAllocation['anchor-manager'].semi_space}`,
          "UV_THREADPOOL_SIZE": String(THREAD_POOL['anchor-manager']),
          "ANCHOR_HOME": PATHS.anchor_home,
          "SOCKET_DIR": PATHS.socket_dir,
          "LOG_DIR": PATHS.log_dir,
          "LOG_LEVEL": "INFO",
          "MCP_SERVER_NAME": "anchor-manager",
          "EVENT_LOOP_DELAY_THRESHOLD": "100"
        },
        "autoApprove": ["anchor_status", "anchor_health"]
      },
      
      // SQLite server (if present in original config)
      "sqlite": {
        "command": "node",
        "args": [
          `${PATHS.mcp_dir}/sqlite-wrapper.js`
        ],
        "socketPath": `${PATHS.socket_dir}/sqlite.sock`,
        "env": {
          "NODE_OPTIONS": `--max-old-space-size=${memoryAllocation.sqlite.heap_size} --max-semi-space-size=${memoryAllocation.sqlite.semi_space}`,
          "UV_THREADPOOL_SIZE": String(THREAD_POOL.sqlite),
          "ANCHOR_HOME": PATHS.anchor_home,
          "SOCKET_DIR": PATHS.socket_dir,
          "DATA_DIR": `${PATHS.anchor_home}/data/sqlite`,
          "LOG_DIR": PATHS.log_dir,
          "LOG_LEVEL": "INFO",
          "SQLITE_PRAGMA_CONFIG": "journal_mode=WAL;synchronous=NORMAL;temp_store=MEMORY;mmap_size=8589934592;cache_size=-131072"
        },
        "autoApprove": ["sqlite_list_tables", "sqlite_table_info", "sqlite_query"]
      },
      
      // Slack server (if present in original config)
      "slack": {
        "command": "node",
        "args": [
          `${PATHS.mcp_dir}/slack-wrapper.js`
        ],
        "socketPath": `${PATHS.socket_dir}/slack.sock`,
        "env": {
          "NODE_OPTIONS": `--max-old-space-size=${memoryAllocation.slack.heap_size} --max-semi-space-size=${memoryAllocation.slack.semi_space}`,
          "UV_THREADPOOL_SIZE": String(THREAD_POOL.slack),
          "ANCHOR_HOME": PATHS.anchor_home,
          "SOCKET_DIR": PATHS.socket_dir,
          "CACHE_DIR": `${PATHS.anchor_home}/data/slack-cache`,
          "LOG_DIR": PATHS.log_dir,
          "SLACK_BOT_TOKEN": "${SLACK_BOT_TOKEN}",
          "SLACK_USER_TOKEN": "${SLACK_USER_TOKEN}",
          "SLACK_CACHE_DURATION": "3600",
          "LOG_LEVEL": "INFO"
        },
        "autoApprove": ["slack_list_conversations", "slack_search_messages"]
      }
    },
    
    // Server adapter configuration
    "mcpServerAdapter": {
      "enabled": true,
      "adapterPath": `${PATHS.mcp_dir}/mcp-adapter.js`,
      "preferredImplementations": {
        "git": "git-local",
        "notion": "notion"
      },
      "cachingEnabled": true,
      "cacheTTLs": {
        "git_status": 60,
        "git_version": 86400,
        "notion_search": 300,
        "notion_get_database": 3600,
        "notion_get_page": 3600,
        "slack_list_conversations": 300,
        "slack_user_info": 3600,
        "slack_conversation_history": 60,
        "sqlite_table_info": 86400,
        "anchor_status": 5
      },
      "performanceMetrics": {
        "enabled": true,
        "reportingInterval": 3600000,
        "collection": {
          "memoryUsage": true,
          "responseTime": true,
          "errorRate": true,
          "requestCount": true
        }
      },
      "errorHandling": {
        "retryEnabled": true,
        "fallbackEnabled": true,
        "maxRetries": 3,
        "retryDelayMs": 500,
        "useExponentialBackoff": true
      }
    },
    
    // Path configuration
    "paths": {
      "anchorHome": PATHS.anchor_home,
      "mcp": {
        "servers": PATHS.mcp_dir,
        "sockets": PATHS.socket_dir,
        "data": `${PATHS.anchor_home}/data`,
        "logs": PATHS.log_dir
      }
    },
    
    // Hardware optimization
    "hardwareOptimization": {
      "device": "M3 Max",
      "memory": `${HARDWARE.memory_gb}GB`,
      "performanceCores": HARDWARE.performance_cores,
      "efficiencyCores": HARDWARE.efficiency_cores,
      "nodeHeapSize": memoryAllocation['claude-desktop'].heap_size,
      "threadPoolSize": HARDWARE.total_cores,
      "metalPerformanceShadersEnabled": true,
      "neuralEngineEnabled": true,
      "unifiedMemoryAllocation": {
        "filesystem": memoryAllocation.filesystem.heap_size,
        "git-local": memoryAllocation['git-local'].heap_size,
        "notion": memoryAllocation.notion.heap_size,
        "anchor-manager": memoryAllocation['anchor-manager'].heap_size,
        "sqlite": memoryAllocation.sqlite.heap_size,
        "slack": memoryAllocation.slack.heap_size
      },
      "taskDistribution": {
        "io-intensive": "efficiencyCores",
        "compute-intensive": "performanceCores",
        "mixed-workload": "all"
      }
    },
    
    // Socket optimization
    "socketOptimization": {
      "bufferSize": SOCKET_OPTIMIZATION.buffer_size,
      "keepAlive": SOCKET_OPTIMIZATION.keep_alive,
      "keepAliveInterval": SOCKET_OPTIMIZATION.keep_alive_interval,
      "noDelay": SOCKET_OPTIMIZATION.no_delay,
      "backlog": SOCKET_OPTIMIZATION.backlog,
      "retryOnError": true,
      "maxRetries": 5,
      "retryDelay": 1000
    }
  };
  
  // Create enhanced configuration file
  return writeJsonFile(PATHS.enhanced_config, enhancedConfig);
}

/**
 * Check for Metal Performance Shaders support
 */
function checkMetalSupport() {
  try {
    execSync('system_profiler SPDisplaysDataType | grep Metal');
    printSuccess('Metal Performance Shaders support detected');
    printInfo('JavaScript operations that can use GPU acceleration will be offloaded');
    printInfo('Tensor operations optimized for Neural Engine');
    return true;
  } catch (e) {
    printWarning('Metal Performance Shaders not detected - using CPU only mode');
    return false;
  }
}

/**
 * Update .env file with optimized settings
 */
function updateEnvironmentFile() {
  const memoryAllocation = calculateMemoryAllocation();
  
  // Create .env file content
  const envContent = `# M3 Max Optimized Settings
# Generated: ${new Date().toISOString()}
# For: ${HARDWARE.memory_gb}GB M3 Max with ${HARDWARE.total_cores} cores

# Node.js Memory Settings
export NODE_OPTIONS="--max-old-space-size=${memoryAllocation['claude-desktop'].heap_size} --max-semi-space-size=${memoryAllocation['claude-desktop'].semi_space}"

# Thread Pool Configuration
export UV_THREADPOOL_SIZE="${HARDWARE.total_cores}"

# Environment Variables
export ANCHOR_HOME="${PATHS.anchor_home}"
export MCP_DIR="${PATHS.mcp_dir}"
export SOCKET_DIR="${PATHS.socket_dir}"

# System paths
export LOG_DIR="${PATHS.log_dir}"
export CONFIG_DIR="${PATHS.config_dir}"

# M3 Specific Settings
export M3_OPTIMIZED=true
export M3_MEMORY_ALLOCATION="${TOTAL_MEMORY_ALLOCATION}GB"
export M3_CORE_COUNT="${HARDWARE.total_cores}"
export APPLE_PTHREAD_HIGH_PERFORMANCE_DEFAULT="1"
`;

  try {
    fs.writeFileSync(`${PATHS.anchor_home}/.env`, envContent);
    printSuccess(`Created optimized .env file at: ${PATHS.anchor_home}/.env`);
    return true;
  } catch (error) {
    printError(`Failed to write .env file: ${error.message}`);
    return false;
  }
}

/**
 * Create a launcher script for optimized servers
 */
function createLauncherScript() {
  const launcherPath = `${PATHS.anchor_home}/launch-enhanced-mcp.sh`;
  const optimizerPath = `${PATHS.anchor_home}/m3-optimizer/optimize.sh`;
  
  try {
    // Check if the launcher already exists (created by previous run)
    if (fs.existsSync(launcherPath)) {
      printInfo(`Launcher script already exists at: ${launcherPath}`);
      return true;
    }
    
    // Run the launcher creation from enhanced-config.json
    execSync(`node -e "require('fs').copyFileSync('${launcherPath}', '${launcherPath}.bak')" || true`);
    printInfo('Creating optimized launcher script');
    
    // Create a simple launcher that executes the main launcher
    const optimizerContent = `#!/bin/bash
# M3 Max Optimizer for MCP Servers
# Generated: ${new Date().toISOString()}

cd "${PATHS.anchor_home}" || exit 1
source .env

# Run node optimizer
node "${PATHS.anchor_home}/m3-optimizer/m3_optimizer.js"

# Apply optimizations and launch servers
"${PATHS.anchor_home}/launch-enhanced-mcp.sh"
`;
    
    fs.writeFileSync(optimizerPath, optimizerContent);
    fs.chmodSync(optimizerPath, 0o755);
    printSuccess(`Created optimizer script at: ${optimizerPath}`);
    
    return true;
  } catch (error) {
    printError(`Failed to create launcher script: ${error.message}`);
    return false;
  }
}

/**
 * Detect hardware capabilities
 */
function detectHardware() {
  printHeader('Hardware Detection');
  
  // Detect CPU
  const cpuInfo = os.cpus();
  const cpuModel = cpuInfo[0].model;
  const cores = cpuInfo.length;
  
  printInfo(`CPU: ${cpuModel}`);
  printInfo(`Cores: ${cores} (${HARDWARE.performance_cores} performance, ${HARDWARE.efficiency_cores} efficiency)`);
  printInfo(`Memory: ${HARDWARE.memory_gb}GB unified memory`);
  printInfo(`Memory Bandwidth: ${HARDWARE.memory_bandwidth_gbps}GB/s`);
  printInfo(`GPU Cores: ${HARDWARE.gpu_cores}`);
  printInfo(`Neural Engine Cores: ${HARDWARE.neural_engine_cores}`);
  
  // Check for Metal Performance Shaders
  const metalSupport = checkMetalSupport();
  
  // Calculate recommended memory allocation
  printInfo(`Allocating ${TOTAL_MEMORY_ALLOCATION}GB (${Math.round(TOTAL_MEMORY_ALLOCATION * 100 / HARDWARE.memory_gb)}%) for MCP servers`);
  
  return {
    model: cpuModel,
    cores,
    memory: HARDWARE.memory_gb,
    metal: metalSupport
  };
}

/**
 * Apply optimizations and print summary
 */
function optimizeSystem() {
  // Ensure required directories exist
  ensureDirectoryExists(PATHS.socket_dir);
  ensureDirectoryExists(PATHS.log_dir);
  ensureDirectoryExists(PATHS.config_dir);
  ensureDirectoryExists(`${PATHS.anchor_home}/data`);
  ensureDirectoryExists(`${PATHS.anchor_home}/data/sqlite`);
  ensureDirectoryExists(`${PATHS.anchor_home}/data/notion-cache`);
  ensureDirectoryExists(`${PATHS.anchor_home}/data/slack-cache`);
  
  // Generate enhanced configuration
  printHeader('Creating Enhanced Configuration');
  
  // Calculate memory allocation
  const memoryAllocation = calculateMemoryAllocation();
  
  // Display memory allocation
  console.log('\nMemory Allocation:');
  console.log('-'.repeat(60));
  console.log(`${'Server'.padEnd(20)} ${'Heap Size'.padEnd(15)} ${'Semi Space'.padEnd(15)} ${'Percentage'.padEnd(10)}`);
  console.log('-'.repeat(60));
  
  let totalHeap = 0;
  for (const [server, allocation] of Object.entries(memoryAllocation)) {
    console.log(`${server.padEnd(20)} ${formatBytes(allocation.heap_size * 1024 * 1024).padEnd(15)} ${formatBytes(allocation.semi_space * 1024 * 1024).padEnd(15)} ${allocation.percentage.toString().padEnd(10)}`);
    totalHeap += allocation.heap_size;
  }
  
  console.log('-'.repeat(60));
  console.log(`${'TOTAL'.padEnd(20)} ${formatBytes(totalHeap * 1024 * 1024).padEnd(15)} ${' '.padEnd(15)} ${'100'.padEnd(10)}`);
  console.log('-'.repeat(60));
  
  // Create enhanced configuration
  createEnhancedConfig();
  
  // Update environment file
  printHeader('Updating Environment Configuration');
  updateEnvironmentFile();
  
  // Create launcher script
  printHeader('Creating Launcher Script');
  createLauncherScript();
  
  // Print summary and next steps
  printHeader('Optimization Complete');
  printSuccess('M3 Max optimizations have been applied to MCP server configuration');
  printSuccess(`Enhanced configuration saved to: ${PATHS.enhanced_config}`);
  printSuccess(`Environment configuration saved to: ${PATHS.anchor_home}/.env`);
  
  console.log('\nNext Steps:');
  printInfo(`1. Run the enhanced launcher: ${PATHS.anchor_home}/launch-enhanced-mcp.sh`);
  printInfo(`2. Restart Claude Desktop to connect to the optimized MCP servers`);
  printInfo(`3. Verify MCP server status: ${PATHS.mcp_dir}/verify-servers.sh`);
}

// =========================================================================
// Main Execution
// =========================================================================

console.log(`${COLORS.bright}${COLORS.blue}┌───────────────────────────────────────────────────────┐${COLORS.reset}`);
console.log(`${COLORS.bright}${COLORS.blue}│       M3 Max MCP Server Optimizer (v1.0.0)            │${COLORS.reset}`);
console.log(`${COLORS.bright}${COLORS.blue}└───────────────────────────────────────────────────────┘${COLORS.reset}`);
console.log(`${COLORS.cyan}Timestamp: ${new Date().toISOString()}${COLORS.reset}`);
console.log(`${COLORS.cyan}System: ${os.type()} ${os.release()} (${os.arch()})${COLORS.reset}`);

// Run the hardware detection
detectHardware();

// Apply optimizations
optimizeSystem();

// Print completion message
console.log(`\n${COLORS.green}${COLORS.bright}Optimization completed successfully at ${new Date().toISOString()}${COLORS.reset}`);
