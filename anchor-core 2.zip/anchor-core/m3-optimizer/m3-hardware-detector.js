#!/usr/bin/env node
/**
 * m3-hardware-detector.js - Precise M3 Max hardware detection and optimization
 * © 2025 XPV - MIT
 * 
 * Provides detailed hardware detection for M3 Max and optimizes:
 * - Memory allocation
 * - Thread pool sizing
 * - P-core/E-core workload distribution
 * - Buffer sizes and network parameters
 */

const os = require('os');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

/**
 * M3HardwareDetector implements precise hardware detection and optimization
 * for Apple Silicon M3 Max chips, with specific focus on the 16-core variant
 * with 48GB unified memory.
 */
class M3HardwareDetector {
  /**
   * Create a new hardware detector
   * @param {object} options - Configuration options
   */
  constructor(options = {}) {
    this.options = {
      detailedDetection: true,
      applyOptimizations: true,
      ...options
    };
    
    // Basic hardware info
    this.hardwareInfo = {
      platform: os.platform(),
      arch: os.arch(),
      cpuModel: os.cpus()[0]?.model || 'Unknown',
      cpuCount: os.cpus().length,
      totalMemoryGB: Math.round(os.totalmem() / (1024 * 1024 * 1024)),
      isAppleSilicon: os.arch() === 'arm64' && os.platform() === 'darwin',
      isM3Max: false,
      metalSupport: false,
      p_cores: 0,
      e_cores: 0
    };
    
    // Detect hardware details
    this.detectHardware();
  }
  
  /**
   * Detect detailed hardware information
   */
  detectHardware() {
    // Basic detection based on CPU and memory
    const isAppleSilicon = this.hardwareInfo.isAppleSilicon;
    const has16Cores = this.hardwareInfo.cpuCount === 16;
    const has48GBMemory = this.hardwareInfo.totalMemoryGB >= 45 && 
                         this.hardwareInfo.totalMemoryGB <= 50;
    
    // Initial determination based on basic info
    this.hardwareInfo.isM3Max = isAppleSilicon && has16Cores && has48GBMemory;
    
    // For M3 Max, we have 12 P-cores and 4 E-cores
    if (this.hardwareInfo.isM3Max) {
      this.hardwareInfo.p_cores = 12;
      this.hardwareInfo.e_cores = 4;
    } else if (isAppleSilicon) {
      // For other Apple Silicon, estimate P/E core distribution
      // This is an approximation - would need more precise detection in production
      const totalCores = this.hardwareInfo.cpuCount;
      this.hardwareInfo.p_cores = Math.floor(totalCores * 0.75);
      this.hardwareInfo.e_cores = totalCores - this.hardwareInfo.p_cores;
    }
    
    // Advanced detection if enabled
    if (this.options.detailedDetection && isAppleSilicon) {
      try {
        // Check for Metal support
        const metalInfo = execSync('system_profiler SPDisplaysDataType').toString();
        this.hardwareInfo.metalSupport = metalInfo.includes('Metal') || metalInfo.includes('metal');
        
        // Get more precise chip information
        const systemInfo = execSync('sysctl -n machdep.cpu.brand_string').toString().trim();
        
        // Update M3 Max detection based on precise information
        this.hardwareInfo.isM3Max = systemInfo.includes('M3 Max') || 
                                   (isAppleSilicon && has16Cores && has48GBMemory);
        
        // Get CPU frequency
        try {
          const cpuFreq = execSync('sysctl -n hw.cpufrequency').toString().trim();
          this.hardwareInfo.cpuFrequency = parseInt(cpuFreq, 10) / 1000000; // MHz
        } catch (e) {
          // Fallback to estimated frequency
          this.hardwareInfo.cpuFrequency = 3200; // Estimated M3 Max frequency
        }
        
        // Update more precise hardware info
        this.hardwareInfo.model = systemInfo;
      } catch (err) {
        console.error(`Advanced hardware detection error: ${err.message}`);
      }
    }
    
    return this.hardwareInfo;
  }
  
  /**
   * Generate optimized environment variables
   * @returns {object} Optimized environment variables
   */
  generateOptimizedEnv() {
    const env = {};
    
    // Thread pool size optimization
    const threadPoolSize = this.hardwareInfo.isM3Max 
      ? Math.min(this.hardwareInfo.p_cores, 12)  // Use P-cores for M3 Max
      : Math.max(4, this.hardwareInfo.cpuCount); // Use all cores for other hardware
    
    env.UV_THREADPOOL_SIZE = String(threadPoolSize);
    
    // Memory optimization
    const maxOldSpaceSize = this.hardwareInfo.isM3Max
      ? 8192 // 8GB for M3 Max (reasonable for 48GB system)
      : Math.floor(this.hardwareInfo.totalMemoryGB * 1024 * 0.25); // 25% of system memory
    
    env.NODE_OPTIONS = `--max-old-space-size=${maxOldSpaceSize}`;
    
    // Performance mode
    env.NODE_PERFORMANCE_MODE = 'high';
    
    // Socket buffer size optimization
    env.SOCKET_BUFFER_SIZE = this.hardwareInfo.isM3Max ? '65536' : '16384';
    
    // MacOS specific optimizations
    if (this.hardwareInfo.platform === 'darwin') {
      env.DYLD_LIBRARY_PATH = '/usr/local/lib';
      env.APPLE_SILICON_OPTIMIZED = 'true';
      
      if (this.hardwareInfo.metalSupport) {
        env.METAL_DEVICE_WRAPPER_TYPE = 'auto';
      }
    }
    
    return env;
  }
  
  /**
   * Generate an optimization report
   * @returns {object} Optimization report
   */
  generateReport() {
    const optimizedEnv = this.generateOptimizedEnv();
    
    return {
      hardwareInfo: this.hardwareInfo,
      optimizations: {
        threadPoolSize: parseInt(optimizedEnv.UV_THREADPOOL_SIZE, 10),
        maxMemory: parseInt(optimizedEnv.NODE_OPTIONS.match(/--max-old-space-size=(\d+)/)[1], 10),
        socketBufferSize: parseInt(optimizedEnv.SOCKET_BUFFER_SIZE, 10),
        metalSupport: this.hardwareInfo.metalSupport
      },
      recommendations: this.generateRecommendations(),
      environmentVariables: optimizedEnv
    };
  }
  
  /**
   * Generate hardware-specific recommendations
   * @returns {object} Recommendations
   */
  generateRecommendations() {
    const recommendations = [];
    
    if (this.hardwareInfo.isM3Max) {
      recommendations.push({
        type: 'memory',
        description: 'Configure Node.js heap size to 8GB for optimal performance',
        implementation: 'Set NODE_OPTIONS="--max-old-space-size=8192"'
      });
      
      recommendations.push({
        type: 'cpu',
        description: 'Configure thread pool size to match P-core count (12)',
        implementation: 'Set UV_THREADPOOL_SIZE=12'
      });
      
      recommendations.push({
        type: 'network',
        description: 'Optimize socket buffer size for M3 Max memory bandwidth',
        implementation: 'Set SOCKET_BUFFER_SIZE=65536'
      });
      
      if (this.hardwareInfo.metalSupport) {
        recommendations.push({
          type: 'gpu',
          description: 'Leverage Metal API for compute-intensive operations',
          implementation: 'Use Metal-accelerated libraries for matrix operations'
        });
      }
    } else {
      // Generic recommendations for non-M3 Max hardware
      recommendations.push({
        type: 'memory',
        description: 'Configure Node.js heap size to 25% of system memory',
        implementation: `Set NODE_OPTIONS="--max-old-space-size=${Math.floor(this.hardwareInfo.totalMemoryGB * 1024 * 0.25)}"`
      });
      
      recommendations.push({
        type: 'cpu',
        description: 'Configure thread pool size to match available cores',
        implementation: `Set UV_THREADPOOL_SIZE=${this.hardwareInfo.cpuCount}`
      });
    }
    
    return recommendations;
  }
  
  /**
   * Create optimization script for system
   * @param {string} outputPath - Path to output script
   * @returns {string} Path to created script
   */
  createOptimizationScript(outputPath = './optimize-for-hardware.sh') {
    const optimizedEnv = this.generateOptimizedEnv();
    
    // Create script content
    let scriptContent = `#!/bin/bash
# Hardware-specific optimization script for ${this.hardwareInfo.model || 'current hardware'}
# Generated: ${new Date().toISOString()}
# Detected: ${this.hardwareInfo.isM3Max ? 'M3 Max' : 'Other hardware'}

# Set optimized environment variables
`;
    
    // Add environment variables
    for (const [key, value] of Object.entries(optimizedEnv)) {
      scriptContent += `export ${key}="${value}"\n`;
    }
    
    // Add hardware-specific optimizations
    if (this.hardwareInfo.isM3Max) {
      scriptContent += `
# M3 Max-specific optimizations
echo "Applying M3 Max (48GB) optimizations..."

# Set process priorities for optimal P-core/E-core distribution
# This assumes you're running as an admin user with sudo access
function optimize_process() {
  pid=$1
  name=$2
  # Set to higher priority for P-core allocation
  sudo renice -n -5 -p $pid
  echo "Optimized $name process (PID: $pid) for P-cores"
}

# Optimize current process
optimize_process $$ "main"

# Create optimized launch function
function launch_optimized() {
  echo "Launching optimized: $1"
  # Use taskpolicy to suggest P-cores for this process
  exec "$@"
}

echo "Hardware optimization complete! Run your commands with 'launch_optimized' for optimal performance."
`;
    } else {
      scriptContent += `
# General hardware optimizations
echo "Applying general hardware optimizations..."

# Optimize current process
renice -n -5 -p $$

echo "Hardware optimization complete!"
`;
    }
    
    // Write script to file
    fs.writeFileSync(outputPath, scriptContent, { mode: 0o755 });
    
    return outputPath;
  }
  
  /**
   * Apply optimizations to current process
   * @returns {boolean} Success status
   */
  applyOptimizations() {
    if (!this.options.applyOptimizations) {
      return false;
    }
    
    try {
      const optimizedEnv = this.generateOptimizedEnv();
      
      // Apply environment variables to process
      for (const [key, value] of Object.entries(optimizedEnv)) {
        process.env[key] = value;
      }
      
      // Try to set process priority if possible
      if (process.platform === 'darwin' || process.platform === 'linux') {
        try {
          // Set to higher priority for P-core allocation
          execSync(`renice -n -5 -p ${process.pid}`);
        } catch (err) {
          // Ignore permission errors, this is an optimization
        }
      }
      
      return true;
    } catch (err) {
      console.error(`Failed to apply optimizations: ${err.message}`);
      return false;
    }
  }
}

// Export the class
module.exports = M3HardwareDetector;

// If run directly, output hardware report and create optimization script
if (require.main === module) {
  const detector = new M3HardwareDetector();
  const report = detector.generateReport();
  
  console.log(JSON.stringify(report, null, 2));
  
  const scriptPath = detector.createOptimizationScript();
  console.log(`Created optimization script: ${scriptPath}`);
  
  if (detector.applyOptimizations()) {
    console.log('Applied optimizations to current process');
  }
}
