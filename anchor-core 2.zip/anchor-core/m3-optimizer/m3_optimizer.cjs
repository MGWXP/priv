#!/usr/bin/env node
/**
 * m3_optimizer.cjs – fine-tunes UV_THREADPOOL_SIZE & runs GC watchdogs
 */
process.env.UV_THREADPOOL_SIZE = '12';
if(global.gc){setInterval(()=>{const m=process.memoryUsage();if((m.heapUsed/m.heapTotal)>0.70)global.gc();},30000);}
console.log('✅ M3 optimizer applied – UV_THREADPOOL_SIZE=12, GC watchdog active');
