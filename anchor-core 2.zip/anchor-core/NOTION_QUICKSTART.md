# Notion Integration Quickstart

This file provides a quick guide to get started with the enhanced Notion integration for Claude.

## One-Step Setup

Run this command in your terminal:

```bash
curl -L https://raw.githubusercontent.com/xpv/anchor-core/main/run-notion-quickstart.sh | bash
```

Or if you've already downloaded the files:

```bash
chmod +x /Users/XPV/Desktop/anchor-core/run-notion-quickstart.sh
/Users/XPV/Desktop/anchor-core/run-notion-quickstart.sh
```

## What This Does

The quickstart script:

1. Makes all necessary scripts executable
2. Sets up the Notion integration with SQLite metadata
3. Updates Claude Desktop configuration
4. Starts the MCP servers
5. Offers to open Claude Desktop

## After Setup

Once setup is complete, you can:

1. Launch Claude Desktop
2. Ask Claude to search your Notion workspace, create pages, etc.
3. See NOTION_INTEGRATION_GUIDE.md for detailed usage examples

## Troubleshooting

If you encounter any issues:

1. Check the logs: `tail -f ~/Library/Logs/Claude/mcp-server-notion.log`
2. Restart the servers: `cd /Users/XPV/Desktop/anchor-core && npm run restart`
3. Update your Notion token: Edit `/Users/XPV/Desktop/anchor-core/.env`
