# Archive Candidate Analysis Report

Generated on: Mon May 19 23:31:00 HST 2025
Analysis period: 30 days (since 2025-04-19)
Minimum error threshold: 3 errors

## Error Frequency Analysis

| Component | Error Count | Sample Errors |
|-----------|-------------|---------------|

## Coherence Lock Analysis

| Component | Marker Count | Last Marker Time |
|-----------|--------------|------------------|
| ARCHIVE |        1 | Unknown |
| CNIF |        3 | Unknown |
| mcp-orchestrator |        1 | 2025-05-20T012852 |
| notion |        1 | 2025-05-20T012850 |
| schema-registry |        6 | Unknown |
| SETUP |        2 | Unknown |
| socket-server |        1 | 2025-05-20T012846 |
| streaming-transformer |        1 | 2025-05-20T012848 |

## Recommendations

No archiving candidates found that meet the criteria of 3 errors in the last 30 days.
