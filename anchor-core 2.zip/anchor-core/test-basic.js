/**
 * test-basic.js - Basic Node.js test file
 * Tests basic Node.js functionality to ensure the runtime works
 */

console.log("=== Basic Node.js Test ===");
console.log(`Node.js version: ${process.version}`);
console.log(`Platform: ${process.platform}`);
console.log(`Architecture: ${process.arch}`);
console.log(`Process ID: ${process.pid}`);
console.log(`Current directory: ${process.cwd()}`);
console.log(`Memory usage: ${JSON.stringify(process.memoryUsage())}`);

// Test filesystem operations
const fs = require('fs');
const path = require('path');

// Create a test directory
const testDir = path.join(__dirname, 'test-output');
try {
  if (!fs.existsSync(testDir)) {
    fs.mkdirSync(testDir, { recursive: true });
    console.log(`✅ Successfully created directory: ${testDir}`);
  } else {
    console.log(`✅ Directory already exists: ${testDir}`);
  }
} catch (err) {
  console.error(`❌ Failed to create directory: ${err.message}`);
}

// Write a test file
const testFile = path.join(testDir, 'test-file.txt');
try {
  fs.writeFileSync(testFile, `Test file created at ${new Date().toISOString()}`);
  console.log(`✅ Successfully wrote file: ${testFile}`);
} catch (err) {
  console.error(`❌ Failed to write file: ${err.message}`);
}

// Test socket operations
const net = require('net');
const socketPath = path.join(testDir, 'test-socket.sock');

// Remove existing socket file if it exists
if (fs.existsSync(socketPath)) {
  try {
    fs.unlinkSync(socketPath);
    console.log(`✅ Removed existing socket file: ${socketPath}`);
  } catch (err) {
    console.error(`❌ Failed to remove socket file: ${err.message}`);
  }
}

// Create a test socket server
try {
  const server = net.createServer((socket) => {
    console.log('Client connected');
    
    socket.on('data', (data) => {
      console.log(`Received data: ${data.toString()}`);
      socket.write('Hello from server!');
    });
    
    socket.on('end', () => {
      console.log('Client disconnected');
    });
  });
  
  server.listen(socketPath, () => {
    console.log(`✅ Server listening on ${socketPath}`);
    
    // Set socket permissions
    try {
      fs.chmodSync(socketPath, 0o666);
      console.log(`✅ Set socket permissions to 0666`);
      
      // Check permissions
      const stats = fs.statSync(socketPath);
      const perms = stats.mode & 0o777;
      console.log(`Socket permissions: ${perms.toString(8)}`);
      
      // Test connecting to the socket
      const client = net.createConnection(socketPath, () => {
        console.log('Connected to server!');
        client.write('Hello from client!');
      });
      
      client.on('data', (data) => {
        console.log(`Client received: ${data.toString()}`);
        client.end();
      });
      
      client.on('end', () => {
        console.log('Disconnected from server');
        
        // Close server
        server.close(() => {
          console.log('Server closed');
          
          // Clean up
          if (fs.existsSync(socketPath)) {
            fs.unlinkSync(socketPath);
            console.log(`✅ Removed socket file: ${socketPath}`);
          }
        });
      });
    } catch (err) {
      console.error(`❌ Failed to set socket permissions: ${err.message}`);
    }
  });
  
  server.on('error', (err) => {
    console.error(`❌ Server error: ${err.message}`);
  });
} catch (err) {
  console.error(`❌ Failed to create socket server: ${err.message}`);
}

console.log("=== Basic Test Complete ===");
