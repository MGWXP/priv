# MCP Server Configuration Guide

## ✅ Official MCP Server Implementation

This configuration utilizes official MCP servers instead of custom wrappers:

| Server     | Package                              | Provider                |
|------------|--------------------------------------|-------------------------|
| Filesystem | @modelcontextprotocol/server-filesystem | Anthropic               |
| Git        | github-mcp-server                    | GitHub (with Anthropic) |
| Notion     | @notionhq/notion-mcp-server          | Notion                  |
| Slack      | @modelcontextprotocol/server-slack   | Anthropic               |

## 🔧 Installation Instructions

1. Run the installation script to install all required packages:
   ```bash
   chmod +x /Users/XPV/Desktop/anchor-core/mcp-server-installer.sh
   /Users/XPV/Desktop/anchor-core/mcp-server-installer.sh
   ```

2. Set up API keys for Notion and Slack:
   - For Notion: Create an integration at https://www.notion.so/my-integrations and copy the token
   - For Slack: Create a Slack app at https://api.slack.com/apps and add the required scopes

3. Add the API keys to your environment:
   ```bash
   export NOTION_API_KEY="your_notion_api_key"
   export SLACK_BOT_TOKEN="your_slack_bot_token"
   export SLACK_TEAM_ID="your_slack_team_id"
   ```

4. Restart Claude Desktop to apply the changes

## 📊 Resource Optimization

Configuration has been optimized for M3 Max hardware:
- Memory allocation: 8192MB
- Thread pool size: 12 threads

## 🔄 Troubleshooting

If any servers fail to connect:
1. Verify the package installation with `npm list -g [package-name]`
2. Check that your API keys are correctly set in environment variables
3. Restart Claude Desktop and check the Developer Tools console for errors
