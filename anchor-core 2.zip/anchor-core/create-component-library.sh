#!/bin/bash
# create-component-library.sh - Creates the Component Library database
# For M3 Max (48GB unified memory) hardware

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

NOTION_PAGE_ID="1f7e48c2-bbbd-80df-86ed-d35832916f80"

echo -e "${BLUE}=== Creating Component Library Database in Notion ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e ""

# Check if NOTION_API_KEY is set
if [ -z "${NOTION_API_KEY}" ]; then
    echo -e "${RED}Error: NOTION_API_KEY environment variable is not set${NC}"
    echo -e "Please set your Notion API key first with:"
    echo -e "export NOTION_API_KEY=\"your_notion_api_key\""
    exit 1
fi

# Create the Component Library database
echo -e "${BLUE}Creating Component Library database...${NC}"

RESPONSE=$(curl -s -X POST "https://api.notion.com/v1/databases" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "parent": {
        "type": "page_id",
        "page_id": "'${NOTION_PAGE_ID}'"
    },
    "title": [
        {
            "type": "text",
            "text": {
                "content": "Component Library"
            }
        }
    ],
    "properties": {
        "Comp ID": {
            "title": {}
        },
        "Type": {
            "multi_select": {
                "options": [
                    { "name": "Service", "color": "blue" },
                    { "name": "API", "color": "green" },
                    { "name": "Gateway", "color": "purple" }
                ]
            }
        },
        "Version": {
            "rich_text": {}
        },
        "State": {
            "select": {
                "options": [
                    { "name": "Prod", "color": "green" },
                    { "name": "Beta", "color": "yellow" },
                    { "name": "Deprecated", "color": "red" }
                ]
            }
        },
        "Uptime %": {
            "number": {
                "format": "percent"
            }
        },
        "Health": {
            "select": {
                "options": [
                    { "name": "🟢", "color": "green" },
                    { "name": "🟡", "color": "yellow" },
                    { "name": "🔴", "color": "red" }
                ]
            }
        },
        "Config Blob": {
            "rich_text": {}
        }
    }
}')

echo $RESPONSE

# Extract the database ID from the response
DATABASE_ID=$(echo $RESPONSE | grep -o '"id":"[^"]*"' | sed 's/"id":"//g' | sed 's/"//g')

echo -e "\n${GREEN}✓ Component Library database created successfully!${NC}"
echo -e "${YELLOW}Database ID: ${DATABASE_ID}${NC}"

# Create a sample component entry
echo -e "${BLUE}Creating sample component entry for filesystem-server...${NC}"

curl -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "parent": {
        "database_id": "'"${DATABASE_ID}"'"
    },
    "properties": {
        "Comp ID": {
            "title": [
                {
                    "text": {
                        "content": "CMP-filesystem"
                    }
                }
            ]
        },
        "Type": {
            "multi_select": [
                { "name": "Service" }
            ]
        },
        "Version": {
            "rich_text": [
                {
                    "text": {
                        "content": "1.0.0"
                    }
                }
            ]
        },
        "State": {
            "select": {
                "name": "Prod"
            }
        },
        "Uptime %": {
            "number": 0.995
        },
        "Health": {
            "select": {
                "name": "🟢"
            }
        },
        "Config Blob": {
            "rich_text": [
                {
                    "text": {
                        "content": "{\n  \"command\": \"npx\",\n  \"args\": [\n    \"-y\",\n    \"@modelcontextprotocol/server-filesystem\",\n    \"/Users/XPV/Desktop\",\n    \"/Users/XPV/Library\",\n    \"/Users/XPV/Documents\"\n  ],\n  \"env\": {\n    \"NODE_OPTIONS\": \"--max-old-space-size=8192\",\n    \"UV_THREADPOOL_SIZE\": \"12\"\n  }\n}"
                    }
                }
            ]
        }
    }
}'

echo -e "\n${GREEN}✓ Sample component entry created successfully!${NC}"

# Create another component entry for the git-local MCP server
echo -e "${BLUE}Creating sample component entry for git-local server...${NC}"

curl -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "parent": {
        "database_id": "'"${DATABASE_ID}"'"
    },
    "properties": {
        "Comp ID": {
            "title": [
                {
                    "text": {
                        "content": "CMP-git-local"
                    }
                }
            ]
        },
        "Type": {
            "multi_select": [
                { "name": "Service" },
                { "name": "API" }
            ]
        },
        "Version": {
            "rich_text": [
                {
                    "text": {
                        "content": "1.0.0"
                    }
                }
            ]
        },
        "State": {
            "select": {
                "name": "Prod"
            }
        },
        "Uptime %": {
            "number": 0.985
        },
        "Health": {
            "select": {
                "name": "🟡"
            }
        },
        "Config Blob": {
            "rich_text": [
                {
                    "text": {
                        "content": "{\n  \"command\": \"npx\",\n  \"args\": [\n    \"-y\",\n    \"github-mcp-server\"\n  ],\n  \"env\": {\n    \"NODE_OPTIONS\": \"--max-old-space-size=8192\",\n    \"UV_THREADPOOL_SIZE\": \"12\"\n  }\n}"
                    }
                }
            ]
        }
    }
}'

echo -e "\n${GREEN}✓ Second component entry created successfully!${NC}"

# Create a component entry for the notion MCP server
echo -e "${BLUE}Creating sample component entry for notion server...${NC}"

curl -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "parent": {
        "database_id": "'"${DATABASE_ID}"'"
    },
    "properties": {
        "Comp ID": {
            "title": [
                {
                    "text": {
                        "content": "CMP-notion"
                    }
                }
            ]
        },
        "Type": {
            "multi_select": [
                { "name": "API" }
            ]
        },
        "Version": {
            "rich_text": [
                {
                    "text": {
                        "content": "1.0.0"
                    }
                }
            ]
        },
        "State": {
            "select": {
                "name": "Prod"
            }
        },
        "Uptime %": {
            "number": 0.998
        },
        "Health": {
            "select": {
                "name": "🟢"
            }
        },
        "Config Blob": {
            "rich_text": [
                {
                    "text": {
                        "content": "{\n  \"command\": \"npx\",\n  \"args\": [\n    \"-y\",\n    \"@notionhq/notion-mcp-server\"\n  ],\n  \"env\": {\n    \"NODE_OPTIONS\": \"--max-old-space-size=8192\",\n    \"UV_THREADPOOL_SIZE\": \"12\",\n    \"OPENAPI_MCP_HEADERS\": \"{\\\"Authorization\\\": \\\"Bearer ${NOTION_API_KEY}\\\", \\\"Notion-Version\\\": \\\"2022-06-28\\\" }\"\n  }\n}"
                    }
                }
            ]
        }
    }
}'

echo -e "\n${GREEN}✓ Notion component entry created successfully!${NC}"

# Save the database ID to a local file for future reference
echo -e "${BLUE}Saving database ID for future reference...${NC}"
echo "${DATABASE_ID}" > /Users/XPV/Desktop/anchor-core/component-library-db-id.txt

echo -e "\n${GREEN}✓ Component Library setup complete!${NC}"
echo -e "${YELLOW}View your database at: https://www.notion.so/${DATABASE_ID}${NC}"
