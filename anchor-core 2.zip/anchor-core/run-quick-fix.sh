chmod +x /Users/XPV/Desktop/anchor-core/make-quick-fix-executable.sh
/Users/XPV/Desktop/anchor-core/make-quick-fix-executable.sh
