#!/bin/bash
# Run this script to execute the complete CNIF fix
chmod +x /Users/XPV/Desktop/anchor-core/cnif-complete-fix.sh
/Users/XPV/Desktop/anchor-core/cnif-complete-fix.sh
