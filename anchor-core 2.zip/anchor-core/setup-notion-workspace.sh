#!/bin/bash
# Setup the Anchor workspace in Notion

chmod +x /Users/XPV/Desktop/anchor-core/notion-workspace-creator.sh
/Users/XPV/Desktop/anchor-core/notion-workspace-creator.sh

# Open the Notion page in the default browser
open "https://www.notion.so/Anchor-1f7e48c2bbbd80df86edd35832916f80"
