/**
 * cnif-module-fixer.js - Fix module system issues for Claude-Notion Integration Framework
 * © 2025 XPV - MIT
 * 
 * This script fixes issues with the Node.js module system in CNIF:
 * 1. Updates package.json to explicitly set "type": "commonjs"
 * 2. Fixes malformed schema-registry.js file
 * 3. Creates .cjs versions of each server module for compatibility
 */

const fs = require('fs');
const path = require('path');

// Base paths
const ANCHOR_HOME = '/Users/XPV/Desktop/anchor-core';
const MCP_DIR = path.join(ANCHOR_HOME, 'mcp-servers');
const LOG_DIR = path.join('/Users/XPV/Library/Logs/Claude');

console.log('='.repeat(50));
console.log('CNIF Module System Fixer');
console.log('='.repeat(50));

// 1. Update package.json
console.log('\n[1/3] Updating package.json to use CommonJS...');
try {
  const packageJsonPath = path.join(ANCHOR_HOME, 'package.json');
  const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
  
  // Add explicit type: "commonjs" to package.json
  packageJson.type = 'commonjs';
  
  // Make sure we have all required directories
  if (!packageJson.directories) {
    packageJson.directories = {
      bin: './bin',
      lib: './lib',
      data: './data',
      mcp: './mcp-servers'
    };
  }
  
  // Write updated package.json
  fs.writeFileSync(packageJsonPath, JSON.stringify(packageJson, null, 2));
  console.log('✅ Successfully updated package.json');
} catch (err) {
  console.error(`❌ Failed to update package.json: ${err.message}`);
  process.exit(1);
}

// 2. Fix schema-registry.js
console.log('\n[2/3] Fixing schema-registry.js...');
try {
  const schemaRegistryPath = path.join(MCP_DIR, 'schema-registry.js');
  let schemaRegistryContent = fs.readFileSync(schemaRegistryPath, 'utf8');
  
  // Check if file appears to have duplicate class definition
  if (schemaRegistryContent.includes('getAllSchemas(type)') && 
      schemaRegistryContent.includes('class SchemaRegistry extends EventEmitter')) {
    
    console.log('Detected malformed schema-registry.js, fixing...');
    
    // Create proper schema-registry.js content
    const fixedContent = `/**
 * schema-registry.js - Schema version management for Claude-Notion integration
 * © 2025 XPV - MIT
 * 
 * Implements a versioned schema registry for Claude-Notion integration
 * with SchemaVer versioning (MODEL-REVISION-ADDITION) and validation.
 */

const fs = require('fs');
const path = require('path');
const EventEmitter = require('events');

/**
 * Schema Registry manages schema versioning and lookup
 * Using SchemaVer approach (MODEL-REVISION-ADDITION)
 */
class SchemaRegistry extends EventEmitter {
  /**
   * Create a new SchemaRegistry
   * @param {object} options - Registry options
   */
  constructor(options = {}) {
    super();
    
    this.options = {
      schemaDirClaude: path.join(process.cwd(), 'schemas', 'claude'),
      schemaDirNotion: path.join(process.cwd(), 'schemas', 'notion'),
      cacheEnabled: true,
      validateOnLoad: true,
      ...options
    };
    
    this.claudeSchemas = new Map();
    this.notionSchemas = new Map();
    this.schemaVersions = {
      claude: new Map(),
      notion: new Map()
    };
    
    this.initialized = false;
  }
  
  /**
   * Initialize the registry
   * Loads all schemas from disk
   * @returns {Promise<boolean>} Success status
   */
  async initialize() {
    try {
      // Create schema directories if they don't exist
      await this._ensureDirectory(this.options.schemaDirClaude);
      await this._ensureDirectory(this.options.schemaDirNotion);
      
      // Load Claude schemas
      await this._loadSchemas('claude', this.options.schemaDirClaude, this.claudeSchemas);
      
      // Load Notion schemas
      await this._loadSchemas('notion', this.options.schemaDirNotion, this.notionSchemas);
      
      this.initialized = true;
      this.emit('initialized');
      
      return true;
    } catch (err) {
      this.emit('error', err);
      throw err;
    }
  }
  
  /**
   * Ensure directory exists
   * @param {string} dir - Directory path
   * @private
   */
  async _ensureDirectory(dir) {
    try {
      await fs.promises.mkdir(dir, { recursive: true });
    } catch (err) {
      // Ignore if directory already exists
      if (err.code !== 'EEXIST') {
        throw err;
      }
    }
  }
  
  /**
   * Load schemas from directory
   * @param {string} type - Schema type ('claude' or 'notion')
   * @param {string} dir - Directory path
   * @param {Map} targetMap - Target map to store schemas
   * @private
   */
  async _loadSchemas(type, dir, targetMap) {
    try {
      const files = await fs.promises.readdir(dir);
      
      for (const file of files) {
        if (path.extname(file) === '.json') {
          try {
            const schemaPath = path.join(dir, file);
            const schema = JSON.parse(await fs.promises.readFile(schemaPath, 'utf8'));
            
            // Validate schema structure
            if (this.options.validateOnLoad && !this._validateSchemaStructure(schema)) {
              console.warn(`Invalid schema structure: ${schemaPath}`);
              continue;
            }
            
            // Extract schema ID and version
            const { id, version } = schema;
            
            if (!id || !version) {
              console.warn(`Schema missing id or version: ${schemaPath}`);
              continue;
            }
            
            // Store schema
            targetMap.set(id, schema);
            
            // Update version map
            if (!this.schemaVersions[type].has(id)) {
              this.schemaVersions[type].set(id, []);
            }
            
            const versions = this.schemaVersions[type].get(id);
            versions.push(version);
            
            // Sort versions in descending order (latest first)
            versions.sort((a, b) => this._compareVersions(b, a));
            
            this.emit('schema-loaded', { type, id, version, path: schemaPath });
          } catch (err) {
            console.error(`Error loading schema ${file}: ${err.message}`);
          }
        }
      }
    } catch (err) {
      console.error(`Error reading schema directory ${dir}: ${err.message}`);
      throw err;
    }
  }
  
  /**
   * Compare SchemaVer versions (MODEL-REVISION-ADDITION)
   * @param {string} v1 - First version string
   * @param {string} v2 - Second version string
   * @returns {number} Comparison result (-1, 0, 1)
   * @private
   */
  _compareVersions(v1, v2) {
    const parse = (v) => {
      const parts = v.split('-').map(Number);
      return { model: parts[0] || 0, revision: parts[1] || 0, addition: parts[2] || 0 };
    };
    
    const a = parse(v1);
    const b = parse(v2);
    
    if (a.model !== b.model) return a.model - b.model;
    if (a.revision !== b.revision) return a.revision - b.revision;
    return a.addition - b.addition;
  }
  
  /**
   * Validate schema structure
   * @param {object} schema - Schema to validate
   * @returns {boolean} Validation result
   * @private
   */
  _validateSchemaStructure(schema) {
    // Basic structure validation
    if (!schema || typeof schema !== 'object') return false;
    if (!schema.id || typeof schema.id !== 'string') return false;
    if (!schema.version || typeof schema.version !== 'string') return false;
    if (!schema.description || typeof schema.description !== 'string') return false;
    if (!schema.schema || typeof schema.schema !== 'object') return false;
    
    // Validate version format (MODEL-REVISION-ADDITION)
    const versionRegex = /^\d+-\d+-\d+$/;
    if (!versionRegex.test(schema.version)) {
      console.warn(`Invalid SchemaVer format for ${schema.id}: ${schema.version}. Expected MODEL-REVISION-ADDITION format.`);
      return false;
    }
    
    // Validate schema has required 'type' field
    if (!schema.schema.type) {
      console.warn(`Schema ${schema.id}@${schema.version} missing 'type' field`);
      return false;
    }
    
    return true;
  }
  
  /**
   * Get a schema by ID and version
   * @param {string} type - Schema type ('claude' or 'notion')
   * @param {string} id - Schema ID
   * @param {string} [version] - Schema version (optional, uses latest if not specified)
   * @returns {object|null} Schema or null if not found
   */
  getSchema(type, id, version) {
    if (!this.initialized) {
      throw new Error('Schema registry not initialized');
    }
    
    const schemaMap = type === 'claude' ? this.claudeSchemas : this.notionSchemas;
    
    if (!schemaMap.has(id)) {
      return null;
    }
    
    const schema = schemaMap.get(id);
    
    if (!version) {
      return schema;
    }
    
    // If specific version requested, we need to load it from disk
    // This implementation assumes schemas are stored with version in filename
    const schemaDir = type === 'claude' ? this.options.schemaDirClaude : this.options.schemaDirNotion;
    const schemaPath = path.join(schemaDir, `${id}-${version}.json`);
    
    try {
      const versionedSchema = JSON.parse(fs.readFileSync(schemaPath, 'utf8'));
      return versionedSchema;
    } catch (err) {
      console.error(`Error loading schema version ${id}@${version}: ${err.message}`);
      return null;
    }
  }
  
  /**
   * Get latest schema version by type and ID
   * @param {string} type - Schema type ('claude' or 'notion')
   * @param {string} id - Schema ID
   * @returns {string|null} Latest version or null if not found
   */
  getLatestVersion(type, id) {
    if (!this.initialized) {
      throw new Error('Schema registry not initialized');
    }
    
    if (!this.schemaVersions[type] || !this.schemaVersions[type].has(id)) {
      return null;
    }
    
    const versions = this.schemaVersions[type].get(id);
    return versions[0] || null; // First version is the latest (sorted in descending order)
  }
  
  /**
   * Register a new schema
   * @param {string} type - Schema type ('claude' or 'notion')
   * @param {object} schema - Schema to register
   * @returns {Promise<boolean>} Success status
   */
  async registerSchema(type, schema) {
    if (!this.initialized) {
      throw new Error('Schema registry not initialized');
    }
    
    // Validate schema structure
    if (!this._validateSchemaStructure(schema)) {
      throw new Error('Invalid schema structure');
    }
    
    const { id, version } = schema;
    
    // Determine target map and directory
    const targetMap = type === 'claude' ? this.claudeSchemas : this.notionSchemas;
    const schemaDir = type === 'claude' ? this.options.schemaDirClaude : this.options.schemaDirNotion;
    
    // Add schema to map
    targetMap.set(id, schema);
    
    // Update version map
    if (!this.schemaVersions[type].has(id)) {
      this.schemaVersions[type].set(id, []);
    }
    
    const versions = this.schemaVersions[type].get(id);
    if (!versions.includes(version)) {
      versions.push(version);
      versions.sort((a, b) => this._compareVersions(b, a));
    }
    
    // Save schema to disk
    const schemaPath = path.join(schemaDir, `${id}-${version}.json`);
    await fs.promises.writeFile(schemaPath, JSON.stringify(schema, null, 2));
    
    this.emit('schema-registered', { type, id, version, path: schemaPath });
    
    return true;
  }
  
  /**
   * Validate data against schema
   * @param {string} type - Schema type ('claude' or 'notion')
   * @param {string} id - Schema ID
   * @param {object} data - Data to validate
   * @param {string} [version] - Schema version (optional, uses latest if not specified)
   * @returns {object} Validation result { valid: boolean, errors: array }
   */
  validateData(type, id, data, version) {
    if (!this.initialized) {
      throw new Error('Schema registry not initialized');
    }
    
    const schema = this.getSchema(type, id, version);
    
    if (!schema) {
      throw new Error(`Schema not found: ${type}/${id}${version ? `@${version}` : ''}`);
    }
    
    // Collect validation errors
    const errors = [];
    
    try {
      // Track start time for performance metrics
      const startTime = process.hrtime.bigint();
      
      // Validate against schema
      this._validateObject(data, schema.schema, '', errors);
      
      // Calculate validation time
      const endTime = process.hrtime.bigint();
      const validationTimeMs = Number(endTime - startTime) / 1000000;
      
      // Emit validation event
      this.emit('schema-validation', {
        type,
        id,
        version: version || schema.version,
        valid: errors.length === 0,
        errorCount: errors.length,
        validationTimeMs
      });
      
      return {
        valid: errors.length === 0,
        errors,
        validationTimeMs,
        schemaId: id,
        schemaVersion: version || schema.version
      };
    } catch (err) {
      errors.push({
        path: '',
        message: err.message
      });
      
      this.emit('schema-validation-error', {
        type,
        id,
        version: version || schema.version,
        error: err.message
      });
      
      return {
        valid: false,
        errors,
        schemaId: id,
        schemaVersion: version || schema.version,
        error: err.message
      };
    }
  }
  
  /**
   * Validate object against schema
   * @param {object} data - Data to validate
   * @param {object} schema - Schema to validate against
   * @param {string} path - Current path
   * @param {array} errors - Error array
   * @private
   */
  _validateObject(data, schema, path, errors) {
    // Validate type
    if (schema.type === 'object') {
      if (typeof data !== 'object' || data === null || Array.isArray(data)) {
        errors.push({
          path,
          message: `Expected object but got ${typeof data}`
        });
        return;
      }
      
      // Validate required properties
      if (schema.required) {
        for (const prop of schema.required) {
          if (!(prop in data)) {
            errors.push({
              path: path ? `${path}.${prop}` : prop,
              message: `Missing required property: ${prop}`
            });
          }
        }
      }
      
      // Validate properties
      if (schema.properties) {
        for (const [prop, propSchema] of Object.entries(schema.properties)) {
          if (prop in data) {
            this._validateObject(
              data[prop],
              propSchema,
              path ? `${path}.${prop}` : prop,
              errors
            );
          }
        }
      }
    } else if (schema.type === 'array') {
      if (!Array.isArray(data)) {
        errors.push({
          path,
          message: `Expected array but got ${typeof data}`
        });
        return;
      }
      
      // Validate items
      if (schema.items) {
        for (let i = 0; i < data.length; i++) {
          this._validateObject(
            data[i],
            schema.items,
            path ? `${path}[${i}]` : `[${i}]`,
            errors
          );
        }
      }
    } else if (schema.type === 'string') {
      if (typeof data !== 'string') {
        errors.push({
          path,
          message: `Expected string but got ${typeof data}`
        });
      } else if (schema.pattern) {
        const regex = new RegExp(schema.pattern);
        if (!regex.test(data)) {
          errors.push({
            path,
            message: `String does not match pattern: ${schema.pattern}`
          });
        }
      }
    } else if (schema.type === 'number' || schema.type === 'integer') {
      if (typeof data !== 'number') {
        errors.push({
          path,
          message: `Expected ${schema.type} but got ${typeof data}`
        });
      } else if (schema.type === 'integer' && !Number.isInteger(data)) {
        errors.push({
          path,
          message: 'Expected integer but got float'
        });
      }
      
      if (typeof data === 'number') {
        if (schema.minimum !== undefined && data < schema.minimum) {
          errors.push({
            path,
            message: `Value ${data} is less than minimum ${schema.minimum}`
          });
        }
        
        if (schema.maximum !== undefined && data > schema.maximum) {
          errors.push({
            path,
            message: `Value ${data} is greater than maximum ${schema.maximum}`
          });
        }
      }
    } else if (schema.type === 'boolean') {
      if (typeof data !== 'boolean') {
        errors.push({
          path,
          message: `Expected boolean but got ${typeof data}`
        });
      }
    } else if (schema.type === 'null') {
      if (data !== null) {
        errors.push({
          path,
          message: `Expected null but got ${typeof data}`
        });
      }
    }
  }

  /**
   * Get all registered schemas of a type
   * @param {string} type - Schema type ('claude' or 'notion')
   * @returns {Array} Array of schema objects
   */
  getAllSchemas(type) {
    if (!this.initialized) {
      throw new Error('Schema registry not initialized');
    }
    
    const schemaMap = type === 'claude' ? this.claudeSchemas : this.notionSchemas;
    return Array.from(schemaMap.values());
  }
  
  /**
   * Migrate data from one schema version to another
   * @param {string} type - Schema type ('claude' or 'notion')
   * @param {string} id - Schema ID
   * @param {object} data - Data to migrate
   * @param {string} fromVersion - Source schema version
   * @param {string} toVersion - Target schema version
   * @returns {object} Migrated data
   */
  async migrateData(type, id, data, fromVersion, toVersion) {
    if (!this.initialized) {
      throw new Error('Schema registry not initialized');
    }
    
    // Get source and target schemas
    const sourceSchema = this.getSchema(type, id, fromVersion);
    const targetSchema = this.getSchema(type, id, toVersion);
    
    if (!sourceSchema) {
      throw new Error(`Source schema not found: ${type}/${id}@${fromVersion}`);
    }
    
    if (!targetSchema) {
      throw new Error(`Target schema not found: ${type}/${id}@${toVersion}`);
    }
    
    // Parse versions to determine migration path
    const parseVersion = (v) => {
      const parts = v.split('-').map(Number);
      return { model: parts[0] || 0, revision: parts[1] || 0, addition: parts[2] || 0 };
    };
    
    const source = parseVersion(fromVersion);
    const target = parseVersion(toVersion);
    
    // Check if migration requires model change (incompatible)
    if (source.model !== target.model) {
      throw new Error(`Cannot migrate across major model versions: ${fromVersion} -> ${toVersion}`);
    }
    
    // Validate source data against source schema
    const sourceValidation = this.validateData(type, id, data, fromVersion);
    if (!sourceValidation.valid) {
      throw new Error(`Source data does not validate against source schema: ${sourceValidation.errors.map(e => e.message).join(', ')}`);
    }
    
    // For revision changes, apply transformations
    // For addition-only changes, source schema is a subset of target schema
    
    if (source.revision !== target.revision) {
      // This would implement specific migration logic between revisions
      // For this example, we'll just pass through the data
      // In a real implementation, would look up migration transformers
      this.emit('schema-migration', {
        type,
        id,
        fromVersion,
        toVersion,
        status: 'warning',
        message: 'Revision migration not implemented - passing data through'
      });
    }
    
    // Validate migrated data against target schema
    const targetValidation = this.validateData(type, id, data, toVersion);
    if (!targetValidation.valid) {
      throw new Error(`Migrated data does not validate against target schema: ${targetValidation.errors.map(e => e.message).join(', ')}`);
    }
    
    this.emit('schema-migration', {
      type,
      id,
      fromVersion,
      toVersion,
      status: 'success'
    });
    
    return data;
  }
  
  /**
   * Get schema metrics
   * @returns {object} Schema registry metrics
   */
  getMetrics() {
    return {
      initialized: this.initialized,
      schemaCount: {
        claude: this.claudeSchemas.size,
        notion: this.notionSchemas.size,
        total: this.claudeSchemas.size + this.notionSchemas.size
      },
      latestVersions: {
        claude: Object.fromEntries(
          Array.from(this.schemaVersions.claude.entries())
            .map(([id, versions]) => [id, versions[0] || null])
        ),
        notion: Object.fromEntries(
          Array.from(this.schemaVersions.notion.entries())
            .map(([id, versions]) => [id, versions[0] || null])
        )
      }
    };
  }
}

module.exports = SchemaRegistry;`;
      
      // Create backup of original file
      fs.writeFileSync(`${schemaRegistryPath}.bak`, schemaRegistryContent);
      
      // Write fixed content
      fs.writeFileSync(schemaRegistryPath, fixedContent);
      console.log('✅ Successfully fixed schema-registry.js');
    } else {
      console.log('schema-registry.js appears to be already fixed or has a different issue');
    }
  
  // Check for error logs
  try {
    const schemaRegistryErrorLog = path.join(LOG_DIR, 'schema-registry.log');
    if (fs.existsSync(schemaRegistryErrorLog)) {
      console.log('Checking schema-registry error logs:');
      const logContent = fs.readFileSync(schemaRegistryErrorLog, 'utf8');
      console.log(logContent.split('\n').slice(0, 5).join('\n'));
    }
  } catch (logErr) {
    console.log(`Could not read schema log: ${logErr.message}`);
  }

} catch (err) {
  console.error(`❌ Failed to fix schema-registry.js: ${err.message}`);
}

// 3. Create .cjs versions of key modules
console.log('\n[3/3] Creating .cjs versions of server modules...');

const moduleFiles = [
  'socket-server-implementation.js',
  'notion-connection-manager.js',
  'schema-registry.js',
  'streaming-schema-transformer.js',
  'mcp-orchestrator.js',
  'circuit-breaker.js'
];

let createdCount = 0;
for (const file of moduleFiles) {
  try {
    const sourcePath = path.join(MCP_DIR, file);
    const targetPath = path.join(MCP_DIR, file.replace('.js', '.cjs'));
    
    // Skip if source doesn't exist
    if (!fs.existsSync(sourcePath)) {
      console.warn(`⚠️ Source file doesn't exist: ${sourcePath}`);
      continue;
    }
    
    // Copy to .cjs version
    fs.copyFileSync(sourcePath, targetPath);
    console.log(`✅ Created ${targetPath}`);
    createdCount++;
  } catch (err) {
    console.error(`❌ Failed to create .cjs version of ${file}: ${err.message}`);
  }
}

console.log(`\n✅ Created ${createdCount} .cjs modules`);

// 4. Update launch-optimized.sh to use .cjs files
console.log('\n[4/4] Updating launch-optimized.sh to use .cjs files...');
try {
  const launchScriptPath = path.join(ANCHOR_HOME, 'launch-optimized.sh');
  let launchScript = fs.readFileSync(launchScriptPath, 'utf8');
  
  // Update SERVER_SCRIPTS array to use .cjs extensions
  launchScript = launchScript.replace(
    /SERVER_SCRIPTS=\(\$\{MCP_DIR\}\/socket-server-implementation\.js.*?\)/s,
    'SERVER_SCRIPTS=("$MCP_DIR/socket-server-implementation.cjs" "$MCP_DIR/notion-connection-manager.cjs" "$MCP_DIR/schema-registry.cjs" "$MCP_DIR/streaming-schema-transformer.cjs" "$MCP_DIR/mcp-orchestrator.cjs")'
  );
  
  // Create backup of original file
  fs.writeFileSync(`${launchScriptPath}.bak`, fs.readFileSync(launchScriptPath, 'utf8'));
  
  // Write updated script
  fs.writeFileSync(launchScriptPath, launchScript);
  console.log('✅ Successfully updated launch-optimized.sh');
} catch (err) {
  console.error(`❌ Failed to update launch-optimized.sh: ${err.message}`);
}

console.log('\n='.repeat(50));
console.log('✅ Module system fix complete!');
console.log('='.repeat(50));
console.log('\nRun the following commands to apply the fixes:');
console.log('  chmod +x /Users/XPV/Desktop/anchor-core/cnif-module-fixer.js');
console.log('  node /Users/XPV/Desktop/anchor-core/cnif-module-fixer.js');
console.log('  /Users/XPV/Desktop/anchor-core/launch-optimized.sh');
