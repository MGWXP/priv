#!/bin/bash
# verify-socket-servers.sh - Check socket server status
# © 2025 XPV - MIT

# Define colors for better visibility
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Define paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
SOCKET_DIR="${ANCHOR_HOME}/sockets"

echo -e "${BLUE}=== MCP Socket Servers Check ===${NC}"
echo "Timestamp: $(date '+%Y-%m-%d %H:%M:%S')"
echo "Socket Directory: ${SOCKET_DIR}"

# Check socket directory
if [ -d "$SOCKET_DIR" ]; then
  echo -e "${GREEN}✓${NC} Socket directory exists"
else
  echo -e "${RED}✗${NC} Socket directory missing"
  mkdir -p "$SOCKET_DIR"
  echo -e "${YELLOW}  Created socket directory${NC}"
fi

# List socket files
echo -e "\n${BLUE}Socket Files:${NC}"
if [ -n "$(ls -A $SOCKET_DIR 2>/dev/null)" ]; then
  ls -la $SOCKET_DIR
else
  echo -e "${RED}✗${NC} No socket files found!"
fi

# Check running processes
echo -e "\n${BLUE}Socket Server Processes:${NC}"
GIT_PID=$(pgrep -f "MCP_SERVER_NAME=git-local" || echo "")
NOTION_PID=$(pgrep -f "MCP_SERVER_NAME=notion" || echo "")
ANCHOR_PID=$(pgrep -f "MCP_SERVER_NAME=anchor-manager" || echo "")

if [ -n "$GIT_PID" ]; then
  echo -e "${GREEN}✓${NC} Git Local socket server: Running (PID: $GIT_PID)"
else
  echo -e "${RED}✗${NC} Git Local socket server: Not running"
fi

if [ -n "$NOTION_PID" ]; then
  echo -e "${GREEN}✓${NC} Notion socket server: Running (PID: $NOTION_PID)"
else
  echo -e "${RED}✗${NC} Notion socket server: Not running"
fi

if [ -n "$ANCHOR_PID" ]; then
  echo -e "${GREEN}✓${NC} Anchor Manager socket server: Running (PID: $ANCHOR_PID)"
else
  echo -e "${RED}✗${NC} Anchor Manager socket server: Not running"
fi

# Test socket connections
echo -e "\n${BLUE}Socket Connection Tests:${NC}"

# Function to test a socket
test_socket() {
  local socket_path="$1"
  local socket_name="$2"
  
  if [ -S "$socket_path" ]; then
    # Try to connect to the socket with netcat
    if nc -U -z "$socket_path" 2>/dev/null; then
      echo -e "${GREEN}✓${NC} $socket_name socket: Connection successful"
    else
      echo -e "${YELLOW}!${NC} $socket_name socket: File exists but connection failed"
    fi
  else
    echo -e "${RED}✗${NC} $socket_name socket: File does not exist or is not a socket"
  fi
}

test_socket "$SOCKET_DIR/git-local.sock" "Git Local"
test_socket "$SOCKET_DIR/notion.sock" "Notion"
test_socket "$SOCKET_DIR/anchor-manager.sock" "Anchor Manager"

# Check Claude configuration
echo -e "\n${BLUE}Claude Configuration:${NC}"
CONFIG_FILE="${HOME}/Library/Application Support/Claude/claude_desktop_config.json"

if [ -f "$CONFIG_FILE" ]; then
  echo -e "${GREEN}✓${NC} Claude configuration file exists"
  
  # Check for MCP server configuration
  if grep -q "\"socketPath\"" "$CONFIG_FILE"; then
    echo -e "${GREEN}✓${NC} MCP socket paths configured"
    
    # Extract and display the socket paths
    echo -e "\nConfigured socket paths:"
    grep -A 1 "\"socketPath\"" "$CONFIG_FILE" | grep -v "\"socketPath\"" | sed 's/[",]//g' | sed 's/^[ \t]*//'
  else
    echo -e "${RED}✗${NC} MCP socket paths not configured"
  fi
else
  echo -e "${RED}✗${NC} Claude configuration file not found"
fi

echo -e "\n${BLUE}=== Summary ===${NC}"
if [ -n "$GIT_PID" ] && [ -n "$NOTION_PID" ] && [ -n "$ANCHOR_PID" ] && [ -n "$(ls -A $SOCKET_DIR 2>/dev/null)" ]; then
  echo -e "${GREEN}All socket servers appear to be running properly.${NC}"
  echo "Now you can:
  1. Open Claude and check the Developer settings
  2. Restart Claude if it was already running
  3. Check if the warning indicators have disappeared"
else
  echo -e "${RED}One or more socket servers are not running or socket files are missing.${NC}"
  echo "To restart socket servers, run:
  ${ANCHOR_HOME}/socket-server-launcher.sh"
fi
