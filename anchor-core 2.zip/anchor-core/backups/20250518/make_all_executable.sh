#!/bin/bash
# One command to make all scripts executable
# Run this to ensure proper permissions

# Make all scripts executable
chmod +x /Users/XPV/Desktop/anchor-core/*.sh
chmod +x /Users/XPV/Desktop/anchor-core/mcp-servers/*.sh
chmod +x /Users/XPV/Desktop/anchor-core/mcp-servers/*.js
chmod +x /Users/XPV/Desktop/anchor-core/scripts/*.sh 2>/dev/null || true

echo "✅ Made all scripts executable"
echo "✅ You can now run: ./launch-optimized.sh"
