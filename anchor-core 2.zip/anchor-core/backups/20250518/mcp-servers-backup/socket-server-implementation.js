#!/usr/bin/env node
/*  socket-server-implementation.js  –  Unix socket implementation for MCP servers */
/*  © 2025 XPV - MIT                                                             */

const fs = require('fs');
const net = require('net');
const path = require('path');

// Configuration
const SOCKET_DIR = process.env.SOCKET_DIR || '/Users/XPV/Desktop/anchor-core/sockets';
const SERVER_NAME = process.env.MCP_SERVER_NAME || 'unknown';
const SOCKET_PATH = path.join(SOCKET_DIR, `${SERVER_NAME}.sock`);
const LOG_DIR = process.env.LOG_DIR || path.join(process.env.HOME, 'Library/Logs/Claude');
const LOG_FILE = path.join(LOG_DIR, `mcp-server-${SERVER_NAME}.log`);

// Ensure directories exist
try {
  fs.mkdirSync(SOCKET_DIR, { recursive: true });
  fs.mkdirSync(LOG_DIR, { recursive: true });
} catch (err) {
  console.error(`Failed to create directories: ${err.message}`);
}

// Logger
function log(level, message, extra = {}) {
  const logEntry = JSON.stringify({
    ts: new Date().toISOString(),
    lvl: level,
    svr: SERVER_NAME,
    msg: message,
    extra,
    pid: process.pid
  });
  
  console.error(logEntry);
  
  try {
    fs.appendFileSync(LOG_FILE, logEntry + '\n');
  } catch (err) {
    console.error(`Failed to write to log file: ${err.message}`);
  }
}

// Remove socket file if it exists
try {
  if (fs.existsSync(SOCKET_PATH)) {
    fs.unlinkSync(SOCKET_PATH);
    log('INFO', `Removed existing socket file: ${SOCKET_PATH}`);
  }
} catch (err) {
  log('ERROR', `Failed to remove existing socket file: ${err.message}`);
  process.exit(1);
}

// Create server
const server = net.createServer((socket) => {
  log('INFO', 'Client connected');
  
  socket.on('data', (data) => {
    log('DEBUG', `Received data: ${data.length} bytes`);
    
    try {
      // Parse the received data as JSON
      const message = JSON.parse(data.toString());
      log('DEBUG', 'Parsed message', { type: message.type });
      
      // Process the message based on type
      let response;
      if (message.type === 'handshake') {
        response = { 
          type: 'handshake_response', 
          status: 'success',
          server: SERVER_NAME,
          version: '1.0.0'
        };
      } else if (message.type === 'invoke_tool') {
        response = {
          type: 'tool_response',
          id: message.id || 'unknown',
          status: 'success',
          result: `Mock response from ${SERVER_NAME} tool: ${message.tool || 'unknown'}`
        };
      } else {
        response = {
          type: 'error_response',
          status: 'error',
          error: `Unknown message type: ${message.type}`
        };
      }
      
      // Send response
      socket.write(JSON.stringify(response) + '\n');
      log('DEBUG', 'Sent response', { type: response.type });
    } catch (err) {
      log('ERROR', `Failed to process message: ${err.message}`);
      
      // Send error response
      const errorResponse = {
        type: 'error_response',
        status: 'error',
        error: `Failed to process message: ${err.message}`
      };
      socket.write(JSON.stringify(errorResponse) + '\n');
    }
  });
  
  socket.on('end', () => {
    log('INFO', 'Client disconnected');
  });
  
  socket.on('error', (err) => {
    log('ERROR', `Socket error: ${err.message}`);
  });
});

// Start listening
server.listen(SOCKET_PATH, () => {
  log('INFO', `Server listening on ${SOCKET_PATH}`);
  
  // Set permissions on socket file (666 = rw-rw-rw-)
  try {
    fs.chmodSync(SOCKET_PATH, 0o666);
    log('INFO', `Set permissions on socket file: 0666`);
  } catch (err) {
    log('ERROR', `Failed to set permissions on socket file: ${err.message}`);
  }
});

// Handle errors
server.on('error', (err) => {
  log('ERROR', `Server error: ${err.message}`);
  
  if (err.code === 'EADDRINUSE') {
    log('ERROR', `Socket file is already in use: ${SOCKET_PATH}`);
  }
  
  process.exit(1);
});

// Handle process exit
process.on('exit', () => {
  try {
    if (fs.existsSync(SOCKET_PATH)) {
      fs.unlinkSync(SOCKET_PATH);
      log('INFO', `Removed socket file on exit: ${SOCKET_PATH}`);
    }
  } catch (err) {
    log('ERROR', `Failed to remove socket file on exit: ${err.message}`);
  }
});

process.on('SIGINT', () => {
  log('INFO', 'Received SIGINT, shutting down');
  server.close(() => {
    process.exit(0);
  });
});

process.on('SIGTERM', () => {
  log('INFO', 'Received SIGTERM, shutting down');
  server.close(() => {
    process.exit(0);
  });
});

log('INFO', `Started ${SERVER_NAME} MCP socket server (PID: ${process.pid})`);
