#!/bin/bash
# verify-servers.sh - Enhanced status check for all MCP servers
# © 2025 XPV - MIT

# Define colors for better visibility
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Define paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
MCP_DIR="${ANCHOR_HOME}/mcp-servers"
LOG_DIR="${HOME}/Library/Logs/Claude"
SOCKET_DIR="${ANCHOR_HOME}/sockets"

echo -e "${BLUE}=== MCP Servers Status Check ===${NC}"
echo "Timestamp: $(date '+%Y-%m-%d %H:%M:%S')"
echo "Socket Directory: ${SOCKET_DIR}"

# Check if directories exist
echo -e "\n${BLUE}Directory Check:${NC}"
if [ -d "$SOCKET_DIR" ]; then
  echo -e "${GREEN}✓${NC} Socket directory exists: $SOCKET_DIR"
  ls -la "$SOCKET_DIR"
else
  echo -e "${RED}✗${NC} Socket directory missing: $SOCKET_DIR"
fi

if [ -d "$LOG_DIR" ]; then
  echo -e "${GREEN}✓${NC} Log directory exists: $LOG_DIR"
else
  echo -e "${RED}✗${NC} Log directory missing: $LOG_DIR"
fi

# Check for running processes
echo -e "\n${BLUE}Process Check:${NC}"
GIT_PID=$(pgrep -f git-local-optimized.js || echo "")
NOTION_PID=$(pgrep -f "notion.*wrapper.js" || echo "")
ANCHOR_PID=$(pgrep -f anchor-manager-optimized.js || echo "")

if [ -n "$GIT_PID" ]; then
  echo -e "${GREEN}✓${NC} Git Local server: Running (PID: $GIT_PID)"
else
  echo -e "${RED}✗${NC} Git Local server: Not running"
fi

if [ -n "$NOTION_PID" ]; then
  echo -e "${GREEN}✓${NC} Notion server: Running (PID: $NOTION_PID)"
else
  echo -e "${RED}✗${NC} Notion server: Not running"
fi

if [ -n "$ANCHOR_PID" ]; then
  echo -e "${GREEN}✓${NC} Anchor Manager server: Running (PID: $ANCHOR_PID)"
else
  echo -e "${RED}✗${NC} Anchor Manager server: Not running"
fi

# Check for PID files
echo -e "\n${BLUE}PID File Check:${NC}"
for server in git-local notion anchor-manager; do
  PID_FILE="${MCP_DIR}/${server}.pid"
  if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    if ps -p "$PID" > /dev/null; then
      echo -e "${GREEN}✓${NC} $server.pid: Valid (PID: $PID)"
    else
      echo -e "${YELLOW}!${NC} $server.pid: Stale (PID: $PID)"
    fi
  else
    echo -e "${RED}✗${NC} $server.pid: Missing"
  fi
done

# Check log files
echo -e "\n${BLUE}Log Check:${NC}"
for server in git-local notion anchor-manager; do
  LOG_FILE="${LOG_DIR}/mcp-server-${server}.log"
  if [ -f "$LOG_FILE" ]; then
    LAST_MODIFIED=$(stat -f "%Sm" -t "%Y-%m-%d %H:%M:%S" "$LOG_FILE")
    SIZE=$(du -h "$LOG_FILE" | cut -f1)
    echo -e "${GREEN}✓${NC} $server log: Exists (Last modified: $LAST_MODIFIED, Size: $SIZE)"
    echo "Latest log entries:"
    tail -n 5 "$LOG_FILE"
    echo "----------------"
  else
    echo -e "${RED}✗${NC} $server log: Missing"
  fi
done

# Summary
echo -e "\n${BLUE}=== Status Summary ===${NC}"
if [ -n "$GIT_PID" ] && [ -n "$NOTION_PID" ] && [ -n "$ANCHOR_PID" ]; then
  echo -e "${GREEN}All MCP servers are running properly.${NC}"
else
  echo -e "${RED}One or more MCP servers are not running!${NC}"
  echo -e "Use this command to restart all servers:"
  echo -e "  ${YELLOW}${ANCHOR_HOME}/restart-all.sh${NC}"
fi

# Node.js version check
echo -e "\n${BLUE}Environment Check:${NC}"
echo -e "Node.js: $(node -v)"
echo -e "NODE_OPTIONS: ${NODE_OPTIONS:-'Not set'}"
echo -e "UV_THREADPOOL_SIZE: ${UV_THREADPOOL_SIZE:-'Not set'}"
