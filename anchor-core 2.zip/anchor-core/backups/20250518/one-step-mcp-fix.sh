#!/bin/bash
# one-step-mcp-fix.sh - Fix all MCP connection issues
# © 2025 XPV - MIT

echo "🔧 Starting comprehensive MCP socket fix..."

# Make all scripts executable
chmod +x /Users/XPV/Desktop/anchor-core/make-socket-scripts-executable.sh
chmod +x /Users/XPV/Desktop/anchor-core/socket-server-launcher.sh
chmod +x /Users/XPV/Desktop/anchor-core/verify-socket-servers.sh
chmod +x /Users/XPV/Desktop/anchor-core/update-claude-socket-config.sh
chmod +x /Users/XPV/Desktop/anchor-core/mcp-servers/socket-server-implementation.js

# Stop any running processes
echo "🛑 Stopping existing processes..."
pkill -f "socket-server-implementation.js" 2>/dev/null || true
pkill -f "git-local-optimized.js" 2>/dev/null || true
pkill -f "notion-v5-wrapper.js" 2>/dev/null || true
pkill -f "anchor-manager-optimized.js" 2>/dev/null || true
sleep 1

# Update Claude configuration
echo "📝 Updating Claude configuration..."
/Users/XPV/Desktop/anchor-core/update-claude-socket-config.sh

# Launch socket servers
echo "🚀 Launching socket servers..."
/Users/XPV/Desktop/anchor-core/socket-server-launcher.sh

# Verify socket servers
echo "🔍 Verifying socket servers..."
/Users/XPV/Desktop/anchor-core/verify-socket-servers.sh

echo "✅ MCP socket fix complete!"
echo
echo "Next steps:"
echo "1. Restart Claude if it's already running"
echo "2. Check Developer settings in Claude"
echo "3. Try using the MCP tools in Claude"
