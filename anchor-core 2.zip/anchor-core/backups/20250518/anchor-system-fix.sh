#!/bin/bash
# anchor-system-fix.sh - Comprehensive fix for Anchor System V6
# Implements solutions for socket, process, and M3 Max optimization issues
# © 2025 XPV - MIT

set -e

echo "┌─────────────────────────────────────────────────────┐"
echo "│      Anchor System V6 Comprehensive Fix             │"
echo "└─────────────────────────────────────────────────────┘"

# Define paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
MCP_DIR="${ANCHOR_HOME}/mcp-servers"
LOG_DIR="${HOME}/Library/Logs/Claude"
SOCKET_DIR="${ANCHOR_HOME}/sockets"
CONFIG_DIR="${HOME}/Library/Application Support/Claude"
CONFIG_FILE="${CONFIG_DIR}/claude_desktop_config.json"
BACKUP_DIR="${ANCHOR_HOME}/backups/$(date '+%Y%m%d')"

# Step 1: Create backup directory and backup current configuration
echo -e "\n🔄 Step 1: Backing up current configuration..."
mkdir -p "${BACKUP_DIR}"

# Backup Claude configuration
if [ -f "${CONFIG_FILE}" ]; then
  cp "${CONFIG_FILE}" "${BACKUP_DIR}/claude_desktop_config.json.bak"
  echo "✅ Backed up Claude configuration"
fi

# Backup existing scripts
cp -r "${MCP_DIR}" "${BACKUP_DIR}/mcp-servers-backup" 2>/dev/null || true
cp "${ANCHOR_HOME}/"*.sh "${BACKUP_DIR}/" 2>/dev/null || true
echo "✅ Backed up existing scripts"

# Step 2: Stop all running servers
echo -e "\n🔄 Step 2: Stopping any running servers..."
pkill -f "git-local-optimized.js" 2>/dev/null || true
pkill -f "notion-v5-wrapper.js" 2>/dev/null || true
pkill -f "anchor-manager-optimized.js" 2>/dev/null || true
pkill -f "socket-server-implementation.js" 2>/dev/null || true
pkill -f "enhanced-socket-server.js" 2>/dev/null || true
sleep 2
echo "✅ Stopped all running servers"

# Step 3: Clean up stale files
echo -e "\n🔄 Step 3: Cleaning up stale files..."
rm -f "${MCP_DIR}"/*.pid 2>/dev/null || true
rm -f "${SOCKET_DIR}"/*.sock 2>/dev/null || true
echo "✅ Cleaned up stale files"

# Step 4: Ensure directories exist
echo -e "\n🔄 Step 4: Creating required directories..."
mkdir -p "${SOCKET_DIR}"
mkdir -p "${LOG_DIR}"
mkdir -p "${MCP_DIR}"
mkdir -p "${CONFIG_DIR}"
echo "✅ Created required directories"

# Step 5: Apply correct permissions
echo -e "\n🔄 Step 5: Setting correct permissions..."
chmod 755 "${SOCKET_DIR}"
chmod 755 "${LOG_DIR}"
chmod 755 "${MCP_DIR}"
echo "✅ Set directory permissions"

# Step 6: Run M3 optimizer
echo -e "\n🔄 Step 6: Running M3 optimizer..."
node "${ANCHOR_HOME}/m3-optimizer/m3-optimizer.js"

# Step 7: Make scripts executable
echo -e "\n🔄 Step 7: Making scripts executable..."
chmod +x "${ANCHOR_HOME}"/*.sh 2>/dev/null || true
chmod +x "${MCP_DIR}"/*.sh 2>/dev/null || true
chmod +x "${MCP_DIR}"/*.js 2>/dev/null || true
chmod +x "${ANCHOR_HOME}/enhanced-socket-server.js"
chmod +x "${ANCHOR_HOME}/m3-optimizer/m3-optimizer.js"
echo "✅ Made scripts executable"

# Step 8: Update Claude configuration
echo -e "\n🔄 Step 8: Updating Claude configuration..."
cat > "${CONFIG_FILE}" << EOL
{
  "mcpServers": {
    "git-local": {
      "socketPath": "${SOCKET_DIR}/git-local.sock"
    },
    "notion": {
      "socketPath": "${SOCKET_DIR}/notion.sock"
    },
    "anchor-manager": {
      "socketPath": "${SOCKET_DIR}/anchor-manager.sock"
    }
  }
}
EOL
echo "✅ Updated Claude configuration"

# Step 9: Create launcher for enhanced socket server
echo -e "\n🔄 Step 9: Creating enhanced socket server launcher..."
cat > "${ANCHOR_HOME}/launch-enhanced-servers.sh" << 'EOL'
#!/bin/bash
# launch-enhanced-servers.sh - Launch enhanced socket servers for Anchor System V6
# © 2025 XPV - MIT

set -e

ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
MCP_DIR="${ANCHOR_HOME}/mcp-servers"
LOG_DIR="${HOME}/Library/Logs/Claude"
SOCKET_DIR="${ANCHOR_HOME}/sockets"

# Load environment variables
if [ -f "${ANCHOR_HOME}/.env" ]; then
  source "${ANCHOR_HOME}/.env"
fi

# Make sure directories exist
mkdir -p "${SOCKET_DIR}"
mkdir -p "${LOG_DIR}"

# Stop any running servers
echo "🛑 Stopping existing servers..."
pkill -f "git-local-optimized.js" 2>/dev/null || true
pkill -f "notion-v5-wrapper.js" 2>/dev/null || true
pkill -f "anchor-manager-optimized.js" 2>/dev/null || true
pkill -f "socket-server-implementation.js" 2>/dev/null || true
pkill -f "enhanced-socket-server.js" 2>/dev/null || true
sleep 1

# Clean up PID files and stale sockets
rm -f "${MCP_DIR}"/*.pid 2>/dev/null || true
rm -f "${SOCKET_DIR}"/*.sock 2>/dev/null || true

# Start enhanced socket servers
echo "🚀 Starting enhanced socket servers..."

# Launch Git Local server
echo "🚀 Launching Git Local socket server..."
MCP_SERVER_NAME="git-local" \
  node --expose-gc "${ANCHOR_HOME}/enhanced-socket-server.js" > "${LOG_DIR}/mcp-server-git-local.log" 2>&1 &
echo $! > "${MCP_DIR}/git-local.pid"

# Launch Notion server
echo "🚀 Launching Notion socket server..."
MCP_SERVER_NAME="notion" \
  node --expose-gc "${ANCHOR_HOME}/enhanced-socket-server.js" > "${LOG_DIR}/mcp-server-notion.log" 2>&1 &
echo $! > "${MCP_DIR}/notion.pid"

# Launch Anchor Manager server
echo "🚀 Launching Anchor Manager socket server..."
MCP_SERVER_NAME="anchor-manager" \
  node --expose-gc "${ANCHOR_HOME}/enhanced-socket-server.js" > "${LOG_DIR}/mcp-server-anchor-manager.log" 2>&1 &
echo $! > "${MCP_DIR}/anchor-manager.pid"

echo "✅ All enhanced socket servers launched!"
echo "📂 Socket files located in: ${SOCKET_DIR}"
echo "📊 To verify, run: ${ANCHOR_HOME}/verify-enhanced-servers.sh"
EOL

chmod +x "${ANCHOR_HOME}/launch-enhanced-servers.sh"
echo "✅ Created enhanced socket server launcher"

# Step 10: Create verification script
echo -e "\n🔄 Step 10: Creating verification script..."
cat > "${ANCHOR_HOME}/verify-enhanced-servers.sh" << 'EOL'
#!/bin/bash
# verify-enhanced-servers.sh - Verify enhanced socket servers
# © 2025 XPV - MIT

# Define colors for better visibility
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Define paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
MCP_DIR="${ANCHOR_HOME}/mcp-servers"
LOG_DIR="${HOME}/Library/Logs/Claude"
SOCKET_DIR="${ANCHOR_HOME}/sockets"
CONFIG_DIR="${HOME}/Library/Application Support/Claude"
CONFIG_FILE="${CONFIG_DIR}/claude_desktop_config.json"

echo -e "${BLUE}=== Enhanced Socket Servers Check ===${NC}"
echo "Timestamp: $(date '+%Y-%m-%d %H:%M:%S')"
echo "Socket Directory: ${SOCKET_DIR}"
echo "Running on: $(uname -v)"

# Check socket directory
if [ -d "$SOCKET_DIR" ]; then
  echo -e "${GREEN}✓${NC} Socket directory exists"
  ls -la "$SOCKET_DIR"
else
  echo -e "${RED}✗${NC} Socket directory missing"
  mkdir -p "$SOCKET_DIR"
  echo -e "${YELLOW}  Created socket directory${NC}"
fi

# Check log directory
if [ -d "$LOG_DIR" ]; then
  echo -e "${GREEN}✓${NC} Log directory exists"
else
  echo -e "${RED}✗${NC} Log directory missing"
  mkdir -p "$LOG_DIR"
  echo -e "${YELLOW}  Created log directory${NC}"
fi

# Check running processes
echo -e "\n${BLUE}Socket Server Processes:${NC}"
for server in git-local notion anchor-manager; do
  PID_FILE="${MCP_DIR}/${server}.pid"
  if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    if ps -p "$PID" > /dev/null; then
      echo -e "${GREEN}✓${NC} ${server} socket server: Running (PID: $PID)"
    else
      echo -e "${RED}✗${NC} ${server} socket server: Not running (stale PID file: $PID)"
    fi
  else
    echo -e "${RED}✗${NC} ${server} socket server: Not running (no PID file)"
  fi
done

# Check socket files
echo -e "\n${BLUE}Socket Files:${NC}"
for server in git-local notion anchor-manager; do
  SOCKET_FILE="${SOCKET_DIR}/${server}.sock"
  if [ -S "$SOCKET_FILE" ]; then
    PERMS=$(ls -la "$SOCKET_FILE" | awk '{print $1}')
    echo -e "${GREEN}✓${NC} ${server} socket: Exists (permissions: $PERMS)"
  else
    echo -e "${RED}✗${NC} ${server} socket: Missing"
  fi
done

# Test socket connections
echo -e "\n${BLUE}Socket Connection Tests:${NC}"
for server in git-local notion anchor-manager; do
  SOCKET_FILE="${SOCKET_DIR}/${server}.sock"
  if [ -S "$SOCKET_FILE" ]; then
    # Try to connect to the socket with netcat
    if nc -U -z "$SOCKET_FILE" 2>/dev/null; then
      echo -e "${GREEN}✓${NC} ${server} socket: Connection successful"
    else
      echo -e "${YELLOW}!${NC} ${server} socket: File exists but connection failed"
    fi
  else
    echo -e "${RED}✗${NC} ${server} socket: File does not exist"
  fi
done

# Check Claude configuration
echo -e "\n${BLUE}Claude Configuration:${NC}"
if [ -f "$CONFIG_FILE" ]; then
  echo -e "${GREEN}✓${NC} Claude configuration file exists"
  
  # Check for MCP server configuration
  if grep -q "\"socketPath\"" "$CONFIG_FILE"; then
    echo -e "${GREEN}✓${NC} MCP socket paths configured"
    
    # Extract and display the socket paths
    echo -e "\nConfigured socket paths:"
    grep -A 1 "\"socketPath\"" "$CONFIG_FILE" | grep -v "\"socketPath\"" | sed 's/[",]//g' | sed 's/^[ \t]*//'
  else
    echo -e "${RED}✗${NC} MCP socket paths not configured"
  fi
else
  echo -e "${RED}✗${NC} Claude configuration file not found"
fi

# Check log files
echo -e "\n${BLUE}Log Files:${NC}"
for server in git-local notion anchor-manager; do
  LOG_FILE="${LOG_DIR}/mcp-server-${server}.log"
  if [ -f "$LOG_FILE" ]; then
    LAST_MODIFIED=$(stat -f "%Sm" -t "%Y-%m-%d %H:%M:%S" "$LOG_FILE")
    SIZE=$(du -h "$LOG_FILE" | cut -f1)
    echo -e "${GREEN}✓${NC} ${server} log: Exists (Last modified: $LAST_MODIFIED, Size: $SIZE)"
    echo "Latest log entries:"
    tail -n 3 "$LOG_FILE"
    echo "----------------"
  else
    echo -e "${RED}✗${NC} ${server} log: Missing"
  fi
done

# Check M3 optimization
echo -e "\n${BLUE}M3 Max Optimization:${NC}"
if [ -f "${ANCHOR_HOME}/.env" ]; then
  echo -e "${GREEN}✓${NC} M3 Max optimization file exists"
  echo "Current settings:"
  grep -E "NODE_OPTIONS|UV_THREADPOOL_SIZE" "${ANCHOR_HOME}/.env" | sed 's/^export //'
else
  echo -e "${RED}✗${NC} M3 Max optimization file missing"
fi

# Summary
echo -e "\n${BLUE}=== Summary ===${NC}"
RUNNING_COUNT=$(ps -ef | grep -E "enhanced-socket-server.js" | grep -v grep | wc -l)
if [ $RUNNING_COUNT -eq 3 ] && ls -la "${SOCKET_DIR}"/*.sock >/dev/null 2>&1; then
  echo -e "${GREEN}All enhanced socket servers are running properly.${NC}"
  echo "Claude should now be able to connect to all MCP servers."
else
  echo -e "${RED}One or more enhanced socket servers are not running or socket files are missing.${NC}"
  echo "To restart socket servers, run:"
  echo "  ${ANCHOR_HOME}/launch-enhanced-servers.sh"
fi

# Provide next steps
echo -e "\n${BLUE}Next Steps:${NC}"
echo "1. Restart Claude Desktop application if it's already running"
echo "2. Check Developer settings in Claude to verify MCP servers"
echo "3. If issues persist, check logs in: ${LOG_DIR}"
EOL

chmod +x "${ANCHOR_HOME}/verify-enhanced-servers.sh"
echo "✅ Created verification script"

# Step 11: Create process manager launcher
echo -e "\n🔄 Step 11: Creating process manager launcher..."
cat > "${ANCHOR_HOME}/launch-with-process-manager.sh" << 'EOL'
#!/bin/bash
# launch-with-process-manager.sh - Launch servers with process manager
# © 2025 XPV - MIT

set -e

ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
MCP_DIR="${ANCHOR_HOME}/mcp-servers"
LOG_DIR="${HOME}/Library/Logs/Claude"
SOCKET_DIR="${ANCHOR_HOME}/sockets"

# Create a temporary process manager script
cat > "${ANCHOR_HOME}/pm-launcher.js" << 'EOJS'
const ProcessManager = require('./process-manager');
const path = require('path');
const os = require('os');

// Configuration
const ANCHOR_HOME = '/Users/XPV/Desktop/anchor-core';
const MCP_DIR = path.join(ANCHOR_HOME, 'mcp-servers');
const LOG_DIR = path.join(os.homedir(), 'Library/Logs/Claude');
const SOCKET_DIR = path.join(ANCHOR_HOME, 'sockets');

// Create and configure process manager
const pm = new ProcessManager({
  checkInterval: 5000,
  restartDelay: 1000,
  maxRestarts: 5,
  restartBackoff: true,
  logDirectory: LOG_DIR
});

// Register Git Local server
pm.registerProcess('git-local', {
  command: 'node',
  args: ['--expose-gc', path.join(ANCHOR_HOME, 'enhanced-socket-server.js')],
  cwd: ANCHOR_HOME,
  env: {
    MCP_SERVER_NAME: 'git-local',
    SOCKET_DIR,
    LOG_DIR
  },
  pidFile: path.join(MCP_DIR, 'git-local.pid'),
  socketPath: path.join(SOCKET_DIR, 'git-local.sock'),
  logPath: path.join(LOG_DIR, 'mcp-server-git-local.log')
});

// Register Notion server
pm.registerProcess('notion', {
  command: 'node',
  args: ['--expose-gc', path.join(ANCHOR_HOME, 'enhanced-socket-server.js')],
  cwd: ANCHOR_HOME,
  env: {
    MCP_SERVER_NAME: 'notion',
    SOCKET_DIR,
    LOG_DIR
  },
  pidFile: path.join(MCP_DIR, 'notion.pid'),
  socketPath: path.join(SOCKET_DIR, 'notion.sock'),
  logPath: path.join(LOG_DIR, 'mcp-server-notion.log')
});

// Register Anchor Manager server
pm.registerProcess('anchor-manager', {
  command: 'node',
  args: ['--expose-gc', path.join(ANCHOR_HOME, 'enhanced-socket-server.js')],
  cwd: ANCHOR_HOME,
  env: {
    MCP_SERVER_NAME: 'anchor-manager',
    SOCKET_DIR,
    LOG_DIR
  },
  pidFile: path.join(MCP_DIR, 'anchor-manager.pid'),
  socketPath: path.join(SOCKET_DIR, 'anchor-manager.sock'),
  logPath: path.join(LOG_DIR, 'mcp-server-anchor-manager.log')
});

// Start all processes
pm.startAll()
  .then(() => {
    console.log('✅ All servers started with process manager');
    console.log('ℹ️ Press Ctrl+C to stop all servers');
    
    // Display status periodically
    setInterval(() => {
      const status = pm.getStatus();
      console.log(`\nServer Status (${new Date().toLocaleTimeString()}):`);
      Object.entries(status).forEach(([name, info]) => {
        console.log(`${name}: ${info.status.toUpperCase()} (PID: ${info.pid || 'N/A'}, Restarts: ${info.restarts})`);
      });
    }, 30000);
  })
  .catch(err => {
    console.error(`Failed to start servers: ${err.message}`);
    process.exit(1);
  });

// Handle exit
process.on('SIGINT', async () => {
  console.log('\nShutting down all servers...');
  await pm.stopAll();
  console.log('All servers stopped');
  process.exit(0);
});
EOJS

# Create the launcher script
cat > "${ANCHOR_HOME}/run-with-pm.sh" << 'EOSH'
#!/bin/bash

ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"

# Load environment variables
if [ -f "${ANCHOR_HOME}/.env" ]; then
  source "${ANCHOR_HOME}/.env"
fi

# Run the process manager
echo "🚀 Starting servers with process manager..."
node "${ANCHOR_HOME}/pm-launcher.js"
EOSH

chmod +x "${ANCHOR_HOME}/run-with-pm.sh"
echo "✅ Created process manager launcher script"

# Step 12: Launch the enhanced socket servers
echo -e "\n🔄 Step 12: Launching enhanced socket servers..."
"${ANCHOR_HOME}/launch-enhanced-servers.sh"

# Step 13: Create success marker
echo -e "\n🔄 Step 13: Creating success marker..."
cat > "${ANCHOR_HOME}/ANCHOR_SYSTEM_FIXED.marker" << EOL
Anchor System V6 Fix Successfully Applied
Date: $(date)
User: $(whoami)
Hostname: $(hostname)
EOL

# Final step: Verify servers
echo -e "\n🔄 Final Step: Verifying enhanced socket servers..."
"${ANCHOR_HOME}/verify-enhanced-servers.sh"

echo -e "\n✅ Anchor System V6 fix has been successfully applied!"
echo "The following enhancements have been implemented:"
echo "1. Enhanced Socket Manager for proper socket lifecycle management"
echo "2. Optimized configuration for M3 Max hardware"
echo "3. Improved process management with health monitoring"
echo "4. Consolidated configuration and logging"
echo ""
echo "You can now use the following commands:"
echo "• Launch enhanced servers: ${ANCHOR_HOME}/launch-enhanced-servers.sh"
echo "• Verify server status: ${ANCHOR_HOME}/verify-enhanced-servers.sh"
echo "• Launch with process manager: ${ANCHOR_HOME}/run-with-pm.sh"
echo ""
echo "Important: Restart Claude Desktop to connect to the enhanced servers"
