#!/bin/bash
# M3 Max Optimized Launch Script
# Fixed version - 2025-05-18

set -e

# Load optimized environment if it exists
if [ -f "/Users/XPV/Desktop/anchor-core/.env" ]; then
  source /Users/XPV/Desktop/anchor-core/.env
fi

# Set up environment variables with proper NODE_OPTIONS (no invalid flags)
export NODE_OPTIONS="--max-old-space-size=16384"
export UV_THREADPOOL_SIZE=12
export ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
export MCP_DIR="${ANCHOR_HOME}/mcp-servers"
export SOCKET_DIR="${ANCHOR_HOME}/sockets"
export LOG_DIR="${HOME}/Library/Logs/Claude"

# Start all servers with optimized settings
echo "🚀 Starting M3 Max optimized servers..."

# Make sure required directories exist
mkdir -p "${LOG_DIR}"
mkdir -p "${SOCKET_DIR}"

# Terminate any existing servers
pkill -f "git-local-optimized.js" 2>/dev/null || true
pkill -f "notion-v5-wrapper.js" 2>/dev/null || true
pkill -f "anchor-manager-optimized.js" 2>/dev/null || true
sleep 1

# Start Git Local
echo "Starting Git Local server..."
SOCKET_DIR="${SOCKET_DIR}" MCP_SERVER_NAME="git-local" \
  node "${MCP_DIR}/git-local-optimized.js" > "${LOG_DIR}/mcp-server-git-local.log" 2>&1 &
echo $! > "${MCP_DIR}/git-local.pid"

# Start Notion
echo "Starting Notion server..."
SOCKET_DIR="${SOCKET_DIR}" MCP_SERVER_NAME="notion" \
  node "${MCP_DIR}/notion-v5-wrapper.js" > "${LOG_DIR}/mcp-server-notion.log" 2>&1 &
echo $! > "${MCP_DIR}/notion.pid"

# Start Anchor Manager
echo "Starting Anchor Manager server..."
SOCKET_DIR="${SOCKET_DIR}" MCP_SERVER_NAME="anchor-manager" \
  node "${MCP_DIR}/anchor-manager-optimized.js" > "${LOG_DIR}/mcp-server-anchor-manager.log" 2>&1 &
echo $! > "${MCP_DIR}/anchor-manager.pid"

echo "✅ All servers started with M3 Max optimizations"
echo "🖥 Launch Claude to connect to optimized servers"
