chmod +x /Users/XPV/Desktop/anchor-core/one-step-mcp-fix.sh
