#!/bin/bash
# make-archiving-scripts-executable.sh - Make all archiving protocol scripts executable

# Set strict error handling
set -e

# ANSI color codes for output formatting
GREEN='\033[0;32m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

echo -e "${CYAN}Making archiving protocol scripts executable...${NC}"

chmod +x /Users/XPV/Desktop/anchor-core/meta-protocols/archive-component.sh
chmod +x /Users/XPV/Desktop/anchor-core/meta-protocols/bulk-archive-components.sh
chmod +x /Users/XPV/Desktop/anchor-core/meta-protocols/analyze-archive-candidates.sh
chmod +x /Users/XPV/Desktop/anchor-core/meta-protocols/create-replacement-component.sh

echo -e "${GREEN}✅ All archiving protocol scripts are now executable${NC}"

# Create marker file to indicate this has been done
touch /Users/XPV/Desktop/anchor-core/coherence_lock/ARCHIVE_TOOLS_EXECUTABLE_$(date +"%Y%m%d%H%M%S").marker

exit 0
