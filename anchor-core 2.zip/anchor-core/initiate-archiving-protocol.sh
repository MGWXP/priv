#!/bin/bash
# initiate-archiving-protocol.sh - Initialize and run the archiving protocol

# Set strict error handling
set -e

# ANSI color codes for output formatting
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Print banner
echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║                ANCHOR V6 ARCHIVING PROTOCOL                    ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"

# Make all archiving scripts executable
echo -e "${CYAN}📋 Step 1: Making all protocol scripts executable...${NC}"
chmod +x /Users/XPV/Desktop/anchor-core/make-archiving-scripts-executable.sh
/Users/XPV/Desktop/anchor-core/make-archiving-scripts-executable.sh

# Create archive directory structure if it doesn't exist
echo -e "${CYAN}📋 Step 2: Creating archive directory structure...${NC}"

# Define all required directories
ARCHIVE_DIRS=(
    "/Users/XPV/Desktop/anchor-core/archive/module-system-conflicts"
    "/Users/XPV/Desktop/anchor-core/archive/socket-connectivity-issues"
    "/Users/XPV/Desktop/anchor-core/archive/schema-validation-errors"
    "/Users/XPV/Desktop/anchor-core/archive/process-management-issues"
    "/Users/XPV/Desktop/anchor-core/archive/performance-bottlenecks"
    "/Users/XPV/Desktop/anchor-core/archive/deprecated-implementations"
    "/Users/XPV/Desktop/anchor-core/archive/obsolete-configurations"
    "/Users/XPV/Desktop/anchor-core/analysis"
)

# Create each directory if it doesn't exist
for DIR in "${ARCHIVE_DIRS[@]}"; do
    if [ ! -d "$DIR" ]; then
        echo -e "${YELLOW}Creating directory: $DIR${NC}"
        mkdir -p "$DIR"
    else
        echo -e "${GREEN}Directory exists: $DIR${NC}"
    fi
done

# Run initial analysis
echo -e "${CYAN}📋 Step 3: Running initial component analysis...${NC}"
/Users/XPV/Desktop/anchor-core/meta-protocols/analyze-archive-candidates.sh 30 3

# Display instructions
echo -e "\n${GREEN}✅ Archiving protocol initialized successfully!${NC}"
echo -e "\n${CYAN}Available Commands:${NC}"
echo -e "${MAGENTA}./meta-protocols/analyze-archive-candidates.sh [days] [min_errors]${NC}"
echo -e "   Analyzes components to identify archiving candidates"
echo -e "${MAGENTA}./meta-protocols/archive-component.sh [component_path] [category] [reason] [replacement_path]${NC}"
echo -e "   Archives a single component"
echo -e "${MAGENTA}./meta-protocols/bulk-archive-components.sh [component_list_file]${NC}"
echo -e "   Archives multiple components listed in a CSV file"
echo -e "${MAGENTA}./meta-protocols/create-replacement-component.sh [archived_path] [replacement_path] [type]${NC}"
echo -e "   Creates a replacement component for an archived component"

echo -e "\n${CYAN}Documentation:${NC}"
echo -e "${MAGENTA}/Users/XPV/Desktop/anchor-core/SYSTEMATIC_ARCHIVING_PROTOCOL.md${NC}"
echo -e "   Comprehensive documentation on the archiving protocol"

# Create coherence marker
COHERENCE_MARKER="/Users/XPV/Desktop/anchor-core/coherence_lock/ARCHIVE_PROTOCOL_INITIALIZED_$(date +"%Y-%m-%dT%H%M%S%3N%z").marker"
touch $COHERENCE_MARKER

exit 0
