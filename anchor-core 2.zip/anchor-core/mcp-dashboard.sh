#!/bin/bash
# mcp-dashboard.sh - Real-time MCP system status dashboard
# Part of Anchor System MCP optimization (2025-05-18)

clear
echo "==================================================="
echo "       ANCHOR V6 MCP SYSTEM STATUS DASHBOARD       "
echo "==================================================="
echo "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo "Hardware: M3 Max (48GB unified memory)"
echo ""

# Critical paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
MCP_DIR="$ANCHOR_HOME/mcp-servers"
SOCKET_DIR="$ANCHOR_HOME/sockets"
LOG_DIR="$HOME/Library/Logs/Claude"
COHERENCE_DIR="$ANCHOR_HOME/coherence_lock"

# ANSI colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
RESET='\033[0m'
BOLD='\033[1m'

# Check socket directory
check_socket_dir() {
  if [ -d "/var/run/claude" ]; then
    local perms=$(stat -f '%A' "/var/run/claude")
    if [ "$perms" == "770" ]; then
      echo -e "Socket Directory: ${GREEN}✓ /var/run/claude (770)${RESET}"
    else
      echo -e "Socket Directory: ${YELLOW}⚠ /var/run/claude ($perms)${RESET}"
    fi
  elif [ -d "$SOCKET_DIR" ]; then
    local perms=$(stat -f '%A' "$SOCKET_DIR")
    if [ "$perms" == "770" ]; then
      echo -e "Socket Directory: ${GREEN}✓ $SOCKET_DIR (770)${RESET}"
    else
      echo -e "Socket Directory: ${YELLOW}⚠ $SOCKET_DIR ($perms)${RESET}"
    fi
  else
    echo -e "Socket Directory: ${RED}✗ Not found${RESET}"
  fi
}

# Check server status
check_server() {
  local server_name="$1"
  local pid_file="$MCP_DIR/$server_name.pid"
  local socket_file="$SOCKET_DIR/$server_name.sock"
  
  if [ -f "$pid_file" ]; then
    local pid=$(cat "$pid_file")
    if ps -p "$pid" > /dev/null; then
      if [ -S "$socket_file" ]; then
        echo -e "${server_name}: ${GREEN}✓ RUNNING (PID: $pid)${RESET}"
        return 0
      else
        echo -e "${server_name}: ${YELLOW}⚠ RUNNING BUT NO SOCKET (PID: $pid)${RESET}"
        return 1
      fi
    else
      echo -e "${server_name}: ${RED}✗ NOT RUNNING (Stale PID: $pid)${RESET}"
      return 2
    fi
  else
    # Try to find by process name
    local process_pid=$(pgrep -f "$server_name" || echo "")
    if [ -n "$process_pid" ]; then
      if [ -S "$socket_file" ]; then
        echo -e "${server_name}: ${GREEN}✓ RUNNING (PID: $process_pid)${RESET}"
        return 0
      else
        echo -e "${server_name}: ${YELLOW}⚠ RUNNING BUT NO SOCKET (PID: $process_pid)${RESET}"
        return 1
      fi
    else
      echo -e "${server_name}: ${RED}✗ NOT RUNNING${RESET}"
      return 2
    fi
  fi
}

# Check memory usage
check_memory() {
  local total_memory=$(sysctl -n hw.memsize | awk '{print $1/1024/1024/1024 " GB"}')
  local used_memory=$(vm_stat | grep "Pages active:" | awk '{print $3*4096/1024/1024/1024 " GB"}')
  
  echo -e "Memory Usage: ${BLUE}$used_memory${RESET} / ${BOLD}$total_memory${RESET}"
}

# Check coherence lock
check_coherence() {
  local latest_lock=$(ls -t $COHERENCE_DIR/coherence_lock_*.json 2>/dev/null | head -1)
  
  if [ -n "$latest_lock" ]; then
    local timestamp=$(basename "$latest_lock" | sed 's/coherence_lock_\(.*\)\.json/\1/')
    echo -e "Coherence Lock: ${GREEN}✓ $timestamp${RESET}"
  else
    echo -e "Coherence Lock: ${RED}✗ NOT FOUND${RESET}"
  fi
}

# Check Claude Desktop configuration
check_config() {
  local config_file="$HOME/Library/Application Support/Claude/claude_desktop_config.json"
  
  if [ -f "$config_file" ]; then
    local server_count=$(cat "$config_file" | grep -o "\"mcpServers\"" | wc -l)
    echo -e "Claude Config: ${GREEN}✓ FOUND ($server_count servers)${RESET}"
  else
    echo -e "Claude Config: ${RED}✗ NOT FOUND${RESET}"
  fi
}

# Check Notion database status
check_notion_db() {
  local db_status="$ANCHOR_HOME/notion-db-status.txt"
  
  if [ -f "$db_status" ]; then
    local db_count=$(grep -o "Database ID:" "$db_status" | wc -l)
    echo -e "Notion DBs: ${GREEN}✓ $db_count databases${RESET}"
  else
    echo -e "Notion DBs: ${YELLOW}⚠ Status file not found${RESET}"
  fi
}

# Show system status
show_status() {
  echo -e "${BOLD}SYSTEM STATUS${RESET}"
  echo "-----------------------"
  check_socket_dir
  check_memory
  check_coherence
  check_config
  check_notion_db
  echo ""
  
  echo -e "${BOLD}SERVER STATUS${RESET}"
  echo "-----------------------"
  check_server "filesystem"
  check_server "git-local"
  check_server "notion"
  check_server "anchor-manager"
  echo ""
  
  echo -e "${BOLD}QUICK ACTIONS${RESET}"
  echo "-----------------------"
  echo "1. Restart All Servers"
  echo "2. Fix Socket Directory"
  echo "3. Update Claude Configuration"
  echo "4. Create New Coherence Lock"
  echo "5. View Server Logs"
  echo "6. Exit"
  echo ""
  
  echo -n "Enter your choice (1-6): "
  read choice
  
  case $choice in
    1)
      clear
      echo "Restarting all servers..."
      bash "$ANCHOR_HOME/mcp-restart-all.sh"
      echo ""
      echo "Press Enter to continue..."
      read
      ;;
    2)
      clear
      echo "Fixing socket directory..."
      bash "$ANCHOR_HOME/fix-socket-permissions.sh"
      echo ""
      echo "Press Enter to continue..."
      read
      ;;
    3)
      clear
      echo "Updating Claude configuration..."
      cp "$ANCHOR_HOME/new_claude_config.json" "$HOME/Library/Application Support/Claude/claude_desktop_config.json"
      echo "✅ Configuration updated"
      echo ""
      echo "Press Enter to continue..."
      read
      ;;
    4)
      clear
      echo "Creating new coherence lock..."
      bash -c "source $ANCHOR_HOME/mcp-restart-all.sh; create_coherence_lock"
      echo ""
      echo "Press Enter to continue..."
      read
      ;;
    5)
      clear
      echo "Server logs:"
      echo "1. Filesystem Server"
      echo "2. Git-Local Server"
      echo "3. Notion Server"
      echo "4. Anchor-Manager Server"
      echo "5. Back to Main Menu"
      echo ""
      echo -n "Choose log to view (1-5): "
      read log_choice
      
      case $log_choice in
        1) tail -n 50 "$LOG_DIR/mcp-server-filesystem.log" | less ;;
        2) tail -n 50 "$LOG_DIR/mcp-server-git-local.log" | less ;;
        3) tail -n 50 "$LOG_DIR/mcp-server-notion.log" | less ;;
        4) tail -n 50 "$LOG_DIR/mcp-server-anchor-manager.log" | less ;;
        5) ;;
        *) echo "Invalid choice" ;;
      esac
      
      echo "Press Enter to continue..."
      read
      ;;
    6)
      echo "Exiting..."
      exit 0
      ;;
    *)
      echo "Invalid choice"
      echo "Press Enter to continue..."
      read
      ;;
  esac
}

# Main function
while true; do
  clear
  show_status
done
