#!/usr/bin/env node

const serverName = process.argv[2] || 'unknown';

// Log startup
console.error(`Starting ${serverName} MCP server`);

// Handle input from stdin
process.stdin.on('data', (data) => {
  try {
    // Parse the input as JSON
    const input = JSON.parse(data.toString().trim());
    console.error(`Received message: ${JSON.stringify(input)}`);
    
    // Handle initialize method
    if (input.method === 'initialize') {
      const response = {
        jsonrpc: '2.0',
        id: input.id,
        result: {
          protocolVersion: input.params?.protocolVersion || '2024-11-05',
          name: serverName,
          version: '1.0.0',
          capabilities: {
            tools: {
              [serverName]: {
                description: `${serverName} operations`,
                schema: {
                  type: 'object',
                  properties: {
                    command: {
                      type: 'string',
                      description: 'Command to execute'
                    }
                  },
                  required: ['command']
                }
              }
            }
          }
        }
      };
      
      // Write the response to stdout
      process.stdout.write(JSON.stringify(response) + '\n');
      console.error(`Sent initialize response`);
    }
    // Handle execute method
    else if (input.method === 'execute') {
      const response = {
        jsonrpc: '2.0',
        id: input.id,
        result: {
          output: `Executed ${input.params?.tool} with params: ${JSON.stringify(input.params?.params)}`
        }
      };
      
      // Write the response to stdout
      process.stdout.write(JSON.stringify(response) + '\n');
      console.error(`Sent execute response`);
    }
    // Handle any other method with an error
    else {
      const response = {
        jsonrpc: '2.0',
        id: input.id,
        error: {
          code: -32601,
          message: `Method not found: ${input.method}`
        }
      };
      
      // Write the response to stdout
      process.stdout.write(JSON.stringify(response) + '\n');
      console.error(`Sent error response for unknown method: ${input.method}`);
    }
  } catch (err) {
    console.error(`Error processing message: ${err.message}`);
    
    // Try to send an error response
    try {
      const response = {
        jsonrpc: '2.0',
        id: null,
        error: {
          code: -32700,
          message: `Parse error: ${err.message}`
        }
      };
      
      process.stdout.write(JSON.stringify(response) + '\n');
    } catch (e) {
      console.error(`Failed to send error response: ${e.message}`);
    }
  }
});

// Log when the connection is closed
process.stdin.on('end', () => {
  console.error(`Connection closed for ${serverName}`);
  process.exit(0);
});

// Handle process termination
process.on('SIGINT', () => {
  console.error(`Shutting down ${serverName}...`);
  process.exit(0);
});

// Keep the process running
console.error(`${serverName} MCP server ready`);
