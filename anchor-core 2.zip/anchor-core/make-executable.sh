chmod +x /Users/XPV/Desktop/anchor-core/fix-permissions.sh
echo "✅ Made fix-permissions.sh executable. Run it with:"
echo "./fix-permissions.sh"
