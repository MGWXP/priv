#!/bin/bash
# Run this script to make all CNIF scripts executable
chmod +x /Users/XPV/Desktop/anchor-core/*.sh
chmod +x /Users/XPV/Desktop/anchor-core/m3-optimizer/*.sh
chmod +x /Users/XPV/Desktop/anchor-core/mcp-servers/*.sh

echo "✅ All CNIF scripts are now executable"
echo "🚀 Run ./cnif-quick-start.sh to see available commands"
