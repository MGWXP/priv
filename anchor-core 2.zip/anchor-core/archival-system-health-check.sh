#!/bin/bash
# archival-system-health-check.sh - Health check script for Anchor V6 Archiving System
# Performs diagnostics and verifies all components are functioning correctly

# Set strict error handling
set -e

# ANSI color codes for output formatting
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Make this script executable
chmod +x $0

# Print banner
echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║            ANCHOR V6 ARCHIVAL SYSTEM HEALTH CHECK              ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"

# Define key directories
BASE_DIR="/Users/XPV/Desktop/anchor-core"
META_DIR="$BASE_DIR/meta-protocols"
ARCHIVE_DIR="$BASE_DIR/archive"
ANALYSIS_DIR="$BASE_DIR/analysis"
COHERENCE_DIR="$BASE_DIR/coherence_lock"
LOGS_DIR="$BASE_DIR/logs"
BACKUP_DIR="$BASE_DIR/backups"

# Timestamp for operations
TIMESTAMP=$(date +"%Y%m%d%H%M%S")
HEALTH_LOG="$LOGS_DIR/archival-system-health-$TIMESTAMP.log"

# Create log directory if needed
mkdir -p "$LOGS_DIR"

# Start logging
echo "ANCHOR V6 ARCHIVING SYSTEM HEALTH CHECK LOG" > "$HEALTH_LOG"
echo "Started at: $(date)" >> "$HEALTH_LOG"
echo "----------------------------------------" >> "$HEALTH_LOG"

# Health check status
OVERALL_STATUS="HEALTHY"
ISSUES_FOUND=0

# Function to check directory exists and is writable
check_directory() {
    local dir="$1"
    local description="$2"
    
    if [ ! -d "$dir" ]; then
        echo -e "${RED}✗ $description directory missing: ${MAGENTA}$dir${NC}"
        echo "MISSING DIRECTORY: $dir ($description)" >> "$HEALTH_LOG"
        ISSUES_FOUND=$((ISSUES_FOUND + 1))
        return 1
    fi
    
    if [ ! -w "$dir" ]; then
        echo -e "${YELLOW}⚠ $description directory not writable: ${MAGENTA}$dir${NC}"
        echo "NOT WRITABLE: $dir ($description)" >> "$HEALTH_LOG"
        ISSUES_FOUND=$((ISSUES_FOUND + 1))
        return 1
    fi
    
    echo -e "${GREEN}✓ $description directory: ${MAGENTA}$dir${NC}"
    echo "HEALTHY: $dir ($description)" >> "$HEALTH_LOG"
    return 0
}

# Function to check script exists and is executable
check_script() {
    local script="$1"
    local description="$2"
    
    if [ ! -f "$script" ]; then
        echo -e "${RED}✗ $description script missing: ${MAGENTA}$(basename "$script")${NC}"
        echo "MISSING SCRIPT: $script ($description)" >> "$HEALTH_LOG"
        ISSUES_FOUND=$((ISSUES_FOUND + 1))
        return 1
    fi
    
    if [ ! -x "$script" ]; then
        echo -e "${YELLOW}⚠ $description script not executable: ${MAGENTA}$(basename "$script")${NC}"
        echo "NOT EXECUTABLE: $script ($description)" >> "$HEALTH_LOG"
        ISSUES_FOUND=$((ISSUES_FOUND + 1))
        chmod +x "$script"
        echo "  → Fixed: Made executable" >> "$HEALTH_LOG"
        return 0
    fi
    
    echo -e "${GREEN}✓ $description script: ${MAGENTA}$(basename "$script")${NC}"
    echo "HEALTHY: $script ($description)" >> "$HEALTH_LOG"
    return 0
}

# Function to check archive categories
check_archive_categories() {
    local categories=("$@")
    local missing_count=0
    
    for category in "${categories[@]}"; do
        if [ ! -d "$ARCHIVE_DIR/$category" ]; then
            echo -e "${RED}✗ Archive category missing: ${MAGENTA}$category${NC}"
            echo "MISSING CATEGORY: $ARCHIVE_DIR/$category" >> "$HEALTH_LOG"
            missing_count=$((missing_count + 1))
            
            # Create missing category
            mkdir -p "$ARCHIVE_DIR/$category"
            echo -e "  → Fixed: Created directory" >> "$HEALTH_LOG"
            
            # Create README
            cat > "$ARCHIVE_DIR/$category/README.md" <<EOF
# $category Archive

This directory contains components archived due to $category issues.

## Archived Components

| Component | Archived Date | Reason | Replacement |
|-----------|---------------|--------|-------------|
EOF
            echo -e "  → Fixed: Created README.md" >> "$HEALTH_LOG"
        else
            if [ ! -f "$ARCHIVE_DIR/$category/README.md" ]; then
                echo -e "${YELLOW}⚠ Archive category missing README: ${MAGENTA}$category${NC}"
                echo "MISSING README: $ARCHIVE_DIR/$category/README.md" >> "$HEALTH_LOG"
                
                # Create README
                cat > "$ARCHIVE_DIR/$category/README.md" <<EOF
# $category Archive

This directory contains components archived due to $category issues.

## Archived Components

| Component | Archived Date | Reason | Replacement |
|-----------|---------------|--------|-------------|
EOF
                echo -e "  → Fixed: Created README.md" >> "$HEALTH_LOG"
            else
                echo -e "${GREEN}✓ Archive category: ${MAGENTA}$category${NC}"
                echo "HEALTHY: Archive category $category" >> "$HEALTH_LOG"
            fi
        fi
    done
    
    if [ $missing_count -gt 0 ]; then
        ISSUES_FOUND=$((ISSUES_FOUND + missing_count))
        return 1
    fi
    
    return 0
}

# Function to check coherence markers
check_coherence_markers() {
    if [ ! -d "$COHERENCE_DIR" ]; then
        echo -e "${RED}✗ Coherence lock directory missing${NC}"
        echo "MISSING DIRECTORY: $COHERENCE_DIR" >> "$HEALTH_LOG"
        ISSUES_FOUND=$((ISSUES_FOUND + 1))
        return 1
    fi
    
    # Check for initialization marker
    INIT_MARKER=$(find "$COHERENCE_DIR" -name "ARCHIVAL_SYSTEM_INITIALIZED_*.marker" | sort -r | head -1)
    
    if [ -z "$INIT_MARKER" ]; then
        echo -e "${YELLOW}⚠ No initialization marker found${NC}"
        echo "MISSING MARKER: Initialization marker" >> "$HEALTH_LOG"
        ISSUES_FOUND=$((ISSUES_FOUND + 1))
        
        # Create initialization marker
        NEW_INIT_MARKER="$COHERENCE_DIR/ARCHIVAL_SYSTEM_INITIALIZED_$TIMESTAMP.marker"
        cat > "$NEW_INIT_MARKER" <<EOF
ANCHOR V6 ARCHIVAL SYSTEM INITIALIZED
Initialization Date: $(date)
Protocol Version: 1.0.0
Taxonomy Layer: L0-L13 (All)
Hardware Target: M3 Max (48GB unified memory)
System was re-initialized by health check.
EOF
        echo -e "  → Fixed: Created new initialization marker" >> "$HEALTH_LOG"
    else
        echo -e "${GREEN}✓ Initialization marker: ${MAGENTA}$(basename "$INIT_MARKER")${NC}"
        echo "HEALTHY: Initialization marker $(basename "$INIT_MARKER")" >> "$HEALTH_LOG"
    fi
    
    # Count coherence markers
    MARKER_COUNT=$(find "$COHERENCE_DIR" -name "*.marker" | wc -l)
    echo -e "${GREEN}✓ Coherence markers: ${MAGENTA}$MARKER_COUNT${NC} found"
    echo "INFO: $MARKER_COUNT coherence markers found" >> "$HEALTH_LOG"
    
    return 0
}

# Check filesystem structure
echo -e "\n${CYAN}Checking filesystem structure...${NC}"
echo "Checking filesystem structure" >> "$HEALTH_LOG"

check_directory "$META_DIR" "Meta-protocols"
check_directory "$ARCHIVE_DIR" "Archive"
check_directory "$ANALYSIS_DIR" "Analysis" 
check_directory "$COHERENCE_DIR" "Coherence lock"
check_directory "$LOGS_DIR" "Logs"
check_directory "$BACKUP_DIR" "Backups"

# Check archive categories
echo -e "\n${CYAN}Checking archive categories...${NC}"
echo "Checking archive categories" >> "$HEALTH_LOG"

CATEGORIES=("module-system-conflicts" "socket-connectivity-issues" "schema-validation-errors" "process-management-issues" "performance-bottlenecks" "deprecated-implementations" "obsolete-configurations")
check_archive_categories "${CATEGORIES[@]}"

# Check protocol scripts
echo -e "\n${CYAN}Checking protocol scripts...${NC}"
echo "Checking protocol scripts" >> "$HEALTH_LOG"

PROTOCOL_SCRIPTS=(
    "$META_DIR/analyze-archive-candidates.sh:Log-based analysis tool"
    "$META_DIR/identify-archive-candidates.sh:Source code analysis tool"
    "$META_DIR/archive-component.sh:Single component archiver"
    "$META_DIR/bulk-archive-components.sh:Bulk component archiver"
    "$META_DIR/create-replacement-component.sh:Replacement component generator"
    "$META_DIR/archive-dashboard.sh:Archiving dashboard generator"
    "$META_DIR/component-migration-manager.sh:Migration manager"
    "$BASE_DIR/archival-protocol-controller.sh:Protocol controller"
    "$BASE_DIR/make-archival-scripts-executable.sh:Script permission manager"
    "$BASE_DIR/initialize-archival-system.sh:System initializer"
)

for script_info in "${PROTOCOL_SCRIPTS[@]}"; do
    IFS=: read -r script description <<< "$script_info"
    check_script "$script" "$description"
done

# Check coherence markers
echo -e "\n${CYAN}Checking coherence markers...${NC}"
echo "Checking coherence markers" >> "$HEALTH_LOG"
check_coherence_markers

# Check disk space
echo -e "\n${CYAN}Checking disk space...${NC}"
echo "Checking disk space" >> "$HEALTH_LOG"

AVAILABLE_SPACE=$(df -h "$BASE_DIR" | awk 'NR==2 {print $4}')
echo -e "${GREEN}✓ Available disk space: ${MAGENTA}$AVAILABLE_SPACE${NC}"
echo "INFO: Available disk space: $AVAILABLE_SPACE" >> "$HEALTH_LOG"

# Run quick verification test
echo -e "\n${CYAN}Running quick verification test...${NC}"
echo "Running quick verification test" >> "$HEALTH_LOG"

# Create test marker
TEST_MARKER="$COHERENCE_DIR/HEALTH_CHECK_TEST_$TIMESTAMP.marker"
if touch "$TEST_MARKER"; then
    echo -e "${GREEN}✓ Coherence marker test: ${MAGENTA}successful${NC}"
    echo "TEST PASSED: Created test marker $TEST_MARKER" >> "$HEALTH_LOG"
    # Clean up test marker
    rm "$TEST_MARKER"
else
    echo -e "${RED}✗ Coherence marker test: ${MAGENTA}failed${NC}"
    echo "TEST FAILED: Could not create test marker" >> "$HEALTH_LOG"
    ISSUES_FOUND=$((ISSUES_FOUND + 1))
    OVERALL_STATUS="UNHEALTHY"
fi

# Check archive report existence and format
if [ -f "$BASE_DIR/ARCHIVE_REPORT.md" ]; then
    echo -e "${GREEN}✓ Archive report: ${MAGENTA}exists${NC}"
    echo "HEALTHY: Archive report exists" >> "$HEALTH_LOG"
else
    echo -e "${YELLOW}⚠ Archive report missing: ${MAGENTA}creating template${NC}"
    echo "MISSING: Archive report" >> "$HEALTH_LOG"
    
    # Create archive report template
    cat > "$BASE_DIR/ARCHIVE_REPORT.md" <<EOF
# Anchor V6 System Archiving Report

## Executive Summary

This report documents the systematic archival of files that could potentially cause system instability, module conflicts, performance issues, or coherence failures in the Anchor V6 System. The archival process is an ongoing effort to prevent regression issues, maintain system coherence, and optimize performance on M3 Max hardware.

## Background

The Anchor V6 system utilizes the Systematic Archiving Protocol to manage component lifecycle and maintain system coherence. This report tracks all archived components and their replacements.

## Archived Components

No components have been archived yet.

## Best Practices for Future Development

To ensure continued system coherence:

1. **Module System Consistency**
   - Always maintain consistency between package.json configuration and code syntax
   - For CommonJS: Use \`"type": "commonjs"\` or omit the field (default)
   - For ES Modules: Use \`"type": "module"\` and write all code with \`import\`/\`export\`

2. **File Extensions**
   - Use explicit file extensions for clarity
   - \`.cjs\` for CommonJS modules
   - \`.mjs\` for ES modules
   - \`.js\` follows the package.json \`type\` setting

3. **Memory Optimization**
   - Implement proper cleanup and resource management
   - Monitor memory usage with \`--max-old-space-size=8192\`
   - Optimize for M3 Max hardware with \`UV_THREADPOOL_SIZE=12\`

4. **Coherence Tracking**
   - Create coherence markers for successful operations
   - Use timestamped markers for proper sequencing
   - Document changes in appropriate systems
EOF
    
    echo -e "  → Fixed: Created archive report template" >> "$HEALTH_LOG"
    ISSUES_FOUND=$((ISSUES_FOUND + 1))
fi

# Final health status
if [ $ISSUES_FOUND -gt 0 ]; then
    OVERALL_STATUS="ISSUES FOUND AND FIXED"
fi

# Create health check marker
HEALTH_MARKER="$COHERENCE_DIR/ARCHIVAL_SYSTEM_HEALTH_CHECK_$TIMESTAMP.marker"
cat > "$HEALTH_MARKER" <<EOF
ANCHOR V6 ARCHIVAL SYSTEM HEALTH CHECK
Check Date: $(date)
Status: $OVERALL_STATUS
Issues Found: $ISSUES_FOUND
Health Log: $HEALTH_LOG
EOF

echo -e "\n${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║                  HEALTH CHECK COMPLETED                         ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
echo -e "\n${CYAN}Overall Status: ${ISSUES_FOUND -eq 0 ? "${GREEN}" : "${YELLOW}"}$OVERALL_STATUS${NC}"
echo -e "${CYAN}Issues Found and Fixed: ${MAGENTA}$ISSUES_FOUND${NC}"
echo -e "${CYAN}Health Check Log: ${MAGENTA}$HEALTH_LOG${NC}"
echo -e "${CYAN}Health Check Marker: ${MAGENTA}$(basename "$HEALTH_MARKER")${NC}"

# Log completion
echo "----------------------------------------" >> "$HEALTH_LOG"
echo "Health check completed at: $(date)" >> "$HEALTH_LOG"
echo "Overall Status: $OVERALL_STATUS" >> "$HEALTH_LOG"
echo "Issues Found and Fixed: $ISSUES_FOUND" >> "$HEALTH_LOG"

exit $ISSUES_FOUND
