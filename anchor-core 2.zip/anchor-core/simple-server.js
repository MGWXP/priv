const net = require('net');
const fs = require('fs');

const serverName = process.argv[2];
const socketPath = process.argv[3];

if (!serverName || !socketPath) {
  console.error('Usage: node simple-server.js <server-name> <socket-path>');
  process.exit(1);
}

// Remove existing socket
try {
  if (fs.existsSync(socketPath)) {
    fs.unlinkSync(socketPath);
  }
} catch (err) {
  console.error(`Error removing socket: ${err.message}`);
}

// Create server
const server = net.createServer((socket) => {
  console.log(`Client connected to ${serverName}`);
  
  socket.on('data', (data) => {
    try {
      const message = JSON.parse(data.toString());
      console.log(`Received from ${serverName}:`, JSON.stringify(message, null, 2));
      
      if (message.method === 'initialize') {
        const response = {
          jsonrpc: '2.0',
          id: message.id,
          result: {
            protocolVersion: '2024-11-05',
            name: serverName,
            version: '1.0.0',
            capabilities: {
              tools: {
                [serverName]: {
                  description: `${serverName} operations`,
                  schema: {
                    type: 'object',
                    properties: {
                      command: {
                        type: 'string',
                        description: 'Command to execute'
                      }
                    },
                    required: ['command']
                  }
                }
              }
            }
          }
        };
        console.log(`Sending from ${serverName}:`, JSON.stringify(response, null, 2));
        socket.write(JSON.stringify(response) + '\n');
      } else {
        const response = {
          jsonrpc: '2.0',
          id: message.id,
          result: {
            output: `Executed ${message.method} on ${serverName}`
          }
        };
        console.log(`Sending from ${serverName}:`, JSON.stringify(response, null, 2));
        socket.write(JSON.stringify(response) + '\n');
      }
    } catch (err) {
      console.error(`Error processing message: ${err.message}`);
    }
  });
  
  socket.on('error', (err) => {
    console.error(`Socket error on ${serverName}: ${err.message}`);
  });
  
  socket.on('close', () => {
    console.log(`Client disconnected from ${serverName}`);
  });
});

server.on('error', (err) => {
  console.error(`Server error on ${serverName}: ${err.message}`);
});

// Start listening
server.listen(socketPath, () => {
  console.log(`${serverName} server listening on ${socketPath}`);
  
  // Set permissions
  fs.chmod(socketPath, 0o666, (err) => {
    if (err) {
      console.error(`Failed to set permissions on ${socketPath}: ${err.message}`);
    } else {
      console.log(`Set permissions on ${socketPath} to 0666`);
    }
  });
});

// Handle process termination
process.on('SIGINT', () => {
  console.log(`Shutting down ${serverName} server...`);
  server.close(() => {
    if (fs.existsSync(socketPath)) {
      fs.unlinkSync(socketPath);
    }
    process.exit(0);
  });
});
