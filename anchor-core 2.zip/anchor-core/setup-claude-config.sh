#!/bin/bash
# setup-claude-config.sh - Create or update Claude configuration
# © 2025 XPV - MIT

set -e  # Exit on error

# Define paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
SOCKET_DIR="${ANCHOR_HOME}/sockets"
CONFIG_DIR="${HOME}/Library/Application Support/Claude"
CONFIG_FILE="${CONFIG_DIR}/claude_desktop_config.json"

echo "🔧 Setting up Claude configuration..."

# Create config directory if it doesn't exist
mkdir -p "${CONFIG_DIR}"

# Create a basic configuration if it doesn't exist
if [ ! -f "${CONFIG_FILE}" ]; then
  echo "Creating new Claude configuration..."
  
  cat > "${CONFIG_FILE}" << EOL
{
  "mcpServers": {
    "git-local": {
      "socketPath": "${SOCKET_DIR}/git-local.sock"
    },
    "notion": {
      "socketPath": "${SOCKET_DIR}/notion.sock"
    },
    "anchor-manager": {
      "socketPath": "${SOCKET_DIR}/anchor-manager.sock"
    }
  }
}
EOL
  echo "✅ Created new configuration file: ${CONFIG_FILE}"
else
  # Make a backup of existing config
  cp "${CONFIG_FILE}" "${CONFIG_FILE}.bak"
  echo "📦 Backed up existing configuration to ${CONFIG_FILE}.bak"
  
  # Check if MCP servers already configured
  if grep -q "mcpServers" "${CONFIG_FILE}"; then
    echo "Updating existing MCP server configuration..."
    
    # Use temporary file for sed on macOS
    sed -i.tmp 's|"socketPath": ".*git-local.sock"|"socketPath": "'"${SOCKET_DIR}"'/git-local.sock"|g' "${CONFIG_FILE}"
    sed -i.tmp 's|"socketPath": ".*notion.sock"|"socketPath": "'"${SOCKET_DIR}"'/notion.sock"|g' "${CONFIG_FILE}"
    sed -i.tmp 's|"socketPath": ".*anchor-manager.sock"|"socketPath": "'"${SOCKET_DIR}"'/anchor-manager.sock"|g' "${CONFIG_FILE}"
    
    # Clean up temporary files
    rm -f "${CONFIG_FILE}.tmp"
  else
    echo "Adding MCP server configuration..."
    
    # Create a temporary file with the configuration
    TEMP_FILE=$(mktemp)
    jq '. + {"mcpServers": {"git-local": {"socketPath": "'"${SOCKET_DIR}"'/git-local.sock"}, "notion": {"socketPath": "'"${SOCKET_DIR}"'/notion.sock"}, "anchor-manager": {"socketPath": "'"${SOCKET_DIR}"'/anchor-manager.sock"}}}' "${CONFIG_FILE}" > "${TEMP_FILE}"
    
    # Copy it back to the original location
    cp "${TEMP_FILE}" "${CONFIG_FILE}"
    rm -f "${TEMP_FILE}"
  fi
  
  echo "✅ Updated configuration file: ${CONFIG_FILE}"
fi

echo "✅ Claude configuration is ready"
echo "  - Socket directory: ${SOCKET_DIR}"
echo "  - Configuration file: ${CONFIG_FILE}"
echo
echo "You can now start the MCP servers with:"
echo "  ${ANCHOR_HOME}/launch-optimized.sh"
