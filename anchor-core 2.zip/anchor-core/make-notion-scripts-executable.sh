#!/bin/bash
# make-scripts-executable.sh
# Makes all the Notion integration scripts executable

find /Users/XPV/Desktop/anchor-core -name "*.sh" -exec chmod +x {} \;
chmod +x /Users/XPV/Desktop/anchor-core/mcp-servers/notion-integration.js

echo "✅ Made all Notion integration scripts executable"

echo "To set up the Notion integration, run:"
echo "  /Users/XPV/Desktop/anchor-core/setup-notion-integration.sh"

echo "To update Claude Desktop configuration, run:"
echo "  /Users/XPV/Desktop/anchor-core/update-claude-config.sh"
