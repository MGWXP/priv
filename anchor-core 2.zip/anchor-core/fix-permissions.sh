#!/bin/bash
# fix-permissions.sh - Fix permissions for all CNIF scripts
# © 2025 XPV - MIT

ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
LOG_DIR="${HOME}/Library/Logs/Claude"

# Create output log
log_file="${LOG_DIR}/fix-permissions-$(date +%Y%m%d%H%M%S).log"
mkdir -p "${LOG_DIR}"

# Log function
log() {
  echo "$(date +"%Y-%m-%d %H:%M:%S") - $1" | tee -a "$log_file"
}

log "Starting CNIF permissions fix..."

# Make all scripts executable
for script in $(find "${ANCHOR_HOME}" -name "*.sh"); do
  chmod +x "$script"
  log "Made executable: $script"
done

# Fix permissions for entry point scripts
for entry_point in $(find "${ANCHOR_HOME}/mcp-servers/entry-points" -name "*.js" 2>/dev/null); do
  chmod +x "$entry_point"
  log "Made executable: $entry_point"
done

# Fix permissions for important directories
log "Setting directory permissions..."
mkdir -p "${ANCHOR_HOME}/schemas/claude"
mkdir -p "${ANCHOR_HOME}/schemas/notion"
mkdir -p "${ANCHOR_HOME}/config"
mkdir -p "${ANCHOR_HOME}/sockets"
mkdir -p "${ANCHOR_HOME}/coherence_lock"
mkdir -p "${ANCHOR_HOME}/tests/temp"
mkdir -p "${ANCHOR_HOME}/tests/results"

# Set key directory permissions
chmod 755 "${ANCHOR_HOME}/schemas"
chmod 755 "${ANCHOR_HOME}/schemas/claude"
chmod 755 "${ANCHOR_HOME}/schemas/notion"
chmod 755 "${ANCHOR_HOME}/config"
chmod 755 "${ANCHOR_HOME}/sockets"
chmod 755 "${ANCHOR_HOME}/coherence_lock"
chmod 755 "${ANCHOR_HOME}/m3-optimizer"
chmod 755 "${ANCHOR_HOME}/mcp-servers"
chmod 755 "${ANCHOR_HOME}/mcp-servers/entry-points"
chmod 755 "${ANCHOR_HOME}/tests"
chmod 755 "${ANCHOR_HOME}/tests/temp"
chmod 755 "${ANCHOR_HOME}/tests/results"
chmod 755 "${LOG_DIR}"

# Check and fix socket files
for socket in $(find "${ANCHOR_HOME}/sockets" -name "*.sock" 2>/dev/null); do
  chmod 666 "$socket"
  log "Set socket permissions: $socket"
done

# Make key scripts executable by name
chmod +x "${ANCHOR_HOME}/sequenced-launcher.sh"
chmod +x "${ANCHOR_HOME}/simple-launcher.sh"
chmod +x "${ANCHOR_HOME}/cnif-system-check.sh"
chmod +x "${ANCHOR_HOME}/cnif-integration-test.sh"
chmod +x "${ANCHOR_HOME}/run-cnif-optimizer.sh"
chmod +x "${ANCHOR_HOME}/fix-socket-permissions.sh"
chmod +x "${ANCHOR_HOME}/make-all-executable.sh"

log "✅ Fixed permissions for all CNIF components"
echo "✅ All CNIF scripts are now executable"
echo "🚀 You can now run CNIF commands without permission errors"
