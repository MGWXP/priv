#!/bin/bash
# create-system-metrics-db.sh - Creates System Metrics Database in Notion
# For M3 Max (48GB unified memory) hardware

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

NOTION_PAGE_ID="1f7e48c2-bbbd-80df-86ed-d35832916f80"

echo -e "${BLUE}=== Creating System Metrics Database in Notion ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e ""

# Check if NOTION_API_KEY is set
if [ -z "${NOTION_API_KEY}" ]; then
    echo -e "${YELLOW}NOTION_API_KEY environment variable is not set${NC}"
    echo -e "Would you like to set it now? (y/n)"
    read -r response
    if [[ "$response" =~ ^([yY][eE][sS]|[yY])$ ]]; then
        echo -e "Enter your Notion API Key:"
        read -s NOTION_KEY
        export NOTION_API_KEY="$NOTION_KEY"
        echo -e "${GREEN}✓ NOTION_API_KEY set${NC}"
    else
        echo -e "${RED}Cannot proceed without Notion API Key${NC}"
        exit 1
    fi
fi

# Create System Metrics database
echo -e "Creating System Metrics database..."
RESPONSE=$(curl -s -X POST "https://api.notion.com/v1/databases" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "parent": {
        "type": "page_id",
        "page_id": "'"${NOTION_PAGE_ID}"'"
    },
    "title": [
        {
            "type": "text",
            "text": {
                "content": "System Metrics"
            }
        }
    ],
    "properties": {
        "Metric ID": {
            "title": {}
        },
        "Category": {
            "select": {
                "options": [
                    {"name": "Performance", "color": "blue"},
                    {"name": "Memory", "color": "green"},
                    {"name": "Network", "color": "purple"},
                    {"name": "Storage", "color": "orange"},
                    {"name": "CPU", "color": "yellow"}
                ]
            }
        },
        "Value": {
            "number": {
                "format": "number"
            }
        },
        "Unit": {
            "select": {
                "options": [
                    {"name": "ms", "color": "default"},
                    {"name": "MB", "color": "default"},
                    {"name": "GB", "color": "default"},
                    {"name": "%", "color": "default"},
                    {"name": "req/s", "color": "default"}
                ]
            }
        },
        "Timestamp": {
            "date": {}
        },
        "Component": {
            "relation": {
                "database_id": "1f8e48c2-bbbd-8123-977b-f35e3fa545e5",
                "single_property": {}
            }
        },
        "Threshold": {
            "number": {
                "format": "number"
            }
        },
        "Alert": {
            "checkbox": {}
        }
    }
}')

# Extract database ID from response
DB_ID=$(echo $RESPONSE | grep -o '"id":"[^"]*' | cut -d'"' -f4)

if [ -z "$DB_ID" ]; then
    echo -e "${RED}Failed to create System Metrics database${NC}"
    echo $RESPONSE
    exit 1
fi

echo -e "${GREEN}✓ System Metrics database created successfully!${NC}"
echo -e "Database ID: ${DB_ID}"

# Extract property IDs for reference
echo $RESPONSE | grep -o '"id":"[^"]*' | cut -d'"' -f4

# Create sample metric entry
echo -e "Creating sample metric entry for CPU utilization..."
METRIC_RESPONSE=$(curl -s -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "parent": {
        "database_id": "'"${DB_ID}"'"
    },
    "properties": {
        "Metric ID": {
            "title": [
                {
                    "text": {
                        "content": "MET-0001"
                    }
                }
            ]
        },
        "Category": {
            "select": {
                "name": "CPU"
            }
        },
        "Value": {
            "number": 42.5
        },
        "Unit": {
            "select": {
                "name": "%"
            }
        },
        "Timestamp": {
            "date": {
                "start": "'"$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")"'"
            }
        },
        "Threshold": {
            "number": 80.0
        },
        "Alert": {
            "checkbox": false
        }
    }
}')

if echo $METRIC_RESPONSE | grep -q "error"; then
    echo -e "${YELLOW}Sample metric entry created with warnings${NC}"
else
    echo -e "${GREEN}✓ Sample metric entry created successfully!${NC}"
fi

# Create second sample metric entry
echo -e "Creating sample metric entry for Memory usage..."
METRIC_RESPONSE2=$(curl -s -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "parent": {
        "database_id": "'"${DB_ID}"'"
    },
    "properties": {
        "Metric ID": {
            "title": [
                {
                    "text": {
                        "content": "MET-0002"
                    }
                }
            ]
        },
        "Category": {
            "select": {
                "name": "Memory"
            }
        },
        "Value": {
            "number": 12.8
        },
        "Unit": {
            "select": {
                "name": "GB"
            }
        },
        "Timestamp": {
            "date": {
                "start": "'"$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")"'"
            }
        },
        "Threshold": {
            "number": 32.0
        },
        "Alert": {
            "checkbox": false
        }
    }
}')

if echo $METRIC_RESPONSE2 | grep -q "error"; then
    echo -e "${YELLOW}Second metric entry created with warnings${NC}"
else
    echo -e "${GREEN}✓ Second metric entry created successfully!${NC}"
fi

# Save database ID for future reference
echo "${DB_ID}" > /Users/XPV/Desktop/anchor-core/system-metrics-db-id.txt
mkdir -p /Users/XPV/Desktop/anchor-core/notion-db-ids
echo "${DB_ID}" > /Users/XPV/Desktop/anchor-core/notion-db-ids/system-metrics-id.txt

echo -e "\n${GREEN}✓ System Metrics setup complete!${NC}"
echo -e "${YELLOW}View your database at: https://www.notion.so/${DB_ID}${NC}"

# Mark the System Metrics task as completed
curl -X PATCH "https://api.notion.com/v1/blocks/1f8e48c2-bced-402c-bcee-e3968da6b6c1" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "to_do": {
        "checked": true
    }
  }'
