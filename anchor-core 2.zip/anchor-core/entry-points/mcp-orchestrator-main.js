/**
 * mcp-orchestrator-main.js - Entry point for MCP orchestrator
 * © 2025 XPV - MIT
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const { MCPOrchestrator } = require('../core/mcp-orchestrator.cjs');

// Configure from environment or defaults
const options = {
  serverName: 'mcp-orchestrator',
  anchorHome: process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core',
  socketDir: process.env.SOCKET_DIR || path.join(process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core', 'sockets'),
  logDir: process.env.LOG_DIR || path.join(os.homedir(), 'Library/Logs/Claude')
};

// Log startup
console.log(`[${new Date().toISOString()}] Starting ${options.serverName}...`);
console.log(`[${new Date().toISOString()}] Using Socket directory: ${options.socketDir}`);
console.log(`[${new Date().toISOString()}] Using Log directory: ${options.logDir}`);

// Create orchestrator
const orchestrator = new MCPOrchestrator(options);

// Initialize and start
orchestrator.initialize()
  .then(() => {
    console.log(`[${new Date().toISOString()}] ${options.serverName} started successfully`);
  })
  .catch(err => {
    console.error(`[${new Date().toISOString()}] Failed to start ${options.serverName}: ${err.message}`);
    process.exit(1);
  });

// Handle process signals
process.on('SIGINT', () => {
  console.log(`[${new Date().toISOString()}] Received SIGINT, shutting down...`);
  orchestrator.stop()
    .then(() => process.exit(0))
    .catch(err => {
      console.error(`[${new Date().toISOString()}] Error during shutdown: ${err.message}`);
      process.exit(1);
    });
});

process.on('SIGTERM', () => {
  console.log(`[${new Date().toISOString()}] Received SIGTERM, shutting down...`);
  orchestrator.stop()
    .then(() => process.exit(0))
    .catch(err => {
      console.error(`[${new Date().toISOString()}] Error during shutdown: ${err.message}`);
      process.exit(1);
    });
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  console.error(`[${new Date().toISOString()}] Uncaught exception: ${err.message}`);
  console.error(err.stack);
  
  // Try to stop orchestrator gracefully, then exit
  orchestrator.stop()
    .catch(() => {/* ignore errors during emergency shutdown */})
    .finally(() => process.exit(1));
});

// Handle unhandled rejections
process.on('unhandledRejection', (reason, promise) => {
  console.error(`[${new Date().toISOString()}] Unhandled rejection: ${reason}`);
  
  // Don't exit, just log the error
});
