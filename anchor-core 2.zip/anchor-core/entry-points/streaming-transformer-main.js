/**
 * streaming-transformer-main.js - Entry point for streaming transformer
 * © 2025 XPV - MIT
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const { StreamingTransformer } = require('../core/streaming-transformer.cjs');
const { SocketServer } = require('../core/socket-server.cjs');
const SchemaRegistry = require('../core/schema-registry.cjs');

// Configure from environment or defaults
const options = {
  serverName: process.env.MCP_SERVER_NAME || 'streaming-transformer',
  anchorHome: process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core',
  socketDir: process.env.SOCKET_DIR || path.join(process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core', 'sockets'),
  logDir: process.env.LOG_DIR || path.join(os.homedir(), 'Library/Logs/Claude'),
  schemaDirClaude: path.join(process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core', 'schemas', 'claude'),
  schemaDirNotion: path.join(process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core', 'schemas', 'notion')
};

// Log startup
console.log(`[${new Date().toISOString()}] Starting ${options.serverName} server...`);
console.log(`[${new Date().toISOString()}] Using Socket directory: ${options.socketDir}`);
console.log(`[${new Date().toISOString()}] Using Log directory: ${options.logDir}`);

// Create schema registry (for validation)
const registry = new SchemaRegistry({
  schemaDirClaude: options.schemaDirClaude,
  schemaDirNotion: options.schemaDirNotion,
  cacheEnabled: true,
  validateOnLoad: true
});

// Create transformer
const transformer = new StreamingTransformer({
  validateInput: true,
  validateOutput: true,
  streamingEnabled: true,
  maxInMemorySize: 1024 * 1024, // 1MB
  useMemoryPool: true,
  schemaRegistry: registry
});

// Create custom socket server class
class TransformerServer extends SocketServer {
  constructor(options) {
    super(options);
    this.transformer = options.transformer;
    this.registry = options.registry;
  }
  
  // Handle tool invocation
  _handleToolInvocation(message, client) {
    // Check tool type
    switch (message.tool) {
      case 'transform-xml-to-json':
        this._handleXmlToJson(message, client);
        break;
        
      case 'transform-json-to-xml':
        this._handleJsonToXml(message, client);
        break;
        
      case 'create-streaming-transform':
        this._handleCreateStreamingTransform(message, client);
        break;
        
      default:
        this.sendErrorResponse(client.id, {
          error: `Unknown tool: ${message.tool}`,
          type: message.type,
          id: message.id
        });
    }
  }
  
  // Handle XML to JSON transformation
  async _handleXmlToJson(message, client) {
    try {
      // Extract parameters
      const { xml, options } = message.parameters || {};
      
      if (!xml) {
        throw new Error('Missing required parameter: xml');
      }
      
      // Transform
      const result = await this.transformer.transformXmlToJson(xml, options || {});
      
      // Send response
      this.sendResponse(client.id, {
        type: 'tool_response',
        id: message.id,
        status: 'success',
        result
      });
    } catch (err) {
      this.log('ERROR', `Error transforming XML to JSON: ${err.message}`, { clientId: client.id });
      
      this.sendErrorResponse(client.id, {
        error: `Transformation error: ${err.message}`,
        type: message.type,
        id: message.id
      });
    }
  }
  
  // Handle JSON to XML transformation
  async _handleJsonToXml(message, client) {
    try {
      // Extract parameters
      const { json, options } = message.parameters || {};
      
      if (!json) {
        throw new Error('Missing required parameter: json');
      }
      
      // Transform
      const result = await this.transformer.transformJsonToXml(json, options || {});
      
      // Send response
      this.sendResponse(client.id, {
        type: 'tool_response',
        id: message.id,
        status: 'success',
        result
      });
    } catch (err) {
      this.log('ERROR', `Error transforming JSON to XML: ${err.message}`, { clientId: client.id });
      
      this.sendErrorResponse(client.id, {
        error: `Transformation error: ${err.message}`,
        type: message.type,
        id: message.id
      });
    }
  }
  
  // Handle streaming transform creation (not fully implemented)
  async _handleCreateStreamingTransform(message, client) {
    try {
      // Extract parameters
      const { direction, options } = message.parameters || {};
      
      if (!direction) {
        throw new Error('Missing required parameter: direction (xml-to-json or json-to-xml)');
      }
      
      // This would normally create a streaming transform
      // For now, just acknowledge the request
      this.sendResponse(client.id, {
        type: 'tool_response',
        id: message.id,
        status: 'success',
        result: {
          transformId: `transform-${Date.now()}`,
          direction,
          streaming: true,
          message: 'Streaming transform created (note: actual streaming not implemented in this version)'
        }
      });
    } catch (err) {
      this.log('ERROR', `Error creating streaming transform: ${err.message}`, { clientId: client.id });
      
      this.sendErrorResponse(client.id, {
        error: `Streaming transform error: ${err.message}`,
        type: message.type,
        id: message.id
      });
    }
  }
  
  // Handle custom message type
  _handleCustomMessageType(message, client) {
    // Handle metrics request
    if (message.type === 'get_metrics') {
      const metrics = this.transformer.getMetrics();
      
      this.sendResponse(client.id, {
        type: 'metrics_response',
        id: message.id || 'unknown',
        status: 'success',
        metrics
      });
      
      return true;
    }
    
    return false;
  }
}

// Create server instance
const server = new TransformerServer({
  ...options,
  transformer,
  registry
});

// Initialize registry and start server
Promise.all([
  registry.initialize(),
  server.start()
])
.then(() => {
  console.log(`[${new Date().toISOString()}] ${options.serverName} server started successfully`);
})
.catch(err => {
  console.error(`[${new Date().toISOString()}] Failed to start ${options.serverName} server: ${err.message}`);
  process.exit(1);
});

// Set up transformer event handlers
transformer.on('error', (data) => {
  console.error(`[${new Date().toISOString()}] Transformer error: ${data.error.message}`);
});

transformer.on('streaming-transform', (data) => {
  console.log(`[${new Date().toISOString()}] Streaming transform started: ${data.type}, size: ${data.size}`);
});

transformer.on('streaming-progress', (data) => {
  console.log(`[${new Date().toISOString()}] Streaming progress: ${data.type}, ${data.progress}%`);
});

// Handle process signals
process.on('SIGINT', () => {
  console.log(`[${new Date().toISOString()}] Received SIGINT, shutting down...`);
  server.stop()
    .then(() => process.exit(0))
    .catch(err => {
      console.error(`[${new Date().toISOString()}] Error during shutdown: ${err.message}`);
      process.exit(1);
    });
});

process.on('SIGTERM', () => {
  console.log(`[${new Date().toISOString()}] Received SIGTERM, shutting down...`);
  server.stop()
    .then(() => process.exit(0))
    .catch(err => {
      console.error(`[${new Date().toISOString()}] Error during shutdown: ${err.message}`);
      process.exit(1);
    });
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  console.error(`[${new Date().toISOString()}] Uncaught exception: ${err.message}`);
  console.error(err.stack);
  
  // Try to stop server gracefully, then exit
  server.stop()
    .catch(() => {/* ignore errors during emergency shutdown */})
    .finally(() => process.exit(1));
});

// Handle unhandled rejections
process.on('unhandledRejection', (reason, promise) => {
  console.error(`[${new Date().toISOString()}] Unhandled rejection: ${reason}`);
  
  // Don't exit, just log the error
});
