/**
 * socket-server-main.js - Entry point for socket server
 * © 2025 XPV - MIT
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const { SocketServer } = require('../core/socket-server.cjs');

// Configure server from environment or defaults
const options = {
  serverName: process.env.MCP_SERVER_NAME || 'socket-server',
  anchorHome: process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core',
  socketDir: process.env.SOCKET_DIR || path.join(process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core', 'sockets'),
  logDir: process.env.LOG_DIR || path.join(os.homedir(), 'Library/Logs/Claude')
};

// Log startup
console.log(`[${new Date().toISOString()}] Starting ${options.serverName} server...`);
console.log(`[${new Date().toISOString()}] Using Socket directory: ${options.socketDir}`);
console.log(`[${new Date().toISOString()}] Using Log directory: ${options.logDir}`);

// Create instance
const server = new SocketServer(options);

// Start server
server.start()
  .then(() => {
    console.log(`[${new Date().toISOString()}] ${options.serverName} server started successfully`);
  })
  .catch(err => {
    console.error(`[${new Date().toISOString()}] Failed to start ${options.serverName} server: ${err.message}`);
    process.exit(1);
  });

// Handle process signals
process.on('SIGINT', () => {
  console.log(`[${new Date().toISOString()}] Received SIGINT, shutting down...`);
  server.stop()
    .then(() => process.exit(0))
    .catch(err => {
      console.error(`[${new Date().toISOString()}] Error during shutdown: ${err.message}`);
      process.exit(1);
    });
});

process.on('SIGTERM', () => {
  console.log(`[${new Date().toISOString()}] Received SIGTERM, shutting down...`);
  server.stop()
    .then(() => process.exit(0))
    .catch(err => {
      console.error(`[${new Date().toISOString()}] Error during shutdown: ${err.message}`);
      process.exit(1);
    });
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  console.error(`[${new Date().toISOString()}] Uncaught exception: ${err.message}`);
  console.error(err.stack);
  
  // Try to stop server gracefully, then exit
  server.stop()
    .catch(() => {/* ignore errors during emergency shutdown */})
    .finally(() => process.exit(1));
});

// Handle unhandled rejections
process.on('unhandledRejection', (reason, promise) => {
  console.error(`[${new Date().toISOString()}] Unhandled rejection: ${reason}`);
  
  // Don't exit, just log the error
});
