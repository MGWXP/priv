/**
 * schema-registry-main.js - Entry point for schema registry
 * © 2025 XPV - MIT
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const net = require('net');
const SchemaRegistry = require('../core/schema-registry.cjs');
const { SocketServer } = require('../core/socket-server.cjs');

// Configure from environment or defaults
const options = {
  serverName: process.env.MCP_SERVER_NAME || 'schema-registry',
  anchorHome: process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core',
  socketDir: process.env.SOCKET_DIR || path.join(process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core', 'sockets'),
  logDir: process.env.LOG_DIR || path.join(os.homedir(), 'Library/Logs/Claude'),
  schemaDirClaude: path.join(process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core', 'schemas', 'claude'),
  schemaDirNotion: path.join(process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core', 'schemas', 'notion')
};

// Log startup
console.log(`[${new Date().toISOString()}] Starting ${options.serverName} server...`);
console.log(`[${new Date().toISOString()}] Using Socket directory: ${options.socketDir}`);
console.log(`[${new Date().toISOString()}] Using Log directory: ${options.logDir}`);
console.log(`[${new Date().toISOString()}] Using Claude schema directory: ${options.schemaDirClaude}`);
console.log(`[${new Date().toISOString()}] Using Notion schema directory: ${options.schemaDirNotion}`);

// Create schema registry
const registry = new SchemaRegistry({
  schemaDirClaude: options.schemaDirClaude,
  schemaDirNotion: options.schemaDirNotion,
  cacheEnabled: true,
  validateOnLoad: true,
  memoryOptimized: true,
  autoReload: true
});

// Create custom socket server class
class SchemaRegistryServer extends SocketServer {
  constructor(options) {
    super(options);
    this.registry = options.registry;
  }
  
  // Handle tool invocation
  _handleToolInvocation(message, client) {
    // Check tool type
    switch (message.tool) {
      case 'validate-schema':
        this._handleValidateSchema(message, client);
        break;
        
      case 'get-schema':
        this._handleGetSchema(message, client);
        break;
        
      case 'register-schema':
        this._handleRegisterSchema(message, client);
        break;
        
      case 'list-schemas':
        this._handleListSchemas(message, client);
        break;
        
      default:
        this.sendErrorResponse(client.id, {
          error: `Unknown tool: ${message.tool}`,
          type: message.type,
          id: message.id
        });
    }
  }
  
  // Handle validate schema request
  async _handleValidateSchema(message, client) {
    try {
      // Ensure registry is initialized
      if (!this.registry.initialized) {
        await this.registry.initialize();
      }
      
      // Extract parameters
      const { type, id, data, version } = message.parameters || {};
      
      if (!type || !id || !data) {
        throw new Error('Missing required parameters: type, id, data');
      }
      
      // Validate schema
      const result = await this.registry.validateData(type, id, data, version);
      
      // Send response
      this.sendResponse(client.id, {
        type: 'tool_response',
        id: message.id,
        status: 'success',
        result
      });
    } catch (err) {
      this.log('ERROR', `Error validating schema: ${err.message}`, { clientId: client.id });
      
      this.sendErrorResponse(client.id, {
        error: `Schema validation error: ${err.message}`,
        type: message.type,
        id: message.id
      });
    }
  }
  
  // Handle get schema request
  async _handleGetSchema(message, client) {
    try {
      // Ensure registry is initialized
      if (!this.registry.initialized) {
        await this.registry.initialize();
      }
      
      // Extract parameters
      const { type, id, version } = message.parameters || {};
      
      if (!type || !id) {
        throw new Error('Missing required parameters: type, id');
      }
      
      // Get schema
      const schema = this.registry.getSchema(type, id, version);
      
      if (!schema) {
        throw new Error(`Schema not found: ${type}/${id}${version ? `@${version}` : ''}`);
      }
      
      // Send response
      this.sendResponse(client.id, {
        type: 'tool_response',
        id: message.id,
        status: 'success',
        result: { schema }
      });
    } catch (err) {
      this.log('ERROR', `Error getting schema: ${err.message}`, { clientId: client.id });
      
      this.sendErrorResponse(client.id, {
        error: `Get schema error: ${err.message}`,
        type: message.type,
        id: message.id
      });
    }
  }
  
  // Handle register schema request
  async _handleRegisterSchema(message, client) {
    try {
      // Ensure registry is initialized
      if (!this.registry.initialized) {
        await this.registry.initialize();
      }
      
      // Extract parameters
      const { type, schema } = message.parameters || {};
      
      if (!type || !schema) {
        throw new Error('Missing required parameters: type, schema');
      }
      
      // Register schema
      await this.registry.registerSchema(type, schema);
      
      // Send response
      this.sendResponse(client.id, {
        type: 'tool_response',
        id: message.id,
        status: 'success',
        result: { 
          registered: true,
          id: schema.id,
          version: schema.version
        }
      });
    } catch (err) {
      this.log('ERROR', `Error registering schema: ${err.message}`, { clientId: client.id });
      
      this.sendErrorResponse(client.id, {
        error: `Register schema error: ${err.message}`,
        type: message.type,
        id: message.id
      });
    }
  }
  
  // Handle list schemas request
  async _handleListSchemas(message, client) {
    try {
      // Ensure registry is initialized
      if (!this.registry.initialized) {
        await this.registry.initialize();
      }
      
      // Extract parameters
      const { type } = message.parameters || {};
      
      if (!type) {
        throw new Error('Missing required parameter: type');
      }
      
      // Get schemas
      const schemas = this.registry.getAllSchemas(type);
      
      // Send response
      this.sendResponse(client.id, {
        type: 'tool_response',
        id: message.id,
        status: 'success',
        result: { 
          schemas: schemas.map(schema => ({
            id: schema.id,
            version: schema.version,
            description: schema.description || ''
          }))
        }
      });
    } catch (err) {
      this.log('ERROR', `Error listing schemas: ${err.message}`, { clientId: client.id });
      
      this.sendErrorResponse(client.id, {
        error: `List schemas error: ${err.message}`,
        type: message.type,
        id: message.id
      });
    }
  }
  
  // Handle custom message type
  _handleCustomMessageType(message, client) {
    // Handle metrics request
    if (message.type === 'get_metrics') {
      const metrics = this.registry.getMetrics();
      
      this.sendResponse(client.id, {
        type: 'metrics_response',
        id: message.id || 'unknown',
        status: 'success',
        metrics
      });
      
      return true;
    }
    
    return false;
  }
}

// Create server instance
const server = new SchemaRegistryServer({
  ...options,
  registry
});

// Initialize registry and start server
registry.initialize()
  .then(() => server.start())
  .then(() => {
    console.log(`[${new Date().toISOString()}] ${options.serverName} server started successfully`);
  })
  .catch(err => {
    console.error(`[${new Date().toISOString()}] Failed to start ${options.serverName} server: ${err.message}`);
    process.exit(1);
  });

// Handle process signals
process.on('SIGINT', () => {
  console.log(`[${new Date().toISOString()}] Received SIGINT, shutting down...`);
  server.stop()
    .then(() => process.exit(0))
    .catch(err => {
      console.error(`[${new Date().toISOString()}] Error during shutdown: ${err.message}`);
      process.exit(1);
    });
});

process.on('SIGTERM', () => {
  console.log(`[${new Date().toISOString()}] Received SIGTERM, shutting down...`);
  server.stop()
    .then(() => process.exit(0))
    .catch(err => {
      console.error(`[${new Date().toISOString()}] Error during shutdown: ${err.message}`);
      process.exit(1);
    });
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  console.error(`[${new Date().toISOString()}] Uncaught exception: ${err.message}`);
  console.error(err.stack);
  
  // Try to stop server gracefully, then exit
  server.stop()
    .catch(() => {/* ignore errors during emergency shutdown */})
    .finally(() => process.exit(1));
});

// Handle unhandled rejections
process.on('unhandledRejection', (reason, promise) => {
  console.error(`[${new Date().toISOString()}] Unhandled rejection: ${reason}`);
  
  // Don't exit, just log the error
});
