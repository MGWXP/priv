#!/bin/bash
chmod +x /Users/XPV/Desktop/anchor-core/make-deploy-executable.sh
/Users/XPV/Desktop/anchor-core/make-deploy-executable.sh
