# CNIF System Documentation

## Overview

The Claude-Notion Integration Framework (CNIF) provides bidirectional communication between Claude and Notion workspaces through Unix socket connections using Model Context Protocol (MCP). This implementation is optimized for M3 Max hardware with 48GB unified memory.

## Architecture

The system employs a modular architecture with the following key components:

- **Socket Server**: Handles MCP communication with Claude using Unix sockets
- **Schema Registry**: Manages versioned schemas for Claude and Notion data
- **Notion Connection Manager**: Handles API communication with Notion
- **Streaming Transformer**: Converts between Claude's XML and Notion's JSON formats
- **MCP Orchestrator**: Coordinates service communication and workflow

## Setup and Operation

### Installation

The system is pre-installed in `/Users/XPV/Desktop/anchor-core/` with all necessary components.

### Starting the System

Two launchers are available:

1. **Simple Launcher**:
   ```bash
   /Users/XPV/Desktop/anchor-core/simple-launcher.sh
   ```

2. **Sequenced Launcher** (recommended):
   ```bash
   /Users/XPV/Desktop/anchor-core/sequenced-launcher.sh
   ```

3. **M3 Max Optimized Launcher** (best performance):
   ```bash
   /Users/XPV/Desktop/anchor-core/m3-optimized-launcher.sh
   ```

### Stopping the System

To stop all services:
```bash
/Users/XPV/Desktop/anchor-core/sequenced-launcher.sh stop
```

### Verifying System Status

```bash
/Users/XPV/Desktop/anchor-core/cnif-system-check.sh
```

### Running Integration Tests

```bash
/Users/XPV/Desktop/anchor-core/cnif-integration-test.sh
```

## Monitoring and Maintenance

### Log Files

All service logs are stored in:
```
~/Library/Logs/Claude/
```

Key log files:
- `socket-server.log`
- `schema-registry.log`
- `streaming-transformer.log`
- `notion.log`
- `mcp-orchestrator.log`

### Socket Files

Socket files for IPC are stored in:
```
/Users/XPV/Desktop/anchor-core/sockets/
```

If socket permissions need to be fixed:
```bash
/Users/XPV/Desktop/anchor-core/fix-socket-permissions.sh
```

### Schema Management

Schemas are stored in:
```
/Users/XPV/Desktop/anchor-core/schemas/claude/
/Users/XPV/Desktop/anchor-core/schemas/notion/
```

To test the schema registry:
```bash
node /Users/XPV/Desktop/anchor-core/mcp-servers/test-schema-registry.js
```

## Optimization for M3 Max

The system includes specific optimizations for M3 Max hardware:

1. **Memory Allocation**: Proper heap sizing with `--max-old-space-size=8192`
2. **Thread Pool**: Optimized `UV_THREADPOOL_SIZE=12` for the 12P+4E core layout
3. **Buffer Sizing**: Enhanced buffer sizes for socket and stream operations
4. **Workload Distribution**: Prioritizes performance-critical components

To apply M3 Max optimizations:
```bash
node /Users/XPV/Desktop/anchor-core/m3-optimizer/m3-cnif-optimizer.js
```

## Troubleshooting

### Common Issues

1. **Socket Connection Failures**:
   - Check socket file permissions (should be 0666)
   - Verify the socket directory exists and is writable
   - Check for stale socket files

2. **Schema Registry Errors**:
   - Verify schema files in `/Users/XPV/Desktop/anchor-core/schemas/`
   - Check schema structure and version format (MODEL-REVISION-ADDITION)
   - Run the test script to validate registry functionality

3. **Notion API Errors**:
   - Verify API token in `/Users/XPV/Desktop/anchor-core/config/notion-config.json`
   - Check API version (should be 2022-06-28)
   - Verify rate limit settings

### Recovery Procedures

1. **Clean Restart**:
   ```bash
   killall node  # Force kill all node processes
   rm -f /Users/XPV/Desktop/anchor-core/sockets/*.sock  # Remove socket files
   /Users/XPV/Desktop/anchor-core/sequenced-launcher.sh  # Start services
   ```

2. **Fix Socket Permissions**:
   ```bash
   /Users/XPV/Desktop/anchor-core/fix-socket-permissions.sh
   ```

3. **Module System Consistency**:
   - Verify package.json has `"type": "commonjs"`
   - Check that server components use .cjs extension
