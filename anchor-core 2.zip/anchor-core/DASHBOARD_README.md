# Anchor Dashboard Views

## Overview
This directory contains scripts to create and manage Notion dashboard views for the Anchor system. The current implementation uses hyperlinks to databases rather than embedded views due to API limitations.

## Dashboard Scripts
- `setup-dashboard-views-fixed.sh` - Creates the main dashboard with links to databases
- `create-dashboard-entry.sh` - Adds system status and action items to the dashboard
- `make-dashboard-views-executable.sh` - Makes the dashboard scripts executable

## Technical Note
The Notion API version 2022-06-28 does not support directly embedding linked databases when creating pages. See `DASHBOARD_ERROR_REPORT.md` for detailed error analysis and the implemented solution.

## Usage
To update the dashboard with current system status:
```bash
./create-dashboard-entry.sh
```

This will add the latest system metrics, service status, and action items to the dashboard.

## Dashboard Structure
1. Main Dashboard - Provides overview of system status and links to all databases
2. Project Dashboard - Focused on project tracking and status

## Troubleshooting
If you encounter issues with the dashboard views, check:
1. Notion API token - Ensure it has proper permissions
2. Database IDs - Verify they exist in /Users/XPV/Desktop/anchor-core/notion-db-ids/
3. API version - The scripts use version 2022-06-28

Refer to `DASHBOARD_ERROR_REPORT.md` for more detailed technical information.
