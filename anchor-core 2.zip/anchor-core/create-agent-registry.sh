#!/bin/bash
# Create Agent Registry Database in Notion Workspace
# For M3 Max (48GB unified memory) hardware

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

NOTION_PAGE_ID="1f7e48c2bbbd80df86edd35832916f80"

echo -e "${BLUE}=== Creating Agent Registry Database in Notion ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e ""

# Check if NOTION_API_KEY is set
if [ -z "${NOTION_API_KEY}" ]; then
    echo -e "${RED}Error: NOTION_API_KEY environment variable is not set${NC}"
    echo -e "Please set your Notion API key first with:"
    echo -e "export NOTION_API_KEY=\"your_notion_api_key\""
    exit 1
fi

# Create the Agent Registry database
echo -e "${BLUE}Creating Agent Registry database...${NC}"

curl -X POST "https://api.notion.com/v1/databases" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "parent": {
        "type": "page_id",
        "page_id": "'${NOTION_PAGE_ID}'"
    },
    "title": [
        {
            "type": "text",
            "text": {
                "content": "Agent Registry"
            }
        }
    ],
    "properties": {
        "Agent ID": {
            "title": {}
        },
        "Kind": {
            "multi_select": {
                "options": [
                    { "name": "Core", "color": "blue" },
                    { "name": "Utility", "color": "green" },
                    { "name": "Frontier", "color": "purple" }
                ]
            }
        },
        "Status": {
            "select": {
                "options": [
                    { "name": "Active", "color": "green" },
                    { "name": "Idle", "color": "yellow" },
                    { "name": "Maintenance", "color": "red" }
                ]
            }
        },
        "Skills": {
            "multi_select": {
                "options": [
                    { "name": "Git", "color": "orange" },
                    { "name": "Notion API", "color": "blue" },
                    { "name": "LLM Routing", "color": "purple" },
                    { "name": "File I/O", "color": "gray" },
                    { "name": "API Integration", "color": "green" }
                ]
            }
        },
        "Perf Score": {
            "number": {
                "format": "percent"
            }
        },
        "Last Active": {
            "date": {}
        },
        "Load %": {
            "number": {
                "format": "percent"
            }
        }
    }
}'

echo -e "\n${GREEN}✓ Agent Registry database created successfully!${NC}"
echo -e "${YELLOW}View your workspace at: https://www.notion.so/Anchor-${NOTION_PAGE_ID}${NC}"

# Create a sample agent entry
echo -e "${BLUE}Creating sample agent entry...${NC}"

curl -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "parent": {
        "database_id": "your_database_id_here"
    },
    "properties": {
        "Agent ID": {
            "title": [
                {
                    "text": {
                        "content": "AGT-0001"
                    }
                }
            ]
        },
        "Kind": {
            "multi_select": [
                { "name": "Core" }
            ]
        },
        "Status": {
            "select": {
                "name": "Active"
            }
        },
        "Skills": {
            "multi_select": [
                { "name": "Git" },
                { "name": "Notion API" }
            ]
        },
        "Perf Score": {
            "number": 0.95
        },
        "Last Active": {
            "date": {
                "start": "'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'"
            }
        },
        "Load %": {
            "number": 0.25
        }
    }
}'

echo -e "\n${GREEN}✓ Sample agent entry creation attempted.${NC}"
echo -e "${YELLOW}Note: You may need to manually update the database ID after the first database is created.${NC}"
