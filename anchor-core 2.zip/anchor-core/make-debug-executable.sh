chmod +x /Users/XPV/Desktop/anchor-core/debug-schema-registry.sh
