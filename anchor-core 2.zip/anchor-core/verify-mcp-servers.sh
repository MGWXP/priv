#!/bin/bash
# verify-mcp-servers.sh
# Verify status of MCP servers
# Version: 1.0.0 (2025-05-18)

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/.env"

echo "===== MCP System Status (M3 Max) ====="
echo "Timestamp: $(date '+%Y-%m-%d %H:%M:%S')"
echo "Hardware: Apple M3 Max (48GB)"
echo "Hostname: $(hostname)"
echo "System Load: $(uptime | awk -F'[a-z]:' '{ print $2 }')"
echo ""

# Check system health
memory_total=$(sysctl -n hw.memsize | awk '{printf "%.2f", $1 / 1024 / 1024 / 1024}')
memory_used=$(vm_stat | grep "Pages active" | awk '{print $3}' | sed 's/\.//')
page_size=$(sysctl -n hw.pagesize)
memory_used_gb=$(echo "scale=2; ${memory_used} * ${page_size} / 1024 / 1024 / 1024" | bc)
memory_percent=$(echo "scale=1; ${memory_used_gb} / ${memory_total} * 100" | bc)

cpu_usage=$(top -l 1 | grep "CPU usage" | awk '{print $3}' | cut -d'%' -f1)

echo "System Health"
echo "CPU Usage: ${cpu_usage}%"
echo "Memory Usage: ${memory_used_gb}GB / ${memory_total}GB (${memory_percent}%)"
echo ""

# Check directories
echo "Directory Check"
check_dir() {
    if [ -d "$1" ]; then
        perms=$(ls -ld "$1" | awk '{print $1}' | cut -c 2-10)
        owner=$(ls -ld "$1" | awk '{print $3}')
        echo "✓ $2: $1 (permissions: ${perms}, owner: ${owner})"
    else
        echo "✗ $2: Directory not found: $1"
    fi
}

check_dir "${ANCHOR_HOME}" "Anchor Home"
check_dir "${ANCHOR_HOME}/mcp-servers" "MCP Servers"
check_dir "${SOCKET_DIR}" "Socket Directory"
check_dir "${LOG_DIR}" "Log Directory"
check_dir "${DATA_DIR}" "Data Directory"
echo ""

# Check processes
echo "Process Check"
check_process() {
    if [ -f "${ANCHOR_HOME}/mcp-servers/$1.pid" ]; then
        pid=$(cat "${ANCHOR_HOME}/mcp-servers/$1.pid")
        if ps -p $pid > /dev/null; then
            log_size=$(du -h "${LOG_DIR}/$1.log" 2>/dev/null | cut -f1)
            mem=$(ps -o rss= -p $pid 2>/dev/null | awk '{printf "%.1f MB", $1 / 1024}')
            cpu=$(ps -o %cpu= -p $pid 2>/dev/null)
            echo "✓ $1: Running (PID: $pid, Memory: $mem, CPU: $cpu%, Log: $log_size)"
        else
            echo "! $1: PID file exists ($pid) but process is not running"
        fi
    else
        echo "✗ $1: Not running (no PID file)"
    fi
}

check_process "filesystem"
check_process "git-local"
check_process "sqlite"
check_process "notion"
check_process "slack"
check_process "anchor-manager"
echo ""

# Check configuration
echo "Configuration Check"
if [ -f "${CLAUDE_CONFIG}" ]; then
    echo "✓ Claude configuration found: ${CLAUDE_CONFIG}"
    grep -q "mcpServers" "${CLAUDE_CONFIG}" && echo "  • MCP servers configured in Claude"
    grep -q "filesystem" "${CLAUDE_CONFIG}" && echo "  • filesystem configured"
    grep -q "git-local" "${CLAUDE_CONFIG}" && echo "  • git-local configured"
    grep -q "sqlite" "${CLAUDE_CONFIG}" && echo "  • sqlite configured"
    grep -q "notion" "${CLAUDE_CONFIG}" && echo "  • notion configured"
    grep -q "slack" "${CLAUDE_CONFIG}" && echo "  • slack configured"
    grep -q "anchor-manager" "${CLAUDE_CONFIG}" && echo "  • anchor-manager configured"
else
    echo "✗ Claude configuration not found: ${CLAUDE_CONFIG}"
fi
echo ""

# Check logs
echo "Log Check"
check_log() {
    if [ -f "${LOG_DIR}/$1.log" ]; then
        size=$(du -h "${LOG_DIR}/$1.log" | cut -f1)
        lines=$(wc -l "${LOG_DIR}/$1.log" | awk '{print $1}')
        last_modified=$(stat -f "%Sm" "${LOG_DIR}/$1.log")
        echo "✓ $1 log: ${size}, ${lines} lines, last modified: ${last_modified}"
        
        # Check for errors
        errors=$(grep -i "error" "${LOG_DIR}/$1.log" | wc -l | awk '{print $1}')
        if [ $errors -gt 0 ]; then
            echo "  • Found $errors errors/warnings"
            grep -i "error" "${LOG_DIR}/$1.log" | tail -3 | while read -r line; do
                echo "    • $line"
            done
        else
            echo "  • No errors found"
        fi
        
        # Show recent activity
        echo "  Recent activity:"
        tail -3 "${LOG_DIR}/$1.log" | while read -r line; do
            echo "    • $line"
        done
    else
        echo "✗ $1 log: Not found"
    fi
}

check_log "filesystem"
check_log "git-local"
check_log "sqlite"
check_log "notion"
check_log "slack"
check_log "anchor-manager"
echo ""

# Check environment
echo "Environment Check"
echo "Node.js: $(node -v)"
echo "NODE_OPTIONS: ${NODE_OPTIONS}"
echo "UV_THREADPOOL_SIZE: ${UV_THREADPOOL_SIZE}"
echo "ANCHOR_HOME: ${ANCHOR_HOME}"
echo ""

# Final status
echo "Status Summary"
running=$(ps aux | grep -c "[m]cp-servers")
echo "MCP servers running: $running"

if [ $running -ge 6 ]; then
    echo "All MCP servers are running properly."
else
    echo "⚠️ Some MCP servers are not running!"
    echo "  Run: ${ANCHOR_HOME}/launch-mcp-servers.sh"
fi

# Check for memory settings
if [[ "${NODE_OPTIONS}" != *"--max-old-space-size="* ]]; then
    echo "⚠️ NODE_OPTIONS not properly set in .env file"
    echo "  Run: ${ANCHOR_HOME}/setup-mcp-integrations.sh"
fi

echo ""
echo "Next Steps"
echo "1. If any servers are not running, restart them with: ${ANCHOR_HOME}/launch-mcp-servers.sh"
echo "2. Restart Claude Desktop to ensure it connects to the MCP servers"
echo "3. If issues persist, check the logs for specific error messages"
