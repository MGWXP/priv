#!/bin/bash
# one-step-mcp-fix.sh - Comprehensive fix for Anchor System V6 MCP Servers
# © 2025 XPV - MIT

set -e

# Define colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Define paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
MCP_DIR="${ANCHOR_HOME}/mcp-servers"
SOCKET_DIR="${ANCHOR_HOME}/sockets"
LOG_DIR="${HOME}/Library/Logs/Claude"
CONFIG_DIR="${HOME}/Library/Application Support/Claude"
CONFIG_FILE="${CONFIG_DIR}/claude_desktop_config.json"

echo -e "${BLUE}=== Anchor System V6 MCP Server Fix ===${NC}"
echo "Timestamp: $(date '+%Y-%m-%d %H:%M:%S')"

# Step 1: Stop any running servers
echo -e "\n${YELLOW}Step 1: Stopping existing servers...${NC}"
pkill -f "git-local-optimized.js" 2>/dev/null || true
pkill -f "notion-v5-wrapper.js" 2>/dev/null || true
pkill -f "anchor-manager-optimized.js" 2>/dev/null || true
pkill -f "socket-server-implementation.js" 2>/dev/null || true
pkill -f "enhanced-socket-server.js" 2>/dev/null || true
sleep 1

# Step 2: Clean up directories and files
echo -e "\n${YELLOW}Step 2: Cleaning up directories and files...${NC}"

# Create directories if they don't exist
echo "Creating required directories..."
mkdir -p "${SOCKET_DIR}"
mkdir -p "${LOG_DIR}"
mkdir -p "${CONFIG_DIR}"

# Clean up stale files
echo "Removing stale PID and socket files..."
rm -f "${MCP_DIR}"/*.pid 2>/dev/null || true
rm -f "${SOCKET_DIR}"/*.sock 2>/dev/null || true

# Step 3: Create or update Claude configuration
echo -e "\n${YELLOW}Step 3: Updating Claude configuration...${NC}"

# Create backup of existing config if it exists
if [ -f "${CONFIG_FILE}" ]; then
  CONFIG_BACKUP="${ANCHOR_HOME}/backups/claude_desktop_config.json.bak"
  mkdir -p "${ANCHOR_HOME}/backups"
  echo "Creating backup of existing configuration: ${CONFIG_BACKUP}"
  cp "${CONFIG_FILE}" "${CONFIG_BACKUP}"
fi

# Generate new configuration with correct socket paths
echo "Creating updated Claude configuration..."
cat > "${CONFIG_FILE}" << EOF
{
  "mcpServers": {
    "filesystem": {
      "command": "npx",
      "args": [
        "-y",
        "@modelcontextprotocol/server-filesystem",
        "/Users/XPV/Desktop",
        "/Users/XPV/Library",
        "/Users/XPV/Downloads"
      ]
    },
    "git-local": {
      "command": "git",
      "socketPath": "${SOCKET_DIR}/git-local.sock"
    },
    "notion": {
      "command": "notion",
      "socketPath": "${SOCKET_DIR}/notion.sock"
    },
    "anchor-manager": {
      "command": "anchor-manager",
      "socketPath": "${SOCKET_DIR}/anchor-manager.sock"
    }
  }
}
EOF

echo -e "${GREEN}✓${NC} Claude configuration updated successfully."

# Step 4: Make scripts executable
echo -e "\n${YELLOW}Step 4: Setting executable permissions...${NC}"
chmod +x "${ANCHOR_HOME}/launch-enhanced-servers.sh"
chmod +x "${ANCHOR_HOME}/verify-enhanced-servers.sh"
chmod +x "${ANCHOR_HOME}/enhanced-socket-server.js"

if [ -f "${ANCHOR_HOME}/scripts/socket_directory_setup.sh" ]; then
  chmod +x "${ANCHOR_HOME}/scripts/socket_directory_setup.sh"
  echo "Running socket directory setup script..."
  "${ANCHOR_HOME}/scripts/socket_directory_setup.sh"
fi

# Step 5: Launch MCP servers
echo -e "\n${YELLOW}Step 5: Launching enhanced MCP servers...${NC}"
"${ANCHOR_HOME}/launch-enhanced-servers.sh"

# Step 6: Verify server status
echo -e "\n${YELLOW}Step 6: Verifying server status...${NC}"
sleep 2 # Give servers time to start
"${ANCHOR_HOME}/verify-enhanced-servers.sh"

# Final instructions
echo -e "\n${BLUE}=== Fix Complete ===${NC}"
echo -e "${GREEN}✅ Anchor System V6 fix has been successfully applied!${NC}"
echo "The following enhancements have been implemented:"
echo "1. Enhanced Socket Manager for proper socket lifecycle management"
echo "2. Optimized configuration for M3 Max hardware"
echo "3. Improved process management with health monitoring"
echo "4. Consolidated configuration and logging"
echo ""
echo "You can now use the following commands:"
echo "• Launch enhanced servers: ${ANCHOR_HOME}/launch-enhanced-servers.sh"
echo "• Verify server status: ${ANCHOR_HOME}/verify-enhanced-servers.sh"
echo ""
echo -e "${YELLOW}Important: Restart Claude Desktop to connect to the enhanced servers${NC}"
