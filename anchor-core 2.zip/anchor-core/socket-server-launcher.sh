#!/bin/bash
# socket-server-launcher.sh - Launch MCP socket servers
# © 2025 XPV - MIT

set -e  # Exit on error

echo "🚀 Launching MCP Socket Servers..."

# Define core paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
MCP_DIR="${ANCHOR_HOME}/mcp-servers"
LOG_DIR="${HOME}/Library/Logs/Claude"
SOCKET_DIR="${ANCHOR_HOME}/sockets"

# Set optimization parameters - using only valid flags
export NODE_OPTIONS="--max-old-space-size=8192"
export UV_THREADPOOL_SIZE=12
export ANCHOR_HOME="${ANCHOR_HOME}"
export MCP_DIR="${MCP_DIR}"
export SOCKET_DIR="${SOCKET_DIR}"
export LOG_DIR="${LOG_DIR}"

# Stop any running servers
echo "🛑 Stopping existing servers..."
pkill -f "node.*socket-server-implementation.js" 2>/dev/null || true
sleep 1

# Clean up any existing socket files
rm -f "${SOCKET_DIR}"/*.sock 2>/dev/null || true

# Create required directories
mkdir -p "${SOCKET_DIR}"
mkdir -p "${LOG_DIR}"

# Launch git-local socket server
echo "🚀 Starting git-local socket server..."
MCP_SERVER_NAME="git-local" \
  node "${MCP_DIR}/socket-server-implementation.js" > "${LOG_DIR}/socket-git-local.log" 2>&1 &
echo $! > "${MCP_DIR}/git-local.pid"

# Launch notion socket server
echo "🚀 Starting notion socket server..."
MCP_SERVER_NAME="notion" \
  node "${MCP_DIR}/socket-server-implementation.js" > "${LOG_DIR}/socket-notion.log" 2>&1 &
echo $! > "${MCP_DIR}/notion.pid"

# Launch anchor-manager socket server
echo "🚀 Starting anchor-manager socket server..."
MCP_SERVER_NAME="anchor-manager" \
  node "${MCP_DIR}/socket-server-implementation.js" > "${LOG_DIR}/socket-anchor-manager.log" 2>&1 &
echo $! > "${MCP_DIR}/anchor-manager.pid"

echo "✅ All socket servers launched!"
echo "📂 Socket files located in: ${SOCKET_DIR}"
echo "📊 To verify, run: ls -la ${SOCKET_DIR}"
