#!/bin/bash
# cnif-deploy.sh - Complete CNIF deployment script
# © 2025 XPV - MIT

set -e

# Define colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color
BLUE='\033[0;34m'

# Base paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
SOCKET_DIR="$ANCHOR_HOME/sockets"
LOG_DIR="$HOME/Library/Logs/Claude"
CONFIG_DIR="$ANCHOR_HOME/data"
MCP_DIR="$ANCHOR_HOME/mcp-servers"

echo -e "${BLUE}==================================================${NC}"
echo -e "${BLUE}CNIF Module System Fix and Deployment             ${NC}"
echo -e "${BLUE}==================================================${NC}"

# 1. Make sure all scripts are executable
echo -e "\n${BLUE}Making scripts executable...${NC}"
chmod +x "$ANCHOR_HOME/make-scripts-executable.sh"
"$ANCHOR_HOME/make-scripts-executable.sh"

# 2. Run the module fixer
echo -e "\n${BLUE}Running Module System Fix...${NC}"
chmod +x "$ANCHOR_HOME/cnif-module-fixer.js"
node "$ANCHOR_HOME/cnif-module-fixer.js"

# 3. Create Socket Directory
echo -e "\n${BLUE}Creating socket directory...${NC}"
mkdir -p "$SOCKET_DIR"
chmod 777 "$SOCKET_DIR"

# 4. Create schemas directory
echo -e "\n${BLUE}Creating schemas directory...${NC}"
mkdir -p "$ANCHOR_HOME/schemas/claude"
mkdir -p "$ANCHOR_HOME/schemas/notion"

# 5. Stop any running processes
echo -e "\n${BLUE}Stopping any running processes...${NC}"
"$ANCHOR_HOME/mcp-restart-all.sh" stop

# 6. Start the system
echo -e "\n${BLUE}Starting the CNIF system...${NC}"
chmod +x "$ANCHOR_HOME/launch-optimized.sh"
"$ANCHOR_HOME/launch-optimized.sh"

echo -e "\n${GREEN}==================================================${NC}"
echo -e "${GREEN}CNIF Module System Fix and Deployment Complete    ${NC}"
echo -e "${GREEN}==================================================${NC}"
