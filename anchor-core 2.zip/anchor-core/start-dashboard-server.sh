#!/bin/bash
# Simple HTTP server to view the dashboard locally

echo "Starting HTTP server for the dashboard..."
echo "Please open http://localhost:8000/master-dashboard.html in your browser"
echo "Press Ctrl+C to stop the server"

cd /Users/XPV/Desktop/anchor-core/notion-embeds/
python3 -m http.server 8000
