# GitHub MCP Server Integration Guide

## Overview

This guide explains how to integrate the official GitHub MCP server with the Claude-Notion Integration Framework (CNIF). The GitHub MCP server provides standardized access to GitHub repositories, issues, pull requests, and other GitHub features through the Model Context Protocol (MCP).

## Prerequisites

- Docker installed on your system
- GitHub Personal Access Token with appropriate scopes (repo, workflow, read:org)
- Claude Desktop application installed
- CNIF system set up and working

## Installation

1. Run the setup script:
   ```bash
   chmod +x /Users/XPV/Desktop/anchor-core/setup-mcp-integrations.sh
   /Users/XPV/Desktop/anchor-core/setup-mcp-integrations.sh
   ```

2. Follow the prompts to:
   - Provide your GitHub Personal Access Token
   - Provide your Notion API Token (if needed)

3. Restart Claude Desktop to apply configuration changes

## Usage

### Starting the Integration

To start all MCP integrations (GitHub and CNIF):

```bash
/Users/XPV/Desktop/anchor-core/launch-mcp-integrations.sh
```

### Stopping the Integration

To stop all MCP integrations:

```bash
/Users/XPV/Desktop/anchor-core/stop-mcp-integrations.sh
```

### Testing the Integration

To test if the GitHub MCP server is working properly:

1. Start a new conversation in Claude Desktop
2. Ask Claude to perform a GitHub task, for example:
   - "List my GitHub repositories"
   - "Show me open issues in my repository"
   - "Create a pull request in my repository"

## Configuration

The GitHub MCP server is configured in Claude Desktop's configuration file:

```
~/Library/Application Support/Claude/claude_desktop_config.json
```

If you need to modify the configuration:

1. Edit the template at `/Users/XPV/Desktop/anchor-core/github_claude_config.json`
2. Run the update script:
   ```bash
   /Users/XPV/Desktop/anchor-core/update-claude-config.sh
   ```
3. Restart Claude Desktop

## Troubleshooting

### Common Issues

1. **GitHub MCP server is not connecting:**
   - Check if Docker is running
   - Verify your GitHub token is valid
   - Check logs at `/Users/XPV/Desktop/anchor-core/logs/github-mcp*.log`

2. **Claude cannot access GitHub features:**
   - Verify your token has the necessary scopes
   - Check if the GitHub MCP server is running:
     ```bash
     docker ps | grep github-mcp-server
     ```

3. **Configuration issues:**
   - Ensure environment variables are properly set
   - Check Claude Desktop configuration

## Advanced Configuration

The GitHub MCP server supports additional configuration options:

- `GITHUB_TOOLSETS`: Comma-separated list of toolsets to enable (default: repos,issues,pull_requests,code_security,experiments)
- `GITHUB_DYNAMIC_TOOLSETS`: Enable dynamic toolset discovery (set to 1)

For additional configuration options, refer to the [GitHub MCP Server documentation](https://github.com/github/github-mcp-server).
