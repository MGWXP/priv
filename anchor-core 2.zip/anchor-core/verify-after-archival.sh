#!/bin/bash
# Make script executable with: chmod +x /Users/XPV/Desktop/anchor-core/verify-after-archival.sh
# verify-after-archival.sh - Verify system coherence after archival
# © 2025 XPV - MIT

# Set terminal colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[0;33m'
NC='\033[0m' # No Color

echo "===================================================="
echo "CNIF System Coherence Verification"
echo "===================================================="
echo

# Set environment variables
export ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
export MCP_SERVER_NAME="verifier"
export SOCKET_DIR="$ANCHOR_HOME/sockets"
export LOG_DIR="$HOME/Library/Logs/Claude"

# Create required directories if they don't exist
mkdir -p "$ANCHOR_HOME/sockets"
mkdir -p "$ANCHOR_HOME/schemas/claude"
mkdir -p "$ANCHOR_HOME/schemas/notion"
mkdir -p "$ANCHOR_HOME/coherence_lock"
mkdir -p "$LOG_DIR"

# Step 1: Check package.json configuration
echo -e "${YELLOW}Checking package.json configuration...${NC}"
if grep -q "\"type\": \"commonjs\"" "$ANCHOR_HOME/package.json"; then
  echo -e "${GREEN}✓ package.json correctly configured with CommonJS${NC}"
else
  echo -e "${RED}✗ package.json not correctly configured${NC}"
  exit 1
fi
echo

# Step 2: Verify schema registry
echo -e "${YELLOW}Verifying schema registry...${NC}"
if [ -f "$ANCHOR_HOME/mcp-servers/schema-registry.cjs" ]; then
  echo -e "${GREEN}✓ schema-registry.cjs exists${NC}"
else
  echo -e "${RED}✗ schema-registry.cjs not found${NC}"
  exit 1
fi

if [ -f "$ANCHOR_HOME/mcp-servers/schema-registry-index.js" ]; then
  echo -e "${GREEN}✓ schema-registry-index.js exists${NC}"
else
  echo -e "${RED}✗ schema-registry-index.js not found${NC}"
  exit 1
fi
echo

# Step 3: Run schema registry test
echo -e "${YELLOW}Running schema registry test...${NC}"
node "$ANCHOR_HOME/mcp-servers/test-schema-registry.js"
if [ $? -eq 0 ]; then
  echo -e "${GREEN}✓ Schema registry test successful${NC}"
else
  echo -e "${RED}✗ Schema registry test failed${NC}"
  exit 1
fi
echo

# Step 4: Verify socket server
echo -e "${YELLOW}Verifying socket server...${NC}"
if [ -f "$ANCHOR_HOME/mcp-servers/socket-server-implementation.cjs" ]; then
  echo -e "${GREEN}✓ socket-server-implementation.cjs exists${NC}"
else
  echo -e "${RED}✗ socket-server-implementation.cjs not found${NC}"
  exit 1
fi
echo

# Step 5: Verify other components
echo -e "${YELLOW}Verifying other components...${NC}"
COMPONENTS=(
  "circuit-breaker.cjs"
  "mcp-orchestrator.cjs"
  "notion-connection-manager.cjs"
  "streaming-schema-transformer.cjs"
)

for component in "${COMPONENTS[@]}"; do
  if [ -f "$ANCHOR_HOME/mcp-servers/$component" ]; then
    echo -e "${GREEN}✓ $component exists${NC}"
  else
    echo -e "${RED}✗ $component not found${NC}"
    exit 1
  fi
done
echo

# Step 6: Verify that no original .js files remain in mcp-servers
echo -e "${YELLOW}Verifying no conflicting .js files remain...${NC}"
JS_FILES=(
  "circuit-breaker.js"
  "mcp-orchestrator.js"
  "notion-connection-manager.js"
  "streaming-schema-transformer.js"
  "schema-registry.js"
  "socket-server-implementation.js"
)

CONFLICTS=0
for file in "${JS_FILES[@]}"; do
  if [ -f "$ANCHOR_HOME/mcp-servers/$file" ]; then
    echo -e "${RED}✗ Conflicting file found: $file${NC}"
    CONFLICTS=$((CONFLICTS+1))
  fi
done

if [ $CONFLICTS -eq 0 ]; then
  echo -e "${GREEN}✓ No conflicting .js files found${NC}"
else
  echo -e "${RED}✗ $CONFLICTS conflicting file(s) found${NC}"
  exit 1
fi
echo

# Success message
echo "===================================================="
echo -e "${GREEN}CNIF System Coherence Verification Complete!${NC}"
echo "===================================================="
echo
echo "The system has been verified for module system coherence."
echo "All necessary components are present and no conflicting files remain."
echo
echo "To start the socket server:"
echo "node $ANCHOR_HOME/mcp-servers/socket-server-implementation.cjs"
echo
echo "To test the schema registry:"
echo "node $ANCHOR_HOME/mcp-servers/test-schema-registry.js"
echo
