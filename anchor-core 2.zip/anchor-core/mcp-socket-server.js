const net = require('net');
const fs = require('fs');
const path = require('path');

// Get server name from command line
const serverName = process.argv[2];
if (!serverName) {
  console.error('Server name must be provided');
  process.exit(1);
}

// Set up socket path
const SOCKET_DIR = '/Users/XPV/Desktop/anchor-core/sockets';
const socketPath = path.join(SOCKET_DIR, `${serverName}.sock`);

// Ensure socket directory exists
if (!fs.existsSync(SOCKET_DIR)) {
  fs.mkdirSync(SOCKET_DIR, { recursive: true });
}

// Remove existing socket file
try {
  if (fs.existsSync(socketPath)) {
    fs.unlinkSync(socketPath);
  }
} catch (err) {
  console.error(`Error removing existing socket: ${err.message}`);
}

// Create server
const server = net.createServer((socket) => {
  console.log(`Client connected to ${serverName}`);
  
  let buffer = '';
  
  socket.on('data', (data) => {
    buffer += data.toString();
    
    try {
      // Try to parse as JSON
      const message = JSON.parse(buffer);
      buffer = ''; // Reset buffer on successful parse
      
      console.log(`Received message: ${JSON.stringify(message)}`);
      
      // Handle initialize method
      if (message.method === 'initialize') {
        const response = {
          jsonrpc: '2.0',
          id: message.id,
          result: {
            protocolVersion: message.params?.protocolVersion || '2024-11-05',
            name: serverName,
            version: '1.0.0',
            capabilities: {
              tools: {
                [serverName]: {
                  description: `${serverName} operations`,
                  schema: {
                    type: 'object',
                    properties: {
                      command: {
                        type: 'string',
                        description: 'Command to execute'
                      }
                    },
                    required: ['command']
                  }
                }
              }
            }
          }
        };
        
        socket.write(JSON.stringify(response) + '\n');
        console.log(`Sent initialize response`);
      }
      // Handle execute method
      else if (message.method === 'execute') {
        const response = {
          jsonrpc: '2.0',
          id: message.id,
          result: {
            output: `Executed ${message.params?.tool} command: ${JSON.stringify(message.params?.params)}`
          }
        };
        
        socket.write(JSON.stringify(response) + '\n');
        console.log(`Sent execute response`);
      }
      // Handle other methods
      else {
        const response = {
          jsonrpc: '2.0',
          id: message.id,
          error: {
            code: -32601,
            message: `Method not found: ${message.method}`
          }
        };
        
        socket.write(JSON.stringify(response) + '\n');
        console.log(`Sent error response for unknown method: ${message.method}`);
      }
    } catch (err) {
      // Incomplete JSON - wait for more data
      if (buffer.length > 10000) {
        // Reset buffer if it gets too large
        buffer = '';
        console.error('Buffer overflow - resetting');
      }
    }
  });
  
  socket.on('error', (err) => {
    console.error(`Socket error: ${err.message}`);
  });
  
  socket.on('close', () => {
    console.log('Client disconnected');
  });
});

// Handle server errors
server.on('error', (err) => {
  console.error(`Server error: ${err.message}`);
});

// Start listening
server.listen(socketPath, () => {
  console.log(`Server listening on ${socketPath}`);
  
  // Set permissions to allow Claude to connect
  fs.chmod(socketPath, 0o666, (err) => {
    if (err) {
      console.error(`Failed to set permissions: ${err.message}`);
    } else {
      console.log(`Set permissions on ${socketPath} to 0666`);
    }
  });
});

// Handle process termination
process.on('SIGINT', () => {
  console.log('Shutting down server...');
  server.close(() => {
    try {
      if (fs.existsSync(socketPath)) {
        fs.unlinkSync(socketPath);
      }
    } catch (err) {
      console.error(`Error removing socket on shutdown: ${err.message}`);
    }
    process.exit(0);
  });
});
