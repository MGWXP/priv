#!/bin/bash
# dashboard-links-update.sh - Master script to fix dashboard hyperlinks
# For M3 Max (48GB unified memory) hardware

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

echo -e "${BLUE}=== Anchor Dashboard Hyperlink Fix Master Script ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e ""

# Make all scripts executable
echo -e "${YELLOW}Making all dashboard fix scripts executable...${NC}"
chmod +x /Users/XPV/Desktop/anchor-core/make-fix-links-executable.sh
chmod +x /Users/XPV/Desktop/anchor-core/fix-dashboard-links.sh

# Run the fix
echo -e "${YELLOW}Running dashboard hyperlink fix...${NC}"
/Users/XPV/Desktop/anchor-core/fix-dashboard-links.sh

# Create documentation
echo -e "${YELLOW}Creating documentation for the dashboard fix...${NC}"

# Write detailed documentation
cat > /Users/XPV/Desktop/anchor-core/DASHBOARD_LINK_FIX.md << 'EOF'
# Notion Dashboard Hyperlink Fix

## Problem Description
The dashboard hyperlinks to Notion databases were not working correctly, showing as plain text links that resulted in error pages when clicked. Analysis of the links and Notion API documentation revealed several issues:

1. The URLs were using the format `https://www.notion.so/DATABASE_ID` instead of `https://notion.so/DATABASE_ID` (without "www")
2. The link formatting in the API requests was missing the required `type` field
3. The links were not visually prominent enough for easy access

## Solution Implemented
A comprehensive fix was applied to both the Main Dashboard and Project Dashboard:

1. **URL Format Correction**: Changed from `www.notion.so` to `notion.so` format
2. **Proper API Formatting**: Added proper link structure with `type: "url"` field
3. **Button-Style Links**: Added callout blocks with emoji icons for better visibility and usability
4. **Link Organization**: Improved the organization of links with clear headings
5. **Explanatory Notes**: Added explanatory notes to help users understand the interface

## Technical Implementation
The fix was implemented in two main scripts:

1. `fix-dashboard-links.sh`: The main script that:
   - Clears problematic content from dashboards
   - Adds properly formatted links in various styles
   - Updates both Main Dashboard and Project Dashboard
   
2. `make-fix-links-executable.sh`: Helper script to ensure proper permissions

The technical approach involved:
- Retrieving existing blocks from the Notion pages
- Selectively removing problematic blocks
- Creating new blocks with correctly formatted links
- Using callout blocks for button-style links
- Adding explanatory text

## How Notion Links Work
Based on research into the Notion API, proper links should use:
- `https://notion.so/` rather than `https://www.notion.so/`
- Proper link object format in API requests: `"link": {"type": "url", "url": "..."}`
- Visual elements like callouts for better usability

## Result
The dashboard hyperlinks now work correctly and provide several ways to access the databases:
- Standard text links
- Button-style callout blocks with icons
- Clear organization by category

## References
- Notion API Documentation
- Notion URL format specifications
- MCP system integration guidelines

---
Generated: 2025-05-18
EOF

echo -e "${GREEN}✓ Documentation created: DASHBOARD_LINK_FIX.md${NC}"

# Update notion-db-status.txt with info about the fix
echo -e "${YELLOW}Updating database status file...${NC}"
cat >> /Users/XPV/Desktop/anchor-core/notion-db-status.txt << EOF

## Dashboard Hyperlink Fix
- Main Dashboard hyperlinks fixed: $(date '+%Y-%m-%d %H:%M:%S')
- Project Dashboard hyperlinks fixed: $(date '+%Y-%m-%d %H:%M:%S')
- Fix type: URL format correction and improved link styling
- Documentation: DASHBOARD_LINK_FIX.md
EOF

echo -e "${GREEN}✓ Status file updated${NC}"

echo -e "\n${GREEN}✅ Dashboard hyperlink fix complete!${NC}"
echo -e "${YELLOW}Main Dashboard: https://notion.so/$(cat /Users/XPV/Desktop/anchor-core/notion-dashboard-ids/main-dashboard-id.txt)${NC}"
echo -e "${YELLOW}Project Dashboard: https://notion.so/$(cat /Users/XPV/Desktop/anchor-core/notion-dashboard-ids/project-dashboard-id.txt)${NC}"
echo -e "${YELLOW}Documentation: /Users/XPV/Desktop/anchor-core/DASHBOARD_LINK_FIX.md${NC}"

echo -e "\n${BLUE}Next Steps:${NC}"
echo -e "1. Access the dashboards to verify the links are working"
echo -e "2. Review DASHBOARD_LINK_FIX.md for technical details"
echo -e "3. Continue with remaining database creation as needed"
