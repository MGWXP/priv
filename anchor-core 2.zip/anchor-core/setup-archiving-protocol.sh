#!/bin/bash
# setup-archiving-protocol.sh - Set up the archiving protocol
# This script makes all necessary scripts executable and initializes the protocol

# Make this script executable
chmod +x $0

# Set strict error handling
set -e

# ANSI color codes for output formatting
GREEN='\033[0;32m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

echo -e "${CYAN}Setting up Anchor V6 Archiving Protocol...${NC}"

# Make the initialization script executable
chmod +x /Users/XPV/Desktop/anchor-core/initiate-archiving-protocol.sh
echo -e "${GREEN}✅ Made initiate-archiving-protocol.sh executable${NC}"

# Create coherence marker
MARKER_DIR="/Users/XPV/Desktop/anchor-core/coherence_lock"
mkdir -p $MARKER_DIR
touch $MARKER_DIR/SETUP_ARCHIVING_PROTOCOL_$(date +"%Y-%m-%dT%H%M%S%3N%z").marker

echo -e "${GREEN}✅ Setup complete!${NC}"
echo -e "${CYAN}To initialize the archiving protocol, run:${NC}"
echo -e "/Users/XPV/Desktop/anchor-core/initiate-archiving-protocol.sh"

exit 0
