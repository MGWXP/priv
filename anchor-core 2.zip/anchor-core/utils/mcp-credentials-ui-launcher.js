#!/usr/bin/env node
/**
 * MCP Credentials Manager UI Launcher
 * 
 * A graphical UI for managing MCP server credentials
 * Built with Electron to provide a modern desktop interface
 * 
 * © 2025 XPV - MIT License
 */

// You'll need to install electron via npm:
// npm install electron --save-dev

const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { spawn } = require('child_process');

// Configuration
const ANCHOR_HOME = process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core';
const SECURE_CREDS_DIR = path.join(ANCHOR_HOME, 'data', 'secure-credentials');
const CREDS_FILE = path.join(SECURE_CREDS_DIR, 'mcp-credentials.enc');
const SALT_FILE = path.join(SECURE_CREDS_DIR, 'salt');
const LOG_DIR = path.join(ANCHOR_HOME, 'logs');
const LOG_FILE = path.join(LOG_DIR, 'mcp-credentials-ui.log');
const CLAUDE_CONFIG_PATH = path.join(require('os').homedir(), 'Library/Application Support/Claude/claude_desktop_config.json');

// Ensure directories exist
try {
  if (!fs.existsSync(SECURE_CREDS_DIR)) {
    fs.mkdirSync(SECURE_CREDS_DIR, { recursive: true });
  }
  if (!fs.existsSync(LOG_DIR)) {
    fs.mkdirSync(LOG_DIR, { recursive: true });
  }
} catch (err) {
  console.error(`Failed to create required directories: ${err.message}`);
  process.exit(1);
}

// Logging utility
function log(level, message) {
  const timestamp = new Date().toISOString();
  const logEntry = `${timestamp} [${level}] ${message}`;
  
  console.log(logEntry);
  
  try {
    fs.appendFileSync(LOG_FILE, logEntry + '\n');
  } catch (err) {
    console.error(`Failed to write to log: ${err.message}`);
  }
}

// Derive an encryption key from a password
function deriveKey(password, salt) {
  return crypto.pbkdf2Sync(password, salt, 100000, 32, 'sha256');
}

// Decrypt credentials data
function decryptData(encryptedData, iv, password) {
  try {
    // Read salt
    if (!fs.existsSync(SALT_FILE)) {
      throw new Error('Salt file not found. Credentials may not be initialized.');
    }
    
    const salt = fs.readFileSync(SALT_FILE);
    const key = deriveKey(password, salt);
    
    // Decrypt the data
    const decipher = crypto.createDecipheriv('aes-256-cbc', key, Buffer.from(iv, 'hex'));
    let decrypted = decipher.update(encryptedData, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
  } catch (err) {
    log('ERROR', `Decryption failed: ${err.message}`);
    throw err;
  }
}

// Load credentials from encrypted file
function loadCredentials(password) {
  try {
    if (!fs.existsSync(CREDS_FILE)) {
      log('INFO', 'No credentials file found. Starting with empty credentials.');
      return {
        github: {},
        notion: {},
        slack: {}
      };
    }
    
    const fileContent = fs.readFileSync(CREDS_FILE, 'utf8');
    const encrypted = JSON.parse(fileContent);
    
    const decrypted = decryptData(encrypted.data, encrypted.iv, password);
    return JSON.parse(decrypted);
  } catch (err) {
    log('ERROR', `Failed to load credentials: ${err.message}`);
    throw err;
  }
}

// Encrypt credentials data
function encryptData(data, password) {
  let salt;
  
  // Get or generate salt
  try {
    if (fs.existsSync(SALT_FILE)) {
      salt = fs.readFileSync(SALT_FILE);
    } else {
      salt = crypto.randomBytes(16);
      fs.writeFileSync(SALT_FILE, salt);
    }
  } catch (err) {
    log('ERROR', `Salt operations failed: ${err.message}`);
    throw err;
  }
  
  // Derive key from password
  const key = deriveKey(password, salt);
  
  // Encrypt the data
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
  let encrypted = cipher.update(data, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  
  return {
    iv: iv.toString('hex'),
    data: encrypted
  };
}

// Save credentials to encrypted file
function saveCredentials(credentials, password) {
  try {
    const dataStr = JSON.stringify(credentials, null, 2);
    const encrypted = encryptData(dataStr, password);
    
    // Save the encrypted credentials with IV
    const fileContent = JSON.stringify({
      iv: encrypted.iv,
      data: encrypted.data
    }, null, 2);
    
    fs.writeFileSync(CREDS_FILE, fileContent);
    log('INFO', 'Credentials saved successfully');
    return true;
  } catch (err) {
    log('ERROR', `Failed to save credentials: ${err.message}`);
    throw err;
  }
}

// Update Claude Desktop config file with current credentials
function updateClaudeConfig(credentials) {
  try {
    if (!fs.existsSync(CLAUDE_CONFIG_PATH)) {
      log('ERROR', `Claude config file not found at: ${CLAUDE_CONFIG_PATH}`);
      throw new Error(`Claude config file not found at: ${CLAUDE_CONFIG_PATH}`);
    }
    
    // Read current config
    const config = JSON.parse(fs.readFileSync(CLAUDE_CONFIG_PATH, 'utf8'));
    
    // Make a backup
    const backupPath = `${CLAUDE_CONFIG_PATH}.bak.${Date.now()}`;
    fs.writeFileSync(backupPath, JSON.stringify(config, null, 2));
    log('INFO', `Backup of Claude config created: ${backupPath}`);
    
    // Update GitHub config if credentials exist
    if (credentials.github && credentials.github.personalAccessToken) {
      if (config.mcpServers && config.mcpServers.github && config.mcpServers.github.env) {
        config.mcpServers.github.env.GITHUB_PERSONAL_ACCESS_TOKEN = credentials.github.personalAccessToken;
        
        if (credentials.github.enterpriseUrl) {
          config.mcpServers.github.env.GITHUB_ENTERPRISE_URL = credentials.github.enterpriseUrl;
        }
        
        log('INFO', 'Updated GitHub credentials in Claude config');
      }
    }
    
    // Update Notion config if credentials exist
    if (credentials.notion && credentials.notion.apiKey) {
      if (config.mcpServers && config.mcpServers.notion && config.mcpServers.notion.env) {
        // Notion uses a special format for its API key in the headers
        const notionHeaders = config.mcpServers.notion.env.OPENAPI_MCP_HEADERS || '{}';
        let headers;
        
        try {
          // Parse current headers if they exist
          headers = JSON.parse(notionHeaders);
        } catch (e) {
          headers = {};
        }
        
        // Update the Authorization header with the new API key
        headers.Authorization = `Bearer ${credentials.notion.apiKey}`;
        
        // Make sure Notion-Version is present
        if (!headers['Notion-Version']) {
          headers['Notion-Version'] = '2022-06-28';
        }
        
        // Stringify the headers back to JSON
        config.mcpServers.notion.env.OPENAPI_MCP_HEADERS = JSON.stringify(headers);
        
        log('INFO', 'Updated Notion credentials in Claude config');
      }
    }
    
    // Update Slack config if credentials exist
    if (credentials.slack && credentials.slack.botToken) {
      if (config.mcpServers && config.mcpServers.slack && config.mcpServers.slack.env) {
        config.mcpServers.slack.env.SLACK_BOT_TOKEN = credentials.slack.botToken;
        
        if (credentials.slack.teamId) {
          config.mcpServers.slack.env.SLACK_TEAM_ID = credentials.slack.teamId;
        }
        
        log('INFO', 'Updated Slack credentials in Claude config');
      }
    }
    
    // Save updated config
    fs.writeFileSync(CLAUDE_CONFIG_PATH, JSON.stringify(config, null, 2));
    log('INFO', 'Claude config file updated successfully');
    
    return true;
  } catch (err) {
    log('ERROR', `Failed to update Claude config: ${err.message}`);
    throw err;
  }
}

// Check if the credentials file exists
function credentialsExist() {
  return fs.existsSync(CREDS_FILE);
}

// Restart Claude Desktop
function restartClaude() {
  return new Promise((resolve, reject) => {
    // Kill existing Claude processes
    const kill = spawn('pkill', ['-x', 'Claude']);
    
    kill.on('close', (code) => {
      // Give it a moment to close
      setTimeout(() => {
        // Start Claude Desktop
        const open = spawn('open', ['-a', 'Claude']);
        
        open.on('close', (code) => {
          if (code === 0) {
            log('INFO', 'Claude Desktop restarted successfully');
            resolve(true);
          } else {
            log('ERROR', `Failed to start Claude Desktop, exit code: ${code}`);
            reject(new Error(`Failed to start Claude Desktop, exit code: ${code}`));
          }
        });
        
        open.on('error', (err) => {
          log('ERROR', `Failed to start Claude Desktop: ${err.message}`);
          reject(err);
        });
      }, 2000);
    });
    
    kill.on('error', (err) => {
      log('ERROR', `Failed to kill Claude Desktop: ${err.message}`);
      reject(err);
    });
  });
}

// Create the browser window
let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 800,
    height: 700,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    },
    title: 'MCP Credentials Manager',
    icon: path.join(ANCHOR_HOME, 'assets', 'mcp-icon.png') // If you have an icon file
  });
  
  // Load the HTML file
  mainWindow.loadFile(path.join(__dirname, 'mcp-credentials-ui.html'));
  
  // Open DevTools in development
  // mainWindow.webContents.openDevTools();
  
  mainWindow.on('closed', function () {
    mainWindow = null;
  });
}

app.on('ready', createWindow);

app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', function () {
  if (mainWindow === null) createWindow();
});

// IPC handlers
ipcMain.on('check-credentials-exist', (event) => {
  event.returnValue = credentialsExist();
});

ipcMain.on('load-credentials', (event, password) => {
  try {
    const credentials = loadCredentials(password);
    event.reply('credentials-loaded', { success: true, credentials });
  } catch (err) {
    log('ERROR', `Failed to load credentials via IPC: ${err.message}`);
    event.reply('credentials-loaded', { success: false, error: err.message });
  }
});

ipcMain.on('save-credentials', (event, { credentials, password }) => {
  try {
    saveCredentials(credentials, password);
    updateClaudeConfig(credentials);
    event.reply('credentials-saved', { success: true });
  } catch (err) {
    log('ERROR', `Failed to save credentials via IPC: ${err.message}`);
    event.reply('credentials-saved', { success: false, error: err.message });
  }
});

ipcMain.on('restart-claude', async (event) => {
  try {
    await restartClaude();
    event.reply('claude-restarted', { success: true });
  } catch (err) {
    log('ERROR', `Failed to restart Claude via IPC: ${err.message}`);
    event.reply('claude-restarted', { success: false, error: err.message });
  }
});

ipcMain.on('open-claude-config', (event) => {
  try {
    // Open the Claude config file in the default editor
    const open = spawn('open', [CLAUDE_CONFIG_PATH]);
    
    open.on('close', (code) => {
      if (code === 0) {
        event.reply('claude-config-opened', { success: true });
      } else {
        event.reply('claude-config-opened', { success: false, error: `Exit code: ${code}` });
      }
    });
    
    open.on('error', (err) => {
      event.reply('claude-config-opened', { success: false, error: err.message });
    });
  } catch (err) {
    log('ERROR', `Failed to open Claude config via IPC: ${err.message}`);
    event.reply('claude-config-opened', { success: false, error: err.message });
  }
});

// Log startup
log('INFO', 'MCP Credentials Manager UI started');
