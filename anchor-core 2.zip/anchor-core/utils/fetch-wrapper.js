/**
 * fetch-wrapper.js - Temporary compatibility wrapper for node-fetch
 *
 * This file creates a CommonJS wrapper for node-fetch which is an ESM-only package
 * It uses dynamic import() to load the ESM module and then exports a wrapped version
 * that works with CommonJS.
 */

let nodeFetch;

// Dynamically import node-fetch (which is ESM-only)
(async () => {
  try {
    const module = await import('node-fetch');
    nodeFetch = module.default;
    console.log('✅ Successfully loaded node-fetch ESM module');
  } catch (err) {
    console.error('❌ Failed to load node-fetch:', err);
  }
})();

/**
 * Wrapper function for node-fetch that waits for the dynamic import to complete
 * @param {string|URL} url - URL to fetch
 * @param {object} options - fetch options
 * @returns {Promise} - fetch promise
 */
function fetch(url, options) {
  if (!nodeFetch) {
    return Promise.reject(new Error('node-fetch is not yet loaded'));
  }
  return nodeFetch(url, options);
}

module.exports = fetch;
