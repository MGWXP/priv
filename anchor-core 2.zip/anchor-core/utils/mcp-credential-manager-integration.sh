#!/bin/bash
# Integration of MCP Credential Manager with CNIF
# © 2025 XPV - MIT License

# This script adds MCP credential management to the CNIF launcher menu
# It should be sourced from the main launcher script

# Add the MCP Credential Manager option to the CNIF launcher menu
add_mcp_credential_manager_option() {
  # Only add if MCP credential scripts are executable
  if [ -f "${ANCHOR_HOME}/.mcp-credential-scripts-executable" ]; then
    return
  fi
  
  # Check if script already exists
  if [ ! -f "${ANCHOR_HOME}/mcp-credential-management.sh" ]; then
    echo "MCP Credential Manager script not found. Skipping integration."
    return
  fi
  
  # Make the script executable
  chmod +x "${ANCHOR_HOME}/mcp-credential-management.sh"
  
  # Create the executable indicator file
  touch "${ANCHOR_HOME}/.mcp-credential-scripts-executable"
}

# Run the MCP Credential Manager
run_mcp_credential_manager() {
  if [ -f "${ANCHOR_HOME}/mcp-credential-management.sh" ]; then
    "${ANCHOR_HOME}/mcp-credential-management.sh"
  else
    echo "MCP Credential Manager script not found."
    read -p "Press Enter to continue..."
  fi
}
