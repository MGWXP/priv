#!/usr/bin/env node
/**
 * MCP Credentials Manager
 * 
 * A secure utility for managing Model Context Protocol (MCP) server credentials
 * This tool handles environment variables for GitHub, Notion, Slack, and other MCP servers
 * 
 * © 2025 XPV - MIT License
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const readline = require('readline');
const os = require('os');

// Configuration
const ANCHOR_HOME = process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core';
const CLAUDE_CONFIG_PATH = path.join(os.homedir(), 'Library/Application Support/Claude/claude_desktop_config.json');
const SECURE_CREDS_DIR = path.join(ANCHOR_HOME, 'data', 'secure-credentials');
const CREDS_FILE = path.join(SECURE_CREDS_DIR, 'mcp-credentials.enc');
const SALT_FILE = path.join(SECURE_CREDS_DIR, 'salt');
const LOG_DIR = path.join(ANCHOR_HOME, 'logs');
const LOG_FILE = path.join(LOG_DIR, 'mcp-credentials-manager.log');

// Ensure directories exist
try {
  if (!fs.existsSync(SECURE_CREDS_DIR)) {
    fs.mkdirSync(SECURE_CREDS_DIR, { recursive: true });
  }
  if (!fs.existsSync(LOG_DIR)) {
    fs.mkdirSync(LOG_DIR, { recursive: true });
  }
} catch (err) {
  console.error(`Failed to create required directories: ${err.message}`);
  process.exit(1);
}

// Initialize readline interface
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

/**
 * Logging utility
 * @param {string} level - Log level (INFO, WARN, ERROR)
 * @param {string} message - Log message
 */
function log(level, message) {
  const timestamp = new Date().toISOString();
  const logEntry = `${timestamp} [${level}] ${message}`;
  
  console.log(logEntry);
  
  try {
    fs.appendFileSync(LOG_FILE, logEntry + '\n');
  } catch (err) {
    console.error(`Failed to write to log: ${err.message}`);
  }
}

/**
 * Derive an encryption key from a password
 * @param {string} password - User password
 * @param {Buffer} salt - Cryptographic salt
 * @returns {Buffer} Derived key
 */
function deriveKey(password, salt) {
  return crypto.pbkdf2Sync(password, salt, 100000, 32, 'sha256');
}

/**
 * Encrypt credentials data
 * @param {string} data - JSON string of credentials
 * @param {string} password - Encryption password
 * @returns {Object} Encrypted data and IV
 */
function encryptData(data, password) {
  let salt;
  
  // Get or generate salt
  try {
    if (fs.existsSync(SALT_FILE)) {
      salt = fs.readFileSync(SALT_FILE);
    } else {
      salt = crypto.randomBytes(16);
      fs.writeFileSync(SALT_FILE, salt);
    }
  } catch (err) {
    log('ERROR', `Salt operations failed: ${err.message}`);
    throw err;
  }
  
  // Derive key from password
  const key = deriveKey(password, salt);
  
  // Encrypt the data
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
  let encrypted = cipher.update(data, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  
  return {
    iv: iv.toString('hex'),
    data: encrypted
  };
}

/**
 * Decrypt credentials data
 * @param {string} encryptedData - Hex string of encrypted data
 * @param {string} iv - Hex string of initialization vector
 * @param {string} password - Decryption password
 * @returns {string} Decrypted data as string
 */
function decryptData(encryptedData, iv, password) {
  try {
    // Read salt
    if (!fs.existsSync(SALT_FILE)) {
      throw new Error('Salt file not found. Credentials may not be initialized.');
    }
    
    const salt = fs.readFileSync(SALT_FILE);
    const key = deriveKey(password, salt);
    
    // Decrypt the data
    const decipher = crypto.createDecipheriv('aes-256-cbc', key, Buffer.from(iv, 'hex'));
    let decrypted = decipher.update(encryptedData, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
  } catch (err) {
    log('ERROR', `Decryption failed: ${err.message}`);
    throw err;
  }
}

/**
 * Save credentials to encrypted file
 * @param {Object} credentials - Credentials object
 * @param {string} password - Encryption password
 */
function saveCredentials(credentials, password) {
  try {
    const dataStr = JSON.stringify(credentials, null, 2);
    const encrypted = encryptData(dataStr, password);
    
    // Save the encrypted credentials with IV
    const fileContent = JSON.stringify({
      iv: encrypted.iv,
      data: encrypted.data
    }, null, 2);
    
    fs.writeFileSync(CREDS_FILE, fileContent);
    log('INFO', 'Credentials saved successfully');
  } catch (err) {
    log('ERROR', `Failed to save credentials: ${err.message}`);
    throw err;
  }
}

/**
 * Load credentials from encrypted file
 * @param {string} password - Decryption password
 * @returns {Object} Credentials object
 */
function loadCredentials(password) {
  try {
    if (!fs.existsSync(CREDS_FILE)) {
      log('INFO', 'No credentials file found. Starting with empty credentials.');
      return {
        github: {},
        notion: {},
        slack: {}
      };
    }
    
    const fileContent = fs.readFileSync(CREDS_FILE, 'utf8');
    const encrypted = JSON.parse(fileContent);
    
    const decrypted = decryptData(encrypted.data, encrypted.iv, password);
    return JSON.parse(decrypted);
  } catch (err) {
    log('ERROR', `Failed to load credentials: ${err.message}`);
    if (err.message.includes('bad decrypt')) {
      console.error('Invalid password or corrupted credential file.');
    }
    throw err;
  }
}

/**
 * Update Claude Desktop config file with current credentials
 * @param {Object} credentials - Credentials object
 */
function updateClaudeConfig(credentials) {
  try {
    if (!fs.existsSync(CLAUDE_CONFIG_PATH)) {
      log('ERROR', `Claude config file not found at: ${CLAUDE_CONFIG_PATH}`);
      throw new Error(`Claude config file not found at: ${CLAUDE_CONFIG_PATH}`);
    }
    
    // Read current config
    const config = JSON.parse(fs.readFileSync(CLAUDE_CONFIG_PATH, 'utf8'));
    
    // Make a backup
    const backupPath = `${CLAUDE_CONFIG_PATH}.bak.${Date.now()}`;
    fs.writeFileSync(backupPath, JSON.stringify(config, null, 2));
    log('INFO', `Backup of Claude config created: ${backupPath}`);
    
    // Update GitHub config if credentials exist
    if (credentials.github.personalAccessToken) {
      if (config.mcpServers && config.mcpServers.github && config.mcpServers.github.env) {
        config.mcpServers.github.env.GITHUB_PERSONAL_ACCESS_TOKEN = credentials.github.personalAccessToken;
        
        if (credentials.github.enterpriseUrl) {
          config.mcpServers.github.env.GITHUB_ENTERPRISE_URL = credentials.github.enterpriseUrl;
        }
        
        log('INFO', 'Updated GitHub credentials in Claude config');
      }
    }
    
    // Update Notion config if credentials exist
    if (credentials.notion.apiKey) {
      if (config.mcpServers && config.mcpServers.notion && config.mcpServers.notion.env) {
        // Notion uses a special format for its API key in the headers
        const notionHeaders = config.mcpServers.notion.env.OPENAPI_MCP_HEADERS || '{}';
        let headers;
        
        try {
          // Parse current headers if they exist
          headers = JSON.parse(notionHeaders);
        } catch (e) {
          headers = {};
        }
        
        // Update the Authorization header with the new API key
        headers.Authorization = `Bearer ${credentials.notion.apiKey}`;
        
        // Make sure Notion-Version is present
        if (!headers['Notion-Version']) {
          headers['Notion-Version'] = '2022-06-28';
        }
        
        // Stringify the headers back to JSON
        config.mcpServers.notion.env.OPENAPI_MCP_HEADERS = JSON.stringify(headers);
        
        log('INFO', 'Updated Notion credentials in Claude config');
      }
    }
    
    // Update Slack config if credentials exist
    if (credentials.slack.botToken) {
      if (config.mcpServers && config.mcpServers.slack && config.mcpServers.slack.env) {
        config.mcpServers.slack.env.SLACK_BOT_TOKEN = credentials.slack.botToken;
        
        if (credentials.slack.teamId) {
          config.mcpServers.slack.env.SLACK_TEAM_ID = credentials.slack.teamId;
        }
        
        log('INFO', 'Updated Slack credentials in Claude config');
      }
    }
    
    // Save updated config
    fs.writeFileSync(CLAUDE_CONFIG_PATH, JSON.stringify(config, null, 2));
    log('INFO', 'Claude config file updated successfully');
    
    return true;
  } catch (err) {
    log('ERROR', `Failed to update Claude config: ${err.message}`);
    throw err;
  }
}

/**
 * Prompt for credential values with masking
 */
async function promptForCredentials() {
  return new Promise((resolve) => {
    // Ask for the master password first
    rl.question('Enter master password (to encrypt/decrypt credentials): ', async (password) => {
      if (!password || password.length < 8) {
        console.log('Password must be at least 8 characters. Please try again.');
        return resolve(await promptForCredentials());
      }
      
      try {
        // Try to load existing credentials with this password
        const credentials = loadCredentials(password);
        
        // GitHub credentials
        credentials.github = credentials.github || {};
        
        rl.question(`GitHub Personal Access Token ${credentials.github.personalAccessToken ? '[*****existing*****]' : ''}: `, (token) => {
          if (token) credentials.github.personalAccessToken = token;
          
          rl.question(`GitHub Enterprise URL ${credentials.github.enterpriseUrl ? '[existing]' : ''}: `, (url) => {
            if (url) credentials.github.enterpriseUrl = url;
            
            // Notion credentials
            credentials.notion = credentials.notion || {};
            
            rl.question(`Notion API Key ${credentials.notion.apiKey ? '[*****existing*****]' : ''}: `, (apiKey) => {
              if (apiKey) credentials.notion.apiKey = apiKey;
              
              // Slack credentials
              credentials.slack = credentials.slack || {};
              
              rl.question(`Slack Bot Token ${credentials.slack.botToken ? '[*****existing*****]' : ''}: `, (botToken) => {
                if (botToken) credentials.slack.botToken = botToken;
                
                rl.question(`Slack Team ID ${credentials.slack.teamId ? '[existing]' : ''}: `, (teamId) => {
                  if (teamId) credentials.slack.teamId = teamId;
                  
                  // Save credentials and update Claude config
                  saveCredentials(credentials, password);
                  updateClaudeConfig(credentials);
                  
                  console.log('\n✅ Credentials updated successfully!\n');
                  console.log('Your MCP servers should now work with the updated credentials.');
                  console.log('Restart Claude Desktop to apply these changes.');
                  
                  rl.close();
                  resolve(credentials);
                });
              });
            });
          });
        });
      } catch (err) {
        console.error(`❌ Error: ${err.message}`);
        if (err.message.includes('bad decrypt')) {
          console.log('Invalid password. Please try again.');
          resolve(await promptForCredentials());
        } else {
          rl.close();
          resolve(null);
        }
      }
    });
  });
}

/**
 * Check if a credential is valid (non-empty string)
 * @param {string} cred - Credential to check
 * @returns {boolean} True if valid, false otherwise
 */
function isValidCredential(cred) {
  return typeof cred === 'string' && cred.trim().length > 0;
}

/**
 * Main function
 */
async function main() {
  console.log('\n🔐 MCP Credentials Manager 🔐');
  console.log('==============================');
  console.log('This utility securely manages credentials for your MCP servers.');
  console.log('The credentials will be encrypted and stored securely.');
  console.log('They will automatically be applied to your Claude Desktop config.');
  console.log('\nCredentials are stored in:');
  console.log(`  ${CREDS_FILE}\n`);
  
  await promptForCredentials();
}

// Execute main function
main().catch(err => {
  log('ERROR', `Unhandled exception: ${err.message}`);
  console.error(`❌ Unhandled error: ${err.message}`);
  process.exit(1);
});
