#!/bin/bash
# cnif-integration-test.sh - End-to-end test for CNIF
# © 2025 XPV - MIT
#
# This script performs integration testing of the CNIF system to verify
# proper integration between all components.

# Environment setup
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
LOG_DIR="${HOME}/Library/Logs/Claude"
TIMESTAMP=$(date +"%Y%m%d%H%M%S")
LOG_FILE="${LOG_DIR}/integration-test-${TIMESTAMP}.log"
SOCKET_DIR="${ANCHOR_HOME}/sockets"
SCHEMA_DIR="${ANCHOR_HOME}/schemas"
TEST_DIR="${ANCHOR_HOME}/tests"
TEMP_DIR="${ANCHOR_HOME}/tests/temp"
TEST_RESULTS_DIR="${TEST_DIR}/results"

# Ensure directories exist
mkdir -p "${LOG_DIR}"
mkdir -p "${TEST_DIR}"
mkdir -p "${TEMP_DIR}"
mkdir -p "${TEST_RESULTS_DIR}"

# ANSI color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Log function
log() {
  local level="$1"
  local message="$2"
  local color="${NC}"
  
  case "${level}" in
    "INFO") color="${GREEN}" ;;
    "WARN") color="${YELLOW}" ;;
    "ERROR") color="${RED}" ;;
    "DEBUG") color="${BLUE}" ;;
    "TEST") color="${CYAN}" ;;
    *) color="${NC}" ;;
  esac
  
  echo -e "${color}$(date +"%Y-%m-%d %H:%M:%S") [${level}] ${message}${NC}" | tee -a "${LOG_FILE}"
}

# Print header
print_header() {
  local title="$1"
  echo -e "\n${CYAN}======================================================================${NC}"
  echo -e "${CYAN}= ${title}${NC}"
  echo -e "${CYAN}======================================================================${NC}"
}

# Check if system is running
check_system_running() {
  # Check for socket files
  local socket_files=$(ls -1 "${SOCKET_DIR}"/*.sock 2>/dev/null | wc -l)
  
  if [ ${socket_files} -lt 3 ]; then
    log "ERROR" "❌ CNIF system not fully running. Found ${socket_files} socket files, expected at least 3"
    log "ERROR" "Please start the system with sequenced-launcher.sh before running tests"
    return 1
  fi
  
  # Check for expected socket files
  for socket_name in "socket-server" "notion" "streaming-transformer"; do
    if [ ! -S "${SOCKET_DIR}/${socket_name}.sock" ]; then
      log "ERROR" "❌ Required socket file missing: ${socket_name}.sock"
      return 1
    fi
  done
  
  # Check for expected schema files
  local claude_schemas=$(ls -1 "${SCHEMA_DIR}/claude/"*.json 2>/dev/null | wc -l)
  local notion_schemas=$(ls -1 "${SCHEMA_DIR}/notion/"*.json 2>/dev/null | wc -l)
  
  if [ ${claude_schemas} -eq 0 ] || [ ${notion_schemas} -eq 0 ]; then
    log "ERROR" "❌ Schema files missing. Claude: ${claude_schemas}, Notion: ${notion_schemas}"
    return 1
  fi
  
  log "INFO" "✅ CNIF system is running with required components"
  return 0
}

# Create test schema
create_test_schema() {
  local schema_file="${TEMP_DIR}/test-integration-schema.json"
  
  cat > "${schema_file}" << EOF
{
  "id": "test-integration",
  "version": "1-0-0",
  "description": "Integration test schema for CNIF",
  "schema": {
    "type": "object",
    "required": ["message", "timestamp", "test_id"],
    "properties": {
      "message": {
        "type": "string"
      },
      "timestamp": {
        "type": "string"
      },
      "test_id": {
        "type": "string"
      },
      "payload": {
        "type": "object",
        "properties": {
          "value": {
            "type": "string"
          },
          "metadata": {
            "type": "object"
          }
        }
      }
    }
  }
}
EOF
  
  log "INFO" "Created test schema at ${schema_file}"
  echo "${schema_file}"
}

# Test schema registry
test_schema_registry() {
  print_header "Testing Schema Registry"
  
  log "TEST" "🔍 Running schema registry test..."
  
  # Run schema registry test
  node "${ANCHOR_HOME}/mcp-servers/test-schema-registry.js" > "${TEST_RESULTS_DIR}/schema-registry-test-${TIMESTAMP}.log" 2>&1
  local test_result=$?
  
  if [ ${test_result} -eq 0 ]; then
    log "TEST" "✅ Schema registry test passed"
  else
    log "ERROR" "❌ Schema registry test failed"
    cat "${TEST_RESULTS_DIR}/schema-registry-test-${TIMESTAMP}.log"
    return 1
  fi
  
  # Test schema registration
  log "TEST" "🔍 Testing schema registration..."
  
  # Create test schema
  local test_schema_file=$(create_test_schema)
  
  # Create registration test script
  local test_script="${TEMP_DIR}/register-test-schema.js"
  
  cat > "${test_script}" << EOF
const SchemaRegistry = require('${ANCHOR_HOME}/mcp-servers/schema-registry.cjs');
const fs = require('fs');
const path = require('path');

async function registerTestSchema() {
  try {
    const registry = new SchemaRegistry({
      schemaDirClaude: '${SCHEMA_DIR}/claude',
      schemaDirNotion: '${SCHEMA_DIR}/notion'
    });
    
    await registry.initialize();
    
    // Load test schema
    const schemaJson = fs.readFileSync('${test_schema_file}', 'utf8');
    const schema = JSON.parse(schemaJson);
    
    // Register test schema
    console.log('Registering test schema: ' + schema.id + '@' + schema.version);
    await registry.registerSchema('claude', schema);
    
    // Verify registration
    const metrics = registry.getMetrics();
    console.log(JSON.stringify(metrics, null, 2));
    
    if (metrics.latestVersions.claude[schema.id] === schema.version) {
      console.log('Schema registration successful');
      return true;
    } else {
      console.error('Schema registration failed - version mismatch');
      return false;
    }
  } catch (err) {
    console.error('Error:', err.message);
    return false;
  }
}

registerTestSchema().then(success => {
  process.exit(success ? 0 : 1);
});
EOF
  
  # Run schema registration test
  node "${test_script}" > "${TEST_RESULTS_DIR}/schema-registration-test-${TIMESTAMP}.log" 2>&1
  test_result=$?
  
  if [ ${test_result} -eq 0 ]; then
    log "TEST" "✅ Schema registration test passed"
    return 0
  else
    log "ERROR" "❌ Schema registration test failed"
    cat "${TEST_RESULTS_DIR}/schema-registration-test-${TIMESTAMP}.log"
    return 1
  fi
}

# Test socket communication
test_socket_communication() {
  print_header "Testing Socket Communication"
  
  log "TEST" "🔍 Testing socket server communication..."
  
  # Create socket client test script
  local test_script="${TEMP_DIR}/socket-client-test.js"
  
  cat > "${test_script}" << EOF
const net = require('net');
const path = require('path');

const SOCKET_PATH = '${SOCKET_DIR}/socket-server.sock';
const TEST_ID = '${TIMESTAMP}';

function log(message) {
  console.log(\`[\${new Date().toISOString()}] \${message}\`);
}

async function testSocketCommunication() {
  return new Promise((resolve, reject) => {
    const socket = net.createConnection({ path: SOCKET_PATH });
    let received = false;
    
    // Set timeout
    const timeout = setTimeout(() => {
      socket.end();
      reject(new Error('Socket communication timeout'));
    }, 5000);
    
    socket.on('connect', () => {
      log('Connected to socket server');
      
      // Send handshake message
      const handshake = {
        type: 'handshake',
        client: 'integration-test',
        test_id: TEST_ID,
        timestamp: new Date().toISOString()
      };
      
      log('Sending handshake: ' + JSON.stringify(handshake));
      socket.write(JSON.stringify(handshake) + '\\n');
    });
    
    socket.on('data', (data) => {
      const messages = data.toString().split('\\n').filter(m => m.trim());
      
      for (const messageText of messages) {
        try {
          log('Received: ' + messageText);
          const message = JSON.parse(messageText);
          
          if (message.type === 'handshake_response' && message.status === 'success') {
            received = true;
            clearTimeout(timeout);
            socket.end();
            resolve(true);
          }
        } catch (err) {
          log('Error parsing message: ' + err.message);
        }
      }
    });
    
    socket.on('error', (err) => {
      log('Socket error: ' + err.message);
      clearTimeout(timeout);
      reject(err);
    });
    
    socket.on('close', () => {
      log('Socket closed');
      clearTimeout(timeout);
      if (!received) {
        reject(new Error('Socket closed without receiving response'));
      }
    });
  });
}

testSocketCommunication()
  .then(() => {
    log('Socket communication test successful');
    process.exit(0);
  })
  .catch(err => {
    log('Socket communication test failed: ' + err.message);
    process.exit(1);
  });
EOF
  
  # Run socket communication test
  node "${test_script}" > "${TEST_RESULTS_DIR}/socket-communication-test-${TIMESTAMP}.log" 2>&1
  local test_result=$?
  
  if [ ${test_result} -eq 0 ]; then
    log "TEST" "✅ Socket communication test passed"
    return 0
  else
    log "ERROR" "❌ Socket communication test failed"
    cat "${TEST_RESULTS_DIR}/socket-communication-test-${TIMESTAMP}.log"
    return 1
  fi
}

# Test Notion API connection
test_notion_connection() {
  print_header "Testing Notion API Connection"
  
  log "TEST" "🔍 Testing Notion API connection..."
  
  # Create Notion connection test script
  local test_script="${TEMP_DIR}/notion-connection-test.js"
  
  cat > "${test_script}" << EOF
const net = require('net');
const path = require('path');

const SOCKET_PATH = '${SOCKET_DIR}/notion.sock';
const TEST_ID = '${TIMESTAMP}';

function log(message) {
  console.log(\`[\${new Date().toISOString()}] \${message}\`);
}

async function testNotionConnection() {
  return new Promise((resolve, reject) => {
    const socket = net.createConnection({ path: SOCKET_PATH });
    let received = false;
    
    // Set timeout
    const timeout = setTimeout(() => {
      socket.end();
      reject(new Error('Notion connection timeout'));
    }, 10000);
    
    socket.on('connect', () => {
      log('Connected to Notion socket');
      
      // Send test query
      const query = {
        type: 'invoke_tool',
        id: TEST_ID,
        tool: 'searchByTitle',
        params: {
          query: 'test'
        },
        timestamp: new Date().toISOString()
      };
      
      log('Sending query: ' + JSON.stringify(query));
      socket.write(JSON.stringify(query) + '\\n');
    });
    
    socket.on('data', (data) => {
      const messages = data.toString().split('\\n').filter(m => m.trim());
      
      for (const messageText of messages) {
        try {
          log('Received: ' + messageText);
          const message = JSON.parse(messageText);
          
          if (message.type === 'tool_response' && message.id === TEST_ID) {
            received = true;
            clearTimeout(timeout);
            socket.end();
            resolve(true);
          }
        } catch (err) {
          log('Error parsing message: ' + err.message);
        }
      }
    });
    
    socket.on('error', (err) => {
      log('Socket error: ' + err.message);
      clearTimeout(timeout);
      reject(err);
    });
    
    socket.on('close', () => {
      log('Socket closed');
      clearTimeout(timeout);
      if (!received) {
        reject(new Error('Socket closed without receiving response'));
      }
    });
  });
}

testNotionConnection()
  .then(() => {
    log('Notion connection test successful');
    process.exit(0);
  })
  .catch(err => {
    log('Notion connection test failed: ' + err.message);
    process.exit(1);
  });
EOF
  
  # Run Notion connection test
  node "${test_script}" > "${TEST_RESULTS_DIR}/notion-connection-test-${TIMESTAMP}.log" 2>&1
  local test_result=$?
  
  if [ ${test_result} -eq 0 ]; then
    log "TEST" "✅ Notion connection test passed"
    return 0
  else
    log "WARN" "⚠️ Notion connection test failed - this may be due to API token configuration"
    cat "${TEST_RESULTS_DIR}/notion-connection-test-${TIMESTAMP}.log"
    log "INFO" "ℹ️ Notion API token may need to be configured in ${ANCHOR_HOME}/config/notion-config.json"
    return 0  # Don't fail the entire test suite
  fi
}

# Test streaming transformer
test_streaming_transformer() {
  print_header "Testing Streaming Transformer"
  
  log "TEST" "🔍 Testing streaming transformer..."
  
  # Create streaming transformer test script
  local test_script="${TEMP_DIR}/streaming-transformer-test.js"
  
  cat > "${test_script}" << EOF
const net = require('net');
const path = require('path');

const SOCKET_PATH = '${SOCKET_DIR}/streaming-transformer.sock';
const TEST_ID = '${TIMESTAMP}';

function log(message) {
  console.log(\`[\${new Date().toISOString()}] \${message}\`);
}

async function testTransformer() {
  return new Promise((resolve, reject) => {
    const socket = net.createConnection({ path: SOCKET_PATH });
    let received = false;
    
    // Set timeout
    const timeout = setTimeout(() => {
      socket.end();
      reject(new Error('Transformer timeout'));
    }, 5000);
    
    socket.on('connect', () => {
      log('Connected to transformer socket');
      
      // Create simple XML to transform
      const xmlData = \`
<cnif:message xmlns:cnif="http://anthropic.com/claude/cnif/v1">
  <cnif:header>
    <cnif:id>\${TEST_ID}</cnif:id>
    <cnif:timestamp>\${new Date().toISOString()}</cnif:timestamp>
  </cnif:header>
  <cnif:body>
    <cnif:text>This is a test message</cnif:text>
    <cnif:metadata>
      <cnif:source>integration-test</cnif:source>
      <cnif:priority>high</cnif:priority>
    </cnif:metadata>
  </cnif:body>
</cnif:message>
      \`;
      
      // Send transform request
      const request = {
        type: 'transform',
        id: TEST_ID,
        format: 'xml-to-json',
        data: xmlData,
        timestamp: new Date().toISOString()
      };
      
      log('Sending transform request');
      socket.write(JSON.stringify(request) + '\\n');
    });
    
    socket.on('data', (data) => {
      const messages = data.toString().split('\\n').filter(m => m.trim());
      
      for (const messageText of messages) {
        try {
          log('Received: ' + messageText);
          const message = JSON.parse(messageText);
          
          if (message.type === 'transform_response' && message.id === TEST_ID) {
            received = true;
            clearTimeout(timeout);
            socket.end();
            
            // Verify the response contains the transformed data
            if (message.data && 
                message.data.header && 
                message.data.header.id === TEST_ID) {
              resolve(true);
            } else {
              reject(new Error('Transform response data invalid'));
            }
          }
        } catch (err) {
          log('Error parsing message: ' + err.message);
        }
      }
    });
    
    socket.on('error', (err) => {
      log('Socket error: ' + err.message);
      clearTimeout(timeout);
      reject(err);
    });
    
    socket.on('close', () => {
      log('Socket closed');
      clearTimeout(timeout);
      if (!received) {
        reject(new Error('Socket closed without receiving response'));
      }
    });
  });
}

testTransformer()
  .then(() => {
    log('Transformer test successful');
    process.exit(0);
  })
  .catch(err => {
    log('Transformer test failed: ' + err.message);
    process.exit(1);
  });
EOF
  
  # Run streaming transformer test
  node "${test_script}" > "${TEST_RESULTS_DIR}/streaming-transformer-test-${TIMESTAMP}.log" 2>&1
  local test_result=$?
  
  if [ ${test_result} -eq 0 ]; then
    log "TEST" "✅ Streaming transformer test passed"
    return 0
  else
    log "ERROR" "❌ Streaming transformer test failed"
    cat "${TEST_RESULTS_DIR}/streaming-transformer-test-${TIMESTAMP}.log"
    return 1
  fi
}

# Generate test report
generate_test_report() {
  local report_file="${TEST_RESULTS_DIR}/integration-test-report-${TIMESTAMP}.md"
  local success_count=0
  local total_tests=4
  
  for result in "${TEST_RESULTS_DIR}/"*-test-${TIMESTAMP}.log; do
    if grep -q "successful" "${result}"; then
      success_count=$((success_count + 1))
    fi
  done
  
  # Create markdown report
  cat > "${report_file}" << EOF
# CNIF Integration Test Report

**Date:** $(date)
**Test ID:** ${TIMESTAMP}

## Test Summary

**Overall Result:** $([ ${success_count} -eq ${total_tests} ] && echo "✅ PASSED" || echo "❌ FAILED")

- **Tests Passed:** ${success_count}/${total_tests}
- **Tests Failed:** $((total_tests - success_count))/${total_tests}

## Test Details

| Test | Result | Log File |
|------|--------|----------|
| Schema Registry | $(grep -q "Schema registry test passed" "${LOG_FILE}" && echo "✅ PASSED" || echo "❌ FAILED") | [schema-registry-test-${TIMESTAMP}.log](./schema-registry-test-${TIMESTAMP}.log) |
| Socket Communication | $(grep -q "Socket communication test passed" "${LOG_FILE}" && echo "✅ PASSED" || echo "❌ FAILED") | [socket-communication-test-${TIMESTAMP}.log](./socket-communication-test-${TIMESTAMP}.log) |
| Notion Connection | $(grep -q "Notion connection test passed" "${LOG_FILE}" && echo "✅ PASSED" || echo "⚠️ WARNING") | [notion-connection-test-${TIMESTAMP}.log](./notion-connection-test-${TIMESTAMP}.log) |
| Streaming Transformer | $(grep -q "Streaming transformer test passed" "${LOG_FILE}" && echo "✅ PASSED" || echo "❌ FAILED") | [streaming-transformer-test-${TIMESTAMP}.log](./streaming-transformer-test-${TIMESTAMP}.log) |

## System Information

- **Node Version:** $(node -v)
- **Platform:** $(uname -a)
- **ANCHOR_HOME:** ${ANCHOR_HOME}
- **Test Timestamp:** ${TIMESTAMP}

## Notes

$(grep -q "Notion connection test failed" "${LOG_FILE}" && echo "⚠️ Notion API connection test may fail if the API token is not configured correctly. Check the notion-config.json file." || echo "")

---

Report generated by cnif-integration-test.sh
EOF
  
  log "INFO" "✅ Generated test report: ${report_file}"
  echo "${report_file}"
}

# Main function
main() {
  print_header "CNIF Integration Test"
  log "INFO" "🚀 Starting CNIF integration test..."
  
  # Check if system is running
  check_system_running
  if [ $? -ne 0 ]; then
    log "ERROR" "❌ Cannot continue testing - system not running properly"
    exit 1
  fi
  
  # Run tests
  local test_failures=0
  
  # Test schema registry
  test_schema_registry
  if [ $? -ne 0 ]; then
    test_failures=$((test_failures + 1))
    log "ERROR" "❌ Schema registry test failed"
  fi
  
  # Test socket communication
  test_socket_communication
  if [ $? -ne 0 ]; then
    test_failures=$((test_failures + 1))
    log "ERROR" "❌ Socket communication test failed"
  fi
  
  # Test Notion connection
  test_notion_connection
  
  # Test streaming transformer
  test_streaming_transformer
  if [ $? -ne 0 ]; then
    test_failures=$((test_failures + 1))
    log "ERROR" "❌ Streaming transformer test failed"
  fi
  
  # Generate test report
  local report_file=$(generate_test_report)
  
  # Final status
  if [ ${test_failures} -eq 0 ]; then
    log "INFO" "✅ All integration tests passed"
    echo -e "\n${GREEN}✅ CNIF Integration test completed successfully.${NC}"
    echo -e "Test report: ${report_file}"
  else
    log "ERROR" "❌ Integration tests failed: ${test_failures} failures"
    echo -e "\n${RED}❌ CNIF Integration test completed with ${test_failures} failures.${NC}"
    echo -e "Test report: ${report_file}"
    exit 1
  fi
}

# Run main function
main
