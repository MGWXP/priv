#!/usr/bin/env node

const net = require('net');
const readline = require('readline');
const socketPath = process.argv[2];

if (!socketPath) {
  console.error('Usage: node test-server.js <socket-path>');
  process.exit(1);
}

console.log(`Testing connection to ${socketPath}...`);
const socket = net.createConnection({ path: socketPath });

socket.on('connect', () => {
  console.log(`Connected successfully to ${socketPath}`);
  
  // Send initialize message
  const initMessage = {
    jsonrpc: '2.0',
    id: 'test-init',
    method: 'initialize',
    params: {
      protocolVersion: '2024-11-05',
      capabilities: {},
      clientInfo: {
        name: 'test-client',
        version: '1.0.0'
      }
    }
  };
  
  console.log(`Sending initialize message: ${JSON.stringify(initMessage)}`);
  socket.write(JSON.stringify(initMessage) + '\n');
});

socket.on('data', (data) => {
  const response = data.toString().trim();
  console.log(`Received response: ${response}`);
  
  try {
    const parsed = JSON.parse(response);
    if (parsed.result && parsed.result.protocolVersion) {
      console.log(`Server is working! Protocol version: ${parsed.result.protocolVersion}`);
      socket.end();
      process.exit(0);
    }
  } catch (err) {
    console.error(`Error parsing response: ${err.message}`);
  }
});

socket.on('error', (err) => {
  console.error(`Socket error: ${err.message}`);
  process.exit(1);
});

socket.on('close', () => {
  console.log('Socket connection closed');
});

// Exit after 5 seconds if no response
setTimeout(() => {
  console.error('Timeout - no response received');
  socket.destroy();
  process.exit(1);
}, 5000);
