#!/usr/bin/env node
/**
 * unified-m3-optimizer.js - Hardware-specific optimizations for M3 Max
 * © 2025 XPV - MIT
 * 
 * This unified optimizer combines the functionality of:
 * - m3-optimizer.js
 * - m3_optimizer.js
 * - m3_optimizer.cjs
 * - m3-mcp-optimizer.js
 * 
 * It provides:
 * - Optimized memory allocation
 * - Thread pool configuration
 * - Memory pooling
 * - Metal acceleration if available
 * - Safe NODE_OPTIONS settings
 */

const fs = require('fs');
const os = require('os');
const path = require('path');
const { execSync } = require('child_process');

class UnifiedM3Optimizer {
  /**
   * Create a new UnifiedM3Optimizer
   * @param {object} options - Options for optimization
   */
  constructor(options = {}) {
    this.cpuCount = os.cpus().length;
    this.totalMemoryGB = Math.round(os.totalmem() / (1024 * 1024 * 1024));
    this.isM3Max = this._detectM3Max();
    
    // Determine P-core and E-core counts based on M3 Max architecture
    this.pCores = this.isM3Max ? 12 : Math.ceil(this.cpuCount * 0.75);
    this.eCores = this.isM3Max ? 4 : Math.floor(this.cpuCount * 0.25);
    
    this.options = {
      memoryPercentage: 0.33,   // Use 1/3 of system memory for Node.js
      gcTargetPercentage: 0.85, // Target memory usage before GC
      threadPoolSize: this.pCores, // Use P-cores for thread pool
      memoryPooling: true,     // Enable memory pooling
      adaptiveBuffering: true, // Enable adaptive buffer sizing
      useMetalIfAvailable: true, // Use Metal Performance Shaders if available
      ...options
    };
    
    this.anchorHome = process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core';
    
    // Memory pools configuration
    this.memoryPools = {
      small: { size: 4 * 1024, count: 1000 },     // 4KB objects, pool of 1000
      medium: { size: 64 * 1024, count: 100 }, // 64KB objects, pool of 100
      large: { size: 1024 * 1024, count: 10 }  // 1MB objects, pool of 10
    };
  }
  
  /**
   * Check if we're running on M3 Max hardware
   * @returns {boolean} - True if running on M3 Max
   * @private
   */
  _detectM3Max() {
    const cpuInfo = os.cpus()[0].model;
    const isAppleSilicon = cpuInfo.includes('Apple') && os.arch() === 'arm64';
    const has16Cores = this.cpuCount === 16;
    const has48GBMemory = this.totalMemoryGB >= 45 && this.totalMemoryGB <= 50;
    
    const isM3Max = isAppleSilicon && has16Cores && has48GBMemory;
    
    if (isM3Max) {
      console.log('✅ M3 Max with 48GB unified memory detected');
      console.log(`• Performance cores: 12 (P-cores)`); 
      console.log(`• Efficiency cores: 4 (E-cores)`);
    } else if (isAppleSilicon) {
      console.log('⚠️ Apple Silicon detected, but not M3 Max with 48GB');
      console.log(`• Estimated performance cores: ${this.pCores}`); 
      console.log(`• Estimated efficiency cores: ${this.eCores}`);
    } else {
      console.log('⚠️ Non-Apple Silicon hardware detected');
      console.log('• Using generic optimization parameters');
    }
    
    return isM3Max;
  }
  
  /**
   * Generate optimized NODE_OPTIONS
   * @returns {string} - Optimized NODE_OPTIONS
   */
  generateNodeOptions() {
    // Calculate optimal memory allocation (in MB)
    const maxOldSpaceSize = Math.floor(this.totalMemoryGB * 1024 * this.options.memoryPercentage);
    
    // IMPORTANT: For NODE_OPTIONS, only specific flags are allowed
    // --expose-gc is NOT allowed in NODE_OPTIONS and will cause errors
    // https://nodejs.org/api/cli.html#environment-variables
    const safeOptions = [
      `--max-old-space-size=${maxOldSpaceSize}`
    ];
    
    return safeOptions.join(' ');
  }
  
  /**
   * Generate an environment file with optimized settings
   * @param {string} outputPath - Path to write .env file
   * @returns {string} - The generated content
   */
  generateEnvFile(outputPath) {
    const envContent = `# M3 Max Optimized Settings
# Generated: ${new Date().toISOString()}
# Hardware: ${this.isM3Max ? 'M3 Max' : 'Generic'} with ${this.totalMemoryGB}GB memory

# Node.js Memory Settings - Safe NODE_OPTIONS only
export NODE_OPTIONS="${this.generateNodeOptions()}"

# Thread Pool Configuration
export UV_THREADPOOL_SIZE=${this.options.threadPoolSize}

# Base Directories
export ANCHOR_HOME=${this.anchorHome}
export CORE_DIR=${this.anchorHome}/core
export ENTRY_POINTS_DIR=${this.anchorHome}/mcp-servers/entry-points
export ADMIN_DIR=${this.anchorHome}/admin
export CONFIG_DIR=${this.anchorHome}/config
export TOOLS_DIR=${this.anchorHome}/tools

# System Directories
export SOCKET_DIR=${this.anchorHome}/sockets
export LOG_DIR=${os.homedir()}/Library/Logs/Claude
export MCP_DIR=${this.anchorHome}/mcp-servers

# M3 Specific Settings
export M3_OPTIMIZED=true
export M3_MEMORY_ALLOCATION=${Math.floor(this.totalMemoryGB * this.options.memoryPercentage)}GB
export M3_CORE_COUNT=${this.cpuCount}
export M3_P_CORES=${this.pCores}
export M3_E_CORES=${this.eCores}

# Advanced Memory Configuration
export M3_MEMORY_POOLING=${this.options.memoryPooling}
export M3_ADAPTIVE_BUFFERING=${this.options.adaptiveBuffering}

# Buffer Configurations
export M3_DEFAULT_BUFFER_SIZE=${this.memoryPools.small.size}
export M3_MEDIUM_BUFFER_SIZE=${this.memoryPools.medium.size}
export M3_LARGE_BUFFER_SIZE=${this.memoryPools.large.size}
export M3_SOCKET_BUFFER_SIZE=${this.memoryPools.medium.size}
export M3_STREAM_HIGH_WATER_MARK=${this.memoryPools.large.size}
`;

    if (outputPath) {
      fs.writeFileSync(outputPath, envContent);
      console.log(`✅ Created optimized .env file at: ${outputPath}`);
    }
    
    return envContent;
  }
  
  /**
   * Generate memory pool initialization code
   * @returns {string} Memory pool code
   * @private
   */
  _generateMemoryPoolCode() {
    return `/**
 * memory-pool-init.js - Memory pooling for M3 Max
 * © 2025 XPV - MIT
 * 
 * Initializes memory pools for different buffer sizes
 * to reduce garbage collection pressure
 */

class MemoryPool {
  constructor(bufferSize, poolSize) {
    this.bufferSize = bufferSize;
    this.maxSize = poolSize;
    this.pool = [];
    
    // Pre-allocate buffers
    for (let i = 0; i < poolSize; i++) {
      this.pool.push(Buffer.allocUnsafe(bufferSize));
    }
    
    this.stats = {
      allocations: 0,
      releases: 0,
      misses: 0,
      highWaterMark: 0
    };
  }
  
  allocate() {
    this.stats.allocations++;
    
    if (this.pool.length === 0) {
      this.stats.misses++;
      return Buffer.allocUnsafe(this.bufferSize);
    }
    
    return this.pool.pop();
  }
  
  release(buffer) {
    this.stats.releases++;
    
    // Only return to pool if it's the right size and pool isn't full
    if (buffer.length === this.bufferSize && this.pool.length < this.maxSize) {
      this.pool.push(buffer);
      this.stats.highWaterMark = Math.max(this.stats.highWaterMark, this.pool.length);
    }
  }
  
  getStats() {
    return {
      ...this.stats,
      bufferSize: this.bufferSize,
      poolSize: this.maxSize,
      currentSize: this.pool.length
    };
  }
}

// Create global memory pools
global.memoryPools = {
  small: new MemoryPool(${this.memoryPools.small.size}, ${this.memoryPools.small.count}),
  medium: new MemoryPool(${this.memoryPools.medium.size}, ${this.memoryPools.medium.count}),
  large: new MemoryPool(${this.memoryPools.large.size}, ${this.memoryPools.large.count})
};

// Utility function to get appropriate buffer
global.getPooledBuffer = function(size) {
  if (size <= ${this.memoryPools.small.size}) {
    return global.memoryPools.small.allocate();
  } else if (size <= ${this.memoryPools.medium.size}) {
    return global.memoryPools.medium.allocate();
  } else if (size <= ${this.memoryPools.large.size}) {
    return global.memoryPools.large.allocate();
  } else {
    return Buffer.allocUnsafe(size);
  }
};

// Utility function to release buffer back to pool
global.releasePooledBuffer = function(buffer) {
  const size = buffer.length;
  
  if (size <= ${this.memoryPools.small.size}) {
    global.memoryPools.small.release(buffer);
  } else if (size <= ${this.memoryPools.medium.size}) {
    global.memoryPools.medium.release(buffer);
  } else if (size <= ${this.memoryPools.large.size}) {
    global.memoryPools.large.release(buffer);
  }
};

// Get memory pool statistics
global.getMemoryPoolStats = function() {
  return {
    small: global.memoryPools.small.getStats(),
    medium: global.memoryPools.medium.getStats(),
    large: global.memoryPools.large.getStats()
  };
};

// Add GC watchdog (only if run with --expose-gc)
if (global.gc) {
  console.log('✅ GC watchdog enabled');
  setInterval(() => {
    const mem = process.memoryUsage();
    if ((mem.heapUsed / mem.heapTotal) > 0.70) {
      console.log('🧹 Running GC due to heap usage >70%');
      global.gc();
    }
  }, 30000);
}

console.log('✅ Memory pools initialized for M3 Max');
`;
  }
  
  /**
   * Generate Metal accelerator code
   * @returns {string} Metal accelerator code
   * @private
   */
  _generateMetalAcceleratorCode() {
    return `/**
 * metal-accelerator.js - Metal Performance Shaders acceleration for M3 Max
 * © 2025 XPV - MIT
 * 
 * Provides GPU-accelerated functions for common operations
 * using Metal Performance Shaders on Apple Silicon
 */

// Mock implementation - in a real system would use Objective-C bridge
class MetalAccelerator {
  constructor() {
    this.enabled = this._checkMetalSupport();
    
    if (this.enabled) {
      console.log('✅ Metal Performance Shaders acceleration enabled');
    } else {
      console.log('⚠️ Metal Performance Shaders not available');
    }
  }
  
  _checkMetalSupport() {
    // In a real implementation, would check Metal support
    // through Objective-C bridge or native module
    return process.platform === 'darwin' && process.arch === 'arm64';
  }
  
  // Example accelerated function for vector operations
  vectorAdd(a, b) {
    if (!this.enabled || !a || !b || a.length !== b.length) {
      // Fallback to CPU implementation
      const result = new Float32Array(a.length);
      for (let i = 0; i < a.length; i++) {
        result[i] = a[i] + b[i];
      }
      return result;
    }
    
    // In a real implementation, would call Metal kernel
    // This is just a mock that still uses CPU
    const result = new Float32Array(a.length);
    for (let i = 0; i < a.length; i++) {
      result[i] = a[i] + b[i];
    }
    return result;
  }
  
  // Example accelerated function for matrix operations
  matrixMultiply(a, b) {
    // Mock implementation
    // In a real implementation, would use Metal Performance Shaders
    return [[0]];
  }
}

// Create global Metal accelerator
global.metalAccelerator = new MetalAccelerator();

console.log('✅ Metal acceleration initialized for M3 Max');
`;
  }
  
  /**
   * Apply all optimizations
   * @returns {object} - Optimization results
   */
  applyOptimizations() {
    console.log('┌─────────────────────────────────────────────────────┐');
    console.log('│        Unified M3 Optimizer for Anchor System       │');
    console.log('└─────────────────────────────────────────────────────┘');
    
    console.log(`\nSystem Detection:`);
    console.log(`• CPU: ${os.cpus()[0].model}`);
    console.log(`• Cores: ${this.cpuCount}`);
    console.log(`• Memory: ${this.totalMemoryGB}GB`);
    console.log(`• Architecture: ${os.arch()}`);
    console.log(`• Platform: ${os.platform()} ${os.release()}`);
    
    // Create required directories
    const directories = [
      path.join(this.anchorHome, 'core'),
      path.join(this.anchorHome, 'admin'),
      path.join(this.anchorHome, 'config'),
      path.join(this.anchorHome, 'tools'),
      path.join(this.anchorHome, 'sockets'),
      path.join(os.homedir(), 'Library/Logs/Claude'),
    ];
    
    console.log('\nCreating required directories:');
    for (const dir of directories) {
      try {
        if (!fs.existsSync(dir)) {
          fs.mkdirSync(dir, { recursive: true });
          console.log(`✅ Created directory: ${dir}`);
        } else {
          console.log(`• Directory exists: ${dir}`);
        }
      } catch (err) {
        console.error(`❌ Failed to create directory ${dir}: ${err.message}`);
      }
    }
    
    // Generate .env file with optimized settings
    console.log('\nApplying M3 Max Optimizations:');
    console.log(`• NODE_OPTIONS: ${this.generateNodeOptions()}`);
    console.log(`• UV_THREADPOOL_SIZE: ${this.options.threadPoolSize}`);
    
    const envPath = path.join(this.anchorHome, '.env');
    this.generateEnvFile(envPath);
    
    // Apply memory pooling configuration if enabled
    if (this.options.memoryPooling) {
      console.log('\n• Memory Pooling Configuration:');
      console.log(`  - Small objects: ${this.memoryPools.small.count} buffers of ${this.memoryPools.small.size} bytes`);
      console.log(`  - Medium objects: ${this.memoryPools.medium.count} buffers of ${this.memoryPools.medium.size} bytes`);
      console.log(`  - Large objects: ${this.memoryPools.large.count} buffers of ${this.memoryPools.large.size} bytes`);
      
      // Create memory pool initialization file
      const poolFilePath = path.join(this.anchorHome, 'tools', 'memory-pool-init.js');
      const poolContent = this._generateMemoryPoolCode();
      fs.writeFileSync(poolFilePath, poolContent);
      console.log(`\n✅ Memory pool initialization code created at: ${poolFilePath}`);
    }
    
    // Check for Metal Performance Shaders (MPS) support
    let hasMetal = false;
    try {
      // This command will fail if Metal is not available
      execSync('system_profiler SPDisplaysDataType | grep Metal');
      console.log('\n✅ Metal Performance Shaders support detected');
      console.log('• JavaScript operations that can use GPU acceleration will be offloaded');
      console.log('• Tensor operations optimized for Neural Engine');
      hasMetal = true;
      
      if (this.options.useMetalIfAvailable) {
        // Create Metal acceleration initialization file
        const metalFilePath = path.join(this.anchorHome, 'tools', 'metal-accelerator.js');
        const metalContent = this._generateMetalAcceleratorCode();
        fs.writeFileSync(metalFilePath, metalContent);
        console.log(`\n✅ Metal acceleration code created at: ${metalFilePath}`);
      }
    } catch (e) {
      console.log('\n⚠️ Metal Performance Shaders not detected - using CPU only mode');
    }
    
    // Create a unified launcher script
    const launcherContent = this._generateUnifiedLauncherScript();
    const launcherPath = path.join(this.anchorHome, 'admin', 'unified-launcher.sh');
    fs.writeFileSync(launcherPath, launcherContent);
    fs.chmodSync(launcherPath, 0o755); // Make executable
    console.log(`\n✅ Created unified launcher script at: ${launcherPath}`);
    
    // Create a unified CLI script
    const cliContent = this._generateCliScript();
    const cliPath = path.join(this.anchorHome, 'admin', 'cnif-cli.sh');
    fs.writeFileSync(cliPath, cliContent);
    fs.chmodSync(cliPath, 0o755); // Make executable
    console.log(`\n✅ Created unified CLI script at: ${cliPath}`);
    
    // Create a convenience symlink in the root directory
    const symLinkPath = path.join(this.anchorHome, 'cnif');
    try {
      if (fs.existsSync(symLinkPath)) {
        fs.unlinkSync(symLinkPath);
      }
      fs.symlinkSync(cliPath, symLinkPath);
      fs.chmodSync(symLinkPath, 0o755); // Make executable
      console.log(`\n✅ Created convenience symlink at: ${symLinkPath}`);
    } catch (err) {
      console.error(`❌ Failed to create symlink: ${err.message}`);
    }
    
    return {
      nodeOptions: this.generateNodeOptions(),
      threadPoolSize: this.options.threadPoolSize,
      hasMetal,
      envPath,
      launcherPath,
      cliPath
    };
  }
  
  /**
   * Generate a unified launcher script
   * @returns {string} - Launcher script content
   * @private
   */
  _generateUnifiedLauncherScript() {
    return `#!/bin/bash
# unified-launcher.sh - M3 Max optimized launcher for Claude-Notion Integration Framework
# © 2025 XPV - MIT
#
# Unified launcher script for CNIF that combines features from:
# - launch-optimized.sh
# - launch-mcp-servers.sh
# - anchor-system-optimizer.sh

set -e

# Define colors for output
GREEN='\\033[0;32m'
YELLOW='\\033[1;33m'
RED='\\033[0;31m'
NC='\\033[0m' # No Color
BLUE='\\033[0;34m'

# Base paths from environment or defaults
ANCHOR_HOME="\${ANCHOR_HOME:-/Users/XPV/Desktop/anchor-core}"
LOG_DIR="\${LOG_DIR:-\$HOME/Library/Logs/Claude}"
SOCKET_DIR="\${SOCKET_DIR:-\$ANCHOR_HOME/sockets}"
COHERENCE_LOCK_DIR="\${COHERENCE_LOCK_DIR:-\$ANCHOR_HOME/coherence_lock}"
CONFIG_DIR="\${CONFIG_DIR:-\$ANCHOR_HOME/config}"
MCP_DIR="\${MCP_DIR:-\$ANCHOR_HOME/mcp-servers}"
PID_DIR="\${PID_DIR:-\$MCP_DIR}"

# Load optimized environment if available
if [ -f "\$ANCHOR_HOME/.env" ]; then
  echo -e "\${BLUE}Loading optimized environment...\${NC}"
  source "\$ANCHOR_HOME/.env"
else
  # Run optimizer to generate env file
  echo -e "\${YELLOW}No .env file found, running optimizer...\${NC}"
  node "\$ANCHOR_HOME/tools/unified-m3-optimizer.js"
  source "\$ANCHOR_HOME/.env"
fi

# Initialize directories
echo -e "\${BLUE}Creating required directories...\${NC}"
mkdir -p "\$LOG_DIR"
mkdir -p "\$SOCKET_DIR"
mkdir -p "\$COHERENCE_LOCK_DIR"
mkdir -p "\$CONFIG_DIR"

# Create a default Notion config if missing
if [ ! -f "\$CONFIG_DIR/notion-config.json" ]; then
  echo -e "\${YELLOW}Creating default Notion config...\${NC}"
  echo '{
    "rootPageId": "",
    "enabledDatabases": [],
    "syncInterval": 30000,
    "rateLimitPerSecond": 3
  }' > "\$CONFIG_DIR/notion-config.json"
fi

# Define server configurations - using array format for compatibility
SERVER_NAMES=("socket-server" "schema-registry" "streaming-transformer" "notion" "mcp-orchestrator")
SERVER_SCRIPTS=("\$MCP_DIR/socket-server-implementation.cjs" "\$MCP_DIR/schema-registry.cjs" "\$MCP_DIR/streaming-schema-transformer.cjs" "\$MCP_DIR/notion-connection-manager.cjs" "\$MCP_DIR/mcp-orchestrator.cjs")

# Function to get script path by server name
get_server_script() {
  local server_name=\$1
  local index=0
  for name in "\${SERVER_NAMES[@]}"; do
    if [ "\$name" = "\$server_name" ]; then
      echo "\${SERVER_SCRIPTS[\$index]}"
      return 0
    fi
    index=\$((index + 1))
  done
  echo ""
}

# Clean up function
cleanup() {
  echo -e "\${YELLOW}Shutting down all servers...\${NC}"
  
  # Kill all running servers
  for server in "\${SERVER_NAMES[@]}"; do
    if [ -f "\$PID_DIR/\$server.pid" ]; then
      pid=\$(cat "\$PID_DIR/\$server.pid")
      if ps -p "\$pid" > /dev/null; then
        echo -e "\${YELLOW}Stopping \$server (PID: \$pid)...\${NC}"
        kill -15 "\$pid" || true
      else
        echo -e "\${YELLOW}Process \$server (PID: \$pid) not running\${NC}"
      fi
    fi
  done
  
  # Remove socket files
  echo -e "\${YELLOW}Removing socket files...\${NC}"
  rm -f "\$SOCKET_DIR"/*.sock
  
  # Remove coherence markers
  echo -e "\${YELLOW}Removing coherence markers...\${NC}"
  rm -f "\$COHERENCE_LOCK_DIR"/*.marker
  
  echo -e "\${GREEN}Cleanup complete\${NC}"
}

# Set trap for clean shutdown
trap cleanup EXIT INT TERM

# Stop any existing servers
echo -e "\${BLUE}Stopping any existing servers...\${NC}"
cleanup

# Initialize memory pools if enabled
if [ "\$M3_MEMORY_POOLING" = "true" ] && [ -f "\$TOOLS_DIR/memory-pool-init.js" ]; then
  echo -e "\${BLUE}Initializing memory pools for M3 Max...\${NC}"
  node --expose-gc --require "\$TOOLS_DIR/memory-pool-init.js" -e "console.log('✅ Memory pools ready');"
fi

# Initialize Metal accelerator if available
if [ "\$M3_METAL_ACCELERATION" = "true" ] && [ -f "\$TOOLS_DIR/metal-accelerator.js" ]; then
  echo -e "\${BLUE}Initializing Metal accelerator for M3 Max...\${NC}"
  node --expose-gc --require "\$TOOLS_DIR/metal-accelerator.js" -e "console.log('✅ Metal acceleration ready');"
fi

# Check if pm2 is available
USE_PM2=false
if command -v pm2 > /dev/null; then
  USE_PM2=true
  echo -e "\${BLUE}PM2 detected - using for process management\${NC}"
fi

# Start each server based on selected method
if [ "\$USE_PM2" = true ]; then
  # Use PM2 for better process management
  echo -e "\${BLUE}Starting services with PM2...\${NC}"
  
  # Generate PM2 ecosystem file
  echo '{
    "apps": [' > "\$ANCHOR_HOME/ecosystem.config.js"
  
  first=true
  for server in "\${SERVER_NAMES[@]}"; do
    if [ "\$first" = true ]; then
      first=false
    else
      echo ',' >> "\$ANCHOR_HOME/ecosystem.config.js"
    fi
    
    script=\$(get_server_script "\$server")
    echo "      {
        \\"name\\": \\"\$server\\",
        \\"script\\": \\"\$script\\",
        \\"env\\": {
          \\"NODE_OPTIONS\\": \\"\$NODE_OPTIONS\\",
          \\"UV_THREADPOOL_SIZE\\": \$UV_THREADPOOL_SIZE,
          \\"MCP_SERVER_NAME\\": \\"\$server\\",
          \\"ANCHOR_HOME\\": \\"\$ANCHOR_HOME\\",
          \\"LOG_DIR\\": \\"\$LOG_DIR\\",
          \\"SOCKET_DIR\\": \\"\$SOCKET_DIR\\"
        },
        \\"log_date_format\\": \\"YYYY-MM-DD HH:mm:ss Z\\",
        \\"out_file\\": \\"\$LOG_DIR/\$server.log\\",
        \\"error_file\\": \\"\$LOG_DIR/\$server.log\\",
        \\"merge_logs\\": true,
        \\"watch\\": false,
        \\"instances\\": 1,
        \\"exec_mode\\": \\"fork\\"
      }" >> "\$ANCHOR_HOME/ecosystem.config.js"
  done
  
  echo '
    ]
  }' >> "\$ANCHOR_HOME/ecosystem.config.js"
  
  # Start all services with PM2
  pm2 start "\$ANCHOR_HOME/ecosystem.config.js"
  
  echo -e "\${GREEN}All services started with PM2. View logs with:\${NC}"
  echo -e "  pm2 logs"
  echo -e "\${GREEN}View dashboard with:\${NC}"
  echo -e "  pm2 monit"
else
  # Start each server
  echo -e "\${BLUE}Starting services...\${NC}"
  
  # Start the servers in the correct order
  ordered_servers=("schema-registry" "streaming-transformer" "socket-server" "notion" "mcp-orchestrator")
  
  for server in "\${ordered_servers[@]}"; do
    script=\$(get_server_script "\$server")
    if [ -z "\$script" ]; then
      echo -e "\${RED}Error: Script not found for \$server\${NC}"
      continue
    fi
    
    echo -e "\${BLUE}Starting \$server...\${NC}"
    # Set environment variables for this server
    export MCP_SERVER_NAME="\$server"
    
    # Start the server with node --expose-gc directly
    node --expose-gc "\$script" > "\$LOG_DIR/\$server.log" 2>&1 &
    pid=\$!
    
    # Verify process actually started
    if ! ps -p "\$pid" > /dev/null; then
      echo -e "\${RED}ERROR: Process for \$server failed to start!\${NC}"
      continue
    fi
    
    # Save PID
    echo "\$pid" > "\$PID_DIR/\$server.pid"
    
    echo -e "\${GREEN}Started \$server (PID: \$pid)\${NC}"
    
    # Add a slight delay to ensure logging is initialized before checking
    sleep 0.5
    
    # Check if process is still running and log is created
    if ps -p "\$pid" > /dev/null; then
      if [ -f "\$LOG_DIR/\$server.log" ]; then
        # Check log for immediate errors
        if grep -q "Error" "\$LOG_DIR/\$server.log" || grep -q "error" "\$LOG_DIR/\$server.log"; then
          echo -e "\${RED}WARNING: Errors detected in log for \$server. See \$LOG_DIR/\$server.log\${NC}"
          cat "\$LOG_DIR/\$server.log" | head -n 10
        fi
      else
        echo -e "\${YELLOW}WARNING: Log file not created for \$server\${NC}"
      fi
    else
      echo -e "\${RED}ERROR: Process for \$server died immediately after starting!\${NC}"
    fi
    
    # Wait a second to stagger startups
    sleep 1
  done
fi

# Wait for all servers to initialize
echo -e "\${BLUE}Waiting for services to initialize...\${NC}"
sleep 3

# Check health
echo -e "\${BLUE}Checking service health...\${NC}"
failed=false

for server in "\${SERVER_NAMES[@]}"; do
  if [ -f "\$PID_DIR/\$server.pid" ]; then
    pid=\$(cat "\$PID_DIR/\$server.pid")
    if ps -p "\$pid" > /dev/null; then
      echo -e "\${GREEN}✅ \$server is running (PID: \$pid)\${NC}"
    else
      echo -e "\${RED}❌ \$server failed to start\${NC}"
      failed=true
    fi
  else
    echo -e "\${RED}❌ No PID file for \$server\${NC}"
    failed=true
  fi
  
  # Check socket file for socket servers
  if [ "\$server" = "socket-server" ]; then
    if [ -e "\$SOCKET_DIR/\$server.sock" ]; then
      echo -e "\${GREEN}✅ Socket file exists for \$server\${NC}"
    else
      echo -e "\${RED}❌ Socket file missing for \$server\${NC}"
      failed=true
    fi
  fi
done

# Check coherence markers
echo -e "\${BLUE}Checking coherence markers...\${NC}"
markers=\$(ls -1 "\$COHERENCE_LOCK_DIR"/*.marker 2>/dev/null | wc -l)
if [ "\$markers" -gt 0 ]; then
  echo -e "\${GREEN}✅ Found \$markers coherence markers\${NC}"
else
  echo -e "\${RED}❌ No coherence markers found\${NC}"
  failed=true
fi

if [ "\$failed" = true ]; then
  echo -e "\${RED}❌ Some services failed to start properly\${NC}"
  echo -e "\${YELLOW}Check logs in \$LOG_DIR for details\${NC}"
  exit 1
else
  echo -e "\${GREEN}✅ All services started successfully\${NC}"
  echo -e "\${BLUE}CNIF is running with M3 Max optimizations\${NC}"
  echo -e "\${BLUE}Logs available in \$LOG_DIR\${NC}"
  echo -e "\${BLUE}Socket files in \$SOCKET_DIR\${NC}"
  
  # Launch dashboard if available
  if [ -f "\$ANCHOR_HOME/dashboard/server.js" ]; then
    echo -e "\${BLUE}Starting dashboard on http://localhost:8765\${NC}"
    node "\$ANCHOR_HOME/dashboard/server.js" > "\$LOG_DIR/dashboard.log" 2>&1 &
    echo "\$!" > "\$PID_DIR/dashboard.pid"
    echo -e "\${GREEN}✅ Dashboard started\${NC}"
  fi
fi

# Keep script running to maintain trap handlers
echo -e "\${GREEN}Press Ctrl+C to stop all services\${NC}"
wait
`;
  }
  
  /**
   * Generate a unified CLI script
   * @returns {string} - CLI script content
   * @private
   */
  _generateCliScript() {
    return `#!/bin/bash
# cnif-cli.sh - Unified CLI for Claude-Notion Integration Framework
# © 2025 XPV - MIT

# Define colors for output
GREEN='\\033[0;32m'
YELLOW='\\033[1;33m'
RED='\\033[0;31m'
NC='\\033[0m' # No Color
BLUE='\\033[0;34m'
CYAN='\\033[0;36m'
BOLD='\\033[1m'

# Base paths
ANCHOR_HOME="\${ANCHOR_HOME:-/Users/XPV/Desktop/anchor-core}"
ADMIN_DIR="\${ADMIN_DIR:-\$ANCHOR_HOME/admin}"
TOOLS_DIR="\${TOOLS_DIR:-\$ANCHOR_HOME/tools}"

# Load .env file if available
if [ -f "\$ANCHOR_HOME/.env" ]; then
  source "\$ANCHOR_HOME/.env"
fi

# CLI Version
VERSION="1.0.0"

# Function to display help
show_help() {
  echo -e "\${BOLD}CNIF CLI v\${VERSION}\${NC} - Unified CLI for Claude-Notion Integration Framework"
  echo
  echo -e "Usage: \${BOLD}\$(basename \$0) [command] [options]\${NC}"
  echo
  echo -e "\${BOLD}Commands:\${NC}"
  echo -e "  \${CYAN}start\${NC}           Start all CNIF services"
  echo -e "  \${CYAN}stop\${NC}            Stop all CNIF services"
  echo -e "  \${CYAN}restart\${NC}         Restart all CNIF services"
  echo -e "  \${CYAN}status\${NC}          Show status of all CNIF services"
  echo -e "  \${CYAN}logs\${NC} [service]  Show logs for a specific service or all services"
  echo -e "  \${CYAN}optimize\${NC}        Run M3 optimizer to tune system for best performance"
  echo -e "  \${CYAN}clean\${NC}           Clean up stale PID files and socket files"
  echo -e "  \${CYAN}dashboard\${NC}       Start the web dashboard"
  echo -e "  \${CYAN}help\${NC}            Show this help message"
  echo -e "  \${CYAN}version\${NC}         Show version information"
  echo
  echo -e "\${BOLD}Available services:\${NC}"
  echo -e "  socket-server, schema-registry, streaming-transformer, notion, mcp-orchestrator"
  echo
  echo -e "\${BOLD}Examples:\${NC}"
  echo -e "  \$(basename \$0) start        # Start all services"
  echo -e "  \$(basename \$0) logs notion  # Show logs for Notion service"
  echo -e "  \$(basename \$0) optimize     # Run M3 optimizer"
  echo
}

# Function to start services
start_services() {
  echo -e "\${BLUE}Starting CNIF services...\${NC}"
  "\$ADMIN_DIR/unified-launcher.sh"
}

# Function to stop services
stop_services() {
  echo -e "\${BLUE}Stopping CNIF services...\${NC}"
  
  # Get the PIDs of all running services
  PIDs=""
  
  # Core services
  for pidfile in "\$MCP_DIR"/*.pid; do
    if [ -f "\$pidfile" ]; then
      pid=\$(cat "\$pidfile")
      if ps -p "\$pid" > /dev/null; then
        PIDs="\$PIDs \$pid"
      fi
    fi
  done
  
  # Dashboard
  if [ -f "\$ANCHOR_HOME/dashboard.pid" ]; then
    pid=\$(cat "\$ANCHOR_HOME/dashboard.pid")
    if ps -p "\$pid" > /dev/null; then
      PIDs="\$PIDs \$pid"
    fi
  fi
  
  # Send SIGTERM to all PIDs
  if [ -n "\$PIDs" ]; then
    echo -e "\${BLUE}Stopping processes: \$PIDs\${NC}"
    kill -15 \$PIDs 2>/dev/null || true
    
    # Wait a bit for processes to terminate
    sleep 2
    
    # Force kill if still running
    for pid in \$PIDs; do
      if ps -p "\$pid" > /dev/null; then
        echo -e "\${YELLOW}Process \$pid still running, sending SIGKILL...\${NC}"
        kill -9 "\$pid" 2>/dev/null || true
      fi
    done
  else
    echo -e "\${YELLOW}No running services found\${NC}"
  fi
  
  # Clean up PID files
  rm -f "\$MCP_DIR"/*.pid "\$ANCHOR_HOME/dashboard.pid" 2>/dev/null || true
  
  # Clean up socket files
  rm -f "\$SOCKET_DIR"/*.sock 2>/dev/null || true
  
  echo -e "\${GREEN}All services stopped\${NC}"
}

# Function to restart services
restart_services() {
  echo -e "\${BLUE}Restarting CNIF services...\${NC}"
  stop_services
  sleep 2
  start_services
}

# Function to show service status
show_status() {
  echo -e "\${BLUE}CNIF Services Status:\${NC}"
  
  running_count=0
  stopped_count=0
  
  # Check core services
  services=("socket-server" "schema-registry" "streaming-transformer" "notion" "mcp-orchestrator")
  
  for service in "\${services[@]}"; do
    pidfile="\$MCP_DIR/\$service.pid"
    if [ -f "\$pidfile" ]; then
      pid=\$(cat "\$pidfile")
      if ps -p "\$pid" > /dev/null; then
        echo -e "\${GREEN}✅ \$service is running (PID: \$pid)\${NC}"
        running_count=\$((running_count + 1))
      else
        echo -e "\${RED}❌ \$service is not running (stale PID file: \$pid)\${NC}"
        stopped_count=\$((stopped_count + 1))
      fi
    else
      echo -e "\${RED}❌ \$service is not running (no PID file)\${NC}"
      stopped_count=\$((stopped_count + 1))
    fi
    
    # Check socket file for socket-server
    if [ "\$service" = "socket-server" ]; then
      if [ -e "\$SOCKET_DIR/\$service.sock" ]; then
        echo -e "  \${GREEN}↳ Socket file exists for \$service\${NC}"
      else
        echo -e "  \${RED}↳ Socket file missing for \$service\${NC}"
      fi
    fi
  done
  
  # Check dashboard
  if [ -f "\$ANCHOR_HOME/dashboard.pid" ]; then
    pid=\$(cat "\$ANCHOR_HOME/dashboard.pid")
    if ps -p "\$pid" > /dev/null; then
      echo -e "\${GREEN}✅ Dashboard is running (PID: \$pid)\${NC}"
      running_count=\$((running_count + 1))
    else
      echo -e "\${RED}❌ Dashboard is not running (stale PID file: \$pid)\${NC}"
      stopped_count=\$((stopped_count + 1))
    fi
  else
    echo -e "\${RED}❌ Dashboard is not running (no PID file)\${NC}"
    stopped_count=\$((stopped_count + 1))
  }
  
  # Summary
  echo
  echo -e "\${BLUE}Summary: \${GREEN}\$running_count running\${NC}, \${RED}\$stopped_count stopped\${NC}"
  
  # System information
  echo
  echo -e "\${BLUE}System Information:\${NC}"
  echo -e "• Memory: \$(vm_stat | grep 'Pages free' | awk '{print \$3}' | tr -d '.') free pages"
  echo -e "• CPU Load: \$(sysctl -n hw.ncpu) cores, load avg: \$(uptime | awk -F'load averages:' '{print \$2}')"
  if [ -f "\$ANCHOR_HOME/.env" ]; then
    echo -e "• Environment: \${GREEN}Optimized\${NC}"
  else
    echo -e "• Environment: \${YELLOW}Not optimized\${NC}"
  fi
}

# Function to show service logs
show_logs() {
  service="\$1"
  
  if [ -z "\$service" ]; then
    echo -e "\${YELLOW}No service specified, showing all logs\${NC}"
    tail -n 20 "\$LOG_DIR"/*.log
  else
    logfile="\$LOG_DIR/\$service.log"
    if [ -f "\$logfile" ]; then
      echo -e "\${BLUE}Showing logs for \$service\${NC}"
      tail -n 50 "\$logfile"
    else
      echo -e "\${RED}No log file found for \$service\${NC}"
      echo -e "\${YELLOW}Available logs:\${NC}"
      ls -1 "\$LOG_DIR"/*.log
    fi
  fi
}

# Function to run optimizer
run_optimizer() {
  echo -e "\${BLUE}Running M3 optimizer...\${NC}"
  node "\$TOOLS_DIR/unified-m3-optimizer.js"
}

# Function to clean up stale files
clean_up() {
  echo -e "\${BLUE}Cleaning up stale files...\${NC}"
  
  # Stop any running services first
  stop_services
  
  # Clean up PID files
  echo -e "\${YELLOW}Removing PID files...\${NC}"
  rm -f "\$MCP_DIR"/*.pid "\$ANCHOR_HOME/dashboard.pid" 2>/dev/null || true
  
  # Clean up socket files
  echo -e "\${YELLOW}Removing socket files...\${NC}"
  rm -f "\$SOCKET_DIR"/*.sock 2>/dev/null || true
  
  # Clean up coherence markers
  echo -e "\${YELLOW}Removing coherence markers...\${NC}"
  rm -f "\$ANCHOR_HOME/coherence_lock"/*.marker 2>/dev/null || true
  
  echo -e "\${GREEN}Cleanup complete\${NC}"
}

# Function to start dashboard
start_dashboard() {
  echo -e "\${BLUE}Starting CNIF dashboard...\${NC}"
  
  # Check if dashboard is already running
  if [ -f "\$ANCHOR_HOME/dashboard.pid" ]; then
    pid=\$(cat "\$ANCHOR_HOME/dashboard.pid")
    if ps -p "\$pid" > /dev/null; then
      echo -e "\${YELLOW}Dashboard is already running (PID: \$pid)\${NC}"
      echo -e "\${BLUE}Visit: http://localhost:8765\${NC}"
      return
    fi
  fi
  
  # Start dashboard
  if [ -f "\$ANCHOR_HOME/dashboard/server.js" ]; then
    node "\$ANCHOR_HOME/dashboard/server.js" > "\$LOG_DIR/dashboard.log" 2>&1 &
    pid=\$!
    echo "\$pid" > "\$ANCHOR_HOME/dashboard.pid"
    echo -e "\${GREEN}Dashboard started (PID: \$pid)\${NC}"
    echo -e "\${BLUE}Visit: http://localhost:8765\${NC}"
  else
    echo -e "\${RED}Dashboard server not found\${NC}"
  fi
}

# Function to show version info
show_version() {
  echo -e "\${BOLD}CNIF CLI v\${VERSION}\${NC}"
  echo -e "Claude-Notion Integration Framework"
  echo -e "© 2025 XPV - MIT"
  echo
  echo -e "System Paths:"
  echo -e "• ANCHOR_HOME: \$ANCHOR_HOME"
  echo -e "• MCP_DIR: \$MCP_DIR"
  echo -e "• SOCKET_DIR: \$SOCKET_DIR"
  echo -e "• LOG_DIR: \$LOG_DIR"
  echo
  echo -e "Environment:"
  if [ -f "\$ANCHOR_HOME/.env" ]; then
    echo -e "• Status: \${GREEN}Optimized\${NC}"
    echo -e "• NODE_OPTIONS: \$NODE_OPTIONS"
    echo -e "• UV_THREADPOOL_SIZE: \$UV_THREADPOOL_SIZE"
  else
    echo -e "• Status: \${YELLOW}Not optimized\${NC}"
  fi
}

# Main command handler
if [ \$# -eq 0 ]; then
  show_help
  exit 0
fi

command="\$1"
shift

case "\$command" in
  start)
    start_services
    ;;
  stop)
    stop_services
    ;;
  restart)
    restart_services
    ;;
  status)
    show_status
    ;;
  logs)
    show_logs "\$1"
    ;;
  optimize)
    run_optimizer
    ;;
  clean)
    clean_up
    ;;
  dashboard)
    start_dashboard
    ;;
  help)
    show_help
    ;;
  version)
    show_version
    ;;
  *)
    echo -e "\${RED}Unknown command: \$command\${NC}"
    show_help
    exit 1
    ;;
esac

exit 0
`;
  }
}

// If run directly, apply optimizations
if (require.main === module) {
  const optimizer = new UnifiedM3Optimizer();
  const results = optimizer.applyOptimizations();
  
  console.log('\n🎉 Unified M3 Max optimization complete!');
  console.log(`\nTo launch optimized servers, run:\n  ${results.launcherPath}`);
  console.log(`\nTo use the CLI tool, run:\n  ${results.cliPath} [command]`);
}

module.exports = UnifiedM3Optimizer;
