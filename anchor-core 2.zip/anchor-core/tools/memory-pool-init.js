/**
 * memory-pool-init.js - Memory pooling for M3 Max
 * © 2025 XPV - MIT
 * 
 * Initializes memory pools for different buffer sizes
 * to reduce garbage collection pressure
 */

class MemoryPool {
  constructor(bufferSize, poolSize) {
    this.bufferSize = bufferSize;
    this.maxSize = poolSize;
    this.pool = [];
    
    // Pre-allocate buffers - but limit initial size to avoid memory pressure
    const initialSize = Math.min(poolSize, 10); // Start with at most 10 buffers
    for (let i = 0; i < initialSize; i++) {
      this.pool.push(Buffer.allocUnsafe(bufferSize));
    }
    
    this.stats = {
      allocations: 0,
      releases: 0,
      misses: 0,
      highWaterMark: initialSize
    };
    
    console.log(`Created memory pool: ${bufferSize} bytes x ${initialSize} buffers (max: ${poolSize})`);
  }
  
  allocate() {
    this.stats.allocations++;
    
    if (this.pool.length === 0) {
      this.stats.misses++;
      return Buffer.allocUnsafe(this.bufferSize);
    }
    
    return this.pool.pop();
  }
  
  release(buffer) {
    this.stats.releases++;
    
    // Only return to pool if it's the right size and pool isn't full
    if (buffer.length === this.bufferSize && this.pool.length < this.maxSize) {
      this.pool.push(buffer);
      this.stats.highWaterMark = Math.max(this.stats.highWaterMark, this.pool.length);
    }
  }
  
  getStats() {
    return {
      ...this.stats,
      bufferSize: this.bufferSize,
      poolSize: this.maxSize,
      currentSize: this.pool.length
    };
  }
}

// Create global memory pools with more modest sizing
global.memoryPools = {
  small: new MemoryPool(4096, 100),     // Reduced from 1000
  medium: new MemoryPool(65536, 20),    // Reduced from 100
  large: new MemoryPool(1048576, 5)     // Reduced from 10
};

// Utility function to get appropriate buffer
global.getPooledBuffer = function(size) {
  if (size <= 4096) {
    return global.memoryPools.small.allocate();
  } else if (size <= 65536) {
    return global.memoryPools.medium.allocate();
  } else if (size <= 1048576) {
    return global.memoryPools.large.allocate();
  } else {
    return Buffer.allocUnsafe(size);
  }
};

// Utility function to release buffer back to pool
global.releasePooledBuffer = function(buffer) {
  const size = buffer.length;
  
  if (size <= 4096) {
    global.memoryPools.small.release(buffer);
  } else if (size <= 65536) {
    global.memoryPools.medium.release(buffer);
  } else if (size <= 1048576) {
    global.memoryPools.large.release(buffer);
  }
};

// Get memory pool statistics
global.getMemoryPoolStats = function() {
  return {
    small: global.memoryPools.small.getStats(),
    medium: global.memoryPools.medium.getStats(),
    large: global.memoryPools.large.getStats()
  };
};

// Add GC watchdog (only if run with --expose-gc)
if (global.gc) {
  console.log('✅ GC watchdog enabled');
  
  // Run GC once at startup to clean up initialization memory
  global.gc();
  
  // Set up a simple watchdog with a higher threshold and less logging
  const watchdogInterval = setInterval(() => {
    const mem = process.memoryUsage();
    const ratio = mem.heapUsed / mem.heapTotal;
    
    // Only run GC if memory usage is very high (85%)
    if (ratio > 0.85) {
      global.gc();
    }
  }, 60000); // Check less frequently (once per minute)
  
  // Ensure the interval doesn't keep the process alive
  watchdogInterval.unref();
}

console.log('✅ Memory pools ready');
