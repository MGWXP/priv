#!/bin/bash
# enhanced-quick-fix.sh - Fix the NODE_OPTIONS invalid flag issues
# © 2025 XPV - MIT

set -e  # Exit on error

echo "🔧 Applying advanced fixes to server configuration..."

# Define core paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
MCP_DIR="${ANCHOR_HOME}/mcp-servers"
SCRIPTS_DIR="${ANCHOR_HOME}/scripts"
LOG_DIR="${HOME}/Library/Logs/Claude"
SOCKET_DIR="${ANCHOR_HOME}/sockets"

# Create required directories
mkdir -p "${LOG_DIR}"
mkdir -p "${SOCKET_DIR}"
mkdir -p "${SCRIPTS_DIR}"

# Check and fix NODE_OPTIONS in environment
if [[ $NODE_OPTIONS == *"--initial-old-space-size"* ]]; then
  echo "⚠️ Detected invalid --initial-old-space-size flag in NODE_OPTIONS"
  export NODE_OPTIONS="--max-old-space-size=16384"
  echo "✅ Set NODE_OPTIONS to: ${NODE_OPTIONS}"
fi

# Fix .env file
cat > "${ANCHOR_HOME}/.env" << 'EOL'
# M3 Max Optimized Settings
# Generated: 2025-05-18T16:45:00.000Z
# For: 48GB M3 Max

# Node.js Memory Settings
# Note: Using only valid NODE_OPTIONS flags
export NODE_OPTIONS="--max-old-space-size=16384"

# Thread Pool Configuration
export UV_THREADPOOL_SIZE=12

# Environment Variables
export ANCHOR_HOME=/Users/XPV/Desktop/anchor-core
export MCP_DIR=/Users/XPV/Desktop/anchor-core/mcp-servers
export SOCKET_DIR=/Users/XPV/Desktop/anchor-core/sockets

# System paths
export LOG_DIR=/Users/XPV/Library/Logs/Claude
export CONFIG_DIR=/Users/XPV/Library/Application\ Support/Claude

# M3 Specific Settings
export M3_OPTIMIZED=true
export M3_MEMORY_ALLOCATION=28GB
export M3_CORE_COUNT=16
EOL

# Fix launch-optimized.sh
cat > "${ANCHOR_HOME}/launch-optimized.sh" << 'EOL'
#!/bin/bash
# M3 Max Optimized Launch Script
# Fixed version - 2025-05-18

set -e

# Load optimized environment if it exists
if [ -f "/Users/XPV/Desktop/anchor-core/.env" ]; then
  source /Users/XPV/Desktop/anchor-core/.env
fi

# Set up environment variables with proper NODE_OPTIONS (no invalid flags)
export NODE_OPTIONS="--max-old-space-size=16384"
export UV_THREADPOOL_SIZE=12
export ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
export MCP_DIR="${ANCHOR_HOME}/mcp-servers"
export SOCKET_DIR="${ANCHOR_HOME}/sockets"
export LOG_DIR="${HOME}/Library/Logs/Claude"

# Start all servers with optimized settings
echo "🚀 Starting M3 Max optimized servers..."

# Make sure required directories exist
mkdir -p "${LOG_DIR}"
mkdir -p "${SOCKET_DIR}"

# Terminate any existing servers
pkill -f "git-local-optimized.js" 2>/dev/null || true
pkill -f "notion-v5-wrapper.js" 2>/dev/null || true
pkill -f "anchor-manager-optimized.js" 2>/dev/null || true
sleep 1

# Clean up PID files
rm -f "${MCP_DIR}"/*.pid 2>/dev/null || true

# Start Git Local
echo "Starting Git Local server..."
SOCKET_DIR="${SOCKET_DIR}" MCP_SERVER_NAME="git-local" \
  node "${MCP_DIR}/git-local-optimized.js" > "${LOG_DIR}/mcp-server-git-local.log" 2>&1 &
echo $! > "${MCP_DIR}/git-local.pid"

# Start Notion
echo "Starting Notion server..."
SOCKET_DIR="${SOCKET_DIR}" MCP_SERVER_NAME="notion" \
  node "${MCP_DIR}/notion-v5-wrapper.js" > "${LOG_DIR}/mcp-server-notion.log" 2>&1 &
echo $! > "${MCP_DIR}/notion.pid"

# Start Anchor Manager
echo "Starting Anchor Manager server..."
SOCKET_DIR="${SOCKET_DIR}" MCP_SERVER_NAME="anchor-manager" \
  node "${MCP_DIR}/anchor-manager-optimized.js" > "${LOG_DIR}/mcp-server-anchor-manager.log" 2>&1 &
echo $! > "${MCP_DIR}/anchor-manager.pid"

echo "✅ All servers started with M3 Max optimizations"
echo "🖥 Launch Claude to connect to optimized servers"
EOL

# Fix git-local-optimized.js to explicitly set NODE_OPTIONS correctly
sed -i.bak 's/process.env.NODE_OPTIONS      ||= .*$/process.env.NODE_OPTIONS = "--max-old-space-size=8192";/' "${MCP_DIR}/git-local-optimized.js"

# Fix notion-v5-wrapper.js to explicitly set NODE_OPTIONS correctly
sed -i.bak 's/process.env.NODE_OPTIONS      ||= .*$/process.env.NODE_OPTIONS = "--max-old-space-size=8192";/' "${MCP_DIR}/notion-v5-wrapper.js"

# Fix anchor-manager-optimized.js to explicitly set NODE_OPTIONS correctly
sed -i.bak 's/process.env.NODE_OPTIONS      ||= .*$/process.env.NODE_OPTIONS = "--max-old-space-size=8192";/' "${MCP_DIR}/anchor-manager-optimized.js"

# Create a success marker
echo "MCP SERVER CONFIGURATION FIXED - $(date)" > "${ANCHOR_HOME}/FIXED_SUCCESS_20250518.marker"

# Make sure all scripts are executable
chmod +x "${ANCHOR_HOME}"/*.sh
chmod +x "${MCP_DIR}"/*.sh
chmod +x "${MCP_DIR}"/*.js
chmod +x "${SCRIPTS_DIR}"/*.sh 2>/dev/null || true

echo "✅ All invalid NODE_OPTIONS flags have been removed!"
echo 
echo "To restart servers with fixed configuration, run:"
echo "  ${ANCHOR_HOME}/restart-all.sh"
echo
echo "Or use the optimized launcher:"
echo "  ${ANCHOR_HOME}/launch-optimized.sh"
echo
echo "Then verify with:"
echo "  ${MCP_DIR}/verify-servers.sh"
