#!/bin/bash
# fix-socket-permissions.sh - Fix socket file permissions for CNIF
# © 2025 XPV - MIT
#
# This script fixes permissions on socket files to ensure proper connectivity
# between Claude and Notion components.

# Environment setup
SOCKET_DIR="/Users/XPV/Desktop/anchor-core/sockets"
LOG_DIR="${HOME}/Library/Logs/Claude"
TIMESTAMP=$(date +"%Y%m%d%H%M%S")
LOG_FILE="${LOG_DIR}/socket-permissions-fix-${TIMESTAMP}.log"
COHERENCE_LOCK_DIR="/Users/XPV/Desktop/anchor-core/coherence_lock"

# Ensure log directory exists
mkdir -p "${LOG_DIR}"

# Log function
log() {
  local level="$1"
  local message="$2"
  echo "$(date +"%Y-%m-%d %H:%M:%S") [${level}] ${message}" | tee -a "${LOG_FILE}"
}

# Create socket directory if needed
log "INFO" "🔧 Starting socket permissions fix script"

if [ ! -d "${SOCKET_DIR}" ]; then
  log "INFO" "📁 Creating socket directory: ${SOCKET_DIR}"
  mkdir -p "${SOCKET_DIR}"
  if [ $? -ne 0 ]; then
    log "ERROR" "❌ Failed to create socket directory"
    exit 1
  fi
  log "INFO" "✅ Socket directory created successfully"
fi

# Fix permissions on the socket directory
log "INFO" "🔧 Setting permissions on socket directory (0755)"
chmod 0755 "${SOCKET_DIR}"
if [ $? -ne 0 ]; then
  log "ERROR" "❌ Failed to set permissions on socket directory"
else
  log "INFO" "✅ Socket directory permissions set successfully"
fi

# Check for existing socket files
SOCKET_FILES=$(ls -1 "${SOCKET_DIR}"/*.sock 2>/dev/null)
SOCKET_COUNT=$(echo "${SOCKET_FILES}" | grep -v "^$" | wc -l)

log "INFO" "📊 Found ${SOCKET_COUNT} socket files"

# Fix permissions on each socket file
if [ ${SOCKET_COUNT} -gt 0 ]; then
  log "INFO" "🔧 Fixing permissions on socket files"
  
  for SOCKET_FILE in ${SOCKET_FILES}; do
    log "INFO" "🔧 Setting permissions on ${SOCKET_FILE} (0666)"
    chmod 0666 "${SOCKET_FILE}"
    if [ $? -ne 0 ]; then
      log "ERROR" "❌ Failed to set permissions on ${SOCKET_FILE}"
    else
      log "INFO" "✅ Socket file permissions set successfully: ${SOCKET_FILE}"
    fi
  done
else
  log "INFO" "ℹ️ No socket files found, nothing to fix"
fi

# Check for coherence markers
mkdir -p "${COHERENCE_LOCK_DIR}"
log "INFO" "📊 Creating coherence marker for verification"

# Create coherence marker for this fix
MARKER_FILE="${COHERENCE_LOCK_DIR}/socket_permissions_fixed_${TIMESTAMP}.marker"
echo "Socket permissions fixed at $(date)" > "${MARKER_FILE}"
log "INFO" "✅ Created coherence marker: ${MARKER_FILE}"

# Verify running services
log "INFO" "🔍 Verifying running services"
PS_OUTPUT=$(ps aux | grep node | grep mcp-servers | grep -v grep)
if [ -z "${PS_OUTPUT}" ]; then
  log "WARN" "⚠️ No CNIF services appear to be running"
  log "INFO" "ℹ️ You may need to start services with /Users/XPV/Desktop/anchor-core/simple-launcher.sh"
else
  log "INFO" "✅ CNIF services are running"
fi

# Final status
log "INFO" "✅ Socket permissions fix completed successfully"
log "INFO" "ℹ️ Log file: ${LOG_FILE}"

echo "✅ Socket permissions fix completed successfully"
exit 0
