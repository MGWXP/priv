#!/bin/bash
# Setup and start WebSocket bridge for MCP real-time dashboards
# This script installs dependencies and initializes the WebSocket bridge

# Set up environment variables
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
SOCKET_DIR="$ANCHOR_HOME/sockets"
LOG_DIR="$HOME/Library/Logs/Claude"
WS_PORT=8765
NOTION_SYNC_INTERVAL=10000
ENABLE_DASHBOARD=true
ENABLE_NOTION_SYNC=true

# Change to anchor-core directory
cd "$ANCHOR_HOME" || {
  echo "Failed to change to $ANCHOR_HOME directory"
  exit 1
}

# Ensure webbridge directory exists
if [ ! -d "$ANCHOR_HOME/src/webbridge" ]; then
  echo "WebSocket bridge directory not found at $ANCHOR_HOME/src/webbridge"
  exit 1
fi

# Install dependencies
echo "Installing WebSocket bridge dependencies..."
cd "$ANCHOR_HOME/src/webbridge" || {
  echo "Failed to change to $ANCHOR_HOME/src/webbridge directory"
  exit 1
}

npm install

# Create socket directory if it doesn't exist
mkdir -p "$SOCKET_DIR"

# Create log directory if it doesn't exist
mkdir -p "$LOG_DIR"

# Make scripts executable
chmod +x "$ANCHOR_HOME/src/webbridge/socket-bridge.js"
chmod +x "$ANCHOR_HOME/src/webbridge/notion-sync.js"
chmod +x "$ANCHOR_HOME/src/webbridge/webbridge-init.js"

# Run initialization script
echo "Starting WebSocket bridge initialization..."
node "$ANCHOR_HOME/src/webbridge/webbridge-init.js" \
  --port "$WS_PORT" \
  --socket-dir "$SOCKET_DIR" \
  --log-dir "$LOG_DIR" \
  $([ "$ENABLE_DASHBOARD" = true ] && echo "--dashboard" || echo "--no-dashboard") \
  $([ "$ENABLE_NOTION_SYNC" = true ] && echo "--notion-sync" || echo "--no-notion-sync")

echo "WebSocket bridge setup completed!"
echo "WebSocket bridge is running at ws://localhost:$WS_PORT"
echo "To stop: kill \$(cat $ANCHOR_HOME/webbridge.pid)"
