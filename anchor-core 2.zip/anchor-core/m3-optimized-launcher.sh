#!/bin/bash
# m3-optimized-launcher.sh - FIXED VERSION
# Generated: Mon May 19 15:23:53 HST 2025

# Load environment variables from backup
if [ -f "/Users/XPV/Desktop/anchor-core/m3-optimized-launcher.sh.bak" ]; then
  source <(grep "export" "/Users/XPV/Desktop/anchor-core/m3-optimized-launcher.sh.bak")
fi

# Print optimization info
echo "✅ M3 Max optimizations applied"
echo "🧠 Memory allocation: ${NODE_OPTIONS:-'--max-old-space-size=8192'}"
echo "⚙️ Thread pool size: ${UV_THREADPOOL_SIZE:-'12'}"
echo "📊 Buffer size: ${CNIF_BUFFER_SIZE:-'65536'}"

# Default optimizations in case backup didn't have them
export NODE_OPTIONS="${NODE_OPTIONS:-'--max-old-space-size=8192'}"
export UV_THREADPOOL_SIZE="${UV_THREADPOOL_SIZE:-'12'}"
export CNIF_BUFFER_SIZE="${CNIF_BUFFER_SIZE:-'65536'}"
export CNIF_SCHEMA_CACHE_SIZE="${CNIF_SCHEMA_CACHE_SIZE:-'256'}"
export CNIF_SOCKET_BACKLOG="${CNIF_SOCKET_BACKLOG:-'128'}"
export CNIF_POOL_SIZE="${CNIF_POOL_SIZE:-'8'}"
export CNIF_USE_ASYNC_HOOKS="${CNIF_USE_ASYNC_HOOKS:-'true'}"
export ANCHOR_HOME="${ANCHOR_HOME:-'/Users/XPV/Desktop/anchor-core'}"

# Start services directly to avoid launcher issues
echo "Starting schema-registry..."
node "${ANCHOR_HOME}/mcp-servers/schema-registry-index.js" > "${HOME}/Library/Logs/Claude/schema-registry.out" 2>&1 &
echo "Started schema-registry (PID: $!)"
sleep 3

echo "Starting socket-server..."
MCP_SERVER_NAME="socket-server" node "${ANCHOR_HOME}/mcp-servers/socket-server-implementation.cjs" > "${HOME}/Library/Logs/Claude/socket-server.out" 2>&1 &
echo "Started socket-server (PID: $!)"
sleep 1

echo "Starting streaming-transformer..."
MCP_SERVER_NAME="streaming-transformer" node "${ANCHOR_HOME}/mcp-servers/streaming-schema-transformer.cjs" > "${HOME}/Library/Logs/Claude/streaming-transformer.out" 2>&1 &
echo "Started streaming-transformer (PID: $!)"
sleep 1

echo "Starting notion..."
MCP_SERVER_NAME="notion" node "${ANCHOR_HOME}/mcp-servers/notion-connection-manager.cjs" > "${HOME}/Library/Logs/Claude/notion.out" 2>&1 &
echo "Started notion (PID: $!)"
sleep 1

echo "Starting mcp-orchestrator..."
MCP_SERVER_NAME="mcp-orchestrator" node "${ANCHOR_HOME}/mcp-servers/mcp-orchestrator.cjs" > "${HOME}/Library/Logs/Claude/mcp-orchestrator.out" 2>&1 &
echo "Started mcp-orchestrator (PID: $!)"

echo "✅ All services started"
echo "Use 'ps aux | grep node' to check if services are running"
echo "Use 'tail -f ${HOME}/Library/Logs/Claude/*.log' to view logs"
