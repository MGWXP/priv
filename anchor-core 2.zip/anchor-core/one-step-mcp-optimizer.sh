#!/bin/bash
# one-step-mcp-optimizer.sh - Complete M3 Max MCP optimization in one step
# © 2025 XPV - MIT License

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
RED='\033[0;31m'
BOLD='\033[1m'
NC='\033[0m'  # No Color

ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
MCP_DIR="${ANCHOR_HOME}/mcp-servers"
LOG_DIR="${HOME}/Library/Logs/Claude"
CONFIG_DIR="${HOME}/Library/Application Support/Claude"
OPTIMIZER="${ANCHOR_HOME}/m3-optimizer/m3-mcp-optimizer.js"
LAUNCHER="${ANCHOR_HOME}/launch-enhanced-mcp.sh"

echo -e "${BLUE}${BOLD}┌───────────────────────────────────────────────────────┐${NC}"
echo -e "${BLUE}${BOLD}│       One-Step M3 Max MCP Optimizer (v1.0.0)          │${NC}"
echo -e "${BLUE}${BOLD}└───────────────────────────────────────────────────────┘${NC}"
echo -e "Started at: $(date '+%Y-%m-%d %H:%M:%S')"
echo

# Make sure we have the newest Node.js version available
if command -v brew &> /dev/null; then
    echo -e "${BLUE}${BOLD}Ensuring Node.js is up to date...${NC}"
    brew upgrade node &> /dev/null || true
    NODE_VERSION=$(node -v)
    echo -e "${GREEN}✓ Using Node.js ${NODE_VERSION}${NC}"
else
    NODE_VERSION=$(node -v)
    echo -e "${YELLOW}Homebrew not found. Using existing Node.js ${NODE_VERSION}${NC}"
fi

# Make optimizer script executable
chmod +x "${OPTIMIZER}" 2>/dev/null || true
chmod +x "${LAUNCHER}" 2>/dev/null || true
echo

echo -e "${BLUE}${BOLD}Running M3 Max MCP optimizer...${NC}"
if node "${OPTIMIZER}"; then
    echo -e "${GREEN}${BOLD}✓ Optimizer completed successfully${NC}"
else
    echo -e "${RED}${BOLD}× Optimizer encountered errors${NC}"
    echo -e "${YELLOW}Continuing with server launch...${NC}"
fi
echo

echo -e "${BLUE}${BOLD}Launching optimized MCP servers...${NC}"
if [ -x "${LAUNCHER}" ]; then
    "${LAUNCHER}"
    LAUNCH_RESULT=$?
    if [ $LAUNCH_RESULT -eq 0 ]; then
        echo -e "${GREEN}${BOLD}✓ MCP servers launched successfully${NC}"
    else
        echo -e "${RED}${BOLD}× Error launching MCP servers (Exit code: ${LAUNCH_RESULT})${NC}"
    fi
else
    echo -e "${RED}${BOLD}× Launcher script not found or not executable: ${LAUNCHER}${NC}"
    echo -e "${YELLOW}Running make-executable.sh to fix permissions...${NC}"
    bash "${ANCHOR_HOME}/make-executable.sh" || true
    
    if [ -x "${LAUNCHER}" ]; then
        echo -e "${GREEN}Permissions fixed, running launcher...${NC}"
        "${LAUNCHER}"
        LAUNCH_RESULT=$?
        if [ $LAUNCH_RESULT -eq 0 ]; then
            echo -e "${GREEN}${BOLD}✓ MCP servers launched successfully${NC}"
        else
            echo -e "${RED}${BOLD}× Error launching MCP servers (Exit code: ${LAUNCH_RESULT})${NC}"
        fi
    else
        echo -e "${RED}${BOLD}× Unable to fix launcher permissions${NC}"
        echo -e "${YELLOW}Please run the following command manually:${NC}"
        echo -e "chmod +x \"${LAUNCHER}\" && \"${LAUNCHER}\""
    fi
fi

echo -e "\n${BLUE}${BOLD}Creating success marker...${NC}"
touch "${ANCHOR_HOME}/MCP_OPTIMIZATION_COMPLETE_$(date +%Y%m%d_%H%M%S).marker"

echo -e "\n${GREEN}${BOLD}✓ Optimization process completed at $(date '+%Y-%m-%d %H:%M:%S')${NC}"
echo -e "${CYAN}If Claude Desktop is running, please restart it to connect to the optimized MCP servers.${NC}"
echo -e "${CYAN}To verify server status, run: ${MCP_DIR}/verify-servers.sh${NC}"
