#!/bin/bash
# fix-dashboard-links.sh - Fixes Notion dashboard hyperlinks
# For M3 Max (48GB unified memory) hardware

# Terminal colors for better visibility
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

NOTION_PAGE_ID="1f7e48c2-bbbd-80df-86ed-d35832916f80"
MAIN_DASHBOARD_ID="1f8e48c2-bbbd-8109-b66e-fa7710500815"
PROJECT_DASHBOARD_ID="1f8e48c2-bbbd-8171-9d69-c39ca91b56cd"

echo -e "${BLUE}=== Fixing Dashboard Hyperlinks ===${NC}"
echo -e "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo -e ""

# Check if NOTION_API_KEY is set
if [ -z "${NOTION_API_KEY}" ]; then
    echo -e "${YELLOW}NOTION_API_KEY environment variable is not set${NC}"
    echo -e "Would you like to set it now? (y/n)"
    read -r response
    if [[ "$response" =~ ^([yY][eE][sS]|[yY])$ ]]; then
        echo -e "Enter your Notion API Key:"
        read -s NOTION_KEY
        export NOTION_API_KEY="$NOTION_KEY"
        echo -e "${GREEN}✓ NOTION_API_KEY set${NC}"
    else
        echo -e "${RED}Cannot proceed without Notion API Key${NC}"
        exit 1
    fi
fi

# Load database IDs
AGENT_REGISTRY_ID=$(cat /Users/XPV/Desktop/anchor-core/notion-db-ids/agent-registry-id.txt | head -1)
COMPONENT_LIBRARY_ID=$(cat /Users/XPV/Desktop/anchor-core/notion-db-ids/component-library-id.txt | head -1)
PROJECT_TRACKER_ID=$(cat /Users/XPV/Desktop/anchor-core/notion-db-ids/project-tracker-id.txt | head -1)

# Check if system metrics database ID exists
if [ -f "/Users/XPV/Desktop/anchor-core/notion-db-ids/system-metrics-id.txt" ]; then
    SYSTEM_METRICS_ID=$(cat /Users/XPV/Desktop/anchor-core/notion-db-ids/system-metrics-id.txt | head -1)
else
    echo -e "${YELLOW}System Metrics database ID not found. Will skip related views.${NC}"
    SYSTEM_METRICS_ID=""
fi

# Clear existing content and create new links with proper formatting
echo -e "Clearing existing content from Main Dashboard..."
# First, get the current blocks
CURRENT_BLOCKS=$(curl -s -X GET "https://api.notion.com/v1/blocks/${MAIN_DASHBOARD_ID}/children" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Notion-Version: 2022-06-28")

# Extract block IDs for deletion
BLOCK_IDS=$(echo $CURRENT_BLOCKS | grep -o '"id":"[^"]*' | cut -d'"' -f4)

# Delete all blocks except the first two (title and description)
COUNT=0
for BLOCK_ID in $BLOCK_IDS; do
    COUNT=$((COUNT+1))
    # Skip the first two blocks (title and description)
    if [ $COUNT -gt 2 ]; then
        echo -e "Deleting block $BLOCK_ID..."
        DELETE_RESPONSE=$(curl -s -X DELETE "https://api.notion.com/v1/blocks/${BLOCK_ID}" \
          -H "Authorization: Bearer ${NOTION_API_KEY}" \
          -H "Notion-Version: 2022-06-28")
    fi
done

# Add new correctly formatted component links
echo -e "Adding correctly formatted database links to Main Dashboard..."
LINKS_RESPONSE=$(curl -s -X PATCH "https://api.notion.com/v1/blocks/${MAIN_DASHBOARD_ID}/children" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "children": [
        {
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Active Components"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "paragraph",
            "paragraph": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Access Component Library: "
                        }
                    },
                    {
                        "type": "text",
                        "text": {
                            "content": "Component Library",
                            "link": {
                                "type": "url",
                                "url": "https://notion.so/'"${COMPONENT_LIBRARY_ID}"'"
                            }
                        },
                        "annotations": {
                            "bold": true,
                            "color": "blue"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Active Agents"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "paragraph",
            "paragraph": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Access Agent Registry: "
                        }
                    },
                    {
                        "type": "text",
                        "text": {
                            "content": "Agent Registry",
                            "link": {
                                "type": "url",
                                "url": "https://notion.so/'"${AGENT_REGISTRY_ID}"'"
                            }
                        },
                        "annotations": {
                            "bold": true,
                            "color": "blue"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Project Status"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "paragraph",
            "paragraph": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Access Project Tracker: "
                        }
                    },
                    {
                        "type": "text",
                        "text": {
                            "content": "Project Tracker",
                            "link": {
                                "type": "url",
                                "url": "https://notion.so/'"${PROJECT_TRACKER_ID}"'"
                            }
                        },
                        "annotations": {
                            "bold": true,
                            "color": "blue"
                        }
                    }
                ]
            }
        }
    ]
}')

if echo $LINKS_RESPONSE | grep -q "error"; then
    echo -e "${RED}Failed to add correct links to main dashboard${NC}"
    echo $LINKS_RESPONSE
else
    echo -e "${GREEN}✓ Correctly formatted links added to Main Dashboard!${NC}"
fi

# Add the button links for better visibility
echo -e "Adding button-style links for better visibility..."
BUTTON_LINKS_RESPONSE=$(curl -s -X PATCH "https://api.notion.com/v1/blocks/${MAIN_DASHBOARD_ID}/children" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "children": [
        {
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Quick Access"
                        }
                    }
                ]
            }
        },
        {
            "object": "block",
            "type": "callout",
            "callout": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Component Library",
                            "link": {
                                "type": "url",
                                "url": "https://notion.so/'"${COMPONENT_LIBRARY_ID}"'"
                            }
                        },
                        "annotations": {
                            "bold": true
                        }
                    }
                ],
                "icon": {
                    "emoji": "🧩"
                },
                "color": "blue_background"
            }
        },
        {
            "object": "block",
            "type": "callout",
            "callout": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Agent Registry",
                            "link": {
                                "type": "url",
                                "url": "https://notion.so/'"${AGENT_REGISTRY_ID}"'"
                            }
                        },
                        "annotations": {
                            "bold": true
                        }
                    }
                ],
                "icon": {
                    "emoji": "🤖"
                },
                "color": "green_background"
            }
        },
        {
            "object": "block",
            "type": "callout",
            "callout": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Project Tracker",
                            "link": {
                                "type": "url",
                                "url": "https://notion.so/'"${PROJECT_TRACKER_ID}"'"
                            }
                        },
                        "annotations": {
                            "bold": true
                        }
                    }
                ],
                "icon": {
                    "emoji": "📋"
                },
                "color": "yellow_background"
            }
        }
    ]
}')

if echo $BUTTON_LINKS_RESPONSE | grep -q "error"; then
    echo -e "${RED}Failed to add button-style links to main dashboard${NC}"
    echo $BUTTON_LINKS_RESPONSE
else
    echo -e "${GREEN}✓ Button-style links added to Main Dashboard!${NC}"
fi

# Fix Project Dashboard links in a similar way
echo -e "Fixing Project Dashboard links..."
# First, get the current blocks
PROJECT_BLOCKS=$(curl -s -X GET "https://api.notion.com/v1/blocks/${PROJECT_DASHBOARD_ID}/children" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Notion-Version: 2022-06-28")

# Extract block IDs for deletion
PROJECT_BLOCK_IDS=$(echo $PROJECT_BLOCKS | grep -o '"id":"[^"]*' | cut -d'"' -f4)

# Delete all blocks except the first two (title and description)
COUNT=0
for BLOCK_ID in $PROJECT_BLOCK_IDS; do
    COUNT=$((COUNT+1))
    # Skip the first two blocks (title and description)
    if [ $COUNT -gt 2 ]; then
        echo -e "Deleting block $BLOCK_ID from Project Dashboard..."
        DELETE_RESPONSE=$(curl -s -X DELETE "https://api.notion.com/v1/blocks/${BLOCK_ID}" \
          -H "Authorization: Bearer ${NOTION_API_KEY}" \
          -H "Notion-Version: 2022-06-28")
    fi
done

# Add properly formatted links to the Project Dashboard
echo -e "Adding correctly formatted links to Project Dashboard..."
PROJECT_LINKS_RESPONSE=$(curl -s -X PATCH "https://api.notion.com/v1/blocks/${PROJECT_DASHBOARD_ID}/children" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "children": [
        {
            "object": "block",
            "type": "callout",
            "callout": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Project Tracker",
                            "link": {
                                "type": "url",
                                "url": "https://notion.so/'"${PROJECT_TRACKER_ID}"'"
                            }
                        },
                        "annotations": {
                            "bold": true
                        }
                    }
                ],
                "icon": {
                    "emoji": "📋"
                },
                "color": "yellow_background"
            }
        },
        {
            "object": "block",
            "type": "callout",
            "callout": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Component Library",
                            "link": {
                                "type": "url",
                                "url": "https://notion.so/'"${COMPONENT_LIBRARY_ID}"'"
                            }
                        },
                        "annotations": {
                            "bold": true
                        }
                    }
                ],
                "icon": {
                    "emoji": "🧩"
                },
                "color": "blue_background"
            }
        }
    ]
}')

if echo $PROJECT_LINKS_RESPONSE | grep -q "error"; then
    echo -e "${RED}Failed to add correct links to Project Dashboard${NC}"
    echo $PROJECT_LINKS_RESPONSE
else
    echo -e "${GREEN}✓ Correctly formatted links added to Project Dashboard!${NC}"
fi

# Add explanation note
echo -e "Adding explanation note about the hyperlink fix..."
EXPLANATION_RESPONSE=$(curl -s -X PATCH "https://api.notion.com/v1/blocks/${MAIN_DASHBOARD_ID}/children" \
  -H "Authorization: Bearer ${NOTION_API_KEY}" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  --data '{
    "children": [
        {
            "object": "block",
            "type": "callout",
            "callout": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": "Note: Hyperlinks have been updated to use the correct format for Notion API. If you encounter any issues with the links, please refresh the page or try clicking on the button-style links above."
                        }
                    }
                ],
                "icon": {
                    "emoji": "ℹ️"
                },
                "color": "gray_background"
            }
        }
    ]
}')

echo -e "\n${GREEN}✓ Dashboard hyperlinks fixed!${NC}"
echo -e "${YELLOW}Both dashboards have been updated with properly formatted links.${NC}"
echo -e "${YELLOW}Main Dashboard: https://notion.so/${MAIN_DASHBOARD_ID}${NC}"
echo -e "${YELLOW}Project Dashboard: https://notion.so/${PROJECT_DASHBOARD_ID}${NC}"
echo -e "\n${BLUE}Technical Explanation:${NC}"
echo -e "The previous links used 'https://www.notion.so/' format which can cause errors."
echo -e "The updated links use 'https://notion.so/' format (without 'www') and include"
echo -e "proper link formatting with callout blocks for improved visibility."
