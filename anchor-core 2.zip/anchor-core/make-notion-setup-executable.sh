#!/bin/bash

# Script to make the Notion integration setup script executable
chmod +x /Users/XPV/Desktop/anchor-core/setup-notion-integration.sh
echo "✅ Made setup-notion-integration.sh executable"

# Run the setup script if requested
read -p "Do you want to run the setup script now? (y/n): " RUN_SETUP
if [ "$RUN_SETUP" = "y" ] || [ "$RUN_SETUP" = "Y" ]; then
  /Users/XPV/Desktop/anchor-core/setup-notion-integration.sh
fi
