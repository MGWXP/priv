#!/bin/bash
# Run this script to make the quickstart executable and then run it

chmod +x /Users/XPV/Desktop/anchor-core/notion-quickstart.sh
/Users/XPV/Desktop/anchor-core/notion-quickstart.sh
