#!/bin/bash
# launch-mcp-servers.sh
# Launch MCP servers with M3 Max optimizations
# Version: 1.0.0 (2025-05-18)

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/.env"

echo "=== Launching MCP Servers with M3 Max Optimizations (v1.0.0) ==="
echo "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo "Node.js: $(node -v)"
echo "Hardware: Apple M3 Max (48GB)"
echo "Memory settings: ${NODE_OPTIONS}"
echo "Thread pool: UV_THREADPOOL_SIZE=${UV_THREADPOOL_SIZE}"

# Stop any running servers
echo "Stopping any running MCP servers..."
pkill -f "mcp-servers" || true
sleep 2

# Create directories if they don't exist
mkdir -p "${LOG_DIR}"
mkdir -p "${SOCKET_DIR}"
mkdir -p "${DATA_DIR}/sqlite"

# Launch MCP servers
echo "Launching MCP servers..."

# Filesystem server (use official MCP server)
echo "Starting filesystem server..."
npx -y @modelcontextprotocol/server-filesystem ${FILESYSTEM_PATHS//,/ } > "${LOG_DIR}/filesystem.log" 2>&1 &
echo $! > "${ANCHOR_HOME}/mcp-servers/filesystem.pid"
echo "✅ Started filesystem server (PID: $!)"

# Git server
echo "Starting git-local server..."
node "${ANCHOR_HOME}/mcp-servers/git-local-optimized.js" > "${LOG_DIR}/git-local.log" 2>&1 &
echo $! > "${ANCHOR_HOME}/mcp-servers/git-local.pid"
echo "✅ Started git-local server (PID: $!)"

# SQLite server
echo "Starting sqlite server..."
node "${ANCHOR_HOME}/mcp-servers/sqlite-wrapper.js" > "${LOG_DIR}/sqlite.log" 2>&1 &
echo $! > "${ANCHOR_HOME}/mcp-servers/sqlite.pid"
echo "✅ Started sqlite server (PID: $!)"

# Notion server
echo "Starting notion server..."
node "${ANCHOR_HOME}/mcp-servers/notion-integration.js" > "${LOG_DIR}/notion.log" 2>&1 &
echo $! > "${ANCHOR_HOME}/mcp-servers/notion.pid"
echo "✅ Started notion server (PID: $!)"

# Slack server
echo "Starting slack server..."
node "${ANCHOR_HOME}/mcp-servers/slack-wrapper.js" > "${LOG_DIR}/slack.log" 2>&1 &
echo $! > "${ANCHOR_HOME}/mcp-servers/slack.pid"
echo "✅ Started slack server (PID: $!)"

# Anchor manager
echo "Starting anchor-manager server..."
node "${ANCHOR_HOME}/mcp-servers/anchor-manager-optimized.js" > "${LOG_DIR}/anchor-manager.log" 2>&1 &
echo $! > "${ANCHOR_HOME}/mcp-servers/anchor-manager.pid"
echo "✅ Started anchor-manager server (PID: $!)"

echo ""
echo "All MCP servers started with M3 Max optimizations!"
echo "To verify server status, run: ${ANCHOR_HOME}/mcp-servers/verify-servers.sh"
