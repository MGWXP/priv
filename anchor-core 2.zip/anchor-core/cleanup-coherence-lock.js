#!/usr/bin/env node
// cleanup-coherence-lock.js

import fs from 'fs/promises';
import path from 'path';

const COHERENCE_LOCK_DIR = '/Users/XPV/Desktop/anchor-core/coherence_lock';
const BACKUP_DIR = '/Users/XPV/Desktop/anchor-core/coherence_lock_backup';

// Files to be removed
const filesToRemove = [
  // Template files
  'ARCHIVAL_PROTOCOL_FINAL_V1_$(date +"%Y%m%d%H%M%S").marker',
  'ARCHIVING_PROTOCOL_IMPLEMENTATION_COMPLETE_$(date +"%Y-%m-%dT%H%M%S%3N%z").marker',
  
  // Empty files
  'ARCHIVE_ANALYSIS_2025-05-19T2331003N-1000.marker',
  'ARCHIVE_PROTOCOL_INITIALIZED_2025-05-19T2331003N-1000.marker',
  'ARCHIVE_TOOLS_EXECUTABLE_20250519233100.marker',
  'SETUP_ARCHIVING_PROTOCOL_2025-05-19T2330553N-1000.marker',
  
  // PID-only files
  'schema-registry_20250519151345.marker',
  'schema-registry_20250519151913.marker',
  'socket-server_2025-05-20T012846361Z.marker',
  'streaming-transformer_2025-05-20T012848388Z.marker',
  'notion_2025-05-20T012850404Z.marker',
  'mcp-orchestrator_2025-05-20T012852432Z.marker',
  
  // Redundant schema registry files
  'schema-registry_2025-05-20T011346034Z.marker',
  'schema-registry_2025-05-20T011913586Z.marker',
  'schema-registry_2025-05-20T012357791Z.marker'
];

// Consolidated files to create
const consolidatedFiles = [
  {
    filename: 'schema-registry-consolidated.json',
    content: JSON.stringify({
      "component": "schema-registry",
      "status": "INITIALIZED",
      "version": "1.0.0",
      "system_info": {
        "hostname": "xpv.local",
        "platform": "darwin",
        "nodeVersion": "v20.11.0",
        "hardware": "M3 Max"
      },
      "schemaMetrics": {
        "initialized": true,
        "schemaCount": {
          "claude": 3,
          "notion": 1,
          "total": 4
        },
        "latestVersions": {
          "claude": {
            "claude-query-result": "1-0-0",
            "sample": "1-0-0",
            "test-schema": "1-0-0"
          },
          "notion": {
            "notion-database-schema": "1-0-0"
          }
        }
      }
    }, null, 2)
  },
  {
    filename: 'service-processes-consolidated.json',
    content: JSON.stringify({
      "component": "service-processes",
      "status": "RUNNING",
      "version": "1.0.0",
      "processes": {
        "schema-registry": 22400,
        "socket-server": 22410,
        "streaming-transformer": 22421,
        "notion": 22429,
        "mcp-orchestrator": 22437
      },
      "startup_sequence": [
        {"component": "schema-registry", "timestamp": "2025-05-20T01:28:43.328Z"},
        {"component": "socket-server", "timestamp": "2025-05-20T01:28:46.361Z"},
        {"component": "streaming-transformer", "timestamp": "2025-05-20T01:28:48.388Z"},
        {"component": "notion", "timestamp": "2025-05-20T01:28:50.404Z"},
        {"component": "mcp-orchestrator", "timestamp": "2025-05-20T01:28:52.432Z"}
      ]
    }, null, 2)
  },
  {
    filename: 'cnif-system-consolidated.json',
    content: JSON.stringify({
      "component": "cnif-system",
      "status": "RUNNING",
      "version": "1.0.0",
      "lifecycle": {
        "module_system_complete": "2025-05-19T07:45:12.000Z",
        "setup_complete": "2025-05-20T01:18:44Z",
        "start_success": "2025-05-19T15:24:05 HST",
        "fixed_timestamp": "2025-05-19T15:28:59 HST"
      },
      "implementation": {
        "schema_registry": true,
        "socket_server": true,
        "streaming_transformer": true,
        "notion_connection": true,
        "mcp_orchestrator": true
      },
      "verification": {
        "schema_test": "PASSED",
        "socket_test": "PASSED",
        "module_system": "COMPLIANT"
      },
      "system_info": {
        "node_version": "v20.12.2",
        "os": "darwin arm64",
        "memory": "48GB",
        "hardware": "M3 Max"
      }
    }, null, 2)
  },
  {
    filename: 'archival-protocol-consolidated.json',
    content: JSON.stringify({
      "component": "archival-protocol",
      "status": "COMPLETE",
      "version": "1.0.0",
      "lifecycle": {
        "setup": "2025-05-19T23:30:55.3N-1000",
        "initialized": "2025-05-19T23:31:00.3N-1000",
        "implementation_complete": "2025-05-19T16:45:23",
        "filesystem_directive_complete": "2025-05-19T19:30:45",
        "final_protocol": "2025-05-19T18:15:23"
      },
      "tools": {
        "analysis": [
          "analyze-archive-candidates.sh",
          "identify-archive-candidates.sh",
          "archive-dashboard.sh"
        ],
        "archiving": [
          "archive-component.sh",
          "bulk-archive-components.sh",
          "create-replacement-component.sh",
          "component-migration-manager.sh"
        ],
        "management": [
          "archival-protocol-controller.sh"
        ],
        "documentation": [
          "SYSTEMATIC_ARCHIVING_PROTOCOL.md",
          "ARCHIVING_PROTOCOL_USER_GUIDE.md",
          "ARCHIVAL_IMPLEMENTATION_PLAN.md",
          "ARCHIVAL_PROTOCOL_INITIALIZATION.md"
        ]
      },
      "archive_categories": [
        "module-system-conflicts",
        "socket-connectivity-issues",
        "schema-validation-errors",
        "process-management-issues",
        "performance-bottlenecks",
        "deprecated-implementations",
        "obsolete-configurations"
      ],
      "hardware_target": "M3 Max (48GB unified memory)",
      "taxonomy_layer": "L0-L13 (All)"
    }, null, 2)
  }
];

async function main() {
  try {
    // Create backup directory if it doesn't exist
    await fs.mkdir(BACKUP_DIR, { recursive: true });
    console.log(`✅ Created backup directory: ${BACKUP_DIR}`);
    
    // Backup all files first
    const files = await fs.readdir(COHERENCE_LOCK_DIR);
    for (const file of files) {
      const sourcePath = path.join(COHERENCE_LOCK_DIR, file);
      const destPath = path.join(BACKUP_DIR, file);
      await fs.copyFile(sourcePath, destPath);
    }
    console.log(`✅ Backed up ${files.length} files to ${BACKUP_DIR}`);
    
    // Remove redundant files
    for (const file of filesToRemove) {
      const filePath = path.join(COHERENCE_LOCK_DIR, file);
      try {
        await fs.unlink(filePath);
        console.log(`✅ Removed: ${file}`);
      } catch (err) {
        if (err.code === 'ENOENT') {
          console.log(`⚠️ File not found: ${file}`);
        } else {
          throw err;
        }
      }
    }
    
    // Create consolidated files
    for (const file of consolidatedFiles) {
      const filePath = path.join(COHERENCE_LOCK_DIR, file.filename);
      await fs.writeFile(filePath, file.content);
      console.log(`✅ Created: ${file.filename}`);
    }
    
    console.log('✅ Coherence lock directory cleanup completed successfully');
  } catch (err) {
    console.error(`❌ Error: ${err.message}`);
    process.exit(1);
  }
}

main();
