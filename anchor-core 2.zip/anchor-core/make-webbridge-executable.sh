#!/bin/bash
# Make all WebSocket Bridge scripts executable
echo "Making WebSocket Bridge scripts executable..."

# Change to directory where this script is located
cd "$(dirname "$0")"

# Make start script executable
chmod +x start-webbridge.sh
echo "✅ start-webbridge.sh"

# Make stop script executable
chmod +x stop-webbridge.sh
echo "✅ stop-webbridge.sh"

# Make reset script executable
chmod +x reset-webbridge.sh
echo "✅ reset-webbridge.sh"

# Make update script executable
chmod +x update-webbridge.sh
echo "✅ update-webbridge.sh"

# Make verification script executable
chmod +x verify-webbridge.sh
echo "✅ verify-webbridge.sh"

# Make setup script executable
chmod +x setup-webbridge.sh
echo "✅ setup-webbridge.sh"

# Make WebSocket bridge scripts executable
chmod +x src/webbridge/socket-bridge.js
echo "✅ socket-bridge.js"

# Make Notion sync script executable
chmod +x src/webbridge/notion-sync.js
echo "✅ notion-sync.js"

# Make initialization script executable
chmod +x src/webbridge/webbridge-init.js
echo "✅ webbridge-init.js"

echo "All WebSocket Bridge scripts are now executable"
