#!/bin/bash
# chmod +x /Users/XPV/Desktop/anchor-core/scripts/verify_system_coherence.sh
set -e
# ──────────────────────────────────────────────────────────────────────────
#  ANCHOR CORE V6 – SYSTEM COHERENCE VERIFICATION [L1-L7]
# ──────────────────────────────────────────────────────────────────────────
SOCKET_DIR="/var/run/claude"
CONFIG="${HOME}/Library/Application Support/Claude/claude_desktop_config.json"
BASE_DIR="/Users/XPV/Desktop/anchor-core"
MCP_DIR="${BASE_DIR}/mcp-servers"
LOG_DIR="${HOME}/Library/Logs/Claude"

echo "┌────────  ANCHOR CORE COHERENCE CHECK [L1-L7]  ────────┐"

# [L4] Configuration verification
if [[ -f "$CONFIG" ]]; then
  if python3 -m json.tool <"$CONFIG" >/dev/null; then
    echo "✅ [L4] Config JSON valid → $CONFIG"
    # Verify references to the correct paths
    if grep -q "anchor-core" "$CONFIG"; then
      echo "✅ [L4] Config references correct anchor-core paths"
    else
      echo "❌ [L4] Config references incorrect paths (update required)"
      echo "   Run: ${BASE_DIR}/scripts/anchor-core-deploy.sh"
    fi
  else
    echo "❌ [L4] Config JSON invalid → $CONFIG"
    echo "   Run: ${BASE_DIR}/scripts/anchor-core-deploy.sh"
  fi
else
  echo "❌ [L4] Config file missing → $CONFIG"
  echo "   Run: ${BASE_DIR}/scripts/anchor-core-deploy.sh"
fi

# [L2] Process verification
echo -e "\n├── MCP Server Processes [L2] ──────────────────────┤"
for s in filesystem git-local notion anchor-manager; do
  p=$(pgrep -f "$s") || true
  printf "│  %-15s : " "$s"
  if [[ $p ]]; then
    echo "✅ Process $p"
  else
    echo "❌ NOT RUNNING"
  fi
done

# [L1] Socket verification
echo -e "\n├── Socket Files [L1] ───────────────────────────────┤"
if [[ -d "$SOCKET_DIR" ]]; then
  perms=$(stat -f "%Lp" "$SOCKET_DIR")
  if [[ "$perms" == "775" ]]; then
    echo "│  ✅ Socket dir permissions correct (775) → $SOCKET_DIR"
  else
    echo "│  ❌ Socket dir wrong permissions ($perms) → $SOCKET_DIR"
    echo "│     Run: sudo chmod 775 $SOCKET_DIR"
  fi
  
  # Check socket files
  for name in filesystem git-local notion anchor-manager; do
    file="$SOCKET_DIR/${name}.sock"
    if [[ -S "$file" ]]; then
      echo "│  ✅ Socket exists → $file"
    else
      echo "│  ❌ Socket missing → $file"
    fi
  done
else
  echo "│  ❌ Socket directory missing → $SOCKET_DIR"
  echo "│     Run: sudo mkdir -p $SOCKET_DIR && sudo chmod 775 $SOCKET_DIR && sudo chown root:staff $SOCKET_DIR"
fi

# [L3] Log verification
echo -e "\n├── Log Files [L3] ──────────────────────────────────┤"
mkdir -p "$LOG_DIR"
log_count=$(find "$LOG_DIR" -name "mcp-server-*.log" | wc -l)
echo "│  Found $log_count log files in $LOG_DIR"

# [L7] Server executable verification
echo -e "\n├── MCP Server Files [L7] ───────────────────────────┤"
for server in git-local-optimized.js anchor-manager-optimized.js notion-v5-wrapper.js; do
  file="$MCP_DIR/$server"
  if [[ -x "$file" ]]; then
    echo "│  ✅ $server executable [755]"
  elif [[ -f "$file" ]]; then
    echo "│  ❌ $server not executable"
    echo "│     Run: chmod +x $file"
  else
    echo "│  ❌ $server missing"
    echo "│     Run: ${BASE_DIR}/scripts/anchor-core-deploy.sh"
  fi
done

echo "└─────────────────────────────────────────────────────────┘"
