#!/bin/bash
# ──────────────────────────────────────────────────────────────────────────
#  ANCHOR CORE V6 – REAL-TIME LOG VIEWER [L3]
# ──────────────────────────────────────────────────────────────────────────
LOG_DIR="$HOME/Library/Logs/Claude"
COLORS=(31 32 33 34 35 36 37)
i=0
pids=()

# Create log directory if it doesn't exist
mkdir -p "$LOG_DIR"

# Title banner
echo -e "\033[1;34m┌─────────────────────────────────────────────────────────┐"
echo -e "│             ANCHOR CORE V6 - REAL-TIME LOG VIEWER             │"
echo -e "│                 [Press Ctrl+C to exit]                        │"
echo -e "└─────────────────────────────────────────────────────────────┘\033[0m"

# Check if any log files exist
log_count=$(ls -1 "$LOG_DIR"/mcp-server-*.log 2>/dev/null | wc -l)
if [ "$log_count" -eq 0 ]; then
  echo -e "\033[1;33m⚠️  No log files found in $LOG_DIR\033[0m"
  echo -e "\033[1;33m   Waiting for logs to be created...\033[0m"
fi

# Tail the logs with color coding
for f in $(ls -1t "$LOG_DIR"/mcp-server-*.log 2>/dev/null); do
  c=${COLORS[$((i % ${#COLORS[@]}))]}
  tail -n 20 -F "$f" | sed -e "s/^/[$(basename "$f")]\t/" \
                           -e "s/^/\x1b[${c}m/" -e "s/$/\x1b[0m/" &
  pids+=($!); i=$((i+1))
done

# If no logs found, wait for them
if [ "$log_count" -eq 0 ]; then
  while [ "$(ls -1 "$LOG_DIR"/mcp-server-*.log 2>/dev/null | wc -l)" -eq 0 ]; do
    sleep 1
  done
  echo -e "\033[1;32m✅ Logs detected - starting monitoring\033[0m"
  for f in $(ls -1t "$LOG_DIR"/mcp-server-*.log); do
    c=${COLORS[$((i % ${#COLORS[@]}))]}
    tail -n 20 -F "$f" | sed -e "s/^/[$(basename "$f")]\t/" \
                             -e "s/^/\x1b[${c}m/" -e "s/$/\x1b[0m/" &
    pids+=($!); i=$((i+1))
  done
fi

# Clean up on exit
trap 'kill "${pids[@]}" >/dev/null 2>&1; echo -e "\033[1;34m\nStopped log viewing\033[0m"; exit' INT TERM
wait
