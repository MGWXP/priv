#!/bin/bash
# socket_directory_setup.sh - Ensure socket directory has correct structure and permissions
# © 2025 XPV - MIT

set -e

ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
SOCKET_DIR="${ANCHOR_HOME}/sockets"

echo "Setting up socket directory structure..."

# Create socket directory if it doesn't exist
mkdir -p "${SOCKET_DIR}"

# Set proper permissions
chmod 755 "${SOCKET_DIR}"

# Clean up any stale socket files
rm -f "${SOCKET_DIR}"/*.sock 2>/dev/null || true

echo "✅ Socket directory setup complete: ${SOCKET_DIR}"
echo "Directory permissions:"
ls -ld "${SOCKET_DIR}"
