#!/bin/bash
# anchor-system-optimizer.sh - Unified deployment script
# Optimizes and consolidates the MCP server ecosystem
# © 2025 XPV - MIT

set -e  # Exit on error

echo "🚀 Starting Anchor System Optimization..."

# Define core paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
MCP_DIR="${ANCHOR_HOME}/mcp-servers"
CONFIG_DIR="${HOME}/Library/Application Support/Claude"
LOG_DIR="${HOME}/Library/Logs/Claude"
SOCKET_DIR="/var/run/claude"

# Create required directories
echo "📁 Creating required directories..."
mkdir -p "${LOG_DIR}"
mkdir -p "${ANCHOR_HOME}/coherence_lock"

# Install sudo if socket creation requires it
if [[ ! -d "${SOCKET_DIR}" ]]; then
  echo "🔧 Creating socket directory (may require password)..."
  sudo mkdir -p "${SOCKET_DIR}"
  sudo chown $(whoami) "${SOCKET_DIR}"
  sudo chmod 775 "${SOCKET_DIR}"
fi

# Check environment variables
echo "✅ Validating environment setup..."
if [[ -z "${NODE_PATH}" ]]; then
  echo "⚠️ NODE_PATH not set, setting to include required paths"
  export NODE_PATH="${MCP_DIR}/node_modules:/usr/local/lib/node_modules:/opt/homebrew/lib/node_modules"
fi

# Apply specific M3 Max optimizations
echo "🧠 Applying M3 Max memory optimizations..."
export NODE_OPTIONS="--max-old-space-size=8192 --expose-gc"
export UV_THREADPOOL_SIZE=12

# Update Claude Desktop configuration
echo "⚙️ Updating Claude Desktop configuration..."
TEMP_CONFIG=$(mktemp)
cat > ${TEMP_CONFIG} << 'EOL'
{
  "mcpServers": {
    "filesystem": {
      "command": "npx",
      "args": [
        "-y",
        "@modelcontextprotocol/server-filesystem",
        "/Users/XPV/Desktop",
        "/Users/XPV/Library",
        "/Users/XPV/Downloads"
      ]
    },
    "git-local": {
      "command": "node",
      "args": [
        "/Users/XPV/Desktop/anchor-core/mcp-servers/git-local-optimized.js"
      ],
      "env": {
        "ANCHOR_HOME": "/Users/XPV/Desktop/anchor-core",
        "NODE_OPTIONS": "--max-old-space-size=8192 --expose-gc",
        "UV_THREADPOOL_SIZE": "12",
        "MCP_SERVER_NAME": "git-local"
      }
    },
    "notion": {
      "command": "node",
      "args": [
        "/Users/XPV/Desktop/anchor-core/mcp-servers/notion-v5-wrapper.js"
      ],
      "env": {
        "ANCHOR_HOME": "/Users/XPV/Desktop/anchor-core",
        "NODE_OPTIONS": "--max-old-space-size=8192 --expose-gc",
        "UV_THREADPOOL_SIZE": "12",
        "MCP_SERVER_NAME": "notion",
        "NOTION_API_TOKEN": "replace-with-your-token"
      }
    },
    "anchor-manager": {
      "command": "node",
      "args": [
        "/Users/XPV/Desktop/anchor-core/mcp-servers/anchor-manager-optimized.js"
      ],
      "env": {
        "ANCHOR_HOME": "/Users/XPV/Desktop/anchor-core",
        "MCP_DIR": "/Users/XPV/Desktop/anchor-core/mcp-servers",
        "NODE_OPTIONS": "--max-old-space-size=8192 --expose-gc",
        "UV_THREADPOOL_SIZE": "12",
        "MCP_SERVER_NAME": "anchor-manager"
      }
    }
  }
}
EOL

cp ${TEMP_CONFIG} "${CONFIG_DIR}/claude_desktop_config.json"
rm ${TEMP_CONFIG}

# Make scripts executable
echo "🔧 Making scripts executable..."
chmod +x "${MCP_DIR}"/*.js

# Stop any running instances
echo "🛑 Stopping running MCP servers..."
pkill -f "git-local-optimized.js" || true
pkill -f "notion-v5-wrapper.js" || true
pkill -f "anchor-manager-optimized.js" || true
sleep 2

# Clean up any stale PID files
rm -f "${MCP_DIR}"/*.pid || true

# Start all servers
echo "🚀 Starting optimized MCP servers..."

# Start Git Local server
GIT_LOG="${LOG_DIR}/mcp-server-git-local.log"
echo "Starting Git Local server, logging to ${GIT_LOG}"
ANCHOR_HOME="${ANCHOR_HOME}" NODE_OPTIONS="--max-old-space-size=8192 --expose-gc" UV_THREADPOOL_SIZE=12 \
  MCP_SERVER_NAME="git-local" node "${MCP_DIR}/git-local-optimized.js" > "${GIT_LOG}" 2>&1 &
echo $! > "${MCP_DIR}/git-local.pid"

# Start Notion server
NOTION_LOG="${LOG_DIR}/mcp-server-notion.log"
echo "Starting Notion server, logging to ${NOTION_LOG}"
ANCHOR_HOME="${ANCHOR_HOME}" NODE_OPTIONS="--max-old-space-size=8192 --expose-gc" UV_THREADPOOL_SIZE=12 \
  MCP_SERVER_NAME="notion" NOTION_API_TOKEN="replace-with-your-token" node "${MCP_DIR}/notion-v5-wrapper.js" > "${NOTION_LOG}" 2>&1 &
echo $! > "${MCP_DIR}/notion.pid"

# Start Anchor Manager server
ANCHOR_LOG="${LOG_DIR}/mcp-server-anchor-manager.log"
echo "Starting Anchor Manager server, logging to ${ANCHOR_LOG}"
ANCHOR_HOME="${ANCHOR_HOME}" MCP_DIR="${MCP_DIR}" NODE_OPTIONS="--max-old-space-size=8192 --expose-gc" UV_THREADPOOL_SIZE=12 \
  MCP_SERVER_NAME="anchor-manager" node "${MCP_DIR}/anchor-manager-optimized.js" > "${ANCHOR_LOG}" 2>&1 &
echo $! > "${MCP_DIR}/anchor-manager.pid"

# Verify servers are running
sleep 2
echo "✅ Verifying server status..."
echo "Git Local server PID: $(cat ${MCP_DIR}/git-local.pid 2>/dev/null || echo 'Not running')"
echo "Notion server PID: $(cat ${MCP_DIR}/notion.pid 2>/dev/null || echo 'Not running')"
echo "Anchor Manager server PID: $(cat ${MCP_DIR}/anchor-manager.pid 2>/dev/null || echo 'Not running')"

# Create a simple verification script
cat > "${MCP_DIR}/verify-servers.sh" << 'EOL'
#!/bin/bash
echo "Checking MCP servers status..."
echo "Git Local server: $(pgrep -f git-local-optimized.js || echo 'Not running')"
echo "Notion server: $(pgrep -f notion-v5-wrapper.js || echo 'Not running')"
echo "Anchor Manager server: $(pgrep -f anchor-manager-optimized.js || echo 'Not running')"
echo "Checking log files..."
for log in git-local notion anchor-manager; do
  echo "Latest log entries for ${log}:"
  tail -n 5 "${HOME}/Library/Logs/Claude/mcp-server-${log}.log" 2>/dev/null || echo "No log file found"
  echo "---"
done
EOL
chmod +x "${MCP_DIR}/verify-servers.sh"

echo "🎉 Optimization complete! Claude has been configured to use the optimized servers."
echo "To verify the status, run: ${MCP_DIR}/verify-servers.sh"
echo "To restart Claude and apply changes, quit Claude and restart it."
