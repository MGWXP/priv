#!/bin/bash
# chmod +x /Users/XPV/Desktop/anchor-core/scripts/repair_and_restart.sh
# ──────────────────────────────────────────────────────────────────────────
#  ANCHOR CORE V6 – REPAIR & RESTART SCRIPT [L0-L7]
# ──────────────────────────────────────────────────────────────────────────
set -euo pipefail

BASE_DIR="/Users/XPV/Desktop/anchor-core"
MCP_DIR="${BASE_DIR}/mcp-servers"
CONFIG_FILE="${HOME}/Library/Application Support/Claude/claude_desktop_config.json"
LOG_DIR="${HOME}/Library/Logs/Claude"
SOCKET_DIR="/var/run/claude"
COHERENCE_DIR="${BASE_DIR}/coherence_lock"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# ---------- ANSI Colors -------------------------------------------------------
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# ---------- Helper Functions --------------------------------------------------
log() {
  local level="$1"
  local message="$2"
  local timestamp=$(date "+%Y-%m-%d %H:%M:%S")
  
  case "${level}" in
    "INFO")
      echo -e "${BLUE}${timestamp} [INFO]${NC} ${message}"
      ;;
    "SUCCESS")
      echo -e "${GREEN}${timestamp} [SUCCESS]${NC} ${message}"
      ;;
    "WARN")
      echo -e "${YELLOW}${timestamp} [WARN]${NC} ${message}"
      ;;
    "ERROR")
      echo -e "${RED}${timestamp} [ERROR]${NC} ${message}"
      ;;
    *)
      echo -e "${timestamp} [${level}] ${message}"
      ;;
  esac
}

create_marker() {
  local status="$1"
  local message="$2"
  
  mkdir -p "${COHERENCE_DIR}"
  local marker_file="${COHERENCE_DIR}/repair_${TIMESTAMP}.marker"
  
  cat > "${marker_file}" << EOF
{
  "timestamp": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
  "component": "repair-script",
  "status": "${status}",
  "message": "${message}",
  "repairs": [
    "permissions",
    "socket_directory",
    "mcp_servers",
    "configuration"
  ]
}
EOF
  chmod 600 "${marker_file}"
  log "SUCCESS" "Created repair marker: ${marker_file}"
}

repair_socket_directory() {
  log "INFO" "Checking socket directory [L1]..."
  
  if [[ ! -d "${SOCKET_DIR}" ]]; then
    log "WARN" "Socket directory missing: ${SOCKET_DIR}"
    log "INFO" "Creating socket directory with sudo..."
    
    sudo mkdir -p "${SOCKET_DIR}"
    sudo chmod 775 "${SOCKET_DIR}"
    sudo chown root:staff "${SOCKET_DIR}"
    
    log "SUCCESS" "Created socket directory: ${SOCKET_DIR}"
  else
    # Check permissions
    local perms=$(stat -f "%Lp" "${SOCKET_DIR}")
    if [[ "${perms}" != "775" ]]; then
      log "WARN" "Socket directory has incorrect permissions: ${perms}"
      log "INFO" "Setting correct permissions (775)..."
      
      sudo chmod 775 "${SOCKET_DIR}"
      log "SUCCESS" "Updated socket directory permissions to 775"
    fi
    
    # Check ownership
    local owner=$(stat -f "%u:%g" "${SOCKET_DIR}")
    if [[ "${owner}" != "0:20" ]]; then
      log "WARN" "Socket directory has incorrect ownership: ${owner}"
      log "INFO" "Setting correct ownership (root:staff)..."
      
      sudo chown root:staff "${SOCKET_DIR}"
      log "SUCCESS" "Updated socket directory ownership to root:staff"
    fi
  fi
  
  log "SUCCESS" "Socket directory verified and repaired [L1]"
}

fix_permissions() {
  log "INFO" "Setting executable permissions on MCP servers [L3]..."
  
  chmod +x "${MCP_DIR}/git-local-optimized.js"
  chmod +x "${MCP_DIR}/anchor-manager-optimized.js"
  chmod +x "${MCP_DIR}/notion-v5-wrapper.js"
  chmod +x "${BASE_DIR}/scripts"/*.sh
  chmod +x "${BASE_DIR}/m3-optimizer"/*.cjs
  
  log "SUCCESS" "Set executable permissions on all scripts and servers"
}

restart_mcp_servers() {
  log "INFO" "Restarting MCP servers [L3]..."
  
  # Stop any existing servers
  pkill -f "git-local-optimized.js" || true
  pkill -f "anchor-manager-optimized.js" || true
  pkill -f "notion-v5-wrapper.js" || true
  
  # Wait for processes to terminate
  sleep 1
  
  # Create log directory if it doesn't exist
  mkdir -p "${LOG_DIR}"
  
  # Start git-local server
  log "INFO" "Starting git-local server..."
  ANCHOR_HOME="${BASE_DIR}" \
  NODE_OPTIONS="--max-old-space-size=8192 --expose-gc" \
  UV_THREADPOOL_SIZE=12 \
  LOG_LEVEL=INFO \
  nohup node "${MCP_DIR}/git-local-optimized.js" > "${LOG_DIR}/mcp-server-git-local.log" 2>&1 &
  
  # Start anchor-manager server
  log "INFO" "Starting anchor-manager server..."
  ANCHOR_HOME="${BASE_DIR}" \
  MCP_DIR="${MCP_DIR}" \
  NODE_OPTIONS="--max-old-space-size=8192 --expose-gc" \
  UV_THREADPOOL_SIZE=12 \
  LOG_LEVEL=INFO \
  DEBUG=true \
  nohup node "${MCP_DIR}/anchor-manager-optimized.js" > "${LOG_DIR}/mcp-server-anchor-manager.log" 2>&1 &
  
  # Start notion server
  log "INFO" "Starting notion server..."
  NOTION_API_TOKEN="replace-with-your-token" \
  NODE_OPTIONS="--max-old-space-size=8192 --expose-gc" \
  UV_THREADPOOL_SIZE=12 \
  LOG_LEVEL=INFO \
  nohup node "${MCP_DIR}/notion-v5-wrapper.js" > "${LOG_DIR}/mcp-server-notion.log" 2>&1 &
  
  # Wait for processes to start
  sleep 2
  
  # Verify servers are running
  local git_pid=$(pgrep -f "git-local-optimized.js" || echo "")
  local anchor_pid=$(pgrep -f "anchor-manager-optimized.js" || echo "")
  local notion_pid=$(pgrep -f "notion-v5-wrapper.js" || echo "")
  
  if [[ -n "${git_pid}" ]]; then
    log "SUCCESS" "git-local server running (PID: ${git_pid})"
  else
    log "ERROR" "git-local server failed to start"
  fi
  
  if [[ -n "${anchor_pid}" ]]; then
    log "SUCCESS" "anchor-manager server running (PID: ${anchor_pid})"
  else
    log "ERROR" "anchor-manager server failed to start"
  fi
  
  if [[ -n "${notion_pid}" ]]; then
    log "SUCCESS" "notion server running (PID: ${notion_pid})"
  else
    log "ERROR" "notion server failed to start"
  fi
  
  log "INFO" "All MCP servers restarted"
}

restart_claude() {
  log "INFO" "Checking Claude Desktop status..."
  
  if pgrep -x "Claude" > /dev/null; then
    log "INFO" "Restarting Claude Desktop..."
    killall Claude
    sleep 3
    open -a Claude
    log "SUCCESS" "Claude Desktop restarted"
  else
    log "INFO" "Starting Claude Desktop..."
    open -a Claude
    log "SUCCESS" "Claude Desktop started"
  fi
}

verify_connections() {
  log "INFO" "Waiting for MCP connections to initialize..."
  sleep 5
  
  log "INFO" "Checking socket files..."
  for server in filesystem git-local notion anchor-manager; do
    socket_file="${SOCKET_DIR}/${server}.sock"
    if [[ -S "${socket_file}" ]]; then
      log "SUCCESS" "Socket file exists: ${socket_file}"
    else
      log "WARN" "Socket file missing: ${socket_file}"
    fi
  done
  
  log "INFO" "Checking processes..."
  for process in "git-local-optimized.js" "anchor-manager-optimized.js" "notion-v5-wrapper.js"; do
    if pgrep -f "${process}" > /dev/null; then
      pid=$(pgrep -f "${process}")
      log "SUCCESS" "Process running: ${process} (PID: ${pid})"
    else
      log "WARN" "Process not running: ${process}"
    fi
  done
  
  log "INFO" "Verification complete"
  log "INFO" "Please check Claude > Settings > Developer to confirm connections"
}

# ---------- Main Execution Flow -----------------------------------------------
echo -e "${CYAN}╔════════════════════════════════════════════════════════════════╗"
echo -e "║             ANCHOR CORE V6 - REPAIR & RESTART                    ║"
echo -e "║               macOS Sequoia 15.4.1 / M3 Max                      ║"
echo -e "╚════════════════════════════════════════════════════════════════╝${NC}"

# Step 1: Fix Socket Directory [L1]
repair_socket_directory

# Step 2: Fix Script & Server Permissions [L3]
fix_permissions

# Step 3: Restart MCP Servers [L3]
restart_mcp_servers

# Step 4: Restart Claude Desktop [L0]
restart_claude

# Step 5: Verify Connections [L2]
verify_connections

# Step 6: Create Repair Marker [L7]
create_marker "completed" "Anchor Core repair & restart"

log "SUCCESS" "✅ REPAIR COMPLETE - Claude should now connect to all MCP servers"
log "INFO" "If issues persist, check logs at: ${LOG_DIR}/mcp-server-*.log"
