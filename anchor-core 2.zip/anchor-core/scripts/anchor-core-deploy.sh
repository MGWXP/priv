#!/bin/bash
# chmod +x /Users/XPV/Desktop/anchor-core/scripts/anchor-core-deploy.sh
set -euo pipefail

# ──────────────────────────────────────────────────────────────────────────
#  ANCHOR CORE V6 – FULL DEPLOYMENT / UPGRADE [L0]
# ──────────────────────────────────────────────────────────────────────────
BASE_DIR="/Users/XPV/Desktop/anchor-core"
MCP_DIR="${BASE_DIR}/mcp-servers"
CONFIG_FILE="${HOME}/Library/Application Support/Claude/claude_desktop_config.json"
LOG_DIR="${BASE_DIR}/logs"
BACKUP_DIR="${BASE_DIR}/backups"
COHERENCE_DIR="${BASE_DIR}/coherence_lock"
mkdir -p "$LOG_DIR" "$BACKUP_DIR" "$COHERENCE_DIR"

# ---------- helper --------------------------------------------------------
log(){ echo -e "[$(date '+%Y-%m-%d %H:%M:%S')] $1  $2"; }
backup(){ cp "$1" "$BACKUP_DIR/$(basename "$1").bak.$(date +%Y%m%d_%H%M%S)"; }

# ---------- validate json -------------------------------------------------
validate_json(){ python3 -m json.tool < "$1" >/dev/null; }

# ---------- step 1 – config backup + validate -----------------------------
log INFO "Backing up Claude config"
backup "$CONFIG_FILE"
validate_json "$CONFIG_FILE" && log INFO "Config JSON valid"

# ---------- step 2 – ensure servers executable ----------------------------
chmod 755 "$MCP_DIR/"*.js "$BASE_DIR"/m3-optimizer/m3_optimizer.cjs

# ---------- step 3 – create updated Claude config -------------------------
log INFO "Creating updated Claude config"
cat > "${CONFIG_FILE}.new" << EOF
{
  "mcpServers": {
    "filesystem": {
      "command": "npx",
      "args": [
        "-y",
        "@modelcontextprotocol/server-filesystem",
        "/Users/XPV/Desktop",
        "/Users/XPV/Library",
        "/Users/XPV/Documents",
        "/Users/XPV/Downloads"
      ]
    },
    "git-local": {
      "command": "node",
      "args": [
        "${MCP_DIR}/git-local-optimized.js"
      ],
      "env": {
        "ANCHOR_HOME": "${BASE_DIR}",
        "NODE_OPTIONS": "--max-old-space-size=8192 --expose-gc",
        "UV_THREADPOOL_SIZE": "12",
        "LOG_LEVEL": "INFO"
      }
    },
    "notion": {
      "command": "node",
      "args": [
        "${MCP_DIR}/notion-v5-wrapper.js"
      ],
      "env": {
        "NOTION_API_TOKEN": "replace-with-your-token",
        "NODE_OPTIONS": "--max-old-space-size=8192 --expose-gc",
        "UV_THREADPOOL_SIZE": "12",
        "LOG_LEVEL": "INFO"
      }
    },
    "anchor-manager": {
      "command": "node",
      "args": [
        "${MCP_DIR}/anchor-manager-optimized.js"
      ],
      "env": {
        "ANCHOR_HOME": "${BASE_DIR}",
        "MCP_DIR": "${MCP_DIR}",
        "NODE_OPTIONS": "--max-old-space-size=8192 --expose-gc",
        "UV_THREADPOOL_SIZE": "12",
        "LOG_LEVEL": "INFO",
        "DEBUG": "true"
      }
    }
  }
}
EOF

validate_json "${CONFIG_FILE}.new" && {
  log INFO "New config valid, deploying..."
  mv "${CONFIG_FILE}.new" "${CONFIG_FILE}"
  chmod 600 "${CONFIG_FILE}"
}

# ---------- step 4 – Launch MCP servers -----------------------------------
log INFO "Starting MCP servers (filesystem via npx handled by Claude)"
pkill -f git-local-optimized.js     || true
pkill -f anchor-manager-optimized.js|| true
pkill -f notion-v5-wrapper.js       || true
sleep 1

nohup node "$MCP_DIR/git-local-optimized.js"        > "$LOG_DIR/git-local.out"        2>&1 &
nohup node "$MCP_DIR/anchor-manager-optimized.js"   > "$LOG_DIR/anchor-manager.out"   2>&1 &
nohup node "$MCP_DIR/notion-v5-wrapper.js"          > "$LOG_DIR/notion.out"           2>&1 &
log INFO "Spawned MCP servers – PIDs: $(pgrep -f git-local-optimized.js) / $(pgrep -f anchor-manager-optimized.js)"

# ---------- step 5 – Claude restart ---------------------------------------
if pgrep -x Claude >/dev/null; then
  log INFO "Restarting Claude Desktop"
  killall Claude; sleep 3; open -a Claude
else
  log INFO "Starting Claude Desktop"
  open -a Claude
fi

# ---------- step 6 – marker ----------------------------------------------
MARKER="$COHERENCE_DIR/deploy_$(date +%Y%m%d_%H%M%S).marker"
cat >"$MARKER"<<EOF
{
  "timestamp":"$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "component":"deploy-script",
  "status":"completed",
  "servers_started":["git-local","anchor-manager","notion"]
}
EOF
chmod 600 "$MARKER"
log INFO "Deployment marker saved → $MARKER"

log INFO "✅ DEPLOY COMPLETE – verify in Claude > Settings > Developer"
