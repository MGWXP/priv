#!/bin/bash
# Final system validation script
# © 2025 XPV - MIT

echo "🧪 Running final system validation..."

# Define colors for better visibility
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Define paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
MCP_DIR="${ANCHOR_HOME}/mcp-servers"
LOG_DIR="${HOME}/Library/Logs/Claude"
SOCKET_DIR="${ANCHOR_HOME}/sockets"
CONFIG_DIR="${HOME}/Library/Application Support/Claude"
CONFIG_FILE="${CONFIG_DIR}/claude_desktop_config.json"

# Function to check if file exists
check_file() {
  if [ -f "$1" ]; then
    echo -e "${GREEN}✓${NC} $2"
  else
    echo -e "${RED}✗${NC} $2"
    VALIDATION_FAILED=1
  fi
}

# Function to check if directory exists
check_dir() {
  if [ -d "$1" ]; then
    echo -e "${GREEN}✓${NC} $2"
  else
    echo -e "${RED}✗${NC} $2"
    mkdir -p "$1"
    echo -e "${YELLOW}  Created directory: $1${NC}"
  fi
}

# Function to check if script is executable
check_executable() {
  if [ -x "$1" ]; then
    echo -e "${GREEN}✓${NC} $2"
  else
    echo -e "${RED}✗${NC} $2"
    chmod +x "$1"
    echo -e "${YELLOW}  Made executable: $1${NC}"
  fi
}

VALIDATION_FAILED=0

echo -e "\n${BLUE}Checking Directories:${NC}"
check_dir "$ANCHOR_HOME" "Anchor home directory"
check_dir "$MCP_DIR" "MCP servers directory"
check_dir "$LOG_DIR" "Log directory"
check_dir "$SOCKET_DIR" "Socket directory"
check_dir "$CONFIG_DIR" "Claude config directory"

echo -e "\n${BLUE}Checking Server Files:${NC}"
check_file "$MCP_DIR/git-local-optimized.js" "Git Local server"
check_file "$MCP_DIR/notion-v5-wrapper.js" "Notion server"
check_file "$MCP_DIR/anchor-manager-optimized.js" "Anchor Manager server"

echo -e "\n${BLUE}Checking Scripts:${NC}"
check_file "$ANCHOR_HOME/restart-all.sh" "Restart script"
check_file "$ANCHOR_HOME/launch-optimized.sh" "Launch script"
check_file "$ANCHOR_HOME/enhanced-quick-fix.sh" "Quick fix script"
check_file "$MCP_DIR/verify-servers.sh" "Verify script"

echo -e "\n${BLUE}Checking Documentation:${NC}"
check_file "$ANCHOR_HOME/IMPLEMENTATION_COMPLETE.md" "Implementation guide"
check_file "$ANCHOR_HOME/TROUBLESHOOTING.md" "Troubleshooting guide"
check_file "$ANCHOR_HOME/OPTIMIZATION_COMPLETE_20250518.marker" "Optimization marker"

echo -e "\n${BLUE}Checking Executables:${NC}"
check_executable "$ANCHOR_HOME/restart-all.sh" "Restart script"
check_executable "$ANCHOR_HOME/launch-optimized.sh" "Launch script"
check_executable "$ANCHOR_HOME/enhanced-quick-fix.sh" "Quick fix script"
check_executable "$MCP_DIR/verify-servers.sh" "Verify script"
check_executable "$MCP_DIR/git-local-optimized.js" "Git Local server"
check_executable "$MCP_DIR/notion-v5-wrapper.js" "Notion server"
check_executable "$MCP_DIR/anchor-manager-optimized.js" "Anchor Manager server"

echo -e "\n${BLUE}Checking Claude Configuration:${NC}"
if [ -f "$CONFIG_FILE" ]; then
  echo -e "${GREEN}✓${NC} Claude config file exists"
  if grep -q "socket" "$CONFIG_FILE"; then
    echo -e "${GREEN}✓${NC} Socket configuration present"
  else
    echo -e "${YELLOW}!${NC} Socket configuration missing"
    echo -e "  Run Claude and configure MCP servers in Settings > Advanced"
  fi
else
  echo -e "${YELLOW}!${NC} Claude config file missing"
  echo -e "  Creating default config..."
  mkdir -p "$CONFIG_DIR"
  
  cat > "$CONFIG_FILE" << 'EOL'
{
  "mcpServers": {
    "git-local": {
      "socketPath": "/Users/XPV/Desktop/anchor-core/sockets/git-local.sock"
    },
    "notion": {
      "socketPath": "/Users/XPV/Desktop/anchor-core/sockets/notion.sock"
    },
    "anchor-manager": {
      "socketPath": "/Users/XPV/Desktop/anchor-core/sockets/anchor-manager.sock"
    }
  }
}
EOL
  echo -e "${GREEN}  Created default config${NC}"
fi

echo -e "\n${BLUE}Summary:${NC}"
if [ $VALIDATION_FAILED -eq 0 ]; then
  echo -e "${GREEN}✅ System validation successful!${NC}"
  echo -e "You can now start the MCP servers with:"
  echo -e "  ${YELLOW}${ANCHOR_HOME}/launch-optimized.sh${NC}"
else
  echo -e "${RED}❌ System validation found issues!${NC}"
  echo -e "Please fix the issues and re-run this script."
  echo -e "You can try running the enhanced quick fix script:"
  echo -e "  ${YELLOW}${ANCHOR_HOME}/enhanced-quick-fix.sh${NC}"
fi

# Create a success marker if validation passed
if [ $VALIDATION_FAILED -eq 0 ]; then
  touch "$ANCHOR_HOME/FIXED_SUCCESS_20250518.marker"
  echo "✅ System validation complete - $(date)" > "$ANCHOR_HOME/FIXED_SUCCESS_20250518.marker"
fi

echo -e "\nValidation completed on $(date)"
