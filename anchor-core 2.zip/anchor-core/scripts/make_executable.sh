#!/bin/bash
# make_executable.sh - Makes all of our scripts executable
# © 2025 XPV - MIT

set -e  # Exit on error

echo "🔒 Making scripts executable..."

# Define core paths
ANCHOR_HOME="/Users/XPV/Desktop/anchor-core"
MCP_DIR="${ANCHOR_HOME}/mcp-servers"

# Make main scripts executable
chmod +x "${ANCHOR_HOME}/restart-all.sh"
chmod +x "${ANCHOR_HOME}/m3-optimizer/m3_optimizer.js" 
chmod +x "${ANCHOR_HOME}/m3-optimizer/m3_optimizer.cjs"
chmod +x "${ANCHOR_HOME}/scripts/anchor-system-optimizer.sh"
chmod +x "${ANCHOR_HOME}/scripts/anchor-dashboard.js"

# Make MCP server scripts executable
chmod +x "${MCP_DIR}/git-local-optimized.js"
chmod +x "${MCP_DIR}/notion-v5-wrapper.js"
chmod +x "${MCP_DIR}/anchor-manager-optimized.js"

echo "✅ All scripts are now executable"
