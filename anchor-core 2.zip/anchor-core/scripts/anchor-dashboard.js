#!/usr/bin/env node
/**
 * Anchor System Monitoring Dashboard
 * Simple monitoring for the Anchor MCP Server ecosystem
 * © 2025 XPV - MIT
 */

const fs = require('fs');
const os = require('os');
const path = require('path');
const { execSync } = require('child_process');

// ANSI color codes for formatting
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  dim: '\x1b[2m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  white: '\x1b[37m',
  bgGreen: '\x1b[42m',
  bgRed: '\x1b[41m',
  bgYellow: '\x1b[43m',
};

// Define paths
const ANCHOR_HOME = process.env.ANCHOR_HOME || '/Users/XPV/Desktop/anchor-core';
const MCP_DIR = process.env.MCP_DIR || path.join(ANCHOR_HOME, 'mcp-servers');
const LOG_DIR = path.join(os.homedir(), 'Library/Logs/Claude');
const CONFIG_DIR = path.join(os.homedir(), 'Library/Application Support/Claude');
const CONFIG_FILE = path.join(CONFIG_DIR, 'claude_desktop_config.json');

// Clear the terminal
console.clear();

// Print header
console.log(`${colors.bright}${colors.cyan}┌────────────────────────────────────────────────────────────┐${colors.reset}`);
console.log(`${colors.bright}${colors.cyan}│               ANCHOR SYSTEM MONITORING DASHBOARD           │${colors.reset}`);
console.log(`${colors.bright}${colors.cyan}└────────────────────────────────────────────────────────────┘${colors.reset}`);
console.log(`${colors.dim}Runtime: ${new Date().toISOString()} | Node ${process.version}${colors.reset}`);

// System information
const systemInfo = {
  hostname: os.hostname(),
  uptime: os.uptime(),
  platform: `${os.type()} ${os.release()}`,
  arch: os.arch(),
  mem: {
    total: os.totalmem(),
    free: os.freemem(),
  },
  cpus: os.cpus(),
};

const uptimeHours = Math.floor(systemInfo.uptime / 3600);
const uptimeMinutes = Math.floor((systemInfo.uptime % 3600) / 60);

console.log(`\n${colors.bright}${colors.blue}SYSTEM INFORMATION${colors.reset}`);
console.log(`${colors.dim}Hostname:${colors.reset} ${systemInfo.hostname}`);
console.log(`${colors.dim}Platform:${colors.reset} ${systemInfo.platform} ${systemInfo.arch}`);
console.log(`${colors.dim}CPUs:${colors.reset} ${systemInfo.cpus.length} cores (${systemInfo.cpus[0].model})`);
console.log(`${colors.dim}Memory:${colors.reset} ${Math.round(systemInfo.mem.total / 1024 / 1024 / 1024)}GB Total, ${Math.round(systemInfo.mem.free / 1024 / 1024 / 1024)}GB Free`);
console.log(`${colors.dim}Uptime:${colors.reset} ${uptimeHours}h ${uptimeMinutes}m`);

// Check configuration
let config = { mcpServers: {} };
try {
  const configData = fs.readFileSync(CONFIG_FILE, 'utf8');
  config = JSON.parse(configData);
  
  console.log(`\n${colors.bright}${colors.blue}CONFIGURATION${colors.reset}`);
  console.log(`${colors.dim}Config File:${colors.reset} ${CONFIG_FILE}`);
  console.log(`${colors.dim}Registered Servers:${colors.reset} ${Object.keys(config.mcpServers).join(', ')}`);
} catch (error) {
  console.log(`\n${colors.bright}${colors.red}CONFIGURATION ERROR${colors.reset}`);
  console.log(`${colors.red}Failed to read config: ${error.message}${colors.reset}`);
}

// Check server processes
console.log(`\n${colors.bright}${colors.blue}MCP SERVER STATUS${colors.reset}`);

const servers = [
  { 
    name: 'filesystem',
    processPattern: '@modelcontextprotocol/server-filesystem',
    logFile: path.join(LOG_DIR, 'mcp-server-filesystem.log'),
    pidFile: null
  },
  { 
    name: 'git-local',
    processPattern: 'git-local-optimized.js',
    logFile: path.join(LOG_DIR, 'mcp-server-git-local.log'),
    pidFile: path.join(MCP_DIR, 'git-local.pid')
  },
  { 
    name: 'notion',
    processPattern: 'notion-v5-wrapper.js',
    logFile: path.join(LOG_DIR, 'mcp-server-notion.log'),
    pidFile: path.join(MCP_DIR, 'notion.pid')
  },
  { 
    name: 'anchor-manager',
    processPattern: 'anchor-manager-optimized.js',
    logFile: path.join(LOG_DIR, 'mcp-server-anchor-manager.log'),
    pidFile: path.join(MCP_DIR, 'anchor-manager.pid')
  },
];

// Check each server
for (const server of servers) {
  // Check if process is running
  let isRunning = false;
  let pid = 'N/A';
  let uptime = 'N/A';
  
  try {
    const output = execSync(`ps -ef | grep "${server.processPattern}" | grep -v grep`).toString();
    if (output) {
      isRunning = true;
      pid = output.split(/\s+/)[1];
      
      // Get process uptime
      const processStartTime = parseInt(execSync(`ps -p ${pid} -o lstart= | date -j -f "%a %b %d %T %Y" "$(cat -)" +%s`).toString());
      const now = Math.floor(Date.now() / 1000);
      const processUptimeSecs = now - processStartTime;
      const processUptimeMins = Math.floor(processUptimeSecs / 60);
      const processUptimeHours = Math.floor(processUptimeMins / 60);
      uptime = `${processUptimeHours}h ${processUptimeMins % 60}m`;
    }
  } catch (error) {
    // Process not running
  }
  
  // Check PID file
  let pidFileStatus = 'N/A';
  if (server.pidFile) {
    try {
      const filePid = fs.readFileSync(server.pidFile, 'utf8').trim();
      pidFileStatus = filePid === pid ? 'Valid' : 'Invalid';
    } catch (error) {
      pidFileStatus = 'Missing';
    }
  }
  
  // Check log file
  let logStatus = 'N/A';
  let lastLogTime = 'N/A';
  if (server.logFile) {
    try {
      const stats = fs.statSync(server.logFile);
      const logSizeKB = Math.round(stats.size / 1024);
      const logModTime = stats.mtime;
      const logAgeMinutes = Math.round((Date.now() - logModTime.getTime()) / (60 * 1000));
      
      logStatus = `${logSizeKB}KB`;
      lastLogTime = logAgeMinutes < 60 
        ? `${logAgeMinutes}m ago` 
        : `${Math.floor(logAgeMinutes / 60)}h ${logAgeMinutes % 60}m ago`;
    } catch (error) {
      logStatus = 'Missing';
    }
  }
  
  // Determine status color
  const statusColor = isRunning ? colors.green : colors.red;
  const statusText = isRunning ? 'RUNNING' : 'STOPPED';
  
  // Print server status
  console.log(`${colors.bright}${colors.white}${server.name}${colors.reset}`);
  console.log(`  Status: ${statusColor}${statusText}${colors.reset}`);
  console.log(`  PID: ${pid}`);
  console.log(`  Uptime: ${uptime}`);
  console.log(`  PID File: ${pidFileStatus}`);
  console.log(`  Log: ${logStatus}, Last Updated: ${lastLogTime}`);
  
  // If running, show most recent log entries
  if (isRunning && server.logFile && fs.existsSync(server.logFile)) {
    try {
      // Get last 3 log lines
      const logTail = execSync(`tail -n 3 "${server.logFile}"`).toString().trim().split('\n');
      if (logTail.length > 0 && logTail[0]) {
        console.log(`  ${colors.dim}Recent Logs:${colors.reset}`);
        for (const line of logTail) {
          // Limit line length
          const trimmedLine = line.length > 80 ? line.substring(0, 77) + '...' : line;
          console.log(`    ${colors.dim}${trimmedLine}${colors.reset}`);
        }
      }
    } catch (error) {
      // Ignore log reading errors
    }
  }
  
  console.log(''); // Add empty line between servers
}

// Memory usage section
console.log(`\n${colors.bright}${colors.blue}MEMORY USAGE${colors.reset}`);

try {
  const processMemoryInfo = execSync(`ps -eo pid,comm,rss | grep -E 'node|Claude' | grep -v grep`).toString().trim().split('\n');
  
  // Headers
  console.log(`${colors.dim}PID       Process                           Memory${colors.reset}`);
  
  for (const line of processMemoryInfo) {
    // Parse process info
    const parts = line.trim().split(/\s+/);
    if (parts.length < 3) continue;
    
    const pid = parts[0];
    const command = parts.slice(1, parts.length - 1).join(' ');
    const memoryKB = parseInt(parts[parts.length - 1]);
    const memoryMB = Math.round(memoryKB / 1024 * 10) / 10;
    
    // Format output
    let displayCommand = command;
    if (displayCommand.length > 30) {
      displayCommand = displayCommand.substring(0, 27) + '...';
    } else {
      displayCommand = displayCommand.padEnd(30);
    }
    
    // Determine color based on memory usage
    let memColor = colors.green;
    if (memoryMB > 500) memColor = colors.yellow;
    if (memoryMB > 1000) memColor = colors.red;
    
    console.log(`${pid.padEnd(10)}${displayCommand}${memColor}${memoryMB.toFixed(1)} MB${colors.reset}`);
  }
} catch (error) {
  console.log(`${colors.red}Failed to retrieve memory usage: ${error.message}${colors.reset}`);
}

// CPU usage trends
console.log(`\n${colors.bright}${colors.blue}SYSTEM LOAD${colors.reset}`);
try {
  const loadAvg = os.loadavg();
  const cpuCount = os.cpus().length;
  
  // Calculate load percentages
  const loadPercentages = loadAvg.map(load => Math.round((load / cpuCount) * 100));
  
  // Determine colors for load values
  const loadColors = loadPercentages.map(percent => {
    if (percent < 50) return colors.green;
    if (percent < 80) return colors.yellow;
    return colors.red;
  });
  
  console.log(`${colors.dim}1 minute:${colors.reset} ${loadColors[0]}${loadPercentages[0]}%${colors.reset} (${loadAvg[0].toFixed(2)})`);
  console.log(`${colors.dim}5 minutes:${colors.reset} ${loadColors[1]}${loadPercentages[1]}%${colors.reset} (${loadAvg[1].toFixed(2)})`);
  console.log(`${colors.dim}15 minutes:${colors.reset} ${loadColors[2]}${loadPercentages[2]}%${colors.reset} (${loadAvg[2].toFixed(2)})`);
} catch (error) {
  console.log(`${colors.red}Failed to retrieve system load: ${error.message}${colors.reset}`);
}

// Troubleshooting tips
console.log(`\n${colors.bright}${colors.blue}QUICK ACTIONS${colors.reset}`);
console.log(`${colors.dim}Restart All Servers:${colors.reset} ${path.join(ANCHOR_HOME, 'restart-all.sh')}`);
console.log(`${colors.dim}View Logs:${colors.reset} tail -f ${path.join(LOG_DIR, 'mcp-server-*.log')}`);
console.log(`${colors.dim}Refresh Dashboard:${colors.reset} Clear terminal and run this script again`);

console.log(`\n${colors.dim}Dashboard updated at: ${new Date().toISOString()}${colors.reset}`);
