#!/bin/bash
# Set execute permissions on all important scripts
chmod +x "/Users/XPV/Desktop/anchor-core/restart-all.sh"
chmod +x "/Users/XPV/Desktop/anchor-core/m3-optimizer/m3_optimizer.js"
chmod +x "/Users/XPV/Desktop/anchor-core/m3-optimizer/m3_optimizer.cjs"
chmod +x "/Users/XPV/Desktop/anchor-core/scripts/anchor-system-optimizer.sh"
chmod +x "/Users/XPV/Desktop/anchor-core/scripts/anchor-dashboard.js"
chmod +x "/Users/XPV/Desktop/anchor-core/scripts/make_executable.sh"
chmod +x "/Users/XPV/Desktop/anchor-core/scripts/apply_permissions.sh"
chmod +x "/Users/XPV/Desktop/anchor-core/mcp-servers/git-local-optimized.js"
chmod +x "/Users/XPV/Desktop/anchor-core/mcp-servers/notion-v5-wrapper.js"
chmod +x "/Users/XPV/Desktop/anchor-core/mcp-servers/anchor-manager-optimized.js"
chmod +x "/Users/XPV/Desktop/anchor-core/mcp-servers/verify-servers.sh"
echo "✅ All scripts are now executable"
