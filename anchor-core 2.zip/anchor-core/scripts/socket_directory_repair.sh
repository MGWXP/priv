#!/bin/bash
# ──────────────────────────────────────────────────────────────────────────
#  ANCHOR CORE V6 – SOCKET DIRECTORY REPAIR UTILITY [L1]
# ──────────────────────────────────────────────────────────────────────────
SOCKET_DIR="/var/run/claude"

echo "🔄 Checking socket directory permissions [L1]..."
if [ -d "$SOCKET_DIR" ]; then
    perms=$(stat -f "%Lp" "$SOCKET_DIR")
    if [ "$perms" != "775" ]; then
        echo "⚠️ Socket directory has incorrect permissions: $perms"
        echo "🔄 Fixing socket directory permissions..."
        sudo chmod 775 "$SOCKET_DIR"
    fi
    
    owner=$(stat -f "%u:%g" "$SOCKET_DIR")
    if [ "$owner" != "0:20" ]; then
        echo "⚠️ Socket directory has incorrect ownership: $owner"
        echo "🔄 Fixing socket directory ownership..."
        sudo chown root:staff "$SOCKET_DIR"
    fi
    
    echo "✅ Socket directory verified: $SOCKET_DIR (permissions: 775, owner: root:staff)"
else
    echo "❌ Socket directory missing: $SOCKET_DIR"
    echo "🔄 Creating socket directory..."
    sudo mkdir -p "$SOCKET_DIR"
    sudo chmod 775 "$SOCKET_DIR"
    sudo chown root:staff "$SOCKET_DIR"
    echo "✅ Socket directory created and configured: $SOCKET_DIR"
fi

echo "✅ Socket directory healthy → $SOCKET_DIR"
