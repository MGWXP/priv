## ANCHOR DASHBOARD QUICK REFERENCE

### Main Dashboard
- URL: `https://notion.so/1f8e48c2-bbbd-8109-b66e-fa7710500815`
- Contains links to:
  - Component Library
  - Agent Registry
  - Project Tracker
  - System Metrics (when created)

### Project Dashboard
- URL: `https://notion.so/1f8e48c2-bbbd-8171-9d69-c39ca91b56cd`
- Contains links to:
  - Project Tracker
  - Component Library

### Database IDs
- Agent Registry: `1f8e48c2-bbbd-8149-aa90-ced3c874efb6`
- Component Library: `1f8e48c2-bbbd-81a3-a6bc-d041fa47215c`
- Project Tracker: `1f8e48c2-bbbd-813f-ae44-db59ea8a6e32`

### Fix Script
Run the following to fix dashboard hyperlinks:
```bash
cd /Users/XPV/Desktop/anchor-core
chmod +x dashboard-links-update.sh
./dashboard-links-update.sh
```

### Important Notes
- Always use `notion.so` format (without www) in URLs
- For API requests, use proper link formatting with `type` field
- Prefer callout blocks for better visibility and usability
