#!/bin/bash
# one-click-notion-setup.sh - Complete Notion integration setup

# Color codes
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}=== Notion + Claude Integration Setup ===${NC}"

# 1. Make scripts executable
chmod +x /Users/XPV/Desktop/anchor-core/fix-notion-config.sh
echo -e "${GREEN}✅ Made fix-notion-config.sh executable${NC}"

# 2. Check for Node.js and npm
if ! command -v node &> /dev/null; then
    echo -e "${YELLOW}Node.js not found. Installing...${NC}"
    if command -v brew &> /dev/null; then
        brew install node
    else
        echo -e "${RED}❌ Homebrew not found. Please install Node.js manually.${NC}"
        exit 1
    fi
fi
echo -e "${GREEN}✅ Node.js is installed${NC}"

# 3. Install Notion MCP server
echo -e "${BLUE}Installing @notionhq/notion-mcp-server...${NC}"
npm install -g @notionhq/notion-mcp-server
echo -e "${GREEN}✅ Notion MCP server installed${NC}"

# 4. Prompt for Notion API token
echo -e "${BLUE}You'll need a Notion API token.${NC}"
echo -e "${YELLOW}Have you already created a Notion integration and have the token? (y/n)${NC}"
read -r HAS_TOKEN

if [[ "$HAS_TOKEN" =~ ^[Nn]$ ]]; then
    echo -e "${BLUE}Please follow these steps:${NC}"
    echo "1. Go to https://www.notion.so/my-integrations"
    echo "2. Click 'Create new integration'"
    echo "3. Name it 'Claude Assistant'"
    echo "4. Select your workspace"
    echo "5. Enable Read/Update/Insert capabilities"
    echo "6. Click 'Submit'"
    echo "7. Copy the 'Internal Integration Token'"
    echo -e "${YELLOW}Press Enter when you have your token...${NC}"
    read -r
fi

echo -e "${BLUE}Please enter your Notion integration token:${NC}"
read -r NOTION_TOKEN

if [ -z "$NOTION_TOKEN" ]; then
    echo -e "${RED}❌ No token provided. You'll need to set it manually later.${NC}"
else
    echo -e "${GREEN}✅ Token received${NC}"
fi

# 5. Run the configuration script
echo -e "${BLUE}Running configuration script...${NC}"
/Users/XPV/Desktop/anchor-core/fix-notion-config.sh

# 6. Remind about page sharing
echo -e "\n${YELLOW}Important: Don't forget to share your Notion pages with the integration!${NC}"
echo "For each page you want Claude to access:"
echo "1. Open the page in Notion"
echo "2. Click '...' in the top right"
echo "3. Select 'Add connections'"
echo "4. Choose your integration"
echo "5. Click 'Confirm'"

echo -e "\n${GREEN}=== Setup Complete ===${NC}"
echo -e "${BLUE}Please restart Claude Desktop to use your Notion integration.${NC}"
